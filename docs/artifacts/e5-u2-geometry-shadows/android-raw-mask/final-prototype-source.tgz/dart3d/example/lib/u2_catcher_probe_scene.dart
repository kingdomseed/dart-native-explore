// ignore_for_file: implementation_imports
library;

import 'package:dart3d/src/geometry/proc.dart';
import 'package:dart3d/src/scene_model.dart';
import 'package:vector_math/vector_math.dart';

import 'light_aim.dart';

enum U2CatcherCaptureMode { nearFar, colorWrite, lightData, rawMask }

enum U2CatcherLightCase { directional, spot }

enum U2CatcherProbeVariant {
  historic,
  splitCull,
  nativeDefaults,
  nativeDefaultsPcf,
  rawMaskNativeDefaultsPcf,
}

final class U2CatcherProbeCase {
  const U2CatcherProbeCase(
    this.captureMode,
    this.lightCase, {
    this.variant = U2CatcherProbeVariant.historic,
  });

  final U2CatcherCaptureMode captureMode;
  final U2CatcherLightCase lightCase;
  final U2CatcherProbeVariant variant;

  String get receiverName =>
      'u2.catcher.probe:${switch (captureMode) {
        U2CatcherCaptureMode.nearFar => 'nearfar',
        U2CatcherCaptureMode.colorWrite => 'colorwrite',
        U2CatcherCaptureMode.lightData => 'lightdata',
        U2CatcherCaptureMode.rawMask => 'rawmask',
      }}:${lightCase.name}${switch (variant) {
        U2CatcherProbeVariant.historic => '',
        U2CatcherProbeVariant.splitCull => ':cull',
        U2CatcherProbeVariant.nativeDefaults => ':cull-native',
        U2CatcherProbeVariant.nativeDefaultsPcf => ':cull-native-pcf',
        U2CatcherProbeVariant.rawMaskNativeDefaultsPcf => ':raw-native-pcf',
      }}';

  String get lightName => switch (variant) {
    U2CatcherProbeVariant.nativeDefaults ||
    U2CatcherProbeVariant.nativeDefaultsPcf =>
      'u2.catcher.probe.light.native-defaults',
    U2CatcherProbeVariant.rawMaskNativeDefaultsPcf =>
      'u2.catcher.probe.light.native-defaults',
    U2CatcherProbeVariant.historic ||
    U2CatcherProbeVariant.splitCull => 'u2.catcher.probe.light',
  };
}

U2CatcherProbeCase? u2CatcherProbeCaseForLabel(String label) => switch (label) {
  'u2-catcher-nearfar-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.nearFar,
    U2CatcherLightCase.directional,
  ),
  'u2-catcher-nearfar-spot' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.nearFar,
    U2CatcherLightCase.spot,
  ),
  'u2-catcher-colorwrite-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.colorWrite,
    U2CatcherLightCase.directional,
  ),
  'u2-catcher-colorwrite-spot' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.colorWrite,
    U2CatcherLightCase.spot,
  ),
  'u2-catcher-lightdata-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.directional,
  ),
  'u2-catcher-lightdata-spot' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.spot,
  ),
  'u2-catcher-cull-spot' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.spot,
    variant: U2CatcherProbeVariant.splitCull,
  ),
  'u2-catcher-cull-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.directional,
    variant: U2CatcherProbeVariant.splitCull,
  ),
  'u2-catcher-cull-native-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.directional,
    variant: U2CatcherProbeVariant.nativeDefaults,
  ),
  'u2-catcher-cull-native-pcf-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.lightData,
    U2CatcherLightCase.directional,
    variant: U2CatcherProbeVariant.nativeDefaultsPcf,
  ),
  'u2-catcher-raw-directional' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.rawMask,
    U2CatcherLightCase.directional,
    variant: U2CatcherProbeVariant.rawMaskNativeDefaultsPcf,
  ),
  'u2-catcher-raw-spot' => const U2CatcherProbeCase(
    U2CatcherCaptureMode.rawMask,
    U2CatcherLightCase.spot,
    variant: U2CatcherProbeVariant.rawMaskNativeDefaultsPcf,
  ),
  _ => null,
};

SceneDocument buildU2CatcherProbeDocument(U2CatcherProbeCase probe) {
  final doc = SceneDocument();
  final receiverMaterial = doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': const ColorValue(0.48, 0.48, 0.48, 1),
        'roughness': const DoubleValue(0.92),
        'metallic': const DoubleValue(0),
      },
    ),
  );
  doc.createNode(
    name: probe.receiverName,
    transform: TrsTransform(translation: Vector3.zero()),
    components: [
      d3ProcMeshComponent(
        D3PlaneProc(width: 4.2, depth: 4.2, segmentsX: 2, segmentsZ: 2),
        material: receiverMaterial.id,
      ),
    ],
    root: true,
  );

  final casterMaterial = doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': const ColorValue(0.82, 0.34, 0.12, 1),
        'roughness': const DoubleValue(0.56),
        'metallic': const DoubleValue(0),
      },
    ),
  );
  doc.createNode(
    name: 'u2.catcher.probe.caster',
    transform: TrsTransform(translation: Vector3(0.24, 0.78, 0.08)),
    components: [
      d3ProcMeshComponent(
        D3CuboidProc(extents: Vector3(1.05, 1.25, 0.92)),
        material: casterMaterial.id,
      ),
    ],
    root: true,
  );

  if (probe.lightCase == U2CatcherLightCase.directional) {
    doc.createNode(
      name: probe.lightName,
      transform: TrsTransform(rotation: aimAlong(Vector3(-0.55, -1.0, 0.3))),
      components: [
        ComponentSpec(
          'directionalLight',
          properties: {
            'color': const ColorValue(1, 1, 1, 1),
            'intensity': const DoubleValue(0.85),
            'castsShadow': const BoolValue(true),
          },
        ),
      ],
      root: true,
    );
  } else {
    final lightPosition = Vector3(-2.4, 4.6, 2.2);
    doc.createNode(
      name: probe.lightName,
      transform: TrsTransform(
        translation: lightPosition,
        rotation: aimAlong(-lightPosition),
      ),
      components: [
        ComponentSpec(
          'spotLight',
          properties: {
            'color': const ColorValue(1, 1, 1, 1),
            'intensity': const DoubleValue(100),
            'range': const DoubleValue(12),
            'direction': Vec3Value(Vector3(0, 0, 1)),
            'innerConeAngle': const DoubleValue(0.25),
            'outerConeAngle': const DoubleValue(0.92),
            'castsShadow': const BoolValue(true),
          },
        ),
      ],
      root: true,
    );
  }

  final environment = doc.addResource(
    EnvironmentResource(
      doc.newId(),
      name: 'u2.catcher.probe.environment',
      environment: const StudioEnvironment(),
      environmentIntensity: 0.22,
      exposure: 1,
      toneMapping: 'pbrNeutral',
      skybox: SkyboxSpec(EnvironmentSkySpec()),
    ),
  );
  doc.stage.environmentRef = environment.id;

  return doc;
}
