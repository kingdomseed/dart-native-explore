/// The showcase loader — pure Dart (no `dartnative` imports) so the
/// upstream-corpus decode + compose path is reachable under `dart
/// test`. The screen lives in `showcase_scene.dart`, which passes
/// `loadAssetBytes` and `dnLog` in through the parameters.
// ignore_for_file: implementation_imports
library;

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:dart3d/src/doc_layer.dart';
import 'package:dart3d/src/fsceneb_reader.dart';
import 'package:dart3d/src/geometry/instances.dart';
import 'package:dart3d/src/geometry/proc.dart';
import 'package:dart3d/src/glb_import.dart';
import 'package:dart3d/src/physics.dart';
import 'package:dart3d/src/scene_model.dart';
import 'package:dart3d/src/vertex_pack.dart';
import 'package:dart3d/src/world_bounds.dart';
import 'package:vector_math/vector_math.dart';

import 'dn_logo_stage.dart';
import 'light_aim.dart';
import 'u2_catcher_probe_scene.dart';
import 'u2_geometry_scene.dart';

/// One showcase entry: the cycler label, its bundle key, and the
/// capability line shown under it.
final class ShowcaseItem {
  const ShowcaseItem(
    this.label,
    this.assetKey,
    this.note, {
    this.cameraDir,
    this.stage,
    this.frameMargin = 1.0,
  });

  final String label;
  final String assetKey;
  final String note;

  /// Direction from the framed center toward the camera (normalized on
  /// use). Null keeps the loader's 3/4 model-viewer angle.
  final (double, double, double)? cameraDir;

  /// The DartNative logo's dramatic stage (dark backdrop, key + pink/
  /// cyan rims, bloom, self-glow — see `dn_logo_stage.dart`). Null
  /// keeps the neutral studio: grey sky, warm key + cool fill.
  final DnLogoStage? stage;

  /// Scales the framed radius — >1 pulls the camera back for breathing
  /// room (e.g. around an animated subject).
  final double frameMargin;
}

/// The upstream corpus bundled under `assets/showcase/` plus the dice
/// set (which keep their physics-ground load path — they roll). The
/// DartNative logo leads: it's the demo centerpiece (P4; built by
/// `tool/dn_logo/build.sh` from the logo SVG).
const showcaseItems = [
  ShowcaseItem(
    'dartnative_logo',
    'assets/showcase/dn_logo.fsceneb',
    'swept brush stroke · baked gradient + AO · 1 animation',
    // The importer's handedness puts the glyph's reading side at −Z:
    // face-on from there, a touch above and to the right.
    cameraDir: (-0.24, 0.2, -1.0),
    stage: DnLogoStage.showcase,
    // Whole glyph plus margin through the spin and bob.
    frameMargin: 1.1,
  ),
  ShowcaseItem(
    'dash',
    'assets/showcase/dash.fsceneb',
    'skinned · 35 joints · 9 animations · 2 textures',
  ),
  ShowcaseItem(
    'fcar',
    'assets/showcase/fcar.fsceneb',
    '17 meshes · 39 geometries · 11 materials',
  ),
  ShowcaseItem(
    'triangles',
    'assets/showcase/two_triangles.fsceneb',
    'minimal skinning · 2 animations',
  ),
  ShowcaseItem(
    'prefabs',
    'assets/showcase/prefab_demo.fscene',
    'upstream prefab instances (composeScene)',
  ),
  ShowcaseItem('cube', 'assets/showcase/cube.fscene', 'upstream .fscene'),
  ShowcaseItem(
    'playground',
    'assets/showcase/playground.fscene',
    'upstream .fscene',
  ),
  ShowcaseItem(
    'materials',
    kBuiltinMaterialsKey,
    'W21 lanes: alpha blend/mask · second UV set',
  ),
  ShowcaseItem(
    'glb',
    'assets/showcase/cube.glb',
    'W29 runtime glTF import · embedded PNG + light',
  ),
  ShowcaseItem(
    'roundtrip',
    kBuiltinDocRoundtripKey,
    'W29: build → .fscene → re-realize',
  ),
  ShowcaseItem(
    'w26',
    kBuiltinGeometryKey,
    'W26: 13 shapes · paths/lines · 1000 instances one draw',
  ),
  ShowcaseItem(
    'u1',
    kBuiltinU1Key,
    'U1: orbit/fly/follow cameras · 5-target BVH picking',
    cameraDir: (0.0, 0.28, -1.0),
    frameMargin: 1.15,
  ),
  ShowcaseItem(
    'w17',
    kBuiltinW17SkyKey,
    'W17: Rayleigh/Mie physical sky · skyEnvironment IBL · sunLight',
    cameraDir: (0.0, 0.10, -1.0),
    frameMargin: 1.15,
  ),
  ShowcaseItem(
    'w19',
    kBuiltinW19CharacterKey,
    'W19: characterController · autostep · slope slide · dynamic push',
    cameraDir: (0.0, 0.25, -1.0),
    frameMargin: 1.15,
  ),
  ShowcaseItem(
    'u2',
    kBuiltinU2Key,
    'U2: wedge · annulus ring · bent extrude CCW/CW · 2 inline wedges',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 1.15,
  ),
  ShowcaseItem(
    'u2-shadow',
    kBuiltinU2ShadowKey,
    'U2: spot shadow · elevated cuboid · neutral receiver',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 1.05,
  ),
  ShowcaseItem(
    'u2-catcher-nearfar-directional',
    kBuiltinU2CatcherProbeKey,
    'NEAR/FAR MASK: directional light',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-nearfar-spot',
    kBuiltinU2CatcherProbeKey,
    'NEAR/FAR MASK: spot light',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-colorwrite-directional',
    kBuiltinU2CatcherProbeKey,
    'COLOR WRITE OFF: directional light',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-colorwrite-spot',
    kBuiltinU2CatcherProbeKey,
    'COLOR WRITE OFF: spot light',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-lightdata-directional',
    kBuiltinU2CatcherProbeKey,
    'LIGHT DATA / HIDDEN CASTER: red lit · green shadow · blue back-facing',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-lightdata-spot',
    kBuiltinU2CatcherProbeKey,
    'LIGHT DATA / HIDDEN CASTER: red lit · green shadow · blue back-facing',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-cull-spot',
    kBuiltinU2CatcherProbeKey,
    'SPLIT CULLING / SPOT / DPCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-cull-directional',
    kBuiltinU2CatcherProbeKey,
    'SPLIT CULLING / DIRECTIONAL / DPCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-cull-native-directional',
    kBuiltinU2CatcherProbeKey,
    'SPLIT CULLING / NATIVE SHADOW DEFAULTS / DPCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-cull-native-pcf-directional',
    kBuiltinU2CatcherProbeKey,
    'SPLIT CULLING / NATIVE SHADOW DEFAULTS / PCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-raw-directional',
    kBuiltinU2CatcherProbeKey,
    'RAW MASK / ALPHA DISPLAY / DIRECTIONAL / NATIVE DEFAULTS / PCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
  ShowcaseItem(
    'u2-catcher-raw-spot',
    kBuiltinU2CatcherProbeKey,
    'RAW MASK / ALPHA DISPLAY / SPOT / NATIVE DEFAULTS / PCF',
    cameraDir: (-0.4, 0.9, -1.0),
    frameMargin: 2.0,
  ),
];

/// The synthetic asset key for the W21 materials conformance scene —
/// no bundled file; [loadShowcaseScene] builds the document
/// procedurally (see [buildMaterialsDocument]).
const String kBuiltinMaterialsKey = 'builtin:materials';

/// The synthetic asset key for the W29 round-trip lane: the loader
/// builds the same materials conformance document; the showcase
/// screen then runs the live round trip — `serializeScene` →
/// `writeFscene` → `loadFscene`, with `sendPayload` re-delivering the
/// byte-carrying chunks the JSON leg cannot carry — and the
/// re-realized document must render identically.
const String kBuiltinDocRoundtripKey = 'builtin:docroundtrip';

/// The synthetic asset key for the W26 geometry showcase — no bundled
/// file; [loadShowcaseScene] builds the document procedurally (see
/// [buildGeometryDocument]).
const String kBuiltinGeometryKey = 'builtin:geometry';

/// The synthetic asset key for the U1 cameras + picking verification
/// scene — builds [buildU1CamerasPickingDocument].
const String kBuiltinU1Key = 'builtin:u1';

/// The synthetic asset key for the W17 physical sky + `skyEnvironment`
/// verification scene — builds [buildW17SkyDocument].
const String kBuiltinW17SkyKey = 'builtin:w17';

/// The synthetic asset key for the W19 character controller verification
/// scene — builds [buildW19CharacterDocument].
const String kBuiltinW19CharacterKey = 'builtin:w19';

/// The synthetic asset key for the U2 live-geometry scene.
const String kBuiltinU2Key = 'builtin:u2';

/// The synthetic asset key for the U2 spot-shadow fixture.
const String kBuiltinU2ShadowKey = 'builtin:u2-shadow';

/// The temporary U2 baked-catcher capture probe.
const String kBuiltinU2CatcherProbeKey = 'builtin:u2-catcher-probe';

const String _kBootW17Mode = String.fromEnvironment(
  'DART3D_W17_MODE',
  defaultValue: 'day',
);

const bool _kBootU2CastShadows = bool.fromEnvironment(
  'DART3D_U2_CAST_SHADOWS',
  defaultValue: true,
);

/// Dice stay in the gallery too — the [DART3D_MODEL] verification lane
/// and anyone wanting a single die on the physics slab.
bool isDiceAsset(String assetKey) => assetKey.startsWith('assets/dice/');

/// What the screen needs: the augmented document plus the camera rig
/// and a one-line capability summary.
final class ShowcaseScene {
  const ShowcaseScene({
    required this.document,
    required this.cameraNode,
    required this.cameraTarget,
    required this.cameraDir,
    required this.frameRadius,
    required this.summary,
  });

  final SceneDocument document;
  final LocalId cameraNode;
  final Vector3 cameraTarget;
  final Vector3 cameraDir;

  /// The bounds-union radius the camera framed — pinch zoom clamps
  /// around `frameRadius * 2.8` (the authored boom distance).
  final double frameRadius;
  final String summary;
}

/// Decodes [item]'s asset, expands prefabs, and injects the viewing
/// rig. Returns null when the asset is missing or fails to decode.
/// [bytesFor] overrides the bundle lookup for tests.
ShowcaseScene? loadShowcaseScene(
  ShowcaseItem item, {
  Uint8List? Function(String key)? bytesFor,
  void Function(String message)? log,
}) {
  final bytesOf = bytesFor ?? (_) => null;
  SceneDocument doc;
  try {
    if (item.assetKey == kBuiltinMaterialsKey ||
        item.assetKey == kBuiltinDocRoundtripKey) {
      // The round-trip lane loads the same fixture — the screen runs
      // it through `SceneController.serializeScene` and the `.fscene`
      // leg itself (loadShowcaseScene stays controller-free so the
      // path is reachable under `dart test`).
      doc = buildMaterialsDocument(bytesOf: bytesOf);
    } else if (item.assetKey == kBuiltinGeometryKey) {
      doc = buildGeometryDocument();
    } else if (item.assetKey == kBuiltinU1Key) {
      doc = buildU1CamerasPickingDocument();
    } else if (item.assetKey == kBuiltinW17SkyKey) {
      doc = buildW17SkyDocument(mode: _kBootW17Mode);
    } else if (item.assetKey == kBuiltinW19CharacterKey) {
      doc = buildW19CharacterDocument();
    } else if (item.assetKey == kBuiltinU2Key) {
      doc = buildU2GeometryDocument();
    } else if (item.assetKey == kBuiltinU2ShadowKey) {
      doc = buildU2ShadowDocument(castsShadow: _kBootU2CastShadows);
      log?.call('dart3d: u2-shadow castsShadow=$_kBootU2CastShadows');
    } else if (item.assetKey == kBuiltinU2CatcherProbeKey) {
      final probeCase = u2CatcherProbeCaseForLabel(item.label);
      if (probeCase == null) {
        log?.call('dart3d: showcase — unknown catcher probe ${item.label}');
        return null;
      }
      doc = buildU2CatcherProbeDocument(probeCase);
    } else {
      final bytes = bytesOf(item.assetKey);
      if (bytes == null) {
        log?.call('dart3d: showcase — missing asset ${item.assetKey}');
        return null;
      }
      doc = item.assetKey.endsWith('.fsceneb')
          ? readFsceneb(bytes)
          : item.assetKey.endsWith('.glb')
          ? importGlbToSceneDocument(bytes)
          // `readFsceneLogged` keeps the vN→vM migration lane log on
          // the bundled-asset path (loadFscene never runs here) — it
          // decodes through the extensions-aware reader, so the dart3d
          // `viewport` view member survives too (W24 merge).
          : readFsceneLogged(utf8.decode(bytes), log: log);
      // Prefab instances expand host-side — prefab_demo.fscene
      // references tree_prefab.fscene by bare filename.
      doc = composeScene(
        doc,
        resolve: (ref) {
          final prefabBytes = bytesOf('assets/showcase/${ref.key}');
          if (prefabBytes == null) {
            throw StateError('missing prefab ${ref.key}');
          }
          return ref.key.endsWith('.fsceneb')
              ? readFsceneb(prefabBytes)
              : readFsceneLogged(utf8.decode(prefabBytes), log: log);
        },
      );
    }
  } catch (error) {
    log?.call('dart3d: showcase — ${item.assetKey} failed: $error');
    return null;
  }

  final stage = item.stage;
  if (stage != null) applyEmissiveGlow(doc, stage.emissiveGlow);

  // Frame from the union of authored mesh bounds in world space —
  // geometry resources are local-space, so the node's world transform
  // applies before the union (imported hierarchies place meshes far
  // from their local origins). Content bounds exclude authored floor
  // slabs that would dwarf the actual subject.
  final bounds = documentContentBounds(doc);
  final bmin = bounds?.$1 ?? Vector3.zero();
  final bmax = bounds?.$2 ?? Vector3.zero();
  final hasBounds = bounds != null;
  final center = hasBounds ? (bmin + bmax) * 0.5 : Vector3.zero();
  final radius = hasBounds ? max((bmax - bmin).length * 0.5, 0.5) : 10.0;
  // The framed radius: bounds plus the item's breathing room (the
  // camera boom and the screen's aspect fit both scale off it).
  final frameRadius = radius * item.frameMargin;
  if (item.assetKey == kBuiltinU2Key) center.y -= radius * 0.55;
  if (item.assetKey == kBuiltinU2ShadowKey) center.y -= radius * 0.55;
  if (item.assetKey == kBuiltinU2CatcherProbeKey) center.y -= radius * 0.35;

  // A slab under the lowest bound gives the key light something to
  // throw shadows onto; visual only, no physics in the gallery.
  if ((stage?.groundSlab ?? true) &&
      item.assetKey != kBuiltinU2Key &&
      item.assetKey != kBuiltinU2ShadowKey &&
      item.assetKey != kBuiltinU2CatcherProbeKey) {
    final slabMat = doc.addResource(
      stage != null
          ? dnLogoSlabMaterial(doc)
          : MaterialResource(
              doc.newId(),
              type: 'physicallyBased',
              properties: {
                'baseColor': ColorValue(0.13, 0.14, 0.17, 1),
                'roughness': DoubleValue(0.92),
                'metallic': DoubleValue(0.0),
              },
            ),
    );
    final slabGeo = doc.addResource(
      GeometryResource(
        doc.newId(),
        procedural: CuboidGeometrySpec(
          extents: Vector3(frameRadius * 8, radius * 0.04, frameRadius * 8),
        ),
      ),
    );
    doc.createNode(
      name: 'showcase.slab',
      transform: TrsTransform(
        translation: Vector3(
          center.x,
          (hasBounds ? bmin.y : 0) - radius * 0.02,
          center.z,
        ),
      ),
      components: [
        ComponentSpec(
          'mesh',
          properties: {
            'geometry': ResourceRefValue(slabGeo.id),
            'material': ResourceRefValue(slabMat.id),
          },
        ),
      ],
      root: true,
    );
  }

  // The 3/4 model-viewer camera: up and south-west of center (unless
  // the item authors its own direction). With the
  // +Z forward convention the pose decomposes as Ry(yaw)·Rx(pitch)
  // over forward = −cameraDir.
  final authoredDir = item.cameraDir;
  final cameraDir =
      (authoredDir == null
            ? Vector3(-0.52, 0.36, -0.77)
            : Vector3(authoredDir.$1, authoredDir.$2, authoredDir.$3))
        ..normalize();
  final fwd = -cameraDir;
  final pitch = -asin(fwd.y.clamp(-1.0, 1.0));
  final yaw = atan2(fwd.x, fwd.z);
  final camera = doc.createNode(
    name: 'showcase.camera',
    transform: TrsTransform(
      translation: center + cameraDir * frameRadius * 2.8,
      rotation:
          Quaternion.axisAngle(Vector3(0, 1, 0), yaw) *
          Quaternion.axisAngle(Vector3(1, 0, 0), pitch),
    ),
    components: [
      ComponentSpec(
        'camera',
        properties: {
          'projection': StringValue('perspective'),
          'fovRadiansY': DoubleValue(0.8),
          'near': DoubleValue(max(radius * 0.02, 0.01)),
          'far': DoubleValue(radius * 60),
        },
      ),
    ],
    root: true,
  );
  if (stage != null) {
    addDnLogoLights(doc, cameraDir: cameraDir, stage: stage);
  } else if (item.assetKey != kBuiltinW17SkyKey &&
      item.assetKey != kBuiltinU2Key &&
      item.assetKey != kBuiltinU2ShadowKey &&
      item.assetKey != kBuiltinU2CatcherProbeKey) {
    doc.createNode(
      name: 'showcase.key',
      transform: TrsTransform(
        // Travels down and away from the camera (upstream +Z travel).
        rotation: aimAlong(Vector3(0.3, -0.8, 0.5)),
      ),
      components: [
        ComponentSpec(
          'directionalLight',
          properties: {
            'color': ColorValue(1.0, 0.95, 0.88, 1),
            'intensity': DoubleValue(0.339),
            'castsShadow': BoolValue(true),
            'shadowRadius': DoubleValue(3.0),
            'shadowDepthBias': DoubleValue(0.01),
          },
        ),
      ],
      root: true,
    );
  }
  doc.stage.environmentRef ??= doc
      .addResource(
        stage != null
            ? dnLogoEnvironment(doc, stage: stage)
            : EnvironmentResource(
                doc.newId(),
                environment: const StudioEnvironment(),
                environmentIntensity: 0.78,
                exposure: 1.0,
                toneMapping: 'pbrNeutral',
                skybox: SkyboxSpec(EnvironmentSkySpec()),
              ),
      )
      .id;

  var textures = 0, materials = 0, geometries = 0;
  for (final r in doc.resources.values) {
    if (r is TextureResource) textures++;
    if (r is MaterialResource) materials++;
    if (r is GeometryResource) geometries++;
  }
  final inventorySummary =
      '${doc.nodes.length} nodes · $geometries geo · $materials mat'
      '${textures == 0 ? '' : ' · $textures tex'}'
      '${doc.skins.isEmpty ? '' : ' · ${doc.skins.length} skins'}'
      '${doc.animations.isEmpty ? '' : ' · ${doc.animations.length} anims'}';
  final summary = item.assetKey == kBuiltinU2Key
      ? 'Wedge · annulus ring · bent extrude CCW/CW · 2 inline wedges'
      : item.assetKey == kBuiltinU2ShadowKey
      ? 'Spot shadow · elevated cuboid · neutral receiver'
      : item.assetKey == kBuiltinU2CatcherProbeKey
      ? item.note
      : inventorySummary;
  log?.call('dart3d: showcase — ${item.label}: $summary');
  return ShowcaseScene(
    document: doc,
    cameraNode: camera.id,
    cameraTarget: center,
    cameraDir: cameraDir,
    frameRadius: frameRadius,
    summary: summary,
  );
}

/// The W21 materials conformance scene — a procedural document (no
/// bundled asset) exercising the alphaMode + UV-set lanes. One row,
/// left to right:
///
/// - `materials.opaque` — control sphere, no alphaMode.
/// - `materials.backdrop` — opaque checker quad wall behind the blend
///   sphere, so `blend` composites against a pattern rather than the
///   slab.
/// - `materials.blend` — `alphaMode:'blend'` sphere at 0.4 alpha; the
///   lane reads "the backdrop shows through".
/// - `materials.mask` — `alphaMode:'mask'` quad sampling a generated
///   lattice texture (opaque cells over alpha-0 holes) with
///   `alphaCutoff: 0.5`; the lane reads "holes are absent, cells
///   present".
/// - `materials.uv0`/`materials.uv1` — one checker quad geometry
///   carrying both UV sets (uv0 covers the texture; uv1 collapses into
///   a single dark cell) drawn twice, the pair differing only in
///   `baseColorTextureTransform.texCoord`. The `texCoord:1` twin
///   renders flat where `texCoord:0` shows the checker.
/// - `materials.ktx2` — a quad sampling a bundled `.ktx2` payload:
///   ETC1S on Android (real Basis transcode through gltfio) and an
///   uncompressed vkFormat-37 file on iOS (the container-parse path;
///   supercompressed formats warn there until a transcoder ships).
/// - `stage.environmentRef` — a `PayloadEnvironment` carrying the
///   bundled `rgb_4x2` equirect: `.exr` on iOS (the W21 decode lane)
///   and `.hdr` on Android (the pre-existing HDR path).
///
/// [bytesOf] is the asset resolver injected by `loadShowcaseScene`;
/// when it cannot supply a file the corresponding lane node/env is
/// skipped rather than faked.
SceneDocument buildMaterialsDocument({
  Uint8List? Function(String key)? bytesOf,
}) {
  final doc = SceneDocument();
  const texSize = 64;

  // ── Shared payload geometry ─────────────────────────────────────
  // Two upright quads' worth of payloads: the plain quad (uv0 spans
  // the texture) and the two-UV-set quad (uv1 collapsed into one dark
  // checker cell). Both share one index buffer — a quad is two
  // triangles either way.
  final quadIndices = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.indexBuffer,
      format: 'uint16',
      length: 12,
      bytes: Uint16List.fromList(const [0, 2, 1, 0, 3, 2]).buffer.asUint8List(),
    ),
  );

  void meshQuad({
    required String name,
    required Vector3 at,
    required MaterialResource material,
    List<Vector2>? uv1s,
    double half = 0.45,
  }) {
    final verts = doc.addPayload(
      PayloadSpec(
        doc.newId(),
        encoding: PayloadEncoding.vertexBuffer,
        layout: 'unskinned_uv1_tangent',
        length: 4 * VertexPack.unskinnedUv1TangentStride,
        bytes: VertexPack.unskinned(
          positions: [
            Vector3(-half, 0, -half),
            Vector3(half, 0, -half),
            Vector3(half, 0, half),
            Vector3(-half, 0, half),
          ],
          normals: List.filled(4, Vector3(0, 1, 0)),
          uvs: [Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)],
          uv1s: uv1s,
          tangents: List.filled(4, Vector4(1, 0, 0, 1)),
        ),
      ),
    );
    final geo = doc.addResource(
      GeometryResource(
        doc.newId(),
        vertices: verts.id,
        indices: quadIndices.id,
        bounds: BoundsSpec(
          min: Vector3(-half, 0, -half),
          max: Vector3(half, 0, half),
        ),
      ),
    );
    // The quad's local frame is a face-up XZ plane; −90° about X turns
    // the +Y normal to −Z so the face fronts the authored camera.
    doc.createNode(
      name: name,
      transform: TrsTransform(
        translation: at,
        rotation: Quaternion.axisAngle(Vector3(1, 0, 0), -pi / 2),
      ),
      components: [
        ComponentSpec(
          'mesh',
          properties: {
            'geometry': ResourceRefValue(geo.id),
            'material': ResourceRefValue(material.id),
          },
        ),
      ],
      root: true,
    );
  }

  LocalId sphereNode(String name, Vector3 at, MaterialResource material) {
    final geo = doc.addResource(
      GeometryResource(
        doc.newId(),
        procedural: SphereGeometrySpec(radius: 0.45),
      ),
    );
    return doc
        .createNode(
          name: name,
          transform: TrsTransform(translation: at),
          components: [
            ComponentSpec(
              'mesh',
              properties: {
                'geometry': ResourceRefValue(geo.id),
                'material': ResourceRefValue(material.id),
              },
            ),
          ],
          root: true,
        )
        .id;
  }

  // ── Textures ────────────────────────────────────────────────────
  final checkerTex = doc.addResource(
    TextureResource(
      doc.newId(),
      payload: doc
          .addPayload(
            PayloadSpec(
              doc.newId(),
              encoding: PayloadEncoding.image,
              format: 'rgba8',
              width: texSize,
              height: texSize,
              length: texSize * texSize * 4,
              bytes: _checkerPixels(texSize, texSize),
            ),
          )
          .id,
    ),
  );
  final latticeTex = doc.addResource(
    TextureResource(
      doc.newId(),
      payload: doc
          .addPayload(
            PayloadSpec(
              doc.newId(),
              encoding: PayloadEncoding.image,
              format: 'rgba8',
              width: texSize,
              height: texSize,
              length: texSize * texSize * 4,
              bytes: _latticePixels(texSize, texSize),
            ),
          )
          .id,
    ),
  );

  // ── Materials + row layout ──────────────────────────────────────
  MaterialResource mat(Map<String, PropertyValue> properties) =>
      doc.addResource(
        MaterialResource(
          doc.newId(),
          type: 'physicallyBased',
          properties: properties,
        ),
      );

  // Backdrop first — an opaque checker wall so the blend lane's
  // translucency composites against a pattern.
  meshQuad(
    name: 'materials.backdrop',
    at: Vector3(-1.1, 0.75, 0.55),
    half: 0.7,
    material: mat({
      'baseColor': ColorValue(1, 1, 1, 1),
      'baseColorTexture': ResourceRefValue(checkerTex.id),
      'roughness': DoubleValue(0.85),
      'doubleSided': BoolValue(true),
    }),
  );
  sphereNode(
    'materials.opaque',
    Vector3(-2.2, 0.5, 0),
    mat({
      'baseColor': ColorValue(0.9, 0.45, 0.15, 1.0),
      'roughness': DoubleValue(0.5),
    }),
  );
  sphereNode(
    'materials.blend',
    Vector3(-1.1, 0.55, 0),
    mat({
      'baseColor': ColorValue(0.25, 0.65, 1.0, 0.4),
      'alphaMode': StringValue('blend'),
      'roughness': DoubleValue(0.35),
    }),
  );
  meshQuad(
    name: 'materials.mask',
    at: Vector3(0, 0.55, 0),
    material: mat({
      'baseColor': ColorValue(1, 1, 1, 1),
      'baseColorTexture': ResourceRefValue(latticeTex.id),
      'alphaMode': StringValue('mask'),
      'alphaCutoff': DoubleValue(0.5),
      'doubleSided': BoolValue(true),
      'roughness': DoubleValue(0.8),
    }),
  );
  // The UV pair shares the two-UV-set geometry: uv0 covers the whole
  // checker while uv1 collapses to a point inside checker cell (1,0) —
  // an odd (dark) cell — so the texCoord:1 quad renders flat dark next
  // to texCoord:0's checker.
  final uv1s = List.filled(4, Vector2(0.19, 0.06));
  meshQuad(
    name: 'materials.uv0',
    at: Vector3(1.1, 0.55, 0),
    uv1s: uv1s,
    material: mat({
      'baseColor': ColorValue(1, 1, 1, 1),
      'baseColorTexture': ResourceRefValue(checkerTex.id),
      'baseColorTextureTransform': MapValue({'texCoord': IntValue(0)}),
      'doubleSided': BoolValue(true),
      'roughness': DoubleValue(0.8),
    }),
  );
  meshQuad(
    name: 'materials.uv1',
    at: Vector3(2.2, 0.55, 0),
    uv1s: uv1s,
    material: mat({
      'baseColor': ColorValue(1, 1, 1, 1),
      'baseColorTexture': ResourceRefValue(checkerTex.id),
      'baseColorTextureTransform': MapValue({'texCoord': IntValue(1)}),
      'doubleSided': BoolValue(true),
      'roughness': DoubleValue(0.8),
    }),
  );

  // ── KTX2 lane ─────────────────────────────────────────────────────
  // Platform-picked asset: Android decodes real ETC1S through gltfio;
  // iOS exercises its container-parse path with an uncompressed
  // vkFormat-37 file (supercompressed payloads warn-once there until a
  // transcoder ships). Missing bytes skip the node, not fake it.
  if (bytesOf != null) {
    final ktx2Bytes = bytesOf(
      Platform.isIOS
          ? 'assets/uncompressed_rgba8_64.ktx2'
          : 'assets/etc1s_srgb_mips_64.ktx2',
    );
    if (ktx2Bytes != null) {
      final ktx2Tex = doc.addResource(
        TextureResource(
          doc.newId(),
          payload: doc
              .addPayload(
                PayloadSpec(
                  doc.newId(),
                  encoding: PayloadEncoding.image,
                  format: 'ktx2',
                  bytes: ktx2Bytes,
                ),
              )
              .id,
        ),
      );
      meshQuad(
        name: 'materials.ktx2',
        at: Vector3(3.3, 0.55, 0),
        material: mat({
          'baseColor': ColorValue(1, 1, 1, 1),
          'baseColorTexture': ResourceRefValue(ktx2Tex.id),
          'doubleSided': BoolValue(true),
          'roughness': DoubleValue(0.8),
        }),
      );
    }

    // ── HDR environment lane ────────────────────────────────────────
    // iOS gets the EXR file (W21 decode lane); Android the .hdr
    // (pre-existing radiance path). 4×2 RGB is tiny but a real HDR
    // equirect — the row visibly re-lights under it. Its saturated
    // primaries run to 10.0, so the intensity comes down to keep the
    // material lanes readable under the colored IBL.
    final envBytes = bytesOf(
      Platform.isIOS ? 'assets/rgb_4x2.exr' : 'assets/rgb_4x2.hdr',
    );
    if (envBytes != null) {
      final envPayload = doc.addPayload(
        PayloadSpec(
          doc.newId(),
          encoding: PayloadEncoding.image,
          format: Platform.isIOS ? 'exr' : 'hdr',
          bytes: envBytes,
        ),
      );
      doc.stage.environmentRef = doc
          .addResource(
            EnvironmentResource(
              doc.newId(),
              environment: PayloadEnvironment(envPayload.id),
              environmentIntensity: 0.0625,
              exposure: 1.0,
              toneMapping: 'pbrNeutral',
              skybox: SkyboxSpec(EnvironmentSkySpec()),
            ),
          )
          .id;
    }
  }
  return doc;
}

/// 8 px checkerboard as raw RGBA8 — near-white vs near-black cells,
/// matching feature_scene's `_checkerRgba` convention.
Uint8List _checkerPixels(int w, int h) {
  final out = Uint8List(w * h * 4);
  var o = 0;
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final v = ((x ~/ 8) + (y ~/ 8)).isEven ? 0xE8 : 0x18;
      out[o] = v;
      out[o + 1] = v;
      out[o + 2] = v;
      out[o + 3] = 255;
      o += 4;
    }
  }
  return out;
}

/// Alpha-cutout lattice as raw RGBA8: 16 px cells whose centered
/// 10×10 px square is opaque leaf-green (a=255) on an alpha-0 grid —
/// the mask lane's "cut out at cutoff" pattern. Cell interiors vary
/// slightly in green so adjacent cells read as separate panels.
Uint8List _latticePixels(int w, int h) {
  const pitch = 16;
  const edge = 3; // transparent border half-width inside each cell
  final out = Uint8List(w * h * 4);
  var o = 0;
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final lx = x % pitch;
      final ly = y % pitch;
      final solid =
          lx >= edge &&
          lx < pitch - edge && //
          ly >= edge &&
          ly < pitch - edge;
      if (solid) {
        final cell = (x ~/ pitch) + (y ~/ pitch) * 7;
        out[o] = 0x30;
        out[o + 1] = 0x90 + (cell * 23 % 60);
        out[o + 2] = 0x38;
        out[o + 3] = 255;
      }
      o += 4;
    }
  }
  return out;
}

/// The W26 geometry showcase — a procedural document exercising the
/// `d3:procMesh`/`d3:instances` vocabulary: the five new primitives
/// plus the real icosphere in the front row, the path-driven shapes
/// (tube, ribbon, dashed polyline, line segments) and a billboard in
/// the second, and a 1000-instance icosphere field — one node, one
/// draw — plus a camera-facing billboard-instance cloud behind them.
const int _envW26Instances = int.fromEnvironment(
  'DART3D_W26_INSTANCES',
  defaultValue: 1000,
);

SceneDocument buildGeometryDocument({int? instanceCount}) {
  final targetInstances = instanceCount ?? _envW26Instances;
  final doc = SceneDocument();

  MaterialResource mat(double r, double g, double b, {double rough = 0.55}) =>
      doc.addResource(
        MaterialResource(
          doc.newId(),
          type: 'physicallyBased',
          properties: {
            'baseColor': ColorValue(r, g, b, 1.0),
            'roughness': DoubleValue(rough),
            'metallic': DoubleValue(0.0),
          },
        ),
      );

  void procNode(String name, Vector3 at, D3Proc proc, MaterialResource m) {
    doc.createNode(
      name: name,
      transform: TrsTransform(translation: at),
      components: [d3ProcMeshComponent(proc, material: m.id)],
      root: true,
    );
  }

  // ── Front row: the solid primitives ─────────────────────────────
  procNode(
    'w26.cylinder',
    Vector3(-6.0, 0.8, 0),
    D3CylinderProc(bottomRadius: 0.45, topRadius: 0.3, height: 1.2),
    mat(0.9, 0.55, 0.2),
  );
  procNode(
    'w26.cone',
    Vector3(-4.0, 0.8, 0),
    D3ConeProc(radius: 0.5, height: 1.4),
    mat(0.85, 0.3, 0.3),
  );
  procNode(
    'w26.capsule',
    Vector3(-2.0, 1.0, 0),
    D3CapsuleProc(radius: 0.4, height: 0.9),
    mat(0.4, 0.75, 0.45),
  );
  procNode(
    'w26.disc',
    Vector3(0.0, 0.8, 0),
    D3DiscProc(radius: 0.65, segments: 40),
    mat(0.3, 0.6, 0.95),
  );
  procNode(
    'w26.icosphere',
    Vector3(2.0, 0.8, 0),
    D3IcosphereProc(radius: 0.6, subdivisions: 3),
    mat(0.75, 0.55, 0.95, rough: 0.35),
  );
  procNode(
    'w26.torus',
    Vector3(4.0, 0.8, 0),
    D3TorusProc(radius: 0.55, tubeRadius: 0.18),
    mat(0.95, 0.8, 0.3),
  );
  procNode(
    'w26.cuboid',
    Vector3(6.0, 0.6, 0),
    D3CuboidProc(extents: Vector3(1.0, 1.0, 1.0), debugColors: true),
    mat(0.6, 0.6, 0.65),
  );

  // The ground lane — the XZ/+Y plane contract under the front row
  // (the pre-fix SCNPlane/XY port drew this edge-on).
  procNode(
    'w26.plane',
    Vector3(0.0, -0.02, 0),
    D3PlaneProc(width: 14.0, depth: 2.4, segmentsX: 4, segmentsZ: 1),
    mat(0.28, 0.30, 0.34, rough: 0.9),
  );

  // ── Second row: path-driven and camera-facing shapes ────────────
  // One shared S-curve carries the tube and the ribbon beside it.
  final sCurve = [
    Vector3(-5.5, 0.4, -2.5),
    Vector3(-4.2, 1.2, -3.2),
    Vector3(-2.8, 0.4, -2.5),
    Vector3(-1.4, 1.2, -3.2),
    Vector3(0.0, 0.4, -2.5),
  ];
  procNode(
    'w26.tube',
    Vector3.zero(),
    D3TubeProc(points: sCurve, radius: 0.14, radialSegments: 10),
    mat(0.9, 0.4, 0.65),
  );
  procNode(
    'w26.ribbon',
    Vector3(0, -0.15, -0.9),
    D3RibbonProc(points: sCurve, width: 0.3),
    mat(0.25, 0.75, 0.8),
  );
  procNode(
    'w26.polyline',
    Vector3(1.6, 0.0, -2.5),
    D3PolylineProc(
      points: [
        Vector3(0, 0.4, 0),
        Vector3(0.8, 1.2, 0.4),
        Vector3(1.6, 0.4, 0),
        Vector3(2.4, 1.2, 0.4),
        Vector3(3.2, 0.4, 0),
      ],
      width: 0.09,
      dashPattern: (0.35, 0.2),
    ),
    mat(1.0, 0.85, 0.25),
  );
  procNode(
    'w26.segments',
    Vector3(5.4, 0.0, -2.5),
    D3LineSegmentsProc(
      points: [
        Vector3(0, 0.3, 0),
        Vector3(0.7, 1.1, 0),
        Vector3(0.7, 0.3, 0.3),
        Vector3(1.4, 1.1, -0.3),
        Vector3(1.4, 0.3, 0),
        Vector3(2.1, 1.1, 0),
      ],
      width: 0.07,
    ),
    mat(0.55, 0.9, 0.35),
  );
  procNode(
    'w26.billboard',
    Vector3(7.4, 0.9, -2.5),
    D3BillboardProc(size: Vector2(0.9, 0.9), color: const [1, 0.5, 0.9, 1]),
    mat(1.0, 1.0, 1.0),
  );

  // ── The instance field — one node (1000 default; 10k via DART3D_W26_INSTANCES) ──
  // 40×25 icospheres by default on a tilted grid; transforms and per-instance
  // colors ride payload chunks (the deferred-path the natives claim
  // against `upsertPayload`).
  final int rows = targetInstances == 1000
      ? 25
      : max(1, sqrt(targetInstances).round());
  final int cols = targetInstances == 1000
      ? 40
      : max(1, (targetInstances / rows).round());
  final double dx = targetInstances == 1000 ? 0.9 : 36.0 / cols;
  final double dz = targetInstances == 1000 ? 0.85 : 21.25 / rows;
  final double icoRadius = targetInstances == 1000
      ? 0.16
      : 0.16 * sqrt(1000.0 / (rows * cols));
  final matrices = <Matrix4>[];
  final colors = <Vector4>[];
  final rng = _Rng(26);
  for (var r = 0; r < rows; r++) {
    for (var c = 0; c < cols; c++) {
      final x = (c - cols / 2) * dx;
      final z = 4.0 + r * dz;
      final y = 0.35 + 0.5 * sin(c * 0.55 + r * 0.7);
      final s = 0.8 + rng.next() * 0.5;
      matrices.add(
        Matrix4.identity()
          ..setTranslationRaw(x, y, z)
          ..rotateY(rng.next() * pi)
          ..scaleByDouble(s, s, s, 1.0),
      );
      colors.add(
        Vector4(
          0.25 + 0.7 * (c / cols),
          0.25 + 0.7 * (r / rows),
          0.9 - 0.5 * (c / cols),
          1.0,
        ),
      );
    }
  }
  final matricesPayload = doc.addPayload(
    d3MatricesPayload(doc.newId(), matrices),
  );
  final colorsPayload = doc.addPayload(d3FloatsPayload(doc.newId(), colors));
  final instanceMat = mat(1.0, 1.0, 1.0, rough: 0.4);
  doc.createNode(
    name: 'w26.instances.field',
    components: [
      D3InstancesSpec(
        proc: D3IcosphereProc(radius: icoRadius, subdivisions: 1),
        material: instanceMat.id,
        transforms: D3InstanceTransforms.payload(matricesPayload.id),
        attributes: {'color': D3InstanceAttribute.payload(colorsPayload.id)},
      ).toComponent(),
    ],
    root: true,
  );

  // ── Billboard-instance cloud — camera-facing quads, re-faced ────
  final bbMatrices = <Matrix4>[
    for (var i = 0; i < 64; i++)
      Matrix4.identity()
        ..setTranslationRaw(((i % 8) - 3.5) * 0.8, 2.2 + (i ~/ 8) * 0.55, 4.0),
  ];
  final bbColors = <Vector4>[
    for (var i = 0; i < 64; i++)
      Vector4(0.3 + 0.7 * ((i % 8) / 7), 0.9, 0.4 + 0.5 * ((i ~/ 8) / 7), 0.85),
  ];
  doc.createNode(
    name: 'w26.instances.billboards',
    components: [
      D3InstancesSpec(
        proc: D3BillboardProc(size: Vector2(0.42, 0.42)),
        material: instanceMat.id,
        transforms: D3InstanceTransforms.inline(bbMatrices),
        attributes: {'color': D3InstanceAttribute.inline(bbColors)},
        billboard: true,
        size: Vector2(0.42, 0.42),
      ).toComponent(),
    ],
    root: true,
  );

  return doc;
}

/// Deterministic tiny PRNG for the instance field — no `dart:math`
/// Random so the scene is identical run to run (xorshift32).
final class _Rng {
  _Rng(this._s);

  int _s;

  double next() {
    var x = _s;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    _s = x & 0x7FFFFFFF;
    return _s / 0x7FFFFFFF;
  }
}

/// The U1 cameras + picking showcase and verification scene:
/// 5 distinct pickable targets in a row (procedural cuboid, payload
/// sphere, `d3:procMesh` capsule, skinned mesh deformed by `u1.joint0`,
/// and 3-instance `d3:instances` column) plus a `u1.pick.marker`
/// indicator sphere.
SceneDocument buildU1CamerasPickingDocument() {
  final doc = SceneDocument();

  MaterialResource mat(
    double r,
    double g,
    double b, {
    double rough = 0.4,
    double metal = 0.05,
  }) => doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': ColorValue(r, g, b, 1.0),
        'roughness': DoubleValue(rough),
        'metallic': DoubleValue(metal),
      },
    ),
  );

  // Target 1: Upstream procedural cuboid at (-3.2, 0.85, 0.0).
  final procGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(1.1, 1.1, 1.1)),
    ),
  );
  doc.createNode(
    name: 'u1.target.procedural',
    transform: TrsTransform(translation: Vector3(-3.2, 0.85, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(procGeo.id),
          'material': ResourceRefValue(mat(0.92, 0.30, 0.25).id),
        },
      ),
    ],
    root: true,
  );

  // Target 2: Payload mesh (`unskinned_uv1_tangent`) sphere at (-1.6, 0.85, 0.0).
  final sphereMesh = buildSphere(radius: 0.62, rings: 16, segments: 24);
  final spherePos = <Vector3>[
    for (var i = 0; i < sphereMesh.vertexCount; i++)
      Vector3(
        sphereMesh.positions[i * 3],
        sphereMesh.positions[i * 3 + 1],
        sphereMesh.positions[i * 3 + 2],
      ),
  ];
  final sphereNrm = <Vector3>[
    for (var i = 0; i < sphereMesh.vertexCount; i++)
      Vector3(
        sphereMesh.normals[i * 3],
        sphereMesh.normals[i * 3 + 1],
        sphereMesh.normals[i * 3 + 2],
      ),
  ];
  final sphereUvs = <Vector2>[
    for (var i = 0; i < sphereMesh.vertexCount; i++)
      Vector2(sphereMesh.uvs[i * 2], sphereMesh.uvs[i * 2 + 1]),
  ];
  final sphereVtxBytes = VertexPack.unskinned(
    positions: spherePos,
    normals: sphereNrm,
    uvs: sphereUvs,
  );
  final sphereIdxBytes = Uint8List(sphereMesh.indices.length * 2);
  final sphereIdxBd = ByteData.sublistView(sphereIdxBytes);
  for (var i = 0; i < sphereMesh.indices.length; i++) {
    sphereIdxBd.setUint16(i * 2, sphereMesh.indices[i], Endian.little);
  }
  final sphereVtxPayload = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.vertexBuffer,
      layout: 'unskinned_uv1_tangent',
      length: sphereVtxBytes.length,
      bytes: sphereVtxBytes,
    ),
  );
  final sphereIdxPayload = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.indexBuffer,
      format: 'uint16',
      length: sphereIdxBytes.length,
      bytes: sphereIdxBytes,
    ),
  );
  final payloadGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      vertices: sphereVtxPayload.id,
      indices: sphereIdxPayload.id,
      bounds: BoundsSpec(min: Vector3.all(-0.62), max: Vector3.all(0.62)),
    ),
  );
  doc.createNode(
    name: 'u1.target.payload',
    transform: TrsTransform(translation: Vector3(-1.6, 0.85, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(payloadGeo.id),
          'material': ResourceRefValue(mat(0.95, 0.72, 0.18).id),
        },
      ),
    ],
    root: true,
  );

  // Target 3: `d3:procMesh` capsule at (0.0, 0.85, 0.0) (also Follow subject).
  doc.createNode(
    name: 'u1.target.d3proc',
    transform: TrsTransform(translation: Vector3(0.0, 0.85, 0.0)),
    components: [
      d3ProcMeshComponent(
        D3CapsuleProc(radius: 0.46, height: 0.75),
        material: mat(0.22, 0.82, 0.45).id,
      ),
    ],
    root: true,
  );

  // Target 4: Skinned mesh (`skinned_uv1_tangent`) at bind origin (1.6, 0.85, 0.0),
  // deformed by `u1.joint0` at (1.6, 1.35, 0.0) (+0.5 Y shift via LBS).
  final joint0 = doc.createNode(
    name: 'u1.joint0',
    transform: TrsTransform(translation: Vector3(1.6, 1.35, 0.0)),
    root: true,
  );
  final ibmFloats = Float32List.fromList(Matrix4.identity().storage);
  final ibmPayload = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.matrices,
      length: 64,
      bytes: ibmFloats.buffer.asUint8List(),
    ),
  );
  final skin = doc.addSkin(
    SkinSpec(
      doc.newId(),
      joints: [joint0.id],
      inverseBindMatrices: ibmPayload.id,
    ),
  );
  final boxMesh = buildCuboid(Vector3(1.0, 1.0, 1.0));
  final boxPos = <Vector3>[
    for (var i = 0; i < boxMesh.vertexCount; i++)
      Vector3(
        boxMesh.positions[i * 3],
        boxMesh.positions[i * 3 + 1],
        boxMesh.positions[i * 3 + 2],
      ),
  ];
  final boxNrm = <Vector3>[
    for (var i = 0; i < boxMesh.vertexCount; i++)
      Vector3(
        boxMesh.normals[i * 3],
        boxMesh.normals[i * 3 + 1],
        boxMesh.normals[i * 3 + 2],
      ),
  ];
  final boxUvs = <Vector2>[
    for (var i = 0; i < boxMesh.vertexCount; i++)
      Vector2(boxMesh.uvs[i * 2], boxMesh.uvs[i * 2 + 1]),
  ];
  final skinnedVtxBytes = VertexPack.skinned(
    positions: boxPos,
    normals: boxNrm,
    uvs: boxUvs,
    joints: List<Vector4>.filled(boxMesh.vertexCount, Vector4.zero()),
    weights: List<Vector4>.filled(boxMesh.vertexCount, Vector4(1, 0, 0, 0)),
  );
  final boxIdxBytes = Uint8List(boxMesh.indices.length * 2);
  final boxIdxBd = ByteData.sublistView(boxIdxBytes);
  for (var i = 0; i < boxMesh.indices.length; i++) {
    boxIdxBd.setUint16(i * 2, boxMesh.indices[i], Endian.little);
  }
  final skinnedVtxPayload = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.vertexBuffer,
      layout: 'skinned_uv1_tangent',
      length: skinnedVtxBytes.length,
      bytes: skinnedVtxBytes,
    ),
  );
  final boxIdxPayload = doc.addPayload(
    PayloadSpec(
      doc.newId(),
      encoding: PayloadEncoding.indexBuffer,
      format: 'uint16',
      length: boxIdxBytes.length,
      bytes: boxIdxBytes,
    ),
  );
  final skinnedGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      vertices: skinnedVtxPayload.id,
      indices: boxIdxPayload.id,
      bounds: BoundsSpec(
        min: Vector3(-0.5, -0.5, -0.5),
        max: Vector3(0.5, 1.0, 0.5),
      ),
    ),
  );
  doc.addNode(
    NodeSpec(
      id: doc.newId(),
      name: 'u1.target.skinned',
      transform: TrsTransform(translation: Vector3(1.6, 0.85, 0.0)),
      skin: skin.id,
      components: [
        ComponentSpec(
          'mesh',
          properties: {
            'geometry': ResourceRefValue(skinnedGeo.id),
            'material': ResourceRefValue(mat(0.25, 0.62, 0.96).id),
          },
        ),
      ],
    ),
    root: true,
  );

  // Target 5: `d3:instances` column of 3 spheres at (3.2, 0.85, 0.0).
  doc.createNode(
    name: 'u1.target.instanced',
    transform: TrsTransform(translation: Vector3(3.2, 0.85, 0.0)),
    components: [
      D3InstancesSpec(
        proc: D3SphereProc(radius: 0.44),
        material: mat(0.75, 0.35, 0.95).id,
        transforms: D3InstanceTransforms.inline([
          Matrix4.identity()..setTranslationRaw(0, -0.65, 0),
          Matrix4.identity()..setTranslationRaw(0, 0.0, 0),
          Matrix4.identity()..setTranslationRaw(0, 0.65, 0),
        ]),
      ).toComponent(),
    ],
    root: true,
  );

  // Pick marker sphere (hidden until a tap hits a target).
  final markerGeo = doc.addResource(
    GeometryResource(doc.newId(), procedural: SphereGeometrySpec(radius: 0.18)),
  );
  final markerMat = doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': const ColorValue(1.0, 0.95, 0.2, 1.0),
        'emissive': const ColorValue(1.0, 0.9, 0.1, 1.0),
        'roughness': const DoubleValue(0.2),
      },
    ),
  );
  doc.addNode(
    NodeSpec(
      id: doc.newId(),
      name: 'u1.pick.marker',
      transform: TrsTransform(
        translation: Vector3(0, 0.85, 0),
        scale: Vector3.zero(),
      ),
      components: [
        ComponentSpec(
          'mesh',
          properties: {
            'geometry': ResourceRefValue(markerGeo.id),
            'material': ResourceRefValue(markerMat.id),
          },
        ),
      ],
    ),
    root: true,
  );

  return doc;
}

/// Builds the W17 physical sky + `skyEnvironment` + `sunLight` verification
/// scene (`builtin:w17`, selected via `--dart-define=DART3D_MODEL=w17`).
///
/// Supported [mode]s:
/// - `'day'` (default): Midday `PhysicalSkySpec` skybox + `SkyEnvironmentSpec`
///   relighting (`equirectWidth: 256`) + shadow-casting `SunLightSpec`.
/// - `'lowsun'`: Low-sun sunset `PhysicalSkySpec` (`sunDirection: (-0.22, 0.04, 0.97)`)
///   warming both the horizon and the `skyEnvironment` IBL.
/// - `'override'`: Static `ConstantEnvironment` (emerald tint) with
///   `skyEnvironment: null` and `PhysicalSkySpec` skybox — verifies static
///   environment precedence when `skyEnvironment` is absent.
/// - `'step1'`, `'step2'`, `'step3'`: Midday `PhysicalSkySpec` with
///   `equirectWidth` set to `64`, `128`, and `256` respectively to verify
///   progressive prefilter convergence against the `'day'` reference.
/// - `'sweep'`: Starts at the morning pose (`(-0.55, 0.10, 0.83)`) with
///   `refresh: 'everyFrame'` so `ShowcaseScreen` sweeps `sunDirection` across
///   frames.
SceneDocument buildW17SkyDocument({
  String mode = 'day',
  Vector3? sunDirectionOverride,
}) {
  final doc = SceneDocument();

  MaterialResource pbrMat(
    double r,
    double g,
    double b, {
    double metallic = 0.0,
    double roughness = 0.5,
  }) => doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': ColorValue(r, g, b, 1.0),
        'metallic': DoubleValue(metallic),
        'roughness': DoubleValue(roughness),
      },
    ),
  );

  final sphereGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: SphereGeometrySpec(radius: 0.72, segments: 48, rings: 24),
    ),
  );
  final pillarGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(0.42, 1.8, 0.42)),
    ),
  );

  // Left: Chrome mirror sphere (shows crisp sky/sun specular reflection).
  doc.createNode(
    name: 'w17.sphere.chrome',
    transform: TrsTransform(translation: Vector3(-1.85, 0.72, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(sphereGeo.id),
          'material': ResourceRefValue(
            pbrMat(0.96, 0.97, 0.99, metallic: 1.0, roughness: 0.04).id,
          ),
        },
      ),
    ],
    root: true,
  );

  // Center: Matte white sphere (shows diffuse SH3 skyEnvironment tint).
  doc.createNode(
    name: 'w17.sphere.matte',
    transform: TrsTransform(translation: Vector3(0.0, 0.72, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(sphereGeo.id),
          'material': ResourceRefValue(
            pbrMat(0.92, 0.92, 0.92, metallic: 0.0, roughness: 0.88).id,
          ),
        },
      ),
    ],
    root: true,
  );

  // Right: Glossy dielectric sphere (shows mid-roughness prefiltered IBL).
  doc.createNode(
    name: 'w17.sphere.glossy',
    transform: TrsTransform(translation: Vector3(1.85, 0.72, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(sphereGeo.id),
          'material': ResourceRefValue(
            pbrMat(0.84, 0.88, 0.94, metallic: 0.0, roughness: 0.18).id,
          ),
        },
      ),
    ],
    root: true,
  );

  // Rear-center shadow caster pillar (casts a clear sunLight shadow across the slab).
  doc.createNode(
    name: 'w17.pillar',
    transform: TrsTransform(translation: Vector3(0.0, 0.90, 1.45)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(pillarGeo.id),
          'material': ResourceRefValue(
            pbrMat(0.85, 0.84, 0.82, metallic: 0.0, roughness: 0.70).id,
          ),
        },
      ),
    ],
    root: true,
  );

  final envRes = buildW17EnvironmentResource(
    doc,
    doc.newId(),
    mode: mode,
    sunDirectionOverride: sunDirectionOverride,
  );
  doc.addResource(envRes);
  doc.stage.environmentRef = envRes.id;

  return doc;
}

/// Builds the [EnvironmentResource] for [mode] in the W17 verification lane.
EnvironmentResource buildW17EnvironmentResource(
  SceneDocument doc,
  LocalId envId, {
  String mode = 'day',
  Vector3? sunDirectionOverride,
}) {
  final sunDir =
      sunDirectionOverride ??
      switch (mode) {
        'lowsun' => Vector3(-0.22, 0.04, 0.97),
        'sweep' => Vector3(-0.55, 0.10, 0.83),
        _ => Vector3(0.22, 0.36, 0.90),
      };

  final physSky = PhysicalSkySpec(
    sunDirection: sunDir,
    sunAngularRadius: 0.028,
    rayleighCoefficient: 2.0,
    turbidity: mode == 'lowsun' ? 14.0 : 10.0,
    energy: 1.0,
  );

  if (mode == 'override') {
    // Static ConstantEnvironment (bright emerald tint) overrides IBL when
    // skyEnvironment is null, while PhysicalSkySpec still draws the skybox.
    return EnvironmentResource(
      envId,
      name: 'w17.env.override',
      environment: ConstantEnvironment(Vector3(0.10, 0.85, 0.30)),
      environmentIntensity: 1.2,
      exposure: 1.0,
      toneMapping: 'pbrNeutral',
      skybox: SkyboxSpec(physSky, intensity: 1.0),
      skyEnvironment: null,
    );
  }

  final eqWidth = switch (mode) {
    'step1' => 64,
    'step2' => 128,
    'step3' => 256,
    _ => 256,
  };

  return EnvironmentResource(
    envId,
    name: 'w17.env.$mode',
    environment: const StudioEnvironment(),
    environmentIntensity: 1.0,
    exposure: 1.0,
    toneMapping: 'pbrNeutral',
    skybox: SkyboxSpec(physSky, intensity: 1.0),
    skyEnvironment: SkyEnvironmentSpec(
      physSky,
      refresh: mode == 'sweep' ? 'everyFrame' : 'manual',
      intervalSeconds: 0.18,
      faceResolution: 128,
      equirectWidth: eqWidth,
      sunLight: SunLightSpec(
        castsShadow: true,
        intensityScale: 1.0,
        shadowMapResolution: 1024,
        shadowMaxDistance: 40.0,
      ),
    ),
  );
}

/// Builds the W19 character controller verification scene (`builtin:w19`,
/// selected via `--dart-define=DART3D_MODEL=w19`):
/// - Physics ground slab (`w19.ground`)
/// - Step platform of height `0.24` (`w19.step`)
/// - Pushable dynamic box on the step (`w19.crate`)
/// - Steep `55°` slope ramp (`w19.slope`)
/// - Primary walking/stepping/jumping character capsule (`w19.character.main`)
/// - Steep-slope sliding character capsule (`w19.character.slope`)
SceneDocument buildW19CharacterDocument() {
  final doc = SceneDocument();

  MaterialResource mat(
    double r,
    double g,
    double b, {
    double roughness = 0.5,
  }) => doc.addResource(
    MaterialResource(
      doc.newId(),
      type: 'physicallyBased',
      properties: {
        'baseColor': ColorValue(r, g, b, 1.0),
        'roughness': DoubleValue(roughness),
      },
    ),
  );

  doc.createNode(
    name: 'w19.world',
    components: [
      ComponentSpec(
        'physicsWorld',
        properties: {
          'gravity': Vec3Value(Vector3(0, -9.8, 0)),
          'fixedTimestep': const DoubleValue(1.0 / 60.0),
        },
      ),
    ],
    root: true,
  );

  final groundGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(10.0, 0.5, 6.0)),
    ),
  );
  doc.createNode(
    name: 'w19.ground',
    transform: TrsTransform(translation: Vector3(0.0, -0.25, 0.0)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(groundGeo.id),
          'material': ResourceRefValue(
            mat(0.22, 0.25, 0.30, roughness: 0.85).id,
          ),
        },
      ),
      rigidBodyComponent(type: 'fixed'),
      colliderComponent(shape: 'box', extents: Vector3(10.0, 0.5, 6.0)),
    ],
    root: true,
  );

  final stepGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(2.4, 0.24, 1.8)),
    ),
  );
  doc.createNode(
    name: 'w19.step',
    transform: TrsTransform(translation: Vector3(0.0, 0.12, -0.4)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(stepGeo.id),
          'material': ResourceRefValue(
            mat(0.35, 0.58, 0.85, roughness: 0.6).id,
          ),
        },
      ),
      rigidBodyComponent(type: 'fixed'),
      colliderComponent(shape: 'box', extents: Vector3(2.4, 0.24, 1.8)),
    ],
    root: true,
  );

  final crateGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(0.55, 0.55, 0.55)),
    ),
  );
  doc.createNode(
    name: 'w19.crate',
    transform: TrsTransform(translation: Vector3(0.45, 0.54, -0.4)),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(crateGeo.id),
          'material': ResourceRefValue(
            mat(0.95, 0.62, 0.18, roughness: 0.4).id,
          ),
        },
      ),
      rigidBodyComponent(type: 'dynamic', mass: 1.5),
      colliderComponent(
        shape: 'box',
        extents: Vector3(0.55, 0.55, 0.55),
        friction: 0.25,
      ),
    ],
    root: true,
  );

  final slopeGeo = doc.addResource(
    GeometryResource(
      doc.newId(),
      procedural: CuboidGeometrySpec(extents: Vector3(2.4, 0.25, 1.4)),
    ),
  );
  doc.createNode(
    name: 'w19.slope',
    transform: TrsTransform(
      translation: Vector3(2.1, 0.85, 1.35),
      rotation: Quaternion.axisAngle(Vector3(0, 0, 1), 0.96),
    ),
    components: [
      ComponentSpec(
        'mesh',
        properties: {
          'geometry': ResourceRefValue(slopeGeo.id),
          'material': ResourceRefValue(
            mat(0.78, 0.34, 0.38, roughness: 0.5).id,
          ),
        },
      ),
      rigidBodyComponent(type: 'fixed'),
      colliderComponent(shape: 'box', extents: Vector3(2.4, 0.25, 1.4)),
    ],
    root: true,
  );

  doc.createNode(
    name: 'w19.character.main',
    transform: TrsTransform(translation: Vector3(-2.4, 0.69, -0.4)),
    components: [
      d3ProcMeshComponent(
        D3CapsuleProc(radius: 0.32, height: 0.70),
        material: mat(0.24, 0.88, 0.52, roughness: 0.3).id,
      ),
      colliderComponent(shape: 'capsule', radius: 0.32, height: 0.70),
      characterControllerComponent(
        offset: 0.02,
        slide: true,
        maxSlopeClimbAngle: pi / 4,
        minSlopeSlideAngle: pi / 4,
        snapToGround: 0.15,
        autostep: true,
        autostepMaxHeight: 0.32,
        autostepMinWidth: 0.10,
        autostepIncludeDynamicBodies: false,
        mass: 25.0,
      ),
    ],
    root: true,
  );

  doc.createNode(
    name: 'w19.character.slope',
    transform: TrsTransform(translation: Vector3(2.25, 1.85, 1.35)),
    components: [
      d3ProcMeshComponent(
        D3CapsuleProc(radius: 0.30, height: 0.60),
        material: mat(0.92, 0.38, 0.82, roughness: 0.3).id,
      ),
      colliderComponent(shape: 'capsule', radius: 0.30, height: 0.60),
      characterControllerComponent(
        offset: 0.02,
        slide: true,
        maxSlopeClimbAngle: pi / 4,
        minSlopeSlideAngle: pi / 4,
        snapToGround: null,
        autostep: false,
        mass: 0.0,
      ),
    ],
    root: true,
  );

  return doc;
}
