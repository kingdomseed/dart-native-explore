package com.jasonholtdigital.dart3d

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.Material
import com.google.android.filament.MaterialInstance
import com.google.android.filament.PixelBufferDescriptor
import com.google.android.filament.RenderTarget
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.Skybox
import com.google.android.filament.Texture
import com.google.android.filament.TextureSampler
import com.google.android.filament.View
import com.google.android.filament.Viewport
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

private const val TAG = "dart3d"
private const val PROBE_SIZE = 256
private val RAW_READBACK_EXECUTOR = Executor { it.run() }

private data class RawMaskSamplePoint(val name: String, val x: Int, val y: Int)

private data class RawMaskPixel(
    val name: String,
    val x: Int,
    val y: Int,
    val rgba: List<Int>,
)

private data class RawMaskChannelRange(val min: Int, val max: Int)

private data class RawMaskReadback(
    val width: Int,
    val height: Int,
    val rowOrigin: String,
    val rgba: ByteArray,
    val channelRanges: List<RawMaskChannelRange>,
    val maxRgbDifference: Int,
    val maskBins: List<Int>,
    val samples: List<RawMaskPixel>,
) {
    fun summary(): String =
        "rgbaRanges=${channelRanges.joinToString(prefix = "[", postfix = "]")}" +
            " maxRgbDifference=$maxRgbDifference" +
            " alphaRange=${channelRanges[3].min}..${channelRanges[3].max}" +
            " maskBins=${maskBins.joinToString(prefix = "[", postfix = "]")}" +
            " samples=${samples.joinToString { sample ->
                "${sample.name}@${sample.x},${sample.y}=${sample.rgba}"
            }}"
}

private val RAW_MASK_SAMPLE_POINTS = listOf(
    RawMaskSamplePoint("clear-nw", 0, 0),
    RawMaskSamplePoint("clear-ne", 255, 0),
    RawMaskSamplePoint("clear-sw", 0, 255),
    RawMaskSamplePoint("clear-se", 255, 255),
    RawMaskSamplePoint("receiver-nw", 16, 16),
    RawMaskSamplePoint("receiver-ne", 240, 16),
    RawMaskSamplePoint("receiver-sw", 16, 240),
    RawMaskSamplePoint("receiver-se", 240, 240),
    RawMaskSamplePoint("caster-projection", 141, 132),
)

private fun analyzeRawMask(bytes: ByteArray): RawMaskReadback {
    val minima = IntArray(4) { 255 }
    val maxima = IntArray(4)
    val maskBins = IntArray(6)
    var maxRgbDifference = 0
    for (offset in bytes.indices step 4) {
        val r = bytes[offset].toInt() and 0xFF
        val g = bytes[offset + 1].toInt() and 0xFF
        val b = bytes[offset + 2].toInt() and 0xFF
        val a = bytes[offset + 3].toInt() and 0xFF
        val pixel = intArrayOf(r, g, b, a)
        for (channel in pixel.indices) {
            minima[channel] = minOf(minima[channel], pixel[channel])
            maxima[channel] = maxOf(maxima[channel], pixel[channel])
        }
        maxRgbDifference = maxOf(
            maxRgbDifference, abs(r - g), abs(g - b), abs(b - r))
        maskBins[when (r) {
            0 -> 0
            in 1..63 -> 1
            in 64..127 -> 2
            in 128..191 -> 3
            in 192..254 -> 4
            else -> 5
        }]++
    }
    val pixels = RAW_MASK_SAMPLE_POINTS.map { point ->
        val offset = (point.y * PROBE_SIZE + point.x) * 4
        RawMaskPixel(
            point.name,
            point.x,
            point.y,
            (0..3).map { channel -> bytes[offset + channel].toInt() and 0xFF },
        )
    }
    return RawMaskReadback(
        PROBE_SIZE,
        PROBE_SIZE,
        "top-left",
        bytes,
        minima.indices.map { RawMaskChannelRange(minima[it], maxima[it]) },
        maxRgbDifference,
        maskBins.toList(),
        pixels,
    )
}

internal class ShadowCatcherProbe(
    private val engine: Engine,
    context: Context,
    val config: Config,
    private val receiver: FsceneRealizer.NodeRec,
    private val caster: FsceneRealizer.NodeRec,
    private val light: FsceneRealizer.NodeRec,
    private val shadowType: View.ShadowType,
    private val onReadbackComplete: () -> Unit,
) {
    enum class CaptureMode(val label: String) {
        NEAR_FAR("nearfar"),
        COLOR_WRITE("colorwrite"),
        LIGHT_DATA("lightdata"),
        RAW_MASK("rawmask"),
    }

    enum class LightCase(val label: String) {
        DIRECTIONAL("directional"),
        SPOT("spot"),
    }

    enum class Variant(
        val label: String,
        val receiverSuffix: String,
        val usesNativeShadowDefaults: Boolean,
        val captureShadowType: View.ShadowType?,
    ) {
        HISTORIC("historic", "", false, null),
        SPLIT_CULL("split-cull", ":cull", false, View.ShadowType.DPCF),
        NATIVE_DEFAULTS(
            "native-defaults", ":cull-native", true, View.ShadowType.DPCF),
        NATIVE_DEFAULTS_PCF(
            "native-defaults-pcf", ":cull-native-pcf", true,
            View.ShadowType.PCF),
        RAW_MASK_NATIVE_DEFAULTS_PCF(
            "raw-mask-native-defaults-pcf", ":raw-native-pcf", true,
            View.ShadowType.PCF),
    }

    data class Config(
        val captureMode: CaptureMode,
        val lightCase: LightCase,
        val variant: Variant = Variant.HISTORIC,
    ) {
        val receiverName: String
            get() = "u2.catcher.probe:${captureMode.label}:" +
                "${lightCase.label}${variant.receiverSuffix}"

        val lightName: String
            get() = if (variant.usesNativeShadowDefaults) {
                LIGHT_NATIVE_DEFAULTS_NAME
            } else {
                LIGHT_NAME
            }

        val shadowOptionsSource: String
            get() = if (variant.usesNativeShadowDefaults) {
                "native-defaults"
            } else {
                "adapter"
            }

        fun effectiveShadowType(defaultType: View.ShadowType): View.ShadowType =
            variant.captureShadowType ?: defaultType
    }

    companion object {
        const val CASTER_NAME = "u2.catcher.probe.caster"
        const val LIGHT_NAME = "u2.catcher.probe.light"
        const val LIGHT_NATIVE_DEFAULTS_NAME =
            "u2.catcher.probe.light.native-defaults"

        fun configForReceiverName(name: String?): Config? = when (name) {
            "u2.catcher.probe:nearfar:directional" ->
                Config(CaptureMode.NEAR_FAR, LightCase.DIRECTIONAL)
            "u2.catcher.probe:nearfar:spot" ->
                Config(CaptureMode.NEAR_FAR, LightCase.SPOT)
            "u2.catcher.probe:colorwrite:directional" ->
                Config(CaptureMode.COLOR_WRITE, LightCase.DIRECTIONAL)
            "u2.catcher.probe:colorwrite:spot" ->
                Config(CaptureMode.COLOR_WRITE, LightCase.SPOT)
            "u2.catcher.probe:lightdata:directional" ->
                Config(CaptureMode.LIGHT_DATA, LightCase.DIRECTIONAL)
            "u2.catcher.probe:lightdata:spot" ->
                Config(CaptureMode.LIGHT_DATA, LightCase.SPOT)
            "u2.catcher.probe:lightdata:spot:cull" ->
                Config(
                    CaptureMode.LIGHT_DATA, LightCase.SPOT,
                    Variant.SPLIT_CULL)
            "u2.catcher.probe:lightdata:directional:cull" ->
                Config(
                    CaptureMode.LIGHT_DATA, LightCase.DIRECTIONAL,
                    Variant.SPLIT_CULL)
            "u2.catcher.probe:lightdata:directional:cull-native" ->
                Config(
                    CaptureMode.LIGHT_DATA, LightCase.DIRECTIONAL,
                    Variant.NATIVE_DEFAULTS)
            "u2.catcher.probe:lightdata:directional:cull-native-pcf" ->
                Config(
                    CaptureMode.LIGHT_DATA, LightCase.DIRECTIONAL,
                    Variant.NATIVE_DEFAULTS_PCF)
            "u2.catcher.probe:rawmask:directional:raw-native-pcf" ->
                Config(
                    CaptureMode.RAW_MASK, LightCase.DIRECTIONAL,
                    Variant.RAW_MASK_NATIVE_DEFAULTS_PCF)
            "u2.catcher.probe:rawmask:spot:raw-native-pcf" ->
                Config(
                    CaptureMode.RAW_MASK, LightCase.SPOT,
                    Variant.RAW_MASK_NATIVE_DEFAULTS_PCF)
            else -> null
        }
    }

    private enum class ReadbackState {
        NOT_REQUESTED,
        PENDING,
        COMPLETE,
        FAILED,
        DESTROY_PENDING,
        DESTROY_READY,
        DESTROYED,
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val isRawMaskCapture = config.captureMode == CaptureMode.RAW_MASK
    private val api = MaterialPackages.apiFor(engine.backend)
    private val captureShadowType = config.effectiveShadowType(shadowType)
    private val captureSpec = MaterialPackages.catcherProbeCaptureSpec(
        api, config.captureMode == CaptureMode.LIGHT_DATA)
    private val casterColorWriteSpec =
        if (config.captureMode != CaptureMode.NEAR_FAR &&
            config.variant == Variant.HISTORIC
        ) {
            MaterialPackages.catcherProbeCasterColorWriteSpec(api)
        } else {
            null
        }
    private val casterSplitCullSpec = if (
        config.variant != Variant.HISTORIC
    ) {
        MaterialPackages.catcherProbeCasterSplitCullSpec(api)
    } else {
        null
    }
    private val displaySpec = if (isRawMaskCapture) {
        MaterialPackages.catcherProbeRawMaskDisplaySpec(api)
    } else {
        MaterialPackages.catcherProbeDisplaySpec(api)
    }
    private var captureMaterial: Material? = null
    private var casterColorWriteMaterial: Material? = null
    private var casterSplitCullMaterial: Material? = null
    private var displayMaterial: Material? = null
    private var captureMaterialInstance: MaterialInstance? = null
    private var casterColorWriteMaterialInstance: MaterialInstance? = null
    private var casterSplitCullMaterialInstance: MaterialInstance? = null
    private var displayMaterialInstance: MaterialInstance? = null
    private var target: RenderTargets.RenderTargetRec? = null
    private var captureScene: Scene? = null
    private var displayScene: Scene? = null
    private var captureCameraEntity = 0
    private var displayCameraEntity = 0
    private var displayCamera: Camera? = null
    private var displaySkybox: Skybox? = null
    private var captureView: View? = null
    private var displayView: View? = null
    private val readbackState = AtomicReference(ReadbackState.NOT_REQUESTED)
    @Volatile private var readbackStorage: ByteBuffer? = null
    private val failedLogs = HashSet<String>()
    private var captureStateLogged = false
    var captured = false
        private set

    init {
        MaterialPackages.compileAsync(captureSpec)
        MaterialPackages.compileAsync(displaySpec)
        casterColorWriteSpec?.let(MaterialPackages::compileAsync)
        casterSplitCullSpec?.let(MaterialPackages::compileAsync)
    }

    fun matches(
        otherConfig: Config,
        receiverEntity: Int,
        casterEntity: Int,
        lightEntity: Int,
    ): Boolean =
        config == otherConfig &&
            receiver.entity == receiverEntity &&
            caster.entity == casterEntity &&
            light.entity == lightEntity

    fun prepare(): Boolean {
        if (captureView != null) return true

        if (captureMaterial == null) {
            val bytes = MaterialPackages.peek(captureSpec.key)
            if (bytes == null) {
                logFailure(captureSpec)
                return false
            }
            captureMaterial = Material.Builder()
                .payload(ByteBuffer.wrap(bytes))
                .fenced { build(engine) }
        }
        if (displayMaterial == null) {
            val bytes = MaterialPackages.peek(displaySpec.key)
            if (bytes == null) {
                logFailure(displaySpec)
                return false
            }
            displayMaterial = Material.Builder()
                .payload(ByteBuffer.wrap(bytes))
                .fenced { build(engine) }
        }
        if (casterColorWriteSpec != null && casterColorWriteMaterial == null) {
            val bytes = MaterialPackages.peek(casterColorWriteSpec.key)
            if (bytes == null) {
                logFailure(casterColorWriteSpec)
                return false
            }
            casterColorWriteMaterial = Material.Builder()
                .payload(ByteBuffer.wrap(bytes))
                .fenced { build(engine) }
        }
        if (casterSplitCullSpec != null && casterSplitCullMaterial == null) {
            val bytes = MaterialPackages.peek(casterSplitCullSpec.key)
            if (bytes == null) {
                logFailure(casterSplitCullSpec)
                return false
            }
            casterSplitCullMaterial = Material.Builder()
                .payload(ByteBuffer.wrap(bytes))
                .fenced { build(engine) }
        }

        val targetRec = if (isRawMaskCapture) {
            buildRawMaskTarget()
        } else {
            RenderTargets.build(
                engine,
                RenderTargets.Spec(
                    PROBE_SIZE, PROBE_SIZE, "manual", 0, "linear",
                    "clampToEdge"),
            )
        }
        target = targetRec
        captureMaterialInstance = captureMaterial!!.createInstance()
        casterColorWriteMaterialInstance =
            casterColorWriteMaterial?.createInstance()
        casterSplitCullMaterialInstance =
            casterSplitCullMaterial?.createInstance()?.apply {
                setDoubleSided(true)
                setCullingMode(
                    Material.CullingMode.FRONT_AND_BACK,
                    Material.CullingMode.NONE)
            }
        displayMaterialInstance = displayMaterial!!.createInstance().apply {
            setParameter(
                "probeTexture", targetRec.colorTex, targetRec.sampler)
        }
        captureScene = engine.createScene().apply {
            addEntity(receiver.entity)
            addEntity(caster.entity)
            addEntity(light.entity)
        }
        displaySkybox = if (isRawMaskCapture) {
            Skybox.Builder()
                .color(0.92f, 0.02f, 0.01f, 1.0f)
                .fenced { build(engine) }
        } else {
            null
        }
        displayScene = engine.createScene().apply {
            addEntity(receiver.entity)
            skybox = displaySkybox
        }

        captureCameraEntity = EntityManager.get().create()
        val captureCamera = engine.createCamera(captureCameraEntity)
        captureCamera.lookAt(
            0.0, 6.0, 0.0,
            0.0, 0.0, 0.0,
            0.0, 0.0, -1.0,
        )
        captureCamera.setExposure(1.0f, 1.0f, 100.0f)
        if (config.captureMode == CaptureMode.NEAR_FAR) {
            captureCamera.setProjection(
                Camera.Projection.ORTHO,
                -2.1, 2.1, -2.1, 2.1, 5.98, 6.02)
        } else {
            val halfExtent = if (isRawMaskCapture) 2.3 else 2.1
            captureCamera.setProjection(
                Camera.Projection.ORTHO,
                -halfExtent, halfExtent, -halfExtent, halfExtent, 0.1, 12.0)
        }

        displayCameraEntity = EntityManager.get().create()
        val displayCameraComponent = engine.createCamera(displayCameraEntity)
        displayCamera = displayCameraComponent
        displayCameraComponent.lookAt(
            0.0, 6.0, 0.0,
            0.0, 0.0, 0.0,
            0.0, 0.0, -1.0,
        )
        displayCameraComponent.setExposure(1.0f, 1.0f, 100.0f)
        displayCameraComponent.setProjection(
            Camera.Projection.ORTHO,
            -2.1, 2.1, -2.1, 2.1, 0.1, 12.0)

        captureView = engine.createView().apply {
            scene = captureScene
            camera = captureCamera
            setRenderTarget(targetRec.rt)
            viewport = Viewport(0, 0, PROBE_SIZE, PROBE_SIZE)
            isPostProcessingEnabled = false
            setShadowType(captureShadowType)
            setShadowingEnabled(true)
            setVisibleLayers(0xFF, 0xFF)
        }
        displayView = engine.createView().apply {
            scene = displayScene
            camera = displayCamera
            isPostProcessingEnabled = false
            setShadowingEnabled(false)
            setVisibleLayers(0xFF, 0xFF)
        }

        val lightManager = engine.lightManager
        val lightInstance = lightManager.getInstance(light.entity)
        val position = lightManager.getPosition(lightInstance, FloatArray(3))
        val direction = lightManager.getDirection(lightInstance, FloatArray(3))
        val color = lightManager.getColor(lightInstance, FloatArray(3))
        val shadowOptions = lightManager.getShadowOptions(lightInstance)
        val shadowTransform = shadowOptions.getTransform()
        val renderableManager = engine.renderableManager
        val receiverInstance = renderableManager.getInstance(receiver.entity)
        val casterInstance = renderableManager.getInstance(caster.entity)
        val casterCaptureMaterial = casterSplitCullMaterialInstance
            ?: renderableManager.getMaterialInstanceAt(casterInstance, 0)
        val transformManager = engine.transformManager
        val receiverWorld = FloatArray(16)
        val casterWorld = FloatArray(16)
        val lightWorld = FloatArray(16)
        transformManager.getWorldTransform(
            transformManager.getInstance(receiver.entity), receiverWorld)
        transformManager.getWorldTransform(
            transformManager.getInstance(caster.entity), casterWorld)
        transformManager.getWorldTransform(
            transformManager.getInstance(light.entity), lightWorld)
        val captureClip = if (config.captureMode == CaptureMode.NEAR_FAR) {
            "5.98..6.02"
        } else {
            "0.1..12.0"
        }
        Log.i(
            TAG,
            "shadow catcher probe state mode=${config.captureMode.label}" +
                " variant=${config.variant.label}" +
                " lightEntity=${light.entity} lightInstance=$lightInstance" +
                " type=${lightManager.getType(lightInstance)}" +
                " positionLocal=${position.contentToString()}" +
                " directionLocal=${direction.contentToString()}" +
                " lightWorldTransform=${lightWorld.contentToString()}" +
                " color=${color.contentToString()}" +
                " intensity=${lightManager.getIntensity(lightInstance)}" +
                " castsShadow=${lightManager.isShadowCaster(lightInstance)}" +
                " shadowOptionsSource=${config.shadowOptionsSource}" +
                " shadowMap=${shadowOptions.mapSize}" +
                " cascades=${shadowOptions.shadowCascades}" +
                " shadowFar=${shadowOptions.shadowFar}" +
                " nearHint=${shadowOptions.shadowNearHint}" +
                " farHint=${shadowOptions.shadowFarHint}" +
                " lispsm=${shadowOptions.lispsm}" +
                " stable=${shadowOptions.getStable()}" +
                " transform=${shadowTransform.contentToString()}" +
                " bias=${shadowOptions.constantBias}" +
                " normalBias=${shadowOptions.normalBias}" +
                " polygonOffset=${shadowOptions.polygonOffsetConstant}" +
                "/${shadowOptions.polygonOffsetSlope}" +
                " bulbRadius=${shadowOptions.shadowBulbRadius}" +
                " captureShadowType=$captureShadowType" +
                " captureCamera=(0,6,0)->(0,0,0)" +
                " ortho=+-2.1 clip=$captureClip" +
                " receiverEntity=${receiver.entity} receiverInstance=$receiverInstance" +
                " receiverPosition=${receiverWorld[12]}," +
                "${receiverWorld[13]},${receiverWorld[14]}" +
                " receiverLayer=${renderableManager.getLayerMask(receiverInstance)}" +
                " receiverCast=${renderableManager.isShadowCaster(receiverInstance)}" +
                " receiverReceives=${renderableManager.isShadowReceiver(receiverInstance)}" +
                " casterEntity=${caster.entity} casterInstance=$casterInstance" +
                " casterPosition=${casterWorld[12]}," +
                "${casterWorld[13]},${casterWorld[14]}" +
                " casterLayer=${renderableManager.getLayerMask(casterInstance)}" +
                " casterCast=${renderableManager.isShadowCaster(casterInstance)}" +
                " casterCameraCulling=${casterCaptureMaterial.getCullingMode()}" +
                " casterShadowCulling=${casterCaptureMaterial.getShadowCullingMode()}" +
                " casterColorWrite=${casterCaptureMaterial.isColorWriteEnabled()}" +
                " casterDepthWrite=${casterCaptureMaterial.isDepthWriteEnabled()}" +
                " captureLayers=255",
        )

        Log.i(
            TAG,
            "shadow catcher probe ready mode=${config.captureMode.label}" +
                " variant=${config.variant.label}" +
                " light=${config.lightCase.label}" +
                " shadowType=$captureShadowType" +
                " shadowOptionsSource=${config.shadowOptionsSource}" +
                " capture=${PROBE_SIZE}x$PROBE_SIZE",
        )
        return true
    }

    private fun logFailure(spec: MaterialPackages.Spec) {
        if (MaterialPackages.hasFailed(spec.key) && failedLogs.add(spec.key)) {
            Log.e(TAG, "shadow catcher probe material compile failed: ${spec.key}")
        }
    }

    private fun buildRawMaskTarget(): RenderTargets.RenderTargetRec {
        val spec = RenderTargets.Spec(
            PROBE_SIZE, PROBE_SIZE, "manual", 0, "nearest", "clampToEdge")
        val color = Texture.Builder()
            .width(PROBE_SIZE)
            .height(PROBE_SIZE)
            .levels(1)
            .sampler(Texture.Sampler.SAMPLER_2D)
            .format(Texture.InternalFormat.RGBA8)
            .usage(
                Texture.Usage.COLOR_ATTACHMENT or
                    Texture.Usage.SAMPLEABLE or
                    Texture.Usage.BLIT_SRC)
            .fenced { build(engine) }
        val depth = Texture.Builder()
            .width(PROBE_SIZE)
            .height(PROBE_SIZE)
            .levels(1)
            .sampler(Texture.Sampler.SAMPLER_2D)
            .format(Texture.InternalFormat.DEPTH24)
            .usage(Texture.Usage.DEPTH_ATTACHMENT)
            .fenced { build(engine) }
        val renderTarget = RenderTarget.Builder()
            .texture(RenderTarget.AttachmentPoint.COLOR, color)
            .texture(RenderTarget.AttachmentPoint.DEPTH, depth)
            .fenced { build(engine) }
        val sampler = TextureSampler(
            TextureSampler.MinFilter.NEAREST,
            TextureSampler.MagFilter.NEAREST,
            TextureSampler.WrapMode.CLAMP_TO_EDGE,
        )
        return RenderTargets.RenderTargetRec(
            spec, renderTarget, color, depth, sampler, dirty = true)
    }

    private fun requestRawMaskReadback(renderer: Renderer) {
        if (!readbackState.compareAndSet(
                ReadbackState.NOT_REQUESTED, ReadbackState.PENDING)) return

        val storage = ByteBuffer.allocateDirect(PROBE_SIZE * PROBE_SIZE * 4)
        readbackStorage = storage
        val backend = engine.backend.toString().lowercase(Locale.ROOT)
        val descriptor = PixelBufferDescriptor(
            storage,
            Texture.Format.RGBA,
            Texture.Type.UBYTE,
            1,
            0,
            0,
            PROBE_SIZE,
            RAW_READBACK_EXECUTOR,
        ) {
            val rgba = ByteArray(storage.capacity())
            storage.duplicate().apply { clear() }.get(rgba)
            readbackStorage = null
            readbackState.updateAndGet { state ->
                when (state) {
                    ReadbackState.PENDING -> ReadbackState.COMPLETE
                    ReadbackState.DESTROY_PENDING -> ReadbackState.DESTROY_READY
                    else -> state
                }
            }
            Thread({
                try {
                    exportRawMaskReadback(rgba, backend)
                } finally {
                    mainHandler.post(onReadbackComplete)
                }
            }, "dart3d-raw-mask-export").start()
        }
        try {
            renderer.readPixels(
                target!!.rt, 0, 0, PROBE_SIZE, PROBE_SIZE, descriptor)
        } catch (error: RuntimeException) {
            readbackStorage = null
            if (readbackState.compareAndSet(
                    ReadbackState.PENDING, ReadbackState.FAILED)) {
                Log.e(
                    TAG,
                    "shadow catcher raw mask readback submission failed" +
                        " light=${config.lightCase.label} backend=$backend",
                    error,
                )
            }
        }
    }

    private fun exportRawMaskReadback(bytes: ByteArray, backend: String) {
        val readback = analyzeRawMask(bytes)
        Log.i(
            TAG,
            "shadow catcher raw mask complete" +
                " light=${config.lightCase.label} backend=$backend" +
                " size=${readback.width}x${readback.height}" +
                " rowOrigin=${readback.rowOrigin}" +
                " maskChannel=R maskMeaning=occlusion(1-visibility)" +
                " captureAlpha=opaque-material-alpha ${readback.summary()}",
        )
        val directory = appContext.getExternalFilesDir("dart3d-raw-mask")
        if (directory == null) {
            Log.e(TAG, "shadow catcher raw mask external files directory unavailable")
            return
        }
        if (!directory.exists() && !directory.mkdirs()) {
            Log.e(TAG, "shadow catcher raw mask directory could not be created")
            return
        }
        val stem = "raw-mask-${config.lightCase.label}-$backend"
        val rawFile = File(directory, "$stem.rgba")
        val metadataFile = File(directory, "$stem.txt")
        try {
            rawFile.writeBytes(readback.rgba)
            metadataFile.writeText(
                buildString {
                    appendLine("light=${config.lightCase.label}")
                    appendLine("backend=$backend")
                    appendLine("width=${readback.width}")
                    appendLine("height=${readback.height}")
                    appendLine("format=RGBA/UBYTE")
                    appendLine("rowStrideBytes=${readback.width * 4}")
                    appendLine("bufferRowOrigin=${readback.rowOrigin}")
                    appendLine("readPixelsOffsetOrigin=bottom-left")
                    appendLine("maskChannel=R")
                    appendLine(
                        "maskMeaning=occlusion=1-LightData.visibility;" +
                            " 0=unshadowed; 255=fully-shadowed")
                    appendLine(
                        "captureAlphaMeaning=opaque source material alpha;" +
                            " expected=255 on receiver; clear alpha separate")
                    appendLine("cameraEye=(0,6,0); target=(0,0,0); up=(0,0,-1)")
                    appendLine("captureOrtho=-2.3..2.3; receiver=4.2x4.2; clip=0.1..12.0")
                    appendLine("casterCenterWorld=(0.24,0.78,0.08)")
                    appendLine(
                        "casterCenterPixelApprox=(141,132); origin=top-left")
                    appendLine(
                        "channelRanges=" + readback.channelRanges.joinToString())
                    appendLine("maxRgbDifference=${readback.maxRgbDifference}")
                    appendLine(
                        "maskBins(0,1-63,64-127,128-191,192-254,255)=" +
                            readback.maskBins.joinToString())
                    for (sample in readback.samples) {
                        appendLine(
                            "sample.${sample.name}=${sample.x},${sample.y}:" +
                                sample.rgba.joinToString(","))
                    }
                },
                Charsets.UTF_8,
            )
            Log.i(
                TAG,
                "shadow catcher raw mask files raw=${rawFile.absolutePath}" +
                    " metadata=${metadataFile.absolutePath}",
            )
        } catch (error: IOException) {
            Log.e(TAG, "shadow catcher raw mask export failed", error)
        }
    }

    fun renderCapture(renderer: Renderer) {
        if (!prepare()) return

        val rm = engine.renderableManager
        val receiverInstance = rm.getInstance(receiver.entity)
        val casterInstance = rm.getInstance(caster.entity)
        val oldMaterial = rm.getMaterialInstanceAt(receiverInstance, 0)
        val oldCasterMaterial = rm.getMaterialInstanceAt(casterInstance, 0)
        val receiverWasCaster = rm.isShadowCaster(receiverInstance)
        try {
            rm.setCastShadows(receiverInstance, false)
            if (config.variant != Variant.HISTORIC) {
                rm.setMaterialInstanceAt(
                    casterInstance, 0, casterSplitCullMaterialInstance!!)
            } else if (config.captureMode != CaptureMode.NEAR_FAR) {
                rm.setMaterialInstanceAt(
                    casterInstance, 0, casterColorWriteMaterialInstance!!)
            }
            rm.setMaterialInstanceAt(
                receiverInstance, 0, captureMaterialInstance!!)
            renderer.render(captureView!!)
            if (isRawMaskCapture) requestRawMaskReadback(renderer)
            if (!captureStateLogged) {
                Log.i(
                    TAG,
                    "shadow catcher probe capture every frame" +
                        " mode=${config.captureMode.label}" +
                        " variant=${config.variant.label}" +
                        " light=${config.lightCase.label}" +
                        " shadowType=$captureShadowType" +
                        " shadowOptionsSource=${config.shadowOptionsSource}" +
                        " receiverCast=false" +
                        " splitCasterCulling=${config.variant != Variant.HISTORIC}" +
                        " casterColorWriteDisabled=${config.captureMode != CaptureMode.NEAR_FAR &&
                            config.variant == Variant.HISTORIC}",
                )
                captureStateLogged = true
            }
            captured = true
        } finally {
            rm.setCastShadows(receiverInstance, receiverWasCaster)
            rm.setMaterialInstanceAt(receiverInstance, 0, oldMaterial)
            rm.setMaterialInstanceAt(casterInstance, 0, oldCasterMaterial)
        }
    }

    fun renderDisplay(renderer: Renderer, width: Int, height: Int) {
        if (!captured) return

        val rm = engine.renderableManager
        val receiverInstance = rm.getInstance(receiver.entity)
        val oldMaterial = rm.getMaterialInstanceAt(receiverInstance, 0)
        try {
            rm.setMaterialInstanceAt(
                receiverInstance, 0, displayMaterialInstance!!)
            val displayWidth = width - width / 2
            val aspect = displayWidth.toDouble() / height.toDouble()
            val halfWidth = 2.1 * maxOf(1.0, aspect)
            val halfHeight = 2.1 * maxOf(1.0, 1.0 / aspect)
            displayCamera!!.setProjection(
                Camera.Projection.ORTHO,
                -halfWidth, halfWidth, -halfHeight, halfHeight, 0.1, 12.0)
            displayView!!.viewport = Viewport(width / 2, 0, displayWidth, height)
            renderer.render(displayView!!)
        } finally {
            rm.setMaterialInstanceAt(receiverInstance, 0, oldMaterial)
        }
    }

    fun destroy(): Boolean {
        while (true) {
            val state = readbackState.get()
            when (state) {
                ReadbackState.PENDING -> {
                    if (readbackState.compareAndSet(
                            state, ReadbackState.DESTROY_PENDING)) return false
                }
                ReadbackState.DESTROY_PENDING -> return false
                ReadbackState.DESTROYED -> return true
                else -> {
                    if (readbackState.compareAndSet(
                            state, ReadbackState.DESTROYED)) {
                        destroyResources()
                        return true
                    }
                }
            }
        }
    }

    private fun destroyResources() {
        captureView?.let {
            it.setRenderTarget(null)
            engine.destroyView(it)
        }
        displayView?.let(engine::destroyView)
        captureView = null
        displayView = null
        displaySkybox?.let {
            displayScene?.skybox = null
            engine.destroySkybox(it)
        }
        displaySkybox = null
        captureScene?.let(engine::destroyScene)
        displayScene?.let(engine::destroyScene)
        captureScene = null
        displayScene = null
        if (captureCameraEntity != 0) {
            engine.destroyCameraComponent(captureCameraEntity)
            EntityManager.get().destroy(captureCameraEntity)
            captureCameraEntity = 0
        }
        if (displayCameraEntity != 0) {
            engine.destroyCameraComponent(displayCameraEntity)
            EntityManager.get().destroy(displayCameraEntity)
            displayCameraEntity = 0
        }
        displayCamera = null
        target?.let {
            engine.destroyRenderTarget(it.rt)
            engine.destroyTexture(it.colorTex)
            it.depthTex?.let(engine::destroyTexture)
        }
        target = null
        captureMaterialInstance?.let(engine::destroyMaterialInstance)
        casterColorWriteMaterialInstance?.let(engine::destroyMaterialInstance)
        casterSplitCullMaterialInstance?.let(engine::destroyMaterialInstance)
        displayMaterialInstance?.let(engine::destroyMaterialInstance)
        captureMaterialInstance = null
        casterColorWriteMaterialInstance = null
        casterSplitCullMaterialInstance = null
        displayMaterialInstance = null
        captureMaterial?.let(engine::destroyMaterial)
        casterColorWriteMaterial?.let(engine::destroyMaterial)
        casterSplitCullMaterial?.let(engine::destroyMaterial)
        displayMaterial?.let(engine::destroyMaterial)
        captureMaterial = null
        casterColorWriteMaterial = null
        casterSplitCullMaterial = null
        displayMaterial = null
    }
}
