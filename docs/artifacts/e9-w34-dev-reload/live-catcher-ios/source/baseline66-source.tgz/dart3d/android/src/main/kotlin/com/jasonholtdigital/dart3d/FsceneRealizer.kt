package com.jasonholtdigital.dart3d

import android.opengl.Matrix
import android.util.Log
import com.github.stephengold.joltjni.Body
import com.github.stephengold.joltjni.BodyCreationSettings
import com.github.stephengold.joltjni.BoxShape
import com.github.stephengold.joltjni.CapsuleShape
import com.github.stephengold.joltjni.ConvexHullShapeSettings
import com.github.stephengold.joltjni.ConvexShape
import com.github.stephengold.joltjni.CylinderShape
import com.github.stephengold.joltjni.IndexedTriangle
import com.github.stephengold.joltjni.IndexedTriangleList
import com.github.stephengold.joltjni.MeshShapeSettings
import com.github.stephengold.joltjni.Quat
import com.github.stephengold.joltjni.RVec3
import com.github.stephengold.joltjni.RotatedTranslatedShape
import com.github.stephengold.joltjni.RotatedTranslatedShapeSettings
import com.github.stephengold.joltjni.ShapeSettings
import com.github.stephengold.joltjni.SphereShape
import com.github.stephengold.joltjni.StaticCompoundShapeSettings
import com.github.stephengold.joltjni.Vec3
import com.github.stephengold.joltjni.VertexList
import com.github.stephengold.joltjni.enumerate.EAllowedDofs
import com.github.stephengold.joltjni.enumerate.EMotionQuality
import com.github.stephengold.joltjni.enumerate.EMotionType
import com.github.stephengold.joltjni.enumerate.EOverrideMassProperties
import com.github.stephengold.joltjni.readonly.ConstShape
import com.google.android.filament.Box
import com.google.android.filament.EntityManager
import com.google.android.filament.IndexBuffer
import com.google.android.filament.IndirectLight
import com.google.android.filament.InstanceBuffer
import com.google.android.filament.LightManager
import com.google.android.filament.MaterialInstance
import com.google.android.filament.MorphTargetBuffer
import com.google.android.filament.RenderableManager
import com.google.android.filament.SkinningBuffer
import com.google.android.filament.Skybox
import com.google.android.filament.Texture
import com.google.android.filament.TextureSampler
import com.google.android.filament.VertexBuffer
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.ln

private const val TAG = "dart3d"

// Light units are upstream's (flutter_scene 0.23): `intensity` scales the
// light's colour into the radiance a surface receives, and the stage's
// `exposure` is the one linear multiplier before tone mapping. The view
// camera's exposure is therefore set to the stage value itself
// (Dart3dView.setCameraExposure), not to a photographic setting, and
// every intensity passes through unscaled:
//
//  * directional → Filament's illuminance: a white Lambert surface
//    facing the light leaves `intensity / π`.
//  * point, spot → Filament's luminous intensity (candela): the surface
//    receives `intensity / d²`. Filament's range window and its spot
//    cone ramp are the functions upstream uses.
//  * environmentIntensity and skybox.intensity → the IndirectLight's
//    and the Skybox's intensity, a plain multiplier on their texels.
//
// A light with no `range`, or a range of 0, has no cut-off upstream.
// Filament needs a radius, so it gets one no scene reaches.
private const val UNBOUNDED_LIGHT_RANGE = 1.0e5f
// d3:instances bakes N copies into one vertex buffer on CPU — an
// unbounded count is a memory/peak-frame hazard, so over the cap the
// tail is truncated with a warn-once (upstream's GPU instancing has
// no equivalent limit; documented in payload-geometry-spec).
private const val MAX_BAKED_INSTANCES = 16384
// The bake's allocation is instances × base vertices, so the count cap
// alone doesn't bound it (a default sphere × 16 384 ≈ 9.2 M vertices).
// Over this vertex budget the instance tail is truncated (warn-once).
// Mirrors kD3MaxBakedVertices (dart3d/lib/src/geometry/limits.dart).
private const val MAX_BAKED_VERTICES = 1 shl 20
// Procedural tessellation caps (W26 hang/OOM guard) — the Dart wire
// contract in dart3d/lib/src/geometry/limits.dart; clamp, never reject.
//  * segment-style counts (segments, rings, radial/tubular/height
//    segments, capRings, segmentsX/Z, tube stations): ..512
//    (kD3MaxProcSegments)
//  * icosphere subdivisions: 0..6 (kD3MaxIcosphereSubdivisions)
//  * tube: radialSegments ≥3, stations ≥2 (the Dart builder's minimums)
private const val MAX_PROC_SEGMENTS = 512
private const val MAX_ICOSPHERE_SUBDIVISIONS = 6
private const val MIN_TUBE_RADIAL = 3

/** Wire `alphaMode` vocabulary (lowercase in the spec). */
private val ALPHA_MODES = setOf("opaque", "mask", "blend")

/** GPU-side mesh: engine objects plus the CPU data physics hulls read. */
class GpuMesh(
    val vertexBuffer: VertexBuffer,
    val indexBuffer: IndexBuffer,
    val vertexCount: Int,
    val indexCount: Int,
    val bounds: FloatArray,         // cx,cy,cz, hx,hy,hz
    val positions: FloatArray,      // pos triples for hull colliders
    val indices: IntArray,          // tri indices for mesh colliders
    val primitiveType: RenderableManager.PrimitiveType,
    // W11: true when the vertex buffer carries BONE_INDICES +
    // BONE_WEIGHTS streams (the skinned repack).
    val hasSkinning: Boolean = false,
    // W11 morph targets — float4 delta positions (+ packed absolute
    // tangent quats) uploaded at build; `morphDefaults` is the mesh's
    // authored `weights` array padded to `morphTargetCount` by the
    // renderable attach.
    val morphTargetBuffer: MorphTargetBuffer? = null,
    val morphDefaults: FloatArray = FloatArray(0),
    val morphTargetCount: Int = 0,
) {
    fun destroy(engine: com.google.android.filament.Engine) {
        engine.destroyVertexBuffer(vertexBuffer)
        engine.destroyIndexBuffer(indexBuffer)
        morphTargetBuffer?.let { engine.destroyMorphTargetBuffer(it) }
    }
}

/**
 * W26: a node whose vertex buffer re-expands toward the live camera
 * each frame — `d3:procMesh` camera-facing shapes (`polyline`,
 * `lineSegments`, `billboard`) plus the instanced-quad form
 * (`billboardInstances`). `points` holds native-space xyz triples
 * (line points or per-instance centers); the remaining fields mirror
 * the component params so `MeshFactory` can rebuild the record.
 */
class FacingSpec(
    val shape: String,
    val points: List<MeshFactory.V3>,
    val colors: List<FloatArray>?,
    val widths: List<Float>?,
    val width: Float,
    val dashes: DoubleArray?,
    val closed: Boolean,
    val sizeX: Float, val sizeY: Float,
    val rotation: Float,
    val tint: FloatArray,
    val vertexBuffer: VertexBuffer,
    val entity: Int,
    /** Billboard facing mode — `spherical`/`axisY` aim at the
     *  node-local camera position; `screen` keeps the camera plane.
     *  Lines ignore it (they always aim at the camera). */
    val facing: String = "spherical",
) {
    companion object {
        /** The instanced-billboard registration — centers are the
         *  instance transforms' translations in node space. */
        fun billboards(
            centers: FloatArray, sizeX: Float, sizeY: Float,
            rotation: Float, colors: List<FloatArray>?,
            vertexBuffer: VertexBuffer, entity: Int,
            facing: String = "spherical",
        ) = FacingSpec(
            "billboardInstances",
            (0 until centers.size / 3).map {
                MeshFactory.V3(centers[it * 3], centers[it * 3 + 1],
                    centers[it * 3 + 2])
            },
            colors, null, 1f, null, false,
            sizeX, sizeY, rotation,
            floatArrayOf(1f, 1f, 1f, 1f), vertexBuffer, entity, facing)
    }
}

/**
 * Realizes a `.fscene` manifest (canonical JSON) into Filament entities
 * and Jolt bodies. Mirrors FsceneRealizer.swift: same component
 * vocabulary, same deferred physics pass, same tagged-value decoding.
 * Payload-backed resources stay pending until their bytes arrive.
 */
object FsceneRealizer {

    enum class ShadowCatcherMode { LIVE, BAKED }

    data class ShadowCatcherSettings(
        val mode: ShadowCatcherMode,
        val softness: Float,
    )

    data class BakedCatcherReceiver(
        val entity: Int,
        val primitive: Int,
        val worldMatrix: FloatArray,
        val minMaxBounds: FloatArray,
        val ownerKey: Long,
        val owner: NodeRec,
    )

    fun parseShadowCatcherSettings(r: JSONObject): ShadowCatcherSettings? {
        if (r.optString("type") != "shadowCatcher") return null
        val props = r.optJSONObject("properties") ?: JSONObject()
        val mode = when (props.tag("mode").d3String()) {
            "baked" -> ShadowCatcherMode.BAKED
            else -> ShadowCatcherMode.LIVE
        }
        return ShadowCatcherSettings(
            mode,
            (props.tag("softness").d3Double() ?: 0.0).toFloat(),
        )
    }

    internal fun cascadeSplits(
        lambda: Float, cascades: Int, shadowFar: Float,
    ): FloatArray {
        val f = if (shadowFar > 0f) shadowFar else 100f
        val n = minOf(0.1f, f * 0.01f)
        val out = FloatArray(3) { 1.0f }
        for (i in 1 until cascades.coerceAtMost(4)) {
            val t = i.toFloat() / cascades
            val log = n * Math.pow((f / n).toDouble(),
                t.toDouble()).toFloat()
            val uni = n + (f - n) * t
            out[i - 1] = (lambda * log + (1 - lambda) * uni) / f
        }
        return out
    }

    // One-shot log dedup for spec-deferred features (payload-backed
    // shapes, heightField, named backends, bad combine rules).
    private val loggedOnce = mutableSetOf<String>()
    private val warnedOnce = mutableSetOf<String>()

    private fun logOnce(tag: String, msg: String) {
        if (loggedOnce.add(tag)) Log.i(TAG, msg)
    }

    private fun warnOnce(tag: String, msg: String) {
        if (warnedOnce.add(tag)) Log.w(TAG, msg)
    }

    // ── W22: KHR_materials_* ────────────────────────────────────────
    // Feature bits pick the lazily-compiled Material variant
    // (Dart3dView.materialForVariant). The slot/factor rows below are
    // the single registry both sides walk — buildMaterial declares
    // the uniforms+samplers these rows name; buildMaterialInstance
    // writes and binds them — so shader vocabulary can't drift from
    // the wire decode.
    const val EXT_CLEARCOAT = 1 shl 0
    const val EXT_SHEEN = 1 shl 1
    const val EXT_SPECULAR = 1 shl 2
    const val EXT_ANISOTROPY = 1 shl 3
    const val EXT_IOR = 1 shl 4
    const val EXT_TRANSMISSION = 1 shl 5
    const val EXT_VOLUME_SOLID = 1 shl 6
    const val EXT_DISPERSION = 1 shl 7

    /** Wire texture prop → shader slot prefix (`<prefix>Map` +
     * `<prefix>UVTransform`/`UVRotation`/`UVSet`). */
    data class ExtTextureSlot(
        val flag: Int, val prop: String, val prefix: String)

    val EXT_TEXTURE_SLOTS = listOf(
        ExtTextureSlot(EXT_CLEARCOAT, "clearcoatTexture", "clearCoat"),
        ExtTextureSlot(EXT_CLEARCOAT, "clearcoatRoughnessTexture",
            "clearCoatRoughness"),
        ExtTextureSlot(EXT_CLEARCOAT, "clearcoatNormalTexture",
            "clearCoatNormal"),
        ExtTextureSlot(EXT_SHEEN, "sheenColorTexture", "sheenColor"),
        ExtTextureSlot(EXT_SHEEN, "sheenRoughnessTexture",
            "sheenRoughness"),
        ExtTextureSlot(EXT_SPECULAR, "specularTexture", "specular"),
        ExtTextureSlot(EXT_SPECULAR, "specularColorTexture",
            "specularColor"),
        ExtTextureSlot(EXT_ANISOTROPY, "anisotropyTexture", "anisotropy"),
        ExtTextureSlot(EXT_TRANSMISSION, "transmissionTexture",
            "transmission"),
        ExtTextureSlot(EXT_TRANSMISSION, "thicknessTexture", "thickness"),
    )

    /**
     * W22-r3: bound-only sampler emission. Filament's feature-level-1
     * cap counts *declared* samplers (9 — 8 when screen-space
     * refraction reserves one), so a variant declares — and the
     * shader samples — only the texture slots the material actually
     * binds. The bound set travels as a bitmask in the variant key:
     * bits 0-4 index [BASE_TEXTURE_SLOTS], bits 5+ index
     * [EXT_TEXTURE_SLOTS]. Unbound slots emit the factor-only term
     * their 1×1 fallback used to produce.
     */
    data class BaseTextureSlot(
        val prop: String, val prefix: String, val param: String)

    val BASE_TEXTURE_SLOTS = listOf(
        BaseTextureSlot("baseColorTexture", "baseColor", "baseColorMap"),
        BaseTextureSlot("normalTexture", "normal", "normalMap"),
        BaseTextureSlot("metallicRoughnessTexture", "mr",
            "metallicRoughnessMap"),
        BaseTextureSlot("occlusionTexture", "occlusion", "occlusionMap"),
        BaseTextureSlot("emissiveTexture", "emissive", "emissiveMap"),
    )

    /** Every base slot bound — the prebuilt contract, whose instances
     * still bind 1×1 fallbacks so all five samplers stay sampled. */
    const val ALL_BASE_SLOTS = (1 shl 5) - 1

    /** Slot bit for `EXT_TEXTURE_SLOTS[i]` in the bound mask. */
    fun extSlotBit(i: Int) = 1 shl (BASE_TEXTURE_SLOTS.size + i)

    /**
     * Wire props → bound-slot mask. Only texture refs count — a
     * factor-only material declares zero extension samplers. Ext
     * slots whose flag isn't armed don't count either (e.g. an
     * orphaned thicknessTexture with no transmission is inert).
     */
    fun boundTextureMask(props: JSONObject, extFlags: Int): Int {
        var m = 0
        for ((i, s) in BASE_TEXTURE_SLOTS.withIndex()) {
            if (props.tag(s.prop).d3Ref() != null) m = m or (1 shl i)
        }
        for ((i, s) in EXT_TEXTURE_SLOTS.withIndex()) {
            if (extFlags and s.flag == 0) continue
            if (props.tag(s.prop).d3Ref() != null) m = m or extSlotBit(i)
        }
        return m
    }

    /**
     * Wire factor prop → uniform. [mask] is the flag set under which
     * the uniform is declared and written (`ior` lives under
     * TRANSMISSION *or* IOR — Filament also accepts `material.ior` as
     * an alternative to reflectance on non-refractive lit materials).
     */
    data class ExtFactor(
        val mask: Int, val prop: String, val uniform: String,
        val isColor: Boolean, val default: FloatArray)

    val EXT_FACTORS = listOf(
        ExtFactor(EXT_CLEARCOAT, "clearcoat", "clearCoat",
            false, floatArrayOf(0f)),
        ExtFactor(EXT_CLEARCOAT, "clearcoatRoughness",
            "clearCoatRoughness", false, floatArrayOf(0f)),
        ExtFactor(EXT_CLEARCOAT, "clearcoatNormalScale",
            "clearCoatNormalScale", false, floatArrayOf(1f)),
        ExtFactor(EXT_SHEEN, "sheenColor", "sheenColor",
            true, floatArrayOf(0f, 0f, 0f, 0f)),
        ExtFactor(EXT_SHEEN, "sheenRoughness", "sheenRoughness",
            false, floatArrayOf(0f)),
        ExtFactor(EXT_SPECULAR, "specular", "specularFactor",
            false, floatArrayOf(1f)),
        ExtFactor(EXT_SPECULAR, "specularColor", "specularColorFactor",
            true, floatArrayOf(1f, 1f, 1f, 1f)),
        ExtFactor(EXT_ANISOTROPY, "anisotropy", "anisotropy",
            false, floatArrayOf(0f)),
        ExtFactor(EXT_ANISOTROPY, "anisotropyRotation",
            "anisotropyRotation", false, floatArrayOf(0f)),
        ExtFactor(EXT_TRANSMISSION, "transmission", "transmission",
            false, floatArrayOf(0f)),
        ExtFactor(EXT_TRANSMISSION, "thickness", "thickness",
            false, floatArrayOf(0f)),
        ExtFactor(EXT_TRANSMISSION or EXT_IOR, "ior", "ior",
            false, floatArrayOf(1.5f)),
        ExtFactor(EXT_DISPERSION, "dispersion", "dispersion",
            false, floatArrayOf(0f)),
    )

    /** Every wire property name material decode claims — the
     * pre-W22 vocabulary plus the extension registry above
     * (`<slot>Transform` rides its base slot). Anything else on a
     * material resource warn-onces as unhandled: that warn is what
     * the conformance matrix's `warn` row means. */
    private val handledMaterialProps = setOf(
        "baseColor", "baseColorTexture", "blendMode",
        "metallic", "roughness", "metallicRoughnessTexture",
        "normalTexture", "normalScale",
        "occlusionTexture", "occlusionStrength",
        "emissive", "emissiveStrength", "emissiveTexture",
        "doubleSided", "alphaMode", "alphaCutoff",
        "clearcoat", "clearcoatRoughness", "clearcoatTexture",
        "clearcoatRoughnessTexture", "clearcoatNormalTexture",
        "clearcoatNormalScale",
        "sheenColor", "sheenRoughness",
        "sheenColorTexture", "sheenRoughnessTexture",
        "specular", "specularColor",
        "specularTexture", "specularColorTexture",
        "anisotropy", "anisotropyRotation", "anisotropyTexture",
        "iridescence", "iridescenceIor", "iridescenceThicknessMinimum",
        "iridescenceThicknessMaximum", "iridescenceTexture",
        "iridescenceThicknessTexture",
        "transmission", "transmissionTexture",
        "thickness", "thicknessTexture",
        "attenuationColor", "attenuationDistance",
        "dispersion", "ior",
        "diffuseTransmission", "diffuseTransmissionColor",
        "diffuseTransmissionTexture", "diffuseTransmissionColorTexture",
    )

    private fun warnUnhandledMaterialProps(key: Long, props: JSONObject) {
        for (name in props.keys()) {
            val base = if (name.endsWith("Transform"))
                name.removeSuffix("Transform") else name
            if (base !in handledMaterialProps) {
                warnOnce("mat.$key.unhandled.$name",
                    "material $key: unhandled property '$name'")
            }
        }
    }

    /**
     * Extension presence → feature bits. An extension's props only
     * land on the wire when its glTF block existed; a feature is
     * *active* when a factor deviates from its no-op default or a
     * texture slot is referenced — a present-but-default extension
     * needs no variant. Extensions with no Filament input
     * (iridescence, diffuse transmission) warn once per material.
     */
    private fun extFlagsFor(key: Long, props: JSONObject): Int {
        fun num(p: String, d: Double = 0.0) = props.tag(p).d3Double() ?: d
        fun ref(p: String) = props.tag(p).d3Ref() != null
        var f = 0
        if (num("clearcoat") > 0.0 || ref("clearcoatTexture") ||
            ref("clearcoatRoughnessTexture") || ref("clearcoatNormalTexture")) {
            f = f or EXT_CLEARCOAT
        }
        val sheen = props.tag("sheenColor").d3Color()
        if ((sheen != null &&
             (sheen[0] > 0f || sheen[1] > 0f || sheen[2] > 0f)) ||
            ref("sheenColorTexture") || ref("sheenRoughnessTexture")) {
            f = f or EXT_SHEEN
        }
        val specColor = props.tag("specularColor").d3Color()
        if (num("specular", 1.0) != 1.0 ||
            (specColor != null && (specColor[0] != 1f ||
                specColor[1] != 1f || specColor[2] != 1f)) ||
            ref("specularTexture") || ref("specularColorTexture")) {
            f = f or EXT_SPECULAR
        }
        if (num("anisotropy") != 0.0 || ref("anisotropyTexture")) {
            f = f or EXT_ANISOTROPY
        }
        val hasTransmission = num("transmission") > 0.0 ||
            ref("transmissionTexture")
        if (hasTransmission) f = f or EXT_TRANSMISSION
        if (num("ior", 1.5) != 1.5) f = f or EXT_IOR
        val thickness = num("thickness")
        if (hasTransmission && thickness > 0.0) f = f or EXT_VOLUME_SOLID
        val dispersion = num("dispersion")
        if (dispersion != 0.0) {
            if (f and EXT_VOLUME_SOLID != 0) {
                f = f or EXT_DISPERSION
            } else {
                // Filament has no `dispersion` field outside SOLID
                // refraction — documented drop, matching the matrix.
                warnOnce("mat.$key.dispersion",
                    "material $key: dispersion=$dispersion needs a" +
                        " solid refraction volume (transmission +" +
                        " thickness) — dropped")
            }
        }
        if (num("iridescence") > 0.0 || ref("iridescenceTexture") ||
            ref("iridescenceThicknessTexture")) {
            warnOnce("mat.$key.iridescence",
                "material $key: iridescence has no Filament input" +
                    " — dropped")
        }
        if (num("diffuseTransmission") > 0.0 ||
            ref("diffuseTransmissionTexture") ||
            ref("diffuseTransmissionColorTexture")) {
            warnOnce("mat.$key.diffuseTransmission",
                "material $key: diffuse transmission has no Filament" +
                    " input — dropped")
        }
        if (!hasTransmission &&
            (thickness > 0.0 || ref("thicknessTexture") ||
             props.has("attenuationColor") ||
             props.has("attenuationDistance"))) {
            warnOnce("mat.$key.volume",
                "material $key: volume props without transmission are" +
                    " inert — dropped")
        }
        return f
    }

    /**
     * @param preserveStage W25 fix-2 — set only by the payload-arrival
     * re-realize. That pass is a deferred-resource retry, not a stage
     * re-apply: the live stage (updateStage mutations, op-added env
     * resources, LUT/effects state) carries forward instead of the
     * manifest's stale stage being re-decoded on top of it.
     */
    fun realize(manifest: ByteArray, host: Dart3dView,
                preserveStage: Boolean = false) {
        val realizeStart = System.nanoTime()
        val json = try {
            JSONObject(String(manifest, Charsets.UTF_8))
        } catch (e: Exception) {
            Log.w(TAG, "loadScene: manifest is not a JSON object"); return
        }
        val ctx = Context(host, json.optInt("fscene", 5))
        ctx.decodePayloads(json.optJSONObject("payloads"))
        if (preserveStage) ctx.payloadSpecs.putAll(host.opPayloadSpecs)
        ctx.decodeResources(json.optJSONObject("resources"))
        if (preserveStage) {
            // Op-added env resources aren't in the manifest — overlay
            // the live defs so the preserved stage's environmentRef
            // still resolves.
            ctx.environments.putAll(host.resources.environments)
        }
        // W11 before the node pass — decodeMesh attaches skinning at
        // renderable-build time, so the decoded skin records must
        // exist first (iOS attaches late via resolveSkinAttachments;
        // Filament's skinning buffer binds at Builder.build).
        ctx.decodeSkins(json.optJSONObject("skins"))
        ctx.decodeAnimations(json.optJSONObject("animations"))
        // W12: component-joint handles get re-minted per document —
        // drop the previous doc's registrations before node decode
        // re-registers (a same-session re-realize keeps command joints
        // whose bodies come back; component joints always re-decode).
        host.beginComponentJointRegistration()
        host.world.clearCharacters()
        ctx.decodeNodes(json.optJSONObject("nodes"))
        ctx.attachToScene()
        ctx.decodePhysicsDeferred()
        ctx.applyVariantComponents()
        ctx.decodeStage(if (preserveStage) host.lastStage
            else json.optJSONObject("stage"))
        // W14: after decodeStage so the stage-level quality defaults
        // are in place when views resolve theirs; rt refs resolve
        // because decodeResources already built them.
        ctx.decodeViews(json.optJSONArray("views"))
        ctx.install()
        Log.i(TAG, "realize: ${(System.nanoTime() - realizeStart) /
            1_000_000}ms")
    }

    // Upstream NodeChange field names updateNode applies.
    private val NODE_UPDATE_FLAGS = setOf(
        "transform", "name", "layers", "visible",
        "reparented", "components", "skin")

    /**
     * A Context whose registries ARE the host's live ones — decode
     * writes land directly in the installed scene state. The W5
     * command ops (addNode, updateNode, geometry upserts) run through
     * this; the manifest path builds a fresh Context and swaps at
     * install.
     */
    fun surgicalContext(host: Dart3dView): Context {
        val res = host.resources
        return Context(
            host = host,
            fsceneVersion = host.fsceneVersion,
            nodes = host.nodesById,
            geometries = res.geometries,
            gpuMeshes = host.gpuMeshes,
            materials = host.materialInstances,
            materialColors = res.materialColors,
            payloadSpecs = res.payloadSpecs,
            pendingPayloadRefs = host.pendingPayloadRefs,
            textures = res.textures,
            textureSamplers = res.textureSamplers,
            textureConsumers = res.textureConsumers,
            materialConsumers = res.materialConsumers,
            textureResources = res.textureResources,
            materialResources = res.materialResources,
            texturePayloadIds = res.texturePayloadIds,
            geometryResources = res.geometryResources,
            geometryConsumers = res.geometryConsumers,
            geometryPayloadIds = res.geometryPayloadIds,
            environments = res.environments,
            environmentPayloadIds = res.environmentPayloadIds,
            lutPayloadIds = res.lutPayloadIds,
            bodies = host.bodies,
            dynamicBodyKeys = host.dynamicBodyKeys,
            pendingParents = host.pendingParents,
            skins = res.skins,
            animations = res.animations,
            skinPayloadIds = res.skinPayloadIds,
            animPayloadIds = res.animPayloadIds,
            skinDefs = res.skinDefs,
            animDefs = res.animDefs,
            nodeSkinKeys = res.nodeSkinKeys,
            nodeSkinning = host.nodeSkinning,
            particleRuntimes = host.particleRuntimes,
            variantComponents = res.variantComponents,
            disabledComponents = res.disabledComponents,
            renderTargets = host.renderTargets,
            nodeCameraProps = host.nodeCameraProps,
            cameraFacing = host.cameraFacing,
        )
    }

    /**
     * A decoded `skins` entry (W11): joint node keys in authored
     * order, the per-joint inverse-bind matrices (column-major, already
     * S·M·S-converted to engine space; identity when the
     * `inverseBindMatrices` payload is absent — upstream's
     * null-tolerant rule), the optional skeleton root key, and
     * `awaitingIBM` while the IBM payload is still in flight (the
     * chunk's arrival re-decodes the skin surgically). A joint that
     * hasn't landed substitutes identity at bone-matrix upload —
     * upstream renders a missing joint as identity.
     */
    class DecodedSkin(
        val jointKeys: List<Long>,
        val ibms: List<FloatArray>,
        val skeletonKey: Long?,
        val awaitingIBM: Boolean,
    )

    /**
     * One animation channel's decoded timeline + values, converted to
     * engine space at decode: translation negates z, rotation takes the
     * pseudovector map (−x,−y,z,w), scale and weights pass through
     * (mirrors iOS `DecodedChannel`). `vec3` packs xyz triples,
     * `quat` packs xyzw; `weights` is the flattened
     * `targetCount`-per-key layout with trailing incomplete floats
     * dropped (upstream's rule).
     */
    class DecodedChannel(
        val target: Long,
        val targetName: String?,
        val kind: Kind,
        val times: DoubleArray,
        val vec3: FloatArray = FloatArray(0),
        val quat: FloatArray = FloatArray(0),
        val weights: FloatArray = FloatArray(0),
        val targetCount: Int = 0,
    ) {
        enum class Kind { TRANSLATION, ROTATION, SCALE, WEIGHTS }
    }

    /** W12: one decoded `materialsVariants` binding — target node +
     *  primitive index, the declared default material ref, and the
     *  variant-index → material-ref map. [applied]/[defaultMaterial]
     *  record the last write and the default in force (the rebase rule
     *  can adopt a foreign slot content as the new default). */
    class VariantBinding(
        val nodeKey: Long,
        val primitive: Int,
        val defaultMaterialKey: Long?,
        val materialsByVariant: Map<Int, Long>,
        var applied: MaterialInstance? = null,
        var defaultMaterial: MaterialInstance? = null,
        var resolved: Boolean = false,
    )

    /** W12: a decoded `materialsVariants` component — variant names,
     *  the selected name, and its (possibly pending) bindings. */
    class VariantComponent(
        val nodeKey: Long,
        val compIndex: Int,
        val variants: List<String>,
        var selected: String?,
        val bindings: MutableList<VariantBinding>,
    )

    /**
     * A decoded `animations` entry (W11): channels plus `endTime`
     * (max channel last-key — upstream's `Animation.endTime`). Clips
     * don't exist until an `anim` op asks — no autoplay.
     */
    class DecodedAnimation(
        val name: String,
        val channels: List<DecodedChannel>,
        val endTime: Double,
        val definition: AnimationDefinition,
        val properties: List<PropertyCurve>,
    )

    class MaterialColorOwner(val instance: MaterialInstance, val parameter: String,
        val value: AnimatedProperty) {
        fun write(target: MaterialInstance, color: FloatArray) {
            target.setParameter(parameter, color[0], color[1], color[2], color[3])
        }
    }

    fun materialColorOwner(instance: MaterialInstance, resource: JSONObject): MaterialColorOwner? {
        val type = resource.optString("type").ifEmpty { "physicallyBased" }
        if (type !in listOf("physicallyBased", "unlit", "d3:sprite")) return null
        val color = resource.optJSONObject("properties")?.tag("baseColor").d3Color()
            ?: floatArrayOf(1f, 1f, 1f, 1f)
        return MaterialColorOwner(instance, if (type == "d3:sprite") "tint" else "baseColor",
            AnimatedProperty(color))
    }

    class LightOwner(val entities: List<Int>, val directional: Boolean,
        val width: Float = 1f, val height: Float = 1f, val area: Boolean = false,
        intensity: Float) {
        val value = AnimatedProperty(floatArrayOf(intensity))
        fun write(manager: LightManager, intensity: Float) {
            for (entity in entities) {
                val instance = manager.getInstance(entity)
                if (directional) manager.setIntensity(instance, intensity)
                else manager.setIntensityCandela(instance, convertedIntensity(intensity))
            }
        }
        fun convertedIntensity(intensity: Float): Float =
            if (area) intensity * width * height / 4f else intensity
    }

    class NodeRec(
        val entity: Int,
        var parentKey: Long?,
        var localPos: FloatArray,
        var localQuat: FloatArray,
        var localScale: FloatArray,
        var body: Body? = null,
        var isCamera: Boolean = false,
        var hidden: Boolean = false,
        var name: String? = null,
        // Upstream 32-bit render-layer mask; realized onto the
        // renderable's 8-bit Filament layerMask.
        var layers: Int = 1,
        // Geometry the node's mesh component resolved to — colliders
        // read these for convexHull / boundingBox / triMesh shapes.
        var lastGeoPositions: FloatArray? = null,
        var lastGeoIndices: IntArray? = null,
        var lastGeoBounds: FloatArray? = null,
        // Retained mesh-component props — a geometry rebind first-builds
        // the renderable from these when the original decode hit a
        // pending geometry.
        var meshProps: JSONObject? = null,
        // Ordered geometry keys of the mesh's primitives (index =
        // renderable primitive slot). Null until the mesh builds; a
        // geometry upsert reads it for slot-aware setGeometryAt.
        var meshPrimGeoKeys: List<Long>? = null,
        // W12 rectAreaLight: the point-cluster approximation's extra
        // light entities — destroyed with the node (teardownComponents
        // / node removal).
        var lightEntities: MutableList<Int> = mutableListOf(),
        // W18: live particle emitters on this node (sprite and/or
        // mesh) — destroyed with the node's component state.
        val particleRuntimes: MutableList<ParticleRuntime> =
            mutableListOf(),
        // W11: the node's live morph weights — non-null only while a
        // renderable with a MorphTargetBuffer is attached. Written by
        // the `setMorphWeights` op and the animation sampler's
        // weights channels; pushed through
        // RenderableManager.setMorphWeights.
        var morphWeights: FloatArray? = null,
        // W15: the node's raw `instance` spec member — non-null only
        // on lazy prefab placeholders. Recorded, never decoded here:
        // loadSubtree's nested updateNode re-spec clears it and
        // unloadSubtree's restore re-tags it; the Dart layer composes
        // the subtree and streams it as ordinary ops.
        var instanceSpec: JSONObject? = null,
        // W16: the node's `trail` / `lod` runtime state — created at
        // decode, destroyed in teardownComponents/node removal/the
        // install sweep. Riding the rec means surgical contexts see
        // the same object the host does (no extra registry).
        var trail: TrailState? = null,
        var lod: LodState? = null,
        // W26: a `d3:procMesh` or inline-shape/billboard `d3:instances`
        // node's private GpuMesh — unlike the shared gpuMeshes map
        // (keyed by geometry resource), component-owned buffers die
        // with the component.
        var procGpuMesh: GpuMesh? = null,
        // E1: lazily built reflected-tangent VertexBuffer and
        // reversed-winding IndexBuffer for negative-determinant
        // GPU-instanced transforms.
        var procReflectedVertexBuffer: VertexBuffer? = null,
        var procReversedIndexBuffer: IndexBuffer? = null,
        var instanceBakedGpuMesh: GpuMesh? = null,
        // E1: extra chunk entities (parented to `entity` with identity
        // local transform) when a `d3:instances` node spans >64 GPU
        // instances or mixes positive/negative-determinant transforms.
        val instanceEntities: MutableList<Int> = mutableListOf(),
        // E1: per-chunk Filament InstanceBuffers owned by `d3:instances`.
        val instanceBuffers: MutableList<InstanceBuffer> = mutableListOf(),
        // E1: base CPU mesh + instance transforms retained so geometry-
        // derived colliders (convexHull, triMesh, concaveMesh) lazily
        // expand transformed instance geometry only when requested.
        var instanceBasePositions: FloatArray? = null,
        var instanceBaseIndices: IntArray? = null,
        var instanceTransforms: List<FloatArray>? = null,
        // E1: underlying shared MaterialInstance + per-chunk color
        // uniform arrays for `d3:instances` so `materialsVariants` and
        // material upserts update all chunks while preserving per-chunk
        // colors and `doubleSided`.
        var instanceBaseMaterial: MaterialInstance? = null,
        var lightOwner: LightOwner? = null,
        var lightDeclarations: Int = 0,
        var cameraDeclarations: Int = 0,
        val instanceChunkColors: MutableList<FloatArray?> = mutableListOf(),
        // Retained `d3:instances` props — a geometry-ref consumer
        // re-realizes when the resource upserts.
        var instancesProps: JSONObject? = null,
        // W26/E1: per-chunk duplicated MaterialInstances when a
        // `d3:instances` node carries `doubleSided` or per-instance
        // `color` uniforms; component-owned, destroyed with the
        // renderable.
        val instanceMaterialInstances: MutableList<MaterialInstance> =
            mutableListOf(),
    )

    /**
     * W16: one live `trail` component — the decoded spec plus the
     * recorded path and the ribbon renderable's engine objects. The
     * entity is UNPARENTED with identity transform: the path is
     * recorded in world space and the verts write world-space
     * directly, so the ribbon hangs where the node has been
     * (upstream's world-anchored semantics without a per-frame
     * rebase).
     */
    class TrailState(
        val entity: Int,
        val vertexBuffer: VertexBuffer,
        val indexBuffer: IndexBuffer,
        val maxPoints: Int,
        var width: Float,
        var lifetime: Float,
        var minVertexDistance: Float,
        var emitting: Boolean,
        /** `widthOverTrail` (t,v) pairs sorted by t; null → 1−t. */
        val widthKeys: FloatArray?,
        /** `colorOverTrail` (t,r,g,b,a) tuples sorted by t; null →
         *  upstream's white alpha-fade. */
        val colorStops: FloatArray?,
        /** Head-first world positions, capacity maxPoints (xyz
         *  stride). `count` entries are live. */
        val points: FloatArray,
        /** Parallel birth clock of [points] (accumulated seconds). */
        val born: DoubleArray,
        /** Staging buffer the per-frame pass refills — 2 verts per
         *  anchor × (pos f3 + color f4) × 4B = 28B/vert. */
        val staging: java.nio.ByteBuffer,
        var count: Int = 0,
        var time: Double = 0.0,
        var inScene: Boolean = false,
    )

    /** W16: one level of a decoded `lod` spec. */
    class LodLevelSpec(
        val geoKey: Long,
        val matKey: Long,
        val screenSize: Double,
    )

    /**
     * W16: a decoded `lod` component — upstream `LodComponent` (which
     * EXTENDS MeshComponent upstream: the lod owns the node's draw
     * slot, so the realized renderable swaps geometry+material per
     * selection rather than spawning level children). `bound` is the
     * level currently bound to the node's renderable — -1 while
     * culled or unbuilt; `ownsRenderable` distinguishes the lod's
     * renderable from a foreign one (a `mesh` decoded earlier) so a
     * takeover rebuilds instead of slot-swapping; `suspended` marks
     * a later `mesh` decode taking the slot back (last-write-wins —
     * iOS's `node.geometry` overwrite order). `hysteresis` is
     * upstream's dead-band fraction (wire default 0.1) — applied by
     * [selectLodLevel] with `bound` as its memory. `blendRange`
     * decodes for wire parity but is a documented no-op — upstream's
     * cross-fade needs a per-material dither slot Filament doesn't
     * carry here, so dart3d hard-switches.
     */
    class LodState(
        val levels: List<LodLevelSpec>,
        var lodBias: Double,
        var hysteresis: Double,
        var blendRange: Double,
        var bound: Int = -1,
        var boundMatKey: Long? = null,
        var ownsRenderable: Boolean = false,
        var suspended: Boolean = false,
    )

    /**
     * Decode scope for one realize pass — or, when seeded with the
     * host's live maps via [surgicalContext], the vehicle for the W5
     * surgical ops (addNode/updateNode/geometry upserts) whose decode
     * writes land directly in the installed registries.
     */
    class Context(
        val host: Dart3dView,
        private val fsceneVersion: Int,
        val nodes: MutableMap<Long, NodeRec> = LinkedHashMap(),
        val geometries: MutableMap<Long, MeshFactory.MeshData> = HashMap(),
        val gpuMeshes: MutableMap<Long, GpuMesh> = HashMap(),
        val materials: MutableMap<Long, MaterialInstance> = HashMap(),
        val materialColors: MutableMap<Long, MaterialColorOwner> = HashMap(),
        val payloadSpecs: MutableMap<Long, PayloadMeta> = HashMap(),
        val pendingPayloadRefs: MutableSet<Long> = HashSet(),
        // W4: texture uploads + the binding maps the host's surgical
        // upsert ops replay. textureConsumers: texKey → (instance, slot
        // param name); materialConsumers: matKey → (renderable entity,
        // primitive slot) pairs — a multi-primitive mesh binds its
        // material at its own slot, not slot 0.
        // W14: textureSamplers carries a per-resource sampler (a
        // renderTexture's own filter/wrap) consulted at bind + rebind;
        // absent → the shared host.textureSampler.
        val textures: MutableMap<Long, Texture> = HashMap(),
        val textureSamplers: MutableMap<Long, TextureSampler> = HashMap(),
        val textureConsumers: MutableMap<Long,
            MutableList<Pair<MaterialInstance, String>>> = HashMap(),
        val materialConsumers: MutableMap<Long,
            MutableList<Pair<Int, Int>>> = HashMap(),
        val textureResources: MutableMap<Long, JSONObject> = HashMap(),
        val materialResources: MutableMap<Long, JSONObject> = HashMap(),
        val bakedCatcherSettings: MutableMap<Long,
            ShadowCatcherSettings> = LinkedHashMap(),
        val texturePayloadIds: MutableMap<Long, Long> = HashMap(),
        // W5: geometry decode state. geometryConsumers: geoKey → node
        // keys; geometryPayloadIds: geoKey → the payload keys it
        // decodes from.
        val geometryResources: MutableMap<Long, JSONObject> = HashMap(),
        val geometryConsumers: MutableMap<Long,
            MutableSet<Long>> = HashMap(),
        val geometryPayloadIds: MutableMap<Long,
            MutableSet<Long>> = HashMap(),
        // W7: `kind:"environment"` resource defs (the stage consumes
        // them — they hold no realized object of their own) and the
        // envKey → payloadKey claims an `upsertPayload` chunk
        // satisfies by re-running decodeStage.
        val environments: MutableMap<Long, JSONObject> = HashMap(),
        val environmentPayloadIds: MutableMap<Long, Long> = HashMap(),
        // W25: envKey → payloadKey claims for the env resource's
        // `effects.colorGrading.lut` `.cube` table — an arriving chunk
        // re-runs decodeStage like an env equirect claim. Asset-path
        // LUT refs don't claim; the host resolves them from the app
        // assets at apply time.
        val lutPayloadIds: MutableMap<Long, Long> = HashMap(),
        val bodies: MutableMap<Long, Body> = HashMap(),
        val dynamicBodyKeys: MutableSet<Long> = HashSet(),
        // Children whose addNode predated their parent's — childKey →
        // parentKey; resolved as parents land (ops are
        // order-independent within a batch).
        val pendingParents: MutableMap<Long, Long> = HashMap(),
        // W11: decoded skin + animation defs, their payload claims
        // (skinKey → IBM payload key; animKey → the channel payload
        // keys it reads), the raw defs a surgical re-decode replays,
        // and the nodeKey → skinKey binding declared by a node's
        // `skin` member. The `skin` binding is a node MEMBER, not a
        // component — it survives `components` rebuilds like iOS's
        // `nodeSkinKeys`.
        val skins: MutableMap<Long, DecodedSkin> = HashMap(),
        val animations: MutableMap<Long, DecodedAnimation> = HashMap(),
        val skinPayloadIds: MutableMap<Long, Long> = HashMap(),
        val animPayloadIds: MutableMap<Long, MutableSet<Long>> = HashMap(),
        val skinDefs: MutableMap<Long, JSONObject> = HashMap(),
        val animDefs: MutableMap<Long, JSONObject> = HashMap(),
        val nodeSkinKeys: MutableMap<Long, Long> = HashMap(),
        // W12: decoded materialsVariants components (declaring nodeKey
        // → spec) and the enabled:false component marks. Surgical
        // contexts alias the host's installed maps.
        val variantComponents: MutableMap<Long, VariantComponent> =
            HashMap(),
        val disabledComponents: MutableMap<Long, MutableSet<Int>> =
            HashMap(),
        // The skinning buffers `decodeMesh` builds — a manifest
        // Context owns a fresh map swapped onto the host at install;
        // a surgical Context aliases the host's live one. Keeps the
        // install teardown from destroying buffers decoded in the
        // same pass.
        val nodeSkinning: MutableMap<Long, Dart3dView.NodeSkin> = HashMap(),
        val cameraFacing: MutableMap<Long, FacingSpec> = HashMap(),
        // W18: nodeKey → live particle runtimes. Same ownership as
        // nodeSkinning — a manifest Context's fresh map swaps onto the
        // host at install; a surgical Context aliases the live one.
        val particleRuntimes: MutableMap<Long,
            MutableList<ParticleRuntime>> = HashMap(),
        // W14: `rt:` key → live RenderTarget rec (built eagerly in
        // decodeResources pass 1 so materials bind the color texture);
        // every camera node's decoded props (per-view projections);
        // and the decoded `views` list install hands to the host.
        val renderTargets: MutableMap<Long, RenderTargets.RenderTargetRec> =
            HashMap(),
        val nodeCameraProps: MutableMap<Long, RenderTargets.CameraSpec> =
            HashMap(),
        val views: MutableList<RenderTargets.ViewRec> = ArrayList(),
    ) {
        data class PayloadMeta(
            val encoding: String,
            val layout: String?,
            val format: String?,
            val width: Int? = null,   // image payloads (W4): pixel width
            val height: Int? = null,  // image payloads (W4): pixel height
            val length: Int? = null,  // declared byte length (rgba8 check)
        )

        /**
         * The resource dictionaries handed to the host at install so the
         * `upsertResource`/`upsertPayload` ops can re-decode and rebind
         * without a scene re-realize.
         */
        class InstalledResources(
            val materialColors: MutableMap<Long, MaterialColorOwner> = HashMap(),
            val textures: MutableMap<Long, Texture> = HashMap(),
            val textureSamplers: MutableMap<Long, TextureSampler> =
                HashMap(),
            val textureConsumers: MutableMap<Long,
                MutableList<Pair<MaterialInstance, String>>> = HashMap(),
            val materialConsumers: MutableMap<Long,
                MutableList<Pair<Int, Int>>> = HashMap(),
            val textureResources: MutableMap<Long, JSONObject> = HashMap(),
            val materialResources: MutableMap<Long, JSONObject> = HashMap(),
            val texturePayloadIds: MutableMap<Long, Long> = HashMap(),
            val geometries: MutableMap<Long,
                MeshFactory.MeshData> = HashMap(),
            val geometryResources: MutableMap<Long, JSONObject> = HashMap(),
            val geometryConsumers: MutableMap<Long,
                MutableSet<Long>> = HashMap(),
            val geometryPayloadIds: MutableMap<Long,
                MutableSet<Long>> = HashMap(),
            val environments: MutableMap<Long, JSONObject> = HashMap(),
            val environmentPayloadIds: MutableMap<Long, Long> = HashMap(),
            val lutPayloadIds: MutableMap<Long, Long> = HashMap(),
            val payloadSpecs: MutableMap<Long, PayloadMeta> = HashMap(),
            val skins: MutableMap<Long, DecodedSkin> = HashMap(),
            val animations: MutableMap<Long, DecodedAnimation> = HashMap(),
            val skinPayloadIds: MutableMap<Long, Long> = HashMap(),
            val animPayloadIds: MutableMap<Long,
                MutableSet<Long>> = HashMap(),
            val skinDefs: MutableMap<Long, JSONObject> = HashMap(),
            val animDefs: MutableMap<Long, JSONObject> = HashMap(),
            val nodeSkinKeys: MutableMap<Long, Long> = HashMap(),
            val variantComponents: MutableMap<Long, VariantComponent> =
                HashMap(),
            val disabledComponents:
                MutableMap<Long, MutableSet<Int>> = HashMap(),
        ) {
            /**
             * W25 fix-2: true when chunk [id] is awaited by a ref still
             * in [pending] — texture (`tex → payload`) or geometry
             * (`geo → payload-set`) claims are the only pending kinds
             * `applyPayload` has no surgical handler for. Env equirect,
             * LUT, skin, and animation claims are consumed surgically
             * before this check runs, so they never gate the manifest
             * re-realize — and a pending ref whose chunk never lands
             * must not keep re-arming it (the re-realize re-decodes the
             * manifest's stale stage and reverts the live stage's
             * LUT/effects mutations).
             */
            fun pendingClaims(id: Long, pending: Set<Long>): Boolean =
                pending.any {
                    texturePayloadIds[it] == id ||
                        geometryPayloadIds[it]?.contains(id) == true
                }
        }

        var firstCameraKey: Long? = null
        var cameraProps: JSONObject? = null
        val nodeWorld = HashMap<Long, FloatArray>()

        /// Set by `decodeStage` when the env's equirect payload hasn't
        /// arrived — the stage application defers the env + the
        /// `environment`-sourced skybox until the chunk lands (mirrors
        /// iOS's stageEnvDeferred).
        var stageEnvDeferred = false

        private data class PhysicsItem(
            val key: Long, val rec: NodeRec,
            val type: String, val props: JSONObject,
        )
        private val physicsDeferred = ArrayList<PhysicsItem>()

        /** W12: a declarative joint component awaiting the physics
         *  pass — [index] is its position in the node's component list
         *  so a re-decode replaces exactly its own registration. */
        private data class JointItem(
            val key: Long, val index: Int,
            val type: String, val props: JSONObject,
        )
        private val jointComponentsDeferred = ArrayList<JointItem>()

        private val em get() = EntityManager.get()
        private val tcm get() = host.engine.transformManager

        // MARK: Resources

        fun decodePayloads(map: JSONObject?) {
            if (map == null) return
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val spec = map.optJSONObject(token) ?: continue
                payloadSpecs[key] = PayloadMeta(
                    encoding = spec.optString("encoding"),
                    layout = spec.optString("layout").takeIf { it.isNotEmpty() },
                    format = spec.optString("format").takeIf { it.isNotEmpty() },
                    width = (spec.opt("width") as? Number)?.toInt(),
                    height = (spec.opt("height") as? Number)?.toInt(),
                    length = (spec.opt("length") as? Number)?.toInt(),
                )
            }
        }

        fun decodeResources(map: JSONObject?) {
            if (map == null) return
            // Pass 1: textures + environments + render textures, so a
            // material decoding in pass 2 sees its `*Texture` refs —
            // including {'rref':'rt:…'} color textures — already
            // uploaded regardless of manifest ordering.
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val r = map.optJSONObject(token) ?: continue
                when (r.optString("kind")) {
                    "texture" -> decodeTexture(key, r)
                    "environment" -> environments[key] = r
                    "renderTexture" -> decodeRenderTexture(key, r)
                }
            }
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val r = map.optJSONObject(token) ?: continue
                when (r.optString("kind")) {
                    "geometry" -> decodeGeometry(key, r)
                    "material" -> decodeMaterial(key, r)
                    "texture", "environment", "renderTexture" -> {} // pass 1
                    else -> Log.i(TAG, "unknown resource kind '${r.optString("kind")}'")
                }
            }
        }

        /**
         * W14: a `renderTexture` resource → a live RenderTarget rec —
         * the textures + RenderTarget are built eagerly here (pass 1)
         * so pass-2 material decode can bind `{'rref':'rt:…'}`. The
         * color texture also keys into `textures` (rec-owned — the
         * host's texture sweeps skip rt keys) and its spec sampler into
         * `textureSamplers`.
         */
        private fun decodeRenderTexture(key: Long, r: JSONObject) {
            val spec = RenderTargets.decodeSpec(key, r) ?: return
            val rec = RenderTargets.build(host.engine, spec)
            renderTargets[key] = rec
            textures[key] = rec.colorTex
            textureSamplers[key] = rec.sampler
        }

        /**
         * Stored bytes must match the manifest's declared `length` —
         * a mismatch means the chunk under [payloadKey] isn't this
         * document's (a stale key from a previous doc, or a partial
         * write), so the consumer defers until the real chunk lands
         * rather than decoding garbage. Undeclared lengths pass.
         */
        private fun payloadLengthMatches(
            key: Long, payloadKey: Long, meta: PayloadMeta, bytes: ByteArray,
        ): Boolean {
            val declared = meta.length ?: return true
            if (declared == bytes.size) return true
            warnOnce("geometry:$key:payloadLen.$payloadKey",
                "geometry $key: payload $payloadKey is ${bytes.size} B, " +
                    "manifest declares $declared B — awaiting real chunk")
            return false
        }

        private fun decodeGeometry(key: Long, r: JSONObject) {
            geometryResources[key] = r
            val proc = r.optJSONObject("procedural")
            if (proc != null) {
                val shape = proc.optString("shape")
                val md = procedural(key, shape, proc)
                if (md != null) geometries[key] = md
                geometryPayloadIds.remove(key)
                return
            }

            val vertexToken = r.optString("vertices")
            val vertexKey = D3Wire.localIdKey(vertexToken)
            val indexToken = r.optString("indices").takeIf { it.isNotEmpty() }
            val indexKey = indexToken?.let { D3Wire.localIdKey(it) }
            // Record the payload linkage even while a chunk is missing —
            // upsertPayload finds claiming geometries through this map.
            val payloadIds = LinkedHashSet<Long>()
            vertexKey?.let(payloadIds::add)
            indexKey?.let(payloadIds::add)
            if (payloadIds.isEmpty()) geometryPayloadIds.remove(key)
            else geometryPayloadIds[key] = payloadIds
            if (vertexToken.isEmpty() || vertexKey == null) {
                warnOnce("geometry:$key:vertices",
                    "geometry $key: missing or invalid vertices payload token")
                return
            }
            val vertexMeta = payloadSpecs[vertexKey]
            if (vertexMeta == null) {
                warnOnce("geometry:$key:vertexSpec",
                    "geometry $key: payload '$vertexToken' has no manifest spec")
                return
            }
            if (vertexMeta.encoding != "vertexBuffer") {
                warnOnce("geometry:$key:vertexEncoding",
                    "geometry $key: vertices payload encoding '${vertexMeta.encoding}' is not vertexBuffer")
                return
            }
            val vertexBytes = host.payloadStore[vertexKey]
            if (vertexBytes == null ||
                !payloadLengthMatches(key, vertexKey, vertexMeta, vertexBytes)) {
                pendingPayloadRefs.add(key)
                Log.i(TAG, "geometry $key: awaiting payload")
                return
            }

            var indexMeta: PayloadMeta? = null
            var indexBytes: ByteArray? = null
            if (indexToken != null) {
                if (indexKey == null) {
                    warnOnce("geometry:$key:indexToken",
                        "geometry $key: invalid indices payload token '$indexToken'")
                    return
                }
                indexMeta = payloadSpecs[indexKey]
                if (indexMeta == null) {
                    warnOnce("geometry:$key:indexSpec",
                        "geometry $key: payload '$indexToken' has no manifest spec")
                    return
                }
                if (indexMeta.encoding != "indexBuffer") {
                    warnOnce("geometry:$key:indexEncoding",
                        "geometry $key: indices payload encoding '${indexMeta.encoding}' is not indexBuffer")
                    return
                }
                indexBytes = host.payloadStore[indexKey]
                if (indexBytes == null ||
                    !payloadLengthMatches(key, indexKey, indexMeta, indexBytes)) {
                    pendingPayloadRefs.add(key)
                    Log.i(TAG, "geometry $key: awaiting payload")
                    return
                }
            }

            val topology = decodeTopology(key, r.optString("topology", "triangle"))
                ?: return
            val isP3t4 = vertexMeta.layout == "p3t4"
            if (indexToken == null) {
                logOnce("geometry:$key:nonIndexed",
                    "geometry $key: non-indexed winding migration is not implemented; using sequential indices")
            }
            if (topology == MeshFactory.Topology.TRIANGLE_STRIP) {
                logOnce("geometry:$key:triangleStrip",
                    "geometry $key: triangleStrip winding migration is not implemented; using data as-is")
            }
            val start = System.nanoTime()
            try {
                val swapWinding = !isP3t4 && indexToken != null &&
                    topology == MeshFactory.Topology.TRIANGLES &&
                    !r.optBoolean("legacyWinding", false) && fsceneVersion >= 5
                val md = MeshFactory.fromPayload(
                    vertexBytes = vertexBytes,
                    layout = vertexMeta.layout,
                    indexBytes = indexBytes,
                    indexFormat = indexMeta?.format,
                    topology = topology,
                    swapTriangleWinding = swapWinding,
                    wireBounds = decodeGeometryBounds(key, r.optJSONObject("bounds")),
                )
                // W11 morph deltas — decoded alongside the base mesh;
                // a missing/short payload keeps the base either way
                // (iOS decodeMorphTargets defers rather than failing
                // the geometry).
                decodeMorphTargets(key, r, md, vertexBytes, vertexMeta.layout)
                geometries[key] = md
                val elapsedMs = (System.nanoTime() - start) / 1_000_000
                Log.i(TAG, "geometry $key: decoded ${md.vertexCount} verts in ${elapsedMs}ms")
            } catch (e: MeshFactory.PayloadDecodeException) {
                warnOnce("geometry:$key:decode:${e.message}",
                    "geometry $key: ${e.message}")
            } catch (e: Exception) {
                warnOnce("geometry:$key:decode:${e.javaClass.name}",
                    "geometry $key: payload decode failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }

        /**
         * Decodes a geometry's `morphTargets` block (W11) onto
         * [MeshData.morph]. The deltas payload is another claim on the
         * geometry — recorded before resolution so an `upsertPayload`
         * chunk re-decodes the whole resource (mirrors iOS
         * `decodeMorphTargets`, which appends the delta pid to
         * `geometryPayloadKeys`). Malformed specs, missing payloads and
         * short slabs all leave `morph` null — the base mesh stands.
         */
        private fun decodeMorphTargets(
            key: Long, r: JSONObject, md: MeshFactory.MeshData,
            vertexBytes: ByteArray, layout: String?,
        ) {
            val m = r.optJSONObject("morphTargets") ?: return
            val pid = m.optString("deltas").takeIf { it.isNotEmpty() }
                ?.let { D3Wire.localIdKey(it) }
            val targetCount = m.optInt("targetCount", 0)
            if (pid == null || targetCount <= 0) {
                logOnce("geometry:$key:morph.malformed",
                    "geometry $key: morphTargets lacks deltas/targetCount")
                return
            }
            // Claim before resolution — an upsertPayload chunk
            // re-decodes this whole geometry on arrival.
            geometryPayloadIds.getOrPut(key) { LinkedHashSet() }.add(pid)
            val data = host.payloadStore[pid]
            if (data == null) {
                pendingPayloadRefs.add(key)
                logOnce("geometry:$key:morph.awaiting",
                    "geometry $key: awaiting morph delta payload")
                return
            }
            val defaults = m.optJSONArray("weights")?.toFloatArray()
                ?: FloatArray(0)
            try {
                md.morph = MeshFactory.morphDataFromPayload(
                    deltaBytes = data,
                    targetCount = targetCount,
                    hasNormalDeltas = m.optBoolean("normals"),
                    hasTangentDeltas = m.optBoolean("tangents"),
                    vertexBytes = vertexBytes,
                    layout = layout,
                    defaultWeights = defaults,
                )
            } catch (e: MeshFactory.PayloadDecodeException) {
                warnOnce("geometry:$key:morph.decode",
                    "geometry $key: ${e.message}")
            } catch (e: Exception) {
                warnOnce("geometry:$key:morph.${e.javaClass.name}",
                    "geometry $key: morph decode failed: ${e.message}")
            }
        }

        private fun decodeTopology(key: Long, raw: String): MeshFactory.Topology? =
            when (raw.ifEmpty { "triangle" }) {
                "triangle" -> MeshFactory.Topology.TRIANGLES
                "triangleStrip" -> MeshFactory.Topology.TRIANGLE_STRIP
                "line" -> MeshFactory.Topology.LINES
                "lineStrip" -> MeshFactory.Topology.LINE_STRIP
                "point" -> MeshFactory.Topology.POINTS
                else -> {
                    warnOnce("geometry:$key:topology:$raw",
                        "geometry $key: unknown topology '$raw'")
                    null
                }
            }

        private fun decodeGeometryBounds(key: Long, bounds: JSONObject?): FloatArray? {
            if (bounds == null) return null
            val min = bounds.optJSONArray("min")
            val max = bounds.optJSONArray("max")
            if (min == null || max == null || min.length() < 3 || max.length() < 3) {
                warnOnce("geometry:$key:bounds", "geometry $key: malformed bounds; scanning positions")
                return null
            }
            val minX = minOf(min.optDouble(0), max.optDouble(0)).toFloat()
            val maxX = maxOf(min.optDouble(0), max.optDouble(0)).toFloat()
            val minY = minOf(min.optDouble(1), max.optDouble(1)).toFloat()
            val maxY = maxOf(min.optDouble(1), max.optDouble(1)).toFloat()
            val nativeMinZ = -maxOf(min.optDouble(2), max.optDouble(2)).toFloat()
            val nativeMaxZ = -minOf(min.optDouble(2), max.optDouble(2)).toFloat()
            return floatArrayOf(
                (minX + maxX) * 0.5f,
                (minY + maxY) * 0.5f,
                (nativeMinZ + nativeMaxZ) * 0.5f,
                (maxX - minX) * 0.5f,
                (maxY - minY) * 0.5f,
                (nativeMaxZ - nativeMinZ) * 0.5f,
            )
        }

        /** Segment-count params clamp to 1..[MAX_PROC_SEGMENTS] — a
         *  zero/negative on the wire would NaN the generators'
         *  `s / segments` divisions (FsceneRealizer.swift's `seg` does
         *  the same); an unbounded count hangs/OOMs the decode. */
        private fun seg(p: JSONObject, name: String, def: Int,
                        min: Int = 1, max: Int = MAX_PROC_SEGMENTS): Int {
            val raw = p.tag(name).d3Int() ?: def
            val v = raw.coerceIn(min, max)
            if (v != raw) {
                warnOnce("proc.clamp.$name",
                    "procedural '$name'=$raw clamped to $v ($min..$max)")
            }
            return v
        }

        private fun procedural(
            key: Long, shape: String, p: JSONObject,
        ): MeshFactory.MeshData? {
            when (shape) {
                "cuboid" -> {
                    val e = p.tag("extents").d3Vec3() ?: doubleArrayOf(1.0, 1.0, 1.0)
                    return MeshFactory.cuboid(
                        e[0].toFloat(), e[1].toFloat(), e[2].toFloat(),
                        p.tag("debugColors").d3Bool() == true)
                }
                "wedge" -> {
                    val size = p.tag("size").d3Vec3()
                        ?: doubleArrayOf(1.0, 1.0, 1.0)
                    return MeshFactory.wedge(MeshFactory.V3(
                        size[0].toFloat(), size[1].toFloat(), size[2].toFloat()))
                }
                "ring" -> {
                    val innerRadius =
                        (p.tag("innerRadius").d3Double() ?: 0.25).toFloat()
                    val outerRadius =
                        (p.tag("outerRadius").d3Double() ?: 0.5).toFloat()
                    if (innerRadius < 0f || outerRadius <= 0f ||
                        innerRadius >= outerRadius) {
                        Log.w(TAG, "ring: requires 0 <= innerRadius < outerRadius")
                        return null
                    }
                    return MeshFactory.ring(
                        innerRadius, outerRadius, seg(p, "segments", 32, min = 3))
                }
                "sphere" -> return MeshFactory.sphere(
                    (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                    seg(p, "segments", 32), seg(p, "rings", 16))
                "icosphere" -> {
                    // W26: a real subdivided icosahedron replaces the
                    // UV-sphere stand-in (same algorithm proc.dart +
                    // GeometryFactory.swift generate).
                    return MeshFactory.icosphere(
                        (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                        seg(p, "subdivisions", 2, min = 0,
                            max = MAX_ICOSPHERE_SUBDIVISIONS))
                }
                "plane" -> return MeshFactory.plane(
                    (p.tag("width").d3Double() ?: 1.0).toFloat(),
                    (p.tag("depth").d3Double() ?: 1.0).toFloat(),
                    seg(p, "segmentsX", 1), seg(p, "segmentsZ", 1))
                "torus" -> return MeshFactory.torus(
                    (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                    (p.tag("tubeRadius").d3Double() ?: 0.15).toFloat(),
                    seg(p, "radialSegments", 32),
                    seg(p, "tubularSegments", 16))
                // W26 vocabulary — `d3:procMesh` components and
                // upstream-style `procedural` geometry resources share
                // the same shape/param names.
                "cylinder" -> return MeshFactory.cylinder(
                    (p.tag("bottomRadius").d3Double() ?: 0.5).toFloat(),
                    (p.tag("topRadius").d3Double() ?: 0.5).toFloat(),
                    (p.tag("height").d3Double() ?: 1.0).toFloat(),
                    seg(p, "radialSegments", 32, min = 3),
                    seg(p, "heightSegments", 1),
                    p.tag("bottomCap").d3Bool() != false,
                    p.tag("topCap").d3Bool() != false)
                "cone" -> return MeshFactory.cylinder(
                    (p.tag("radius").d3Double() ?: 0.5).toFloat(), 0f,
                    (p.tag("height").d3Double() ?: 1.0).toFloat(),
                    seg(p, "radialSegments", 32, min = 3),
                    seg(p, "heightSegments", 1),
                    p.tag("bottomCap").d3Bool() != false, false)
                "capsule" -> return MeshFactory.capsule(
                    (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                    (p.tag("height").d3Double() ?: 1.0).toFloat(),
                    seg(p, "radialSegments", 32, min = 3),
                    seg(p, "capRings", 8))
                "disc" -> return MeshFactory.disc(
                    (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                    seg(p, "segments", 32, min = 3))
                "extrude" -> {
                    val pts = d3PointList(p, "points")
                    val profile = d3ProfileList(p, "profile")
                    if (pts == null || pts.size < 2 ||
                        profile == null || profile.size < 3) {
                        Log.w(TAG, "extrude: needs at least two path points and three profile points")
                        return null
                    }
                    return MeshFactory.extrude(
                        pts, profile,
                        seg(p, "stations", 64, min = 2),
                        p.tag("caps").d3Bool() != false)
                }
                "tube" -> {
                    val pts = d3PointList(p, "points")
                    if (pts == null || pts.size < 2) {
                        Log.w(TAG, "tube: needs at least two points")
                        return null
                    }
                    // The generator divides by both counts and its caps
                    // read the first/last frame — Dart requires ≥3
                    // radial segments and ≥2 stations.
                    return MeshFactory.tube(pts,
                        (p.tag("radius").d3Double() ?: 0.5).toFloat(),
                        seg(p, "radialSegments", 12, min = MIN_TUBE_RADIAL),
                        seg(p, "stations", 64, min = 2),
                        p.tag("caps").d3Bool() != false,
                        p.tag("closed").d3Bool() == true)
                }
                "ribbon" -> {
                    val pts = d3PointList(p, "points")
                    if (pts == null || pts.size < 2) {
                        Log.w(TAG, "ribbon: needs at least two points")
                        return null
                    }
                    val u = p.tag("up").d3Vec3()
                        ?: doubleArrayOf(0.0, 1.0, 0.0)
                    return MeshFactory.ribbon(pts,
                        (p.tag("width").d3Double() ?: 1.0).toFloat(),
                        seg(p, "stations", 64, min = 2),
                        MeshFactory.V3(
                            u[0].toFloat(), u[1].toFloat(), -u[2].toFloat()),
                        p.tag("closed").d3Bool() == true)
                }
                in FACING_SHAPES -> {
                    // A camera-facing shape as a static geometry
                    // resource can't reface per frame — bake once
                    // toward +Z, the same fallback the instances
                    // path uses.
                    logOnce("geometry.facing.$shape",
                        "geometry $key: camera-facing shape '$shape'" +
                            " bakes once toward +Z")
                    val fp = parseFacing(key, p)
                    warnFacingDrops("geometry", "geometry",
                        key, shape, p, fp)
                    return facingMesh(shape, fp,
                        MeshFactory.V3(0f, 0f, 1f),
                        MeshFactory.V3(1f, 0f, 0f),
                        MeshFactory.V3(0f, 1f, 0f))
                }
                else -> { Log.w(TAG, "unknown procedural shape '$shape'"); return null }
            }
        }

        // MARK: W26 `d3:procMesh` / `d3:instances`

        /** `d3:procMesh` shapes that re-expand toward the live camera
         *  each frame — the rest build once like the upstream
         *  procedural resources above. */
        private val FACING_SHAPES = setOf(
            "polyline", "lineSegments", "billboard")

        /** A `{'v3':[…]}` (or bare `[x,y,z]`) list → native-space
         *  points (z-mirrored at the wire boundary, like every vertex
         *  source). */
        private fun d3PointList(
            p: JSONObject, key: String,
        ): List<MeshFactory.V3>? {
            val list = p.tag(key).d3List() ?: return null
            val out = ArrayList<MeshFactory.V3>(list.length())
            for (i in 0 until list.length()) {
                val v = list.opt(i).d3Vec3() ?: return null
                if (v.size < 3) return null
                out.add(MeshFactory.V3(
                    v[0].toFloat(), v[1].toFloat(), -v[2].toFloat()))
            }
            return out
        }

        private fun d3ProfileList(
            p: JSONObject, key: String,
        ): List<MeshFactory.V2>? {
            val list = p.tag(key).d3List() ?: return null
            val out = ArrayList<MeshFactory.V2>(list.length())
            for (i in 0 until list.length()) {
                val v = list.opt(i).d3Vec2() ?: return null
                if (v.size < 2) return null
                out.add(MeshFactory.V2(v[0].toFloat(), v[1].toFloat()))
            }
            return out
        }

        /** A `{'c':[rgba]}` (or bare `[r,g,b,a]`) list →
         *  per-point colors. */
        private fun d3ColorList(p: JSONObject, key: String): List<FloatArray>? {
            val list = p.tag(key).d3List() ?: return null
            val out = ArrayList<FloatArray>(list.length())
            for (i in 0 until list.length()) {
                out.add(list.opt(i).d3Color() ?: return null)
            }
            return out
        }

        /** A `{'d':x}` (or bare number) list → per-point
         *  widths. */
        private fun d3FloatList(p: JSONObject, key: String): List<Float>? {
            val list = p.tag(key).d3List() ?: return null
            val out = ArrayList<Float>(list.length())
            for (i in 0 until list.length()) {
                out.add((list.opt(i).d3Double() ?: return null)
                    .toFloat())
            }
            return out
        }

        /** The parsed parameters of a camera-facing shape — retained
         *  so stepFrame can re-expand the vertex buffer toward the
         *  live camera basis each frame. `facing` is the billboard
         *  mode (`spherical`/`axisY`/`screen`). */
        private class FacingParams(
            val points: List<MeshFactory.V3>,
            val colors: List<FloatArray>?,
            val widths: List<Float>?,
            val width: Float,
            val dashes: DoubleArray?,
            val closed: Boolean,
            val sizeX: Float, val sizeY: Float,
            val rotation: Float,
            val tint: FloatArray,
            val facing: String,
        )

        /** The billboard facing modes the wire recognizes — anything
         *  else warns once and falls back to `spherical`, the
         *  Dart-side default (mirrors FsceneRealizer.facingMode). */
        private fun facingMode(key: Long, raw: String?): String = when (raw) {
            null, "spherical" -> "spherical"
            "axisY", "screen" -> raw
            else -> {
                warnOnce("facing.$key.$raw",
                    "node $key: unknown billboard facing '$raw'" +
                        " — using spherical")
                "spherical"
            }
        }

        private fun parseFacing(key: Long, p: JSONObject): FacingParams {
            val s = p.tag("size").d3Vec2() ?: doubleArrayOf(1.0, 1.0)
            return FacingParams(
                points = d3PointList(p, "points") ?: emptyList(),
                colors = d3ColorList(p, "colors"),
                widths = d3FloatList(p, "widths"),
                width = (p.tag("width").d3Double() ?: 1.0).toFloat(),
                dashes = p.tag("dashes").d3Vec2(),
                closed = p.tag("closed").d3Bool() == true,
                sizeX = s[0].toFloat(), sizeY = s[1].toFloat(),
                rotation = (p.tag("rotation").d3Double() ?: 0.0).toFloat(),
                tint = p.tag("color").d3Color()
                    ?: floatArrayOf(1f, 1f, 1f, 1f),
                facing = facingMode(key, p.tag("facing").d3String()))
        }

        /** Builds a facing mesh for [shape] from [fp] expanded along
         *  the supplied basis — the decode-time call uses a neutral
         *  viewDir; stepFrame's re-expansion passes the live camera
         *  basis + node-local camera position in. */
        private fun facingMesh(
            shape: String, fp: FacingParams,
            viewDir: MeshFactory.V3,
            right: MeshFactory.V3, up: MeshFactory.V3,
            camPos: MeshFactory.V3 = MeshFactory.V3(0f, 0f, 1f),
        ): MeshFactory.MeshData? = when (shape) {
            "polyline" ->
                if (fp.dashes != null) MeshFactory.dashedPolyline(
                    fp.points, fp.width, viewDir,
                    fp.dashes[0].toFloat(), fp.dashes[1].toFloat(),
                    fp.colors, fp.widths, fp.closed)
                else MeshFactory.polyline(
                    fp.points, fp.width, viewDir,
                    fp.colors, fp.widths, fp.closed)
            "lineSegments" -> MeshFactory.lineSegments(
                fp.points, fp.width, viewDir, fp.colors)
            "billboard" -> MeshFactory.billboardQuad(
                fp.sizeX, fp.sizeY, fp.rotation, fp.tint, right, up,
                facing = fp.facing, camPos = camPos)
            else -> null
        }

        /** Component-owned renderable/buffer teardown for the W26
         *  decoders — unlike mesh nodes (shared gpuMeshes rebound in
         *  place), a proc/instances re-decode replaces its private
         *  buffers wholesale. */
        fun destroyProcRenderable(key: Long, rec: NodeRec) {
            // The facing entry points at procGpuMesh's VertexBuffer —
            // drop it with the buffer, or an empty rebake (which
            // returns before re-registering) leaves updateCameraFacing
            // uploading into a destroyed buffer.
            cameraFacing.remove(key)
            // The rebuild re-registers its (entity, 0) consumer pairs —
            // drop the old ones first, or repeated payload rebakes grow
            // the list and a material upsert rebinds the slot N times.
            for ((_, list) in materialConsumers) {
                list.removeAll {
                    it.first == rec.entity || it.first in rec.instanceEntities
                }
            }
            val rm = host.engine.renderableManager
            if (rm.hasComponent(rec.entity)) rm.destroy(rec.entity)
            for (ie in rec.instanceEntities) {
                host.scene.remove(ie)
                if (rm.hasComponent(ie)) rm.destroy(ie)
                tcm.destroy(ie)
                host.engine.destroyEntity(ie)
                em.destroy(ie)
            }
            rec.instanceEntities.clear()
            for (ib in rec.instanceBuffers) {
                host.engine.destroyInstanceBuffer(ib)
            }
            rec.instanceBuffers.clear()
            rec.procGpuMesh?.let {
                it.destroy(host.engine)
                rec.procGpuMesh = null
            }
            rec.procReflectedVertexBuffer?.let {
                host.engine.destroyVertexBuffer(it)
                rec.procReflectedVertexBuffer = null
            }
            rec.procReversedIndexBuffer?.let {
                host.engine.destroyIndexBuffer(it)
                rec.procReversedIndexBuffer = null
            }
            rec.instanceBakedGpuMesh?.let {
                it.destroy(host.engine)
                rec.instanceBakedGpuMesh = null
            }
            rec.instanceBasePositions = null
            rec.instanceBaseIndices = null
            rec.instanceTransforms = null
            rec.instanceBaseMaterial = null
            rec.instanceChunkColors.clear()
            if (rec.instanceMaterialInstances.isNotEmpty()) {
                for ((_, list) in textureConsumers) {
                    list.removeAll { it.first in rec.instanceMaterialInstances }
                }
                for (dup in rec.instanceMaterialInstances) {
                    host.engine.destroyMaterialInstance(dup)
                }
                rec.instanceMaterialInstances.clear()
            }
        }

        /**
         * Wire fields the facing-shape expanders can't honor —
         * warned once per node on EVERY path that parses a facing
         * shape (procMesh component, procedural resource bake,
         * d3:instances shape), not just the component.
         */
        private fun warnFacingDrops(site: String, noun: String,
                                    key: Long, shape: String,
                                    p: JSONObject, fp: FacingParams) {
            if (p.tag("widthInPixels").d3Bool() == true) {
                warnOnce("$site.$key.widthInPixels",
                    "$noun $key: widthInPixels is" +
                        " unsupported — `width` reads as world" +
                        " units")
            }
            if (shape == "polyline" &&
                p.tag("caps").d3String() != null) {
                warnOnce("$site.$key.caps",
                    "$noun $key: 'caps' is unsupported" +
                        " — line ends are butt")
            }
            if (shape == "lineSegments" && fp.points.size % 2 != 0) {
                warnOnce("$site.$key.oddLineTail",
                    "$noun $key: lineSegments got an" +
                        " odd point count — trailing point" +
                        " dropped")
            }
        }

        /**
         * `d3:procMesh` — one node, one procedural mesh built from the
         * component's `shape` + params. Camera-facing shapes register
         * a FacingSpec so stepFrame re-expands their vertex buffer
         * toward the live camera (Filament line primitives are thin;
         * thick lines ride ribbon quads).
         */
        private fun decodeProcMesh(key: Long, rec: NodeRec, p: JSONObject) {
            val shape = p.tag("shape").d3String() ?: run {
                Log.w(TAG, "d3:procMesh node $key: missing shape"); return
            }
            destroyProcRenderable(key, rec)
            val facing = shape in FACING_SHAPES
            val fp = if (facing) parseFacing(key, p) else null
            if (fp != null) {
                warnFacingDrops("procMesh", "d3:procMesh node",
                    key, shape, p, fp)
            }
            val md = when {
                fp != null -> facingMesh(shape, fp,
                    MeshFactory.V3(0f, 0f, 1f),
                    MeshFactory.V3(1f, 0f, 0f), MeshFactory.V3(0f, 1f, 0f))
                else -> procedural(key, shape, p)
            }
            if (md == null || md.vertexCount == 0) {
                Log.w(TAG, "d3:procMesh node $key: shape '$shape'"
                    + " produced no geometry")
                return
            }
            val gm = buildGpuMesh(md)
            rec.procGpuMesh = gm
            rec.lastGeoPositions = gm.positions
            rec.lastGeoIndices = gm.indices
            rec.lastGeoBounds = gm.bounds
            val matKey = p.tag("material").d3Ref()
            val inst = matKey?.let { materials[it] }
                ?: host.litMaterial.defaultInstance
            val sprite = shape == "billboard" && host.isSpriteMaterial(inst)
            matKey?.let {
                materialConsumers.getOrPut(it) { ArrayList() }
                    .add(Pair(rec.entity, 0))
            }
            RenderableManager.Builder(1)
                .boundingBox(Box(gm.bounds[0], gm.bounds[1], gm.bounds[2],
                    gm.bounds[3], gm.bounds[4], gm.bounds[5]))
                .layerMask(0xFF, rec.layers and 0xFF)
                .castShadows(!sprite)
                .receiveShadows(!sprite)
                .geometry(0, gm.primitiveType, gm.vertexBuffer,
                    gm.indexBuffer)
                .material(0, inst)
                .fenced { build(host.engine, rec.entity) }
            if (fp != null) {
                cameraFacing[key] = FacingSpec(
                    shape, fp.points, fp.colors, fp.widths, fp.width,
                    fp.dashes, fp.closed, fp.sizeX, fp.sizeY,
                    fp.rotation, fp.tint, gm.vertexBuffer, rec.entity,
                    fp.facing)
            }
        }

        /** Instance transforms: an inline `{'m4':[16]}` list or a
         *  `matrices` payload ref — each S·M·S mirrored into native
         *  space like every other transform crossing the wire. */
        private fun d3InstanceTransforms(
            key: Long, p: JSONObject,
        ): List<FloatArray>? {
            val t = p.tag("transforms") ?: return null
            t.d3List()?.let { list ->
                val out = ArrayList<FloatArray>(list.length())
                for (i in 0 until list.length()) {
                    val m = list.opt(i).d3Mat4() ?: return null
                    out.add(D3Wire.matrix(m))
                }
                return out
            }
            val ref = t.d3Ref() ?: return null
            val bytes = host.payloadStore[ref]
            if (bytes == null || bytes.size % 64 != 0) {
                pendingPayloadRefs.add(key)
                return null
            }
            val n = bytes.size / 64
            return (0 until n).map { i ->
                D3Wire.matrix(DoubleArray(16) { k ->
                    D3Wire.f32LE(bytes, i * 64 + k * 4).toDouble()
                })
            }
        }

        /** The `color` per-instance attribute — inline `{'v4':[…]}`
         *  list, a `floats` payload (4×f32 per instance), or a `bytes`
         *  payload (4×u8 normalized). */
        private fun d3InstanceColors(
            key: Long, p: JSONObject,
        ): List<FloatArray>? {
            val attrs = p.tag("attributes").d3Map() ?: return null
            val color = attrs.opt("color") ?: return null
            color.d3List()?.let { list ->
                val out = ArrayList<FloatArray>(list.length())
                for (i in 0 until list.length()) {
                    val v = list.opt(i).d3Vec4() ?: return null
                    out.add(FloatArray(4) { v.getOrElse(it) { 0.0 }.toFloat() })
                }
                return out
            }
            val ref = color.d3Ref() ?: return null
            val bytes = host.payloadStore[ref]
            if (bytes == null) {
                pendingPayloadRefs.add(key)
                return null
            }
            return when (payloadSpecs[ref]?.encoding) {
                "bytes" -> (0 until bytes.size / 4).map { i ->
                    FloatArray(4) {
                        (bytes[i * 4 + it].toInt() and 0xFF) / 255f
                    }
                }
                else -> (0 until bytes.size / 16).map { i ->
                    FloatArray(4) {
                        D3Wire.f32LE(bytes, i * 16 + it * 4)
                    }
                }
            }
        }

        /**
         * `d3:instances` — one node, N copies of a mesh realized via
         * Filament 1.77.3 GPU instancing (`InstanceBuffer`, chunked to
         * `Engine.maxAutomaticInstances` = 64 per renderable with
         * per-chunk `instanceColors[64]` UBOs and reflected vertex/index
         * buffers for negative-determinant transforms). `billboard: true`
         * swaps the mesh for camera-facing quads re-faced per frame
         * (FacingSpec).
         */
        /**
         * Re-bakes every live `d3:instances` node whose `transforms`
         * or `color` attribute is backed by payload [payloadKey] — a
         * replaced matrices/floats/bytes chunk otherwise left the baked
         * mesh stale (the claim tables only tracked env/texture/
         * geometry/skin/animation consumers). Returns the count.
         */
        fun redecodeInstancesForPayload(payloadKey: Long): Int {
            var n = 0
            for ((nodeKey, rec) in nodes.entries.toList()) {
                val p = rec.instancesProps ?: continue
                val tRef = p.tag("transforms")?.d3Ref()
                val cRef = p.tag("attributes").d3Map()?.opt("color").d3Ref()
                if (tRef != payloadKey && cRef != payloadKey) continue
                decodeInstances(nodeKey, rec, p)
                applyVisibility(nodeKey)
                n++
            }
            return n
        }

        /**
         * Rebuilds the doubleSided snapshot duplicate of every live
         * `d3:instances` node bound to material [materialKey]. Those
         * snapshots aren't shared-material consumers (upsertMaterial
         * would rebind them single-sided), so when a background KHR
         * variant compile lands, the node would keep the base stand-in
         * it duplicated at decode — re-bake it against the fresh
         * instance. Returns the count.
         */
        fun redecodeDoubleSidedInstancesForMaterial(materialKey: Long): Int {
            var n = 0
            for ((nodeKey, rec) in nodes.entries.toList()) {
                val p = rec.instancesProps ?: continue
                if (p.tag("doubleSided").d3Bool() != true) continue
                if (rec.instanceMaterialInstances.isEmpty()) continue
                if (p.tag("material").d3Ref() != materialKey) continue
                decodeInstances(nodeKey, rec, p)
                applyVisibility(nodeKey)
                n++
            }
            return n
        }

        /**
         * Re-realizes non-`doubleSided` `d3:instances` nodes that bound
         * per-chunk MaterialInstance duplicates strictly for per-instance
         * `color` uniforms (not `doubleSided`, which stays a snapshot per
         * the payload-geometry contract doc). Called from `upsertMaterial`
         * so surgical material edits propagate to colored instanced nodes.
         */
        fun redecodeColoredInstancesForMaterial(materialKey: Long): Int {
            var n = 0
            for ((nodeKey, rec) in nodes.entries.toList()) {
                val p = rec.instancesProps ?: continue
                if (p.tag("doubleSided").d3Bool() == true) continue
                val hasColorAttr = p.tag("attributes").d3Map()?.opt("color") != null
                if (!hasColorAttr && rec.instanceMaterialInstances.isEmpty()) continue
                if (p.tag("material").d3Ref() != materialKey) continue
                decodeInstances(nodeKey, rec, p)
                applyVisibility(nodeKey)
                n++
            }
            return n
        }

        private fun det3x3(m: FloatArray): Float =
            m[0] * (m[5] * m[10] - m[6] * m[9]) -
                m[4] * (m[1] * m[10] - m[2] * m[9]) +
                m[8] * (m[1] * m[6] - m[2] * m[5])

        /**
         * Returns true when [m] is finite, invertible (`|det| > 1e-20`), and
         * its upper 3x3 is conformal (`s * Q` with `Q` orthogonal — uniform
         * scale + rotation/reflection, no shear). For conformal matrices,
         * Filament's GPU `InstanceBuffer` normal matrix `cofactor(M)` is
         * proportional to `M`, so hardware tangent transformation matches
         * `M * t` re-orthogonalized against `M^-T * n`. Non-conformal
         * (non-uniform scale / shear) or singular transforms take the CPU
         * `MeshFactory.bakeInstances` path so tangent orientation and
         * singular-frame fallback match the payload-geometry contract.
         */
        private fun isConformalInvertible3x3(m: FloatArray): Boolean {
            if (m.size < 16) return false
            for (i in 0 until 16) {
                if (!m[i].isFinite()) return false
            }
            val det = det3x3(m)
            if (!det.isFinite() || kotlin.math.abs(det) <= 1e-20f) return false
            val c0x = m[0]; val c0y = m[1]; val c0z = m[2]
            val c1x = m[4]; val c1y = m[5]; val c1z = m[6]
            val c2x = m[8]; val c2y = m[9]; val c2z = m[10]
            val l0 = c0x * c0x + c0y * c0y + c0z * c0z
            val l1 = c1x * c1x + c1y * c1y + c1z * c1z
            val l2 = c2x * c2x + c2y * c2y + c2z * c2z
            val scale2 = maxOf(l0, maxOf(l1, l2))
            if (!scale2.isFinite() || scale2 <= 1e-20f) return false
            val eps = scale2 * 1e-4f
            if (kotlin.math.abs(l0 - l1) > eps || kotlin.math.abs(l0 - l2) > eps || kotlin.math.abs(l1 - l2) > eps) {
                return false
            }
            val d01 = kotlin.math.abs(c0x * c1x + c0y * c1y + c0z * c1z)
            val d02 = kotlin.math.abs(c0x * c2x + c0y * c2y + c0z * c2z)
            val d12 = kotlin.math.abs(c1x * c2x + c1y * c2y + c1z * c2z)
            return d01 <= eps && d02 <= eps && d12 <= eps
        }

        private fun unionInstanceBounds(
            baseBounds: FloatArray,
            transforms: List<FloatArray>,
        ): FloatArray {
            if (transforms.isEmpty()) return baseBounds
            val cx = baseBounds[0]
            val cy = baseBounds[1]
            val cz = baseBounds[2]
            val hx = baseBounds[3]
            val hy = baseBounds[4]
            val hz = baseBounds[5]
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var maxZ = Float.NEGATIVE_INFINITY
            for (m in transforms) {
                val tcx = m[0] * cx + m[4] * cy + m[8] * cz + m[12]
                val tcy = m[1] * cx + m[5] * cy + m[9] * cz + m[13]
                val tcz = m[2] * cx + m[6] * cy + m[10] * cz + m[14]
                val thx = kotlin.math.abs(m[0]) * hx +
                    kotlin.math.abs(m[4]) * hy +
                    kotlin.math.abs(m[8]) * hz
                val thy = kotlin.math.abs(m[1]) * hx +
                    kotlin.math.abs(m[5]) * hy +
                    kotlin.math.abs(m[9]) * hz
                val thz = kotlin.math.abs(m[2]) * hx +
                    kotlin.math.abs(m[6]) * hy +
                    kotlin.math.abs(m[10]) * hz
                if (tcx - thx < minX) minX = tcx - thx
                if (tcy - thy < minY) minY = tcy - thy
                if (tcz - thz < minZ) minZ = tcz - thz
                if (tcx + thx > maxX) maxX = tcx + thx
                if (tcy + thy > maxY) maxY = tcy + thy
                if (tcz + thz > maxZ) maxZ = tcz + thz
            }
            return floatArrayOf(
                (minX + maxX) * 0.5f,
                (minY + maxY) * 0.5f,
                (minZ + maxZ) * 0.5f,
                (maxX - minX) * 0.5f,
                (maxY - minY) * 0.5f,
                (maxZ - minZ) * 0.5f,
            )
        }

        private fun reflectedVertexBuffer(
            base: MeshFactory.MeshData, rec: NodeRec,
        ): VertexBuffer {
            rec.procReflectedVertexBuffer?.let { return it }
            val vbBuilder = VertexBuffer.Builder()
                .vertexCount(base.vertexCount)
                .bufferCount(1)
                .attribute(VertexBuffer.VertexAttribute.POSITION, 0,
                    VertexBuffer.AttributeType.FLOAT3, 0, base.vertexStrideBytes)
                .attribute(VertexBuffer.VertexAttribute.TANGENTS, 0,
                    VertexBuffer.AttributeType.FLOAT4, 12, base.vertexStrideBytes)
            if (base.hasUvColor) {
                vbBuilder.attribute(VertexBuffer.VertexAttribute.UV0, 0,
                    VertexBuffer.AttributeType.FLOAT2, 28, base.vertexStrideBytes)
                vbBuilder.attribute(VertexBuffer.VertexAttribute.COLOR, 0,
                    VertexBuffer.AttributeType.FLOAT4, 36, base.vertexStrideBytes)
                vbBuilder.attribute(VertexBuffer.VertexAttribute.UV1, 0,
                    VertexBuffer.AttributeType.FLOAT2, 52, base.vertexStrideBytes)
            }
            val vb = vbBuilder.fenced { build(host.engine) }
            vb.setBufferAt(host.engine, 0, MeshFactory.reflectedTangentCopy(base))
            rec.procReflectedVertexBuffer = vb
            return vb
        }

        private fun reversedIndexBuffer(gm: GpuMesh, rec: NodeRec): IndexBuffer {
            rec.procReversedIndexBuffer?.let { return it }
            val src = gm.indices
            val n = src.size
            val triCount = n / 3
            val use32 = gm.vertexCount > 65535
            val ib = if (use32) {
                val rev = IntArray(n)
                for (t in 0 until triCount) {
                    val b = t * 3
                    rev[b] = src[b]
                    rev[b + 1] = src[b + 2]
                    rev[b + 2] = src[b + 1]
                }
                val buf = ByteBuffer.allocateDirect(n * 4)
                    .order(ByteOrder.nativeOrder())
                buf.asIntBuffer().put(rev)
                buf.rewind()
                IndexBuffer.Builder()
                    .indexCount(n)
                    .bufferType(IndexBuffer.Builder.IndexType.UINT)
                    .fenced { build(host.engine) }
                    .also { it.setBuffer(host.engine, buf) }
            } else {
                val rev = ShortArray(n)
                for (t in 0 until triCount) {
                    val b = t * 3
                    rev[b] = src[b].toShort()
                    rev[b + 1] = src[b + 2].toShort()
                    rev[b + 2] = src[b + 1].toShort()
                }
                val buf = ByteBuffer.allocateDirect(n * 2)
                    .order(ByteOrder.nativeOrder())
                buf.asShortBuffer().put(rev)
                buf.rewind()
                IndexBuffer.Builder()
                    .indexCount(n)
                    .bufferType(IndexBuffer.Builder.IndexType.USHORT)
                    .fenced { build(host.engine) }
                    .also { it.setBuffer(host.engine, buf) }
            }
            rec.procReversedIndexBuffer = ib
            return ib
        }

        /**
         * Applies [target] to [rec] at [primitive], covering multi-chunk
         * `d3:instances` entities (`rec.entity` + `rec.instanceEntities`)
         * and preserving per-chunk `doubleSided` + `instanceColors`
         * duplicates when present.
         */
        fun applyMaterialToNode(
            nodeKey: Long, rec: NodeRec,
            primitive: Int, target: MaterialInstance,
        ) {
            val rm = host.engine.renderableManager
            val instProps = rec.instancesProps
            if (instProps != null && primitive == 0) {
                rec.instanceBaseMaterial = target
                val chunkEntities = ArrayList<Int>(1 + rec.instanceEntities.size)
                chunkEntities.add(rec.entity)
                chunkEntities.addAll(rec.instanceEntities)
                val doubleSided = instProps.tag("doubleSided").d3Bool() == true
                val hasColors = rec.instanceChunkColors.any { it != null }
                if (doubleSided || hasColors) {
                    val oldDups = rec.instanceMaterialInstances.toList()
                    rec.instanceMaterialInstances.clear()
                    for ((chunkIdx, entity) in chunkEntities.withIndex()) {
                        val cf = rec.instanceChunkColors.getOrNull(chunkIdx)
                        val chunkMat = if (doubleSided || cf != null) {
                            MaterialInstance.duplicate(
                                target, "d3inst_${nodeKey}_$chunkIdx"
                            ).also { d ->
                                if (doubleSided) d.setDoubleSided(true)
                                if (cf != null) {
                                    d.setParameter("useInstanceColors", 1f)
                                    d.setParameter(
                                        "instanceColors",
                                        MaterialInstance.FloatElement.FLOAT4,
                                        cf, 0, MaterialPackages.MAX_INSTANCES)
                                }
                                rec.instanceMaterialInstances.add(d)
                                for ((_, list) in textureConsumers) {
                                    val params = list.filter { it.first === target }
                                        .map { it.second }
                                    for (param in params) list.add(Pair(d, param))
                                }
                            }
                        } else {
                            target
                        }
                        if (rm.hasComponent(entity)) {
                            val ri = rm.getInstance(entity)
                            if (0 < rm.getPrimitiveCount(ri)) {
                                rm.setMaterialInstanceAt(ri, 0, chunkMat)
                            }
                        }
                    }
                    if (oldDups.isNotEmpty()) {
                        for ((_, list) in textureConsumers) {
                            list.removeAll { it.first in oldDups }
                        }
                        for (oldDup in oldDups) {
                            host.engine.destroyMaterialInstance(oldDup)
                        }
                    }
                } else {
                    for (entity in chunkEntities) {
                        if (rm.hasComponent(entity)) {
                            val ri = rm.getInstance(entity)
                            if (0 < rm.getPrimitiveCount(ri)) {
                                rm.setMaterialInstanceAt(ri, 0, target)
                            }
                        }
                    }
                }
                return
            }
            if (rm.hasComponent(rec.entity)) {
                val ri = rm.getInstance(rec.entity)
                if (primitive < rm.getPrimitiveCount(ri)) {
                    rm.setMaterialInstanceAt(ri, primitive, target)
                    applyBillboardShadows(nodeKey, ri, target)
                }
            }
        }

        private fun applyBillboardShadows(
            nodeKey: Long, renderable: Int, material: MaterialInstance,
        ) {
            if (cameraFacing[nodeKey]?.shape != "billboard") return
            val shadows = !host.isSpriteMaterial(material)
            val rm = host.engine.renderableManager
            rm.setCastShadows(renderable, shadows)
            rm.setReceiveShadows(renderable, shadows)
        }

        fun applyMaterialConsumer(
            entity: Int, primitive: Int, target: MaterialInstance,
        ) {
            val owner = nodes.entries.firstOrNull { (_, rec) ->
                rec.entity == entity || entity in rec.instanceEntities
            } ?: run {
                val rm = host.engine.renderableManager
                if (rm.hasComponent(entity)) {
                    val ri = rm.getInstance(entity)
                    if (primitive < rm.getPrimitiveCount(ri)) {
                        rm.setMaterialInstanceAt(ri, primitive, target)
                    }
                }
                return
            }
            if (owner.value.instancesProps != null && primitive == 0) {
                applyMaterialToNode(owner.key, owner.value, primitive, target)
                return
            }
            val rm = host.engine.renderableManager
            if (rm.hasComponent(entity)) {
                val ri = rm.getInstance(entity)
                if (primitive < rm.getPrimitiveCount(ri)) {
                    rm.setMaterialInstanceAt(ri, primitive, target)
                    applyBillboardShadows(owner.key, ri, target)
                }
            }
        }

        fun firstBakedCatcherReceiver(
            materialKey: Long,
        ): BakedCatcherReceiver? {
            val source = materials[materialKey] ?: return null
            val rm = host.engine.renderableManager
            for ((entity, primitive) in materialConsumers[materialKey].orEmpty()) {
                if (!host.scene.hasEntity(entity) || !rm.hasComponent(entity)) {
                    continue
                }
                val ownerEntry = nodes.entries.firstOrNull { (_, rec) ->
                    rec.entity == entity || entity in rec.instanceEntities
                } ?: continue
                val (ownerKey, owner) = ownerEntry
                if (isHidden(ownerKey) || owner.lod?.let {
                        it.suspended || it.bound < 0
                    } == true) continue
                val ri = rm.getInstance(entity)
                if (primitive < 0 || primitive >= rm.getPrimitiveCount(ri)) {
                    continue
                }
                val current = rm.getMaterialInstanceAt(ri, primitive)
                val sourceIsActive = current.nativeObject == source.nativeObject ||
                    (owner.instancesProps != null && primitive == 0 &&
                        owner.instanceBaseMaterial?.nativeObject ==
                            source.nativeObject)
                if (!sourceIsActive) continue

                val geometryKey = when {
                    owner.lod?.let { it.bound >= 0 } == true ->
                        owner.lod!!.levels[owner.lod!!.bound].geoKey
                    owner.instancesProps != null ->
                        owner.instancesProps!!.tag("geometry").d3Ref()
                    else -> owner.meshPrimGeoKeys?.getOrNull(primitive)
                }
                val minMaxBounds = if (cameraFacing.containsKey(ownerKey)) {
                    val box = rm.getAxisAlignedBoundingBox(ri)
                    val min = box.getMin(FloatArray(3))
                    val max = box.getMax(FloatArray(3))
                    floatArrayOf(
                        min[0], min[1], min[2],
                        max[0], max[1], max[2],
                    )
                } else {
                    val bounds = if (owner.instancesProps != null &&
                        owner.instanceBuffers.isEmpty()
                    ) {
                        owner.instanceBakedGpuMesh?.bounds
                            ?: owner.procGpuMesh?.bounds
                            ?: owner.lastGeoBounds
                    } else {
                        geometryKey?.let { gpuMeshes[it]?.bounds }
                            ?: owner.procGpuMesh?.bounds
                            ?: owner.instanceBakedGpuMesh?.bounds
                            ?: owner.lastGeoBounds
                    } ?: continue
                    floatArrayOf(
                        bounds[0] - bounds[3],
                        bounds[1] - bounds[4],
                        bounds[2] - bounds[5],
                        bounds[0] + bounds[3],
                        bounds[1] + bounds[4],
                        bounds[2] + bounds[5],
                    )
                }
                val world = FloatArray(16)
                tcm.getWorldTransform(tcm.getInstance(entity), world)
                if (owner.instancesProps != null && primitive == 0) {
                    owner.instanceBuffers.firstOrNull()
                        ?.takeIf { it.instanceCount > 0 }
                        ?.getLocalTransform(0, FloatArray(16))
                        ?.let { first ->
                        val withInstance = FloatArray(16)
                        Matrix.multiplyMM(withInstance, 0, world, 0, first, 0)
                        System.arraycopy(withInstance, 0, world, 0, 16)
                    }
                }
                return BakedCatcherReceiver(
                    entity, primitive, world, minMaxBounds, ownerKey, owner)
            }
            return null
        }

        fun bindBakedCatcher(
            materialKey: Long, texture: Texture, region: FloatArray,
        ) {
            val source = materials[materialKey] ?: return
            fun bind(mi: MaterialInstance) {
                mi.setParameter("bakedShadowTexture", texture,
                    host.bakedCatcherTextureSampler)
                mi.setParameter("bakedRegion",
                    region[0], region[1], region[2], region[3])
            }
            bind(source)
            val rm = host.engine.renderableManager
            for ((entity, primitive) in materialConsumers[materialKey].orEmpty()) {
                if (!rm.hasComponent(entity)) continue
                val ri = rm.getInstance(entity)
                if (primitive < 0 || primitive >= rm.getPrimitiveCount(ri)) {
                    continue
                }
                bind(rm.getMaterialInstanceAt(ri, primitive))
            }
            for (rec in nodes.values) {
                if (rec.instanceBaseMaterial?.nativeObject ==
                    source.nativeObject) {
                    for (mi in rec.instanceMaterialInstances) bind(mi)
                }
            }
            for (vc in variantComponents.values) {
                for (binding in vc.bindings) {
                    if (binding.applied?.nativeObject == source.nativeObject) {
                        bind(binding.applied!!)
                    }
                    if (binding.defaultMaterial?.nativeObject ==
                        source.nativeObject) {
                        bind(binding.defaultMaterial!!)
                    }
                }
            }
        }

        private fun decodeInstances(key: Long, rec: NodeRec, p: JSONObject) {
            // Retained BEFORE resolving transforms: a payload-backed
            // node usually decodes before its matrices chunk lands, and
            // redecodeInstancesForPayload finds pending nodes through
            // this spec when the chunk arrives (no claim table covers
            // node-keyed instance payloads).
            rec.instancesProps = p
            var transforms = d3InstanceTransforms(key, p)
            if (transforms == null) {
                Log.i(TAG, "d3:instances node $key: transforms unresolved")
                return
            }
            if (transforms.size > MAX_BAKED_INSTANCES) {
                warnOnce("instances.$key.countCap",
                    "d3:instances node $key: ${transforms.size} instances" +
                        " exceeds the baked-instance cap" +
                        " $MAX_BAKED_INSTANCES — truncated")
                transforms = transforms.take(MAX_BAKED_INSTANCES)
            }
            rec.instancesProps = p
            destroyProcRenderable(key, rec)
            val colors = d3InstanceColors(key, p)
            val billboard = p.tag("billboard").d3Bool() == true
            // Wire precedence (mirrors FsceneRealizer.swift):
            // `billboard` overrides the mesh fields; `shape` wins
            // over `geometry` when both are present.
            if (billboard &&
                (p.tag("shape").d3String() != null ||
                    p.tag("geometry").d3Ref() != null)) {
                logOnce("instances.$key.billboardPrecedence",
                    "d3:instances node $key: 'billboard' overrides" +
                        " shape/geometry")
            }
            if (!billboard && p.tag("shape").d3String() != null &&
                p.tag("geometry").d3Ref() != null) {
                logOnce("instances.$key.shapePrecedence",
                    "d3:instances node $key: 'shape' wins over" +
                        " 'geometry'")
            }
            // attr1–attr3 are wire-carried but unread today — `color`
            // is the only attribute with a renderer contract.
            p.tag("attributes").d3Map()?.let { attrs ->
                for (name in attrs.keys()) {
                    if (name != "color") {
                        logOnce("instances.$key.attr.$name",
                            "d3:instances node $key: attribute" +
                                " '$name' is carried but not" +
                                " rendered (only 'color' is)")
                    }
                }
            }
            val facing = facingMode(key, p.tag("facing").d3String())
            val doubleSided = p.tag("doubleSided").d3Bool() == true
            val s = p.tag("size").d3Vec2() ?: doubleArrayOf(1.0, 1.0)
            val rotation = (p.tag("rotation").d3Double() ?: 0.0).toFloat()
            val matKey = p.tag("material").d3Ref()
            val shared = matKey?.let { materials[it] }
                ?: host.litMaterial.defaultInstance
            rec.instanceBaseMaterial = shared

            if (billboard) {
                val centers = transforms.map {
                    MeshFactory.V3(it[12], it[13], it[14])
                }
                val md = MeshFactory.bakeBillboardInstances(centers,
                    s[0].toFloat(), s[1].toFloat(), rotation, colors,
                    MeshFactory.V3(1f, 0f, 0f), MeshFactory.V3(0f, 1f, 0f),
                    facing = facing)
                if (md.vertexCount == 0) {
                    Log.w(TAG, "d3:instances node $key: empty bake")
                    return
                }
                val gm = buildGpuMesh(md)
                rec.procGpuMesh = gm
                rec.lastGeoPositions = gm.positions
                rec.lastGeoIndices = gm.indices
                rec.lastGeoBounds = gm.bounds
                rec.instanceChunkColors.add(null)
                val inst = if (doubleSided) {
                    MaterialInstance.duplicate(shared, "d3ds_$key").also { dup ->
                        dup.setDoubleSided(true)
                        rec.instanceMaterialInstances.add(dup)
                        for ((_, list) in textureConsumers) {
                            val params = list.filter { it.first === shared }
                                .map { it.second }
                            for (param in params) list.add(Pair(dup, param))
                        }
                    }
                } else shared
                matKey?.let {
                    materialConsumers.getOrPut(it) { ArrayList() }
                        .add(Pair(rec.entity, 0))
                }
                RenderableManager.Builder(1)
                    .boundingBox(Box(gm.bounds[0], gm.bounds[1], gm.bounds[2],
                        gm.bounds[3], gm.bounds[4], gm.bounds[5]))
                    .layerMask(0xFF, rec.layers and 0xFF)
                    .castShadows(true)
                    .receiveShadows(true)
                    .geometry(0, gm.primitiveType, gm.vertexBuffer,
                        gm.indexBuffer)
                    .material(0, inst)
                    .fenced { build(host.engine, rec.entity) }
                val flatCenters = FloatArray(transforms.size * 3)
                for ((i, m) in transforms.withIndex()) {
                    flatCenters[i * 3] = m[12]
                    flatCenters[i * 3 + 1] = m[13]
                    flatCenters[i * 3 + 2] = m[14]
                }
                cameraFacing[key] = FacingSpec.billboards(
                    flatCenters, s[0].toFloat(), s[1].toFloat(), rotation,
                    colors, gm.vertexBuffer, rec.entity, facing)
                Log.i(TAG, "d3:instances node $key: realized ${transforms.size} billboard instance(s)")
                return
            }

            // E1 GPU instancing: resolve the single base mesh once, then
            // submit per-chunk Filament InstanceBuffers (up to 64 instances
            // per automatic-instancing renderable).
            val shape = p.tag("shape").d3String()
            var base: MeshFactory.MeshData? = null
            var geoKey: Long? = null
            if (shape != null && shape in FACING_SHAPES) {
                logOnce("instances.$key.facingShape",
                    "d3:instances node $key: facing shape '$shape'" +
                        " bakes once toward +Z")
                val fp = parseFacing(key, p)
                warnFacingDrops("instances", "d3:instances node",
                    key, shape, p, fp)
                base = facingMesh(shape, fp,
                    MeshFactory.V3(0f, 0f, 1f),
                    MeshFactory.V3(1f, 0f, 0f), MeshFactory.V3(0f, 1f, 0f))
            } else if (shape != null) {
                base = procedural(key, shape, p)
            } else {
                geoKey = p.tag("geometry").d3Ref()
                if (geoKey == null) {
                    Log.w(TAG, "d3:instances node $key: needs" +
                        " geometry or shape")
                    return
                }
                geometryConsumers.getOrPut(geoKey) { LinkedHashSet() }
                    .add(key)
                base = geometries[geoKey]
            }
            if (base == null) {
                Log.i(TAG, "d3:instances node $key: geometry" +
                    " unresolved")
                return
            }
            if (base.topology != MeshFactory.Topology.TRIANGLES) {
                warnOnce("instances.$key.topology",
                    "d3:instances node $key: ${base.topology}" +
                        " geometry can't be instanced (triangle" +
                        " lists only) — not baked")
                return
            }
            if (base.hasSkinning) {
                warnOnce("instances.$key.skinning",
                    "d3:instances node $key: skinned geometry" +
                        " bakes unskinned — joint/weight streams" +
                        " are dropped")
            }
            if (base.morph != null) {
                warnOnce("instances.$key.morph",
                    "d3:instances node $key: morphed geometry" +
                        " bakes unmorphed — morph targets" +
                        " are dropped")
            }
            val maxByVerts = maxOf(1,
                MAX_BAKED_VERTICES / maxOf(1, base.vertexCount))
            if (transforms.size > maxByVerts) {
                warnOnce("instances.$key.vertexCap",
                    "d3:instances node $key: ${transforms.size}" +
                        " × ${base.vertexCount} vertices exceeds the" +
                        " $MAX_BAKED_VERTICES-vertex bake budget" +
                        " — truncated to $maxByVerts instances")
                transforms = transforms.take(maxByVerts)
            }
            if (transforms.isEmpty() || base.vertexCount == 0) {
                Log.w(TAG, "d3:instances node $key: empty bake")
                return
            }

            val unskinnedBase: MeshFactory.MeshData =
                if (base.hasSkinning || base.morph != null) {
                    MeshFactory.bakeInstances(base, listOf(identity16()), null)
                } else {
                    base
                }
            val gm: GpuMesh = when {
                geoKey != null && !base.hasSkinning && base.morph == null ->
                    gpuMesh(geoKey) ?: return
                else -> buildGpuMesh(unskinnedBase).also { rec.procGpuMesh = it }
            }
            val unionBounds = unionInstanceBounds(gm.bounds, transforms)
            // Collider positions/indices are expanded lazily on demand in
            // ensureInstanceColliderGeometry so pure rendering avoids CPU
            // vertex expansion across 10k+ instances.
            rec.lastGeoPositions = null
            rec.lastGeoIndices = null
            rec.instanceBasePositions = gm.positions
            rec.instanceBaseIndices = gm.indices
            rec.instanceTransforms = transforms
            rec.lastGeoBounds = unionBounds

            val maxInst = host.engine.maxAutomaticInstances
                .coerceIn(1, MaterialPackages.MAX_INSTANCES)
            val posIndices = ArrayList<Int>(transforms.size)
            val negIndices = ArrayList<Int>()
            val bakedIndices = ArrayList<Int>()
            for (i in transforms.indices) {
                val m = transforms[i]
                if (!isConformalInvertible3x3(m)) {
                    bakedIndices.add(i)
                } else if (det3x3(m) < 0f) {
                    negIndices.add(i)
                } else {
                    posIndices.add(i)
                }
            }
            val chunks = ArrayList<Pair<List<Int>, Boolean>>()
            var off = 0
            while (off < posIndices.size) {
                val end = minOf(off + maxInst, posIndices.size)
                chunks.add(Pair(posIndices.subList(off, end), false))
                off = end
            }
            off = 0
            while (off < negIndices.size) {
                val end = minOf(off + maxInst, negIndices.size)
                chunks.add(Pair(negIndices.subList(off, end), true))
                off = end
            }

            val ident = identity16()
            val needsDupMat = doubleSided || colors != null
            var nextSlotIdx = 0
            for ((chunkIdx, pair) in chunks.withIndex()) {
                val (indices, negDet) = pair
                val count = indices.size
                val flatTransforms = FloatArray(count * 16)
                for ((slot, srcIdx) in indices.withIndex()) {
                    System.arraycopy(
                        transforms[srcIdx], 0, flatTransforms, slot * 16, 16)
                }
                val ib = InstanceBuffer.Builder(count)
                    .fenced { build(host.engine) }
                ib.setLocalTransforms(flatTransforms, count, 0)
                rec.instanceBuffers.add(ib)

                val entity = if (nextSlotIdx == 0) {
                    rec.entity
                } else {
                    val ie = em.create()
                    tcm.create(ie, 0, ident)
                    tcm.setParent(
                        tcm.getInstance(ie), tcm.getInstance(rec.entity))
                    rec.instanceEntities.add(ie)
                    ie
                }
                nextSlotIdx++

                val colorFloats: FloatArray? = if (colors != null) {
                    FloatArray(MaterialPackages.MAX_INSTANCES * 4) { 1f }.also { cf ->
                        for ((slot, srcIdx) in indices.withIndex()) {
                            val c = colors.getOrNull(srcIdx)
                            if (c != null && c.size >= 4) {
                                cf[slot * 4] = c[0]
                                cf[slot * 4 + 1] = c[1]
                                cf[slot * 4 + 2] = c[2]
                                cf[slot * 4 + 3] = c[3]
                            }
                        }
                    }
                } else null
                rec.instanceChunkColors.add(colorFloats)

                val chunkMat = if (needsDupMat) {
                    MaterialInstance.duplicate(
                        shared, "d3inst_${key}_$chunkIdx"
                    ).also { dup ->
                        if (doubleSided) dup.setDoubleSided(true)
                        if (colorFloats != null) {
                            dup.setParameter("useInstanceColors", 1f)
                            dup.setParameter(
                                "instanceColors",
                                MaterialInstance.FloatElement.FLOAT4,
                                colorFloats, 0,
                                MaterialPackages.MAX_INSTANCES)
                        }
                        rec.instanceMaterialInstances.add(dup)
                        for ((_, list) in textureConsumers) {
                            val params = list.filter { it.first === shared }
                                .map { it.second }
                            for (param in params) list.add(Pair(dup, param))
                        }
                    }
                } else {
                    shared
                }
                if (entity == rec.entity) {
                    matKey?.let {
                        materialConsumers.getOrPut(it) { ArrayList() }
                            .add(Pair(rec.entity, 0))
                    }
                }

                val vertexBuf = if (negDet) {
                    reflectedVertexBuffer(unskinnedBase, rec)
                } else {
                    gm.vertexBuffer
                }
                val indexBuf = if (negDet) {
                    reversedIndexBuffer(gm, rec)
                } else {
                    gm.indexBuffer
                }
                val chunkTransforms = indices.map { transforms[it] }
                val cb = unionInstanceBounds(gm.bounds, chunkTransforms)
                RenderableManager.Builder(1)
                    .instances(count, ib)
                    .boundingBox(Box(cb[0], cb[1], cb[2],
                        cb[3], cb[4], cb[5]))
                    .layerMask(0xFF, rec.layers and 0xFF)
                    .castShadows(true)
                    .receiveShadows(true)
                    .geometry(0, gm.primitiveType, vertexBuf, indexBuf)
                    .material(0, chunkMat)
                    .fenced { build(host.engine, entity) }
            }

            if (bakedIndices.isNotEmpty()) {
                val bakedTransforms = bakedIndices.map { transforms[it] }
                val bakedColors = colors?.let { cs ->
                    bakedIndices.map { cs.getOrElse(it) { floatArrayOf(1f, 1f, 1f, 1f) } }
                }
                val bakedMd = MeshFactory.bakeInstances(
                    unskinnedBase, bakedTransforms, bakedColors)
                if (bakedMd.vertexCount > 0) {
                    val bakedGm = buildGpuMesh(bakedMd)
                    rec.instanceBakedGpuMesh = bakedGm
                    val entity = if (nextSlotIdx == 0) {
                        rec.entity
                    } else {
                        val ie = em.create()
                        tcm.create(ie, 0, ident)
                        tcm.setParent(
                            tcm.getInstance(ie), tcm.getInstance(rec.entity))
                        rec.instanceEntities.add(ie)
                        ie
                    }
                    nextSlotIdx++
                    rec.instanceChunkColors.add(null)
                    val bakedMat = if (doubleSided) {
                        MaterialInstance.duplicate(
                            shared, "d3inst_${key}_baked"
                        ).also { dup ->
                            dup.setDoubleSided(true)
                            rec.instanceMaterialInstances.add(dup)
                            for ((_, list) in textureConsumers) {
                                val params = list.filter { it.first === shared }
                                    .map { it.second }
                                for (param in params) list.add(Pair(dup, param))
                            }
                        }
                    } else shared
                    if (entity == rec.entity) {
                        matKey?.let {
                            materialConsumers.getOrPut(it) { ArrayList() }
                                .add(Pair(rec.entity, 0))
                        }
                    }
                    val b = bakedGm.bounds
                    RenderableManager.Builder(1)
                        .boundingBox(Box(b[0], b[1], b[2], b[3], b[4], b[5]))
                        .layerMask(0xFF, rec.layers and 0xFF)
                        .castShadows(true)
                        .receiveShadows(true)
                        .geometry(0, bakedGm.primitiveType,
                            bakedGm.vertexBuffer, bakedGm.indexBuffer)
                        .material(0, bakedMat)
                        .fenced { build(host.engine, entity) }
                }
            }
            Log.i(TAG, "d3:instances node $key: realized ${transforms.size} instance(s) in ${chunks.size} InstanceBuffer chunk(s)" +
                if (bakedIndices.isNotEmpty()) " + ${bakedIndices.size} baked non-conformal" else "")
        }

        private fun decodeMaterial(key: Long, r: JSONObject) {
            materialResources[key] = r
            val catcherSettings = parseShadowCatcherSettings(r)
            if (catcherSettings?.mode == ShadowCatcherMode.BAKED) {
                bakedCatcherSettings[key] = catcherSettings
            }
            val instance = buildMaterialInstance(
                host, key, r, textures, textureSamplers, textureConsumers,
                catcherSettings)
            materials[key] = instance
            materialColors.remove(key)
            materialColorOwner(instance, r)?.let { materialColors[key] = it }
        }

        private fun decodeTexture(key: Long, r: JSONObject) {
            textureResources[key] = r
            // Record the backing payload id even while pending — the
            // host's upsertPayload replays through this map.
            r.optString("payload").takeIf { it.isNotEmpty() }
                ?.let { D3Wire.localIdKey(it) }
                ?.let { texturePayloadIds[key] = it }
            when (val res = TextureFactory.realize(
                host, key, r, payloadSpecs)) {
                is TextureFactory.Result.Ready -> textures[key] = res.texture
                TextureFactory.Result.Pending -> {
                    pendingPayloadRefs.add(key)
                    Log.i(TAG, "texture $key: awaiting payload")
                }
                TextureFactory.Result.Failed -> Unit // reason already logged
            }
        }

        // MARK: Skins / animations (W11)

        /** Little-endian f32 list — the payload chunk codec every
         *  W11 slab (IBM matrices, timelines, keyframes, morph
         *  deltas) reads through. */
        private fun f32List(d: ByteArray): FloatArray =
            FloatArray(d.size / 4) { D3Wire.f32LE(d, it * 4) }

        fun decodeSkins(map: JSONObject?) {
            if (map == null) return
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val def = map.optJSONObject(token) ?: continue
                skinDefs[key] = def
                decodeSkin(key, def)
            }
        }

        /**
         * One `skins` entry: joint node refs in authored order, the
         * `inverseBindMatrices` payload (16 f32 per joint, converted
         * through `D3Wire.matrix`; absent or in-flight → identity and
         * `awaitingIBM`), and the optional `skeleton` root
         * (informational — binding is by joints list + IBM). Mirrors
         * iOS `decodeSkin`.
         */
        fun decodeSkin(key: Long, def: JSONObject) {
            val jointKeys = ArrayList<Long>()
            def.optJSONArray("joints")?.let { a ->
                for (i in 0 until a.length()) {
                    D3Wire.localIdKey(a.optString(i))?.let(jointKeys::add)
                }
            }
            val skeletonKey = def.optString("skeleton")
                .takeIf { it.isNotEmpty() }?.let { D3Wire.localIdKey(it) }
            val ibms = MutableList(jointKeys.size) { identity16() }
            var awaiting = false
            val token = def.optString("inverseBindMatrices")
                .takeIf { it.isNotEmpty() }
            val pid = token?.let { D3Wire.localIdKey(it) }
            if (pid != null) {
                skinPayloadIds[key] = pid
                val data = host.payloadStore[pid]
                if (data != null) {
                    val floats = f32List(data)
                    val need = jointKeys.size * 16
                    if (floats.size < need) {
                        Log.i(TAG, "skin $key: inverseBindMatrices has " +
                            "${floats.size} floats; expected $need")
                    }
                    for (j in 0 until jointKeys.size) {
                        val b = j * 16
                        if (b + 16 > floats.size) break
                        ibms[j] = D3Wire.matrix(
                            DoubleArray(16) { floats[b + it].toDouble() })
                    }
                } else {
                    awaiting = true
                }
            } else {
                skinPayloadIds.remove(key)
            }
            skins[key] = DecodedSkin(jointKeys, ibms, skeletonKey, awaiting)
        }

        /**
         * `animations` block decode — raw defs kept in [animDefs] so
         * `upsertAnimation`/`upsertPayload` re-decode a single entry.
         */
        fun decodeAnimations(map: JSONObject?) {
            if (map == null) return
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val def = map.optJSONObject(token) ?: continue
                decodeAnimation(key, def)
            }
        }

        /**
         * One `animations` entry. Each channel's timeline (f32
         * seconds) and keyframes are payload refs — recorded as claims
         * first so an `upsertPayload` chunk re-decodes the animation
         * it unblocks; a channel whose payloads haven't landed is
         * skipped this pass. Values convert to engine space here:
         * translation negates z, rotation takes the (−x,−y,z,w)
         * pseudovector map, scale and weights pass through. `weights`
         * channels carry flattened per-key values — `targetCount` is
         * `values.size / times.size`, trailing floats that don't
         * complete a keyframe are dropped (upstream's rule). Mirrors
         * iOS `decodeAnimation`.
         */
        fun decodeAnimation(key: Long, def: JSONObject) {
            val metadata = if (animDefs[key] === def) animations[key]?.definition else null
            val definition = metadata ?: try {
                AnimationDefinition.parse(def)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "animation $key: ${e.message}; keeping prior definition")
                return
            }
            val name = def.optString("name")
            val channels = ArrayList<DecodedChannel>()
            var endTime = 0.0
            val claims = definition.claims
            for (c in definition.ordinary) {
                val target = c.target
                val kind = when (c.kind) {
                    "translation" -> DecodedChannel.Kind.TRANSLATION
                    "rotation" -> DecodedChannel.Kind.ROTATION
                    "scale" -> DecodedChannel.Kind.SCALE
                    "weights" -> DecodedChannel.Kind.WEIGHTS
                    else -> error("validated ordinary kind")
                }
                val tPid = c.timeline
                val kPid = c.keyframes
                val tData = host.payloadStore[tPid]
                val kData = host.payloadStore[kPid]
                if (tData == null || kData == null) {
                    logOnce("anim.$key.awaiting",
                        "animation $key: awaiting channel payloads")
                    continue
                }
                val times = DoubleArray(tData.size / 4) {
                    D3Wire.f32LE(tData, it * 4).toDouble()
                }
                val vals = f32List(kData)
                val arity = when (kind) {
                    DecodedChannel.Kind.TRANSLATION, DecodedChannel.Kind.SCALE -> 3
                    DecodedChannel.Kind.ROTATION -> 4
                    DecodedChannel.Kind.WEIGHTS -> 1
                }
                if (tData.size % 4 != 0 || kData.size % 4 != 0 || times.isEmpty() ||
                    times.indices.any { !times[it].isFinite() || times[it] < 0 ||
                        (it > 0 && times[it] <= times[it - 1]) } ||
                    vals.size < times.size * arity || vals.any { !it.isFinite() }) {
                    Log.w(TAG, "animation $key ${c.kind}: invalid joined curve; inactive")
                    continue
                }
                var vec3 = FloatArray(0)
                var quat = FloatArray(0)
                var weights = FloatArray(0)
                var targetCount = 0
                when (kind) {
                    DecodedChannel.Kind.TRANSLATION -> {
                        val n = minOf(times.size, vals.size / 3)
                        vec3 = FloatArray(n * 3) { j ->
                            val b = (j / 3) * 3
                            val c = j % 3
                            if (c == 2) -vals[b + 2] else vals[b + c]
                        }
                    }
                    DecodedChannel.Kind.SCALE -> {
                        val n = minOf(times.size, vals.size / 3)
                        vec3 = vals.copyOfRange(0, n * 3)
                    }
                    DecodedChannel.Kind.ROTATION -> {
                        val n = minOf(times.size, vals.size / 4)
                        quat = FloatArray(n * 4) { j ->
                            val b = (j / 4) * 4
                            when (j % 4) {
                                0 -> -vals[b]
                                1 -> -vals[b + 1]
                                2 -> vals[b + 2]
                                else -> vals[b + 3]
                            }
                        }
                    }
                    DecodedChannel.Kind.WEIGHTS -> {
                        val keyCount = times.size
                        val tc = if (keyCount > 0) {
                            vals.size / keyCount
                        } else 0
                        targetCount = tc
                        weights = vals.copyOf(
                            minOf(tc * keyCount, vals.size))
                    }
                }
                times.lastOrNull()?.let { endTime = maxOf(endTime, it) }
                channels.add(DecodedChannel(
                    target = target,
                    targetName = c.targetName,
                    kind = kind, times = times,
                    vec3 = vec3, quat = quat,
                    weights = weights, targetCount = targetCount))
            }
            val properties = definition.properties.mapNotNull { property ->
                try {
                    PropertyCurve.decode(property, host.payloadStore[property.timeline],
                        host.payloadStore[property.keyframes], payloadSpecs[property.timeline],
                        payloadSpecs[property.keyframes]).also {
                        if (it == null) logOnce("anim.$key.pending.${property.kind}",
                            "animation $key: property awaiting payloads/specs")
                    }
                } catch (e: IllegalArgumentException) {
                    Log.w(TAG, "animation $key ${property.kind} ${property.timeline}/${property.keyframes}: ${e.message}; inactive")
                    null
                }
            }
            for (property in properties) endTime = maxOf(endTime, property.times.last())
            animDefs[key] = def
            animPayloadIds[key] = claims
            animations[key] = DecodedAnimation(name, channels, endTime, definition, properties)
        }

        /**
         * Re-attaches every node bound to `skinKey` — the
         * `upsertSkin`/`removeSkin`-adjacent refresh after
         * `decodeSkin` rewrites (or removes) the skin record. Joints
         * resolve per-frame at bone-matrix upload, so the refresh only
         * rebuilds the renderable (buffer resize / attach / detach).
         */
        fun refreshSkinConsumers(skinKey: Long) {
            for ((nodeKey, key) in nodeSkinKeys) {
                if (key != skinKey) continue
                rebuildRenderable(nodeKey)
            }
        }

        /**
         * Destroys and re-creates a node's renderable through
         * `decodeMesh` — the skin attach/detach and morph rebind
         * vehicle. Keeps the physics body, light and camera state;
         * the renderable is the only rebuilt piece.
         */
        fun rebuildRenderable(nodeKey: Long) {
            val rec = nodes[nodeKey] ?: return
            // W16: an lod-owned renderable isn't a mesh rebuild
            // target — the frame pass owns the slot (a suspended
            // lod's mesh owns it and rebuilds normally).
            rec.lod?.let {
                if (it.ownsRenderable && !it.suspended) return
            }
            val rm = host.engine.renderableManager
            if (rm.hasComponent(rec.entity)) rm.destroy(rec.entity)
            host.scene.remove(rec.entity)
            for ((_, list) in materialConsumers) {
                list.removeAll { it.first == rec.entity }
            }
            nodeSkinning.remove(nodeKey)?.let {
                host.engine.destroySkinningBuffer(it.buffer)
            }
            rec.morphWeights = null
            val props = rec.meshProps ?: return
            decodeMesh(nodeKey, rec, props)
            applyVisibility(nodeKey)
        }

        private fun identity16(): FloatArray {
            val m = FloatArray(16)
            Matrix.setIdentityM(m, 0)
            return m
        }

        // MARK: Nodes

        fun decodeNodes(map: JSONObject?) {
            if (map == null) return
            // Pass 1: entities + transforms + components.
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val spec = map.optJSONObject(token) ?: continue
                decodeNode(key, spec)
            }
            // Pass 2: hierarchy + world matrices (needed by physics BCS).
            for (token in map.keys()) {
                val key = D3Wire.localIdKey(token) ?: continue
                val rec = nodes[key] ?: continue
                val spec = map.optJSONObject(token) ?: continue
                val children = spec.optJSONArray("children") ?: continue
                for (i in 0 until children.length()) {
                    val ck = D3Wire.localIdKey(children.optString(i)) ?: continue
                    val child = nodes[ck] ?: continue
                    child.parentKey = key
                    // Instance handles are not stable across component
                    // destruction (the manager compacts), so resolve
                    // them fresh rather than caching.
                    tcm.setParent(
                        tcm.getInstance(child.entity),
                        tcm.getInstance(rec.entity))
                }
            }
            for ((key, rec) in nodes) {
                nodeWorld[key] = worldMatOf(key)
            }
        }

        /**
         * One node's pass-1 decode — entity, transform, name/layers/
         * visible, components — shared by [decodeNodes] and the W5
         * `addNode` surgical path. Hierarchy wiring is NOT done here:
         * manifest children attach in pass 2, diff children via their
         * own addNode's parent field.
         */
        private fun decodeNode(key: Long, spec: JSONObject): NodeRec {
            val entity = em.create()
            val trs = decodeTrs(spec.optJSONObject("transform"))
            tcm.create(entity, 0, D3Wire.trs(trs[0], trs[1], trs[2]))
            val rec = NodeRec(
                entity, null,
                trs[0], trs[1], trs[2],
            )
            rec.name = spec.optString("name").takeIf { it.isNotEmpty() }
            rec.layers = spec.optInt("layers", 1)
            if (rec.layers and 0xFFFFFF00.toInt() != 0) {
                // W24 audit: Filament's layer system is natively
                // 8-bit (uint8 masks on layerMask/setVisibleLayers) —
                // the upstream 32-bit mask truncates, not widens.
                warnOnce("w24.nodeLayers.$key",
                    "node $key layers ${rec.layers}: Filament layer " +
                        "masks are 8-bit; high bits ignored")
            }
            if (spec.has("visible") && !spec.getBoolean("visible")) {
                rec.hidden = true
            }
            // W11: the `skin` member binds the node to a `skins`
            // entry — read before components so decodeMesh's skinning
            // attach sees it.
            spec.optString("skin").takeIf { it.isNotEmpty() }
                ?.let { D3Wire.localIdKey(it) }
                ?.let { nodeSkinKeys[key] = it }
            // W15: a surviving `instance` member tags the node as a
            // lazy prefab placeholder — kept raw on the rec; the
            // streaming layer resolves it.
            rec.instanceSpec = spec.optJSONObject("instance")
            val comps = spec.optJSONArray("components")
            if (comps != null) {
                for (i in 0 until comps.length()) {
                    decodeComponent(key, rec, i, comps.opt(i))
                }
            }
            nodes[key] = rec
            return rec
        }

        /** Decoded local TRS (RH space): [pos, quat, scale]. */
        private fun decodeTrs(t: JSONObject?): Array<FloatArray> {
            var p = floatArrayOf(0f, 0f, 0f)
            var q = floatArrayOf(0f, 0f, 0f, 1f)
            var s = floatArrayOf(1f, 1f, 1f)
            val trs = t?.optJSONObject("trs")
            if (trs != null) {
                trs.optJSONArray("t")?.toDoubleArray()?.let { p = D3Wire.position(it) }
                trs.optJSONArray("r")?.toDoubleArray()?.let { q = D3Wire.quaternion(it) }
                trs.optJSONArray("s")?.toDoubleArray()?.let { s = D3Wire.scale(it) }
            } else {
                val m = t?.optJSONArray("matrix")?.toDoubleArray()
                if (m != null && m.size == 16) {
                    val conv = D3Wire.matrix(m)
                    val d = decompose(conv)
                    p = d[0]; q = d[1]; s = d[2]
                }
            }
            return arrayOf(p, q, s)
        }

        /**
         * Filament's scene is flat — transform parenting doesn't pull a
         * child into the render set the way SceneKit's node tree does,
         * so every renderable/light entity is added explicitly. Hidden
         * nodes (and their subtree, matching `SCNNode.isHidden`) stay
         * out; their transform instances still exist for hierarchy math.
         */
        fun attachToScene() {
            for ((key, rec) in nodes) {
                if (isHidden(key)) continue
                attachIfRenderable(rec)
            }
        }

        /** The visibility-aware scene add — [attachToScene]'s per-node
         * body, reused by the W5 node ops. */
        private fun attachIfRenderable(rec: NodeRec) {
            // W18: particle entities are runtime-owned (a sprite's
            // dedicated batch entity; a mesh pool's children) — the
            // node entity's component test doesn't cover them, and LOD
            // culling removes only rec.entity, so they re-attach even
            // while the LOD holds the node's renderable out.
            for (rt in rec.particleRuntimes) rt.setSceneVisible(true)
            // W16: an lod-culled node keeps its renderable out of the
            // scene until the frame pass rebinds a level — a
            // visibility re-eval must not re-attach it.
            rec.lod?.let {
                if (!it.suspended && it.ownsRenderable && it.bound < 0) {
                    return
                }
            }
            val rm = host.engine.renderableManager
            val lm = host.engine.lightManager
            if (rm.hasComponent(rec.entity) || lm.hasComponent(rec.entity)) {
                host.scene.addEntity(rec.entity)
            }
            for (ie in rec.instanceEntities) {
                if (rm.hasComponent(ie)) host.scene.addEntity(ie)
            }
        }

        /** True when the node or any ancestor carries `visible:false`. */
        private fun isHidden(key: Long): Boolean {
            var k: Long? = key
            while (k != null) {
                val rec = nodes[k] ?: return false
                if (rec.hidden) return true
                k = rec.parentKey
            }
            return false
        }

        /** Composes the node's world matrix through the parent chain. */
        private fun worldMatOf(key: Long): FloatArray {
            var m = D3Wire.trs(
                nodes.getValue(key).localPos,
                nodes.getValue(key).localQuat,
                nodes.getValue(key).localScale,
            )
            var p = nodes[key]?.parentKey
            while (p != null) {
                val pr = nodes[p] ?: break
                val pm = D3Wire.trs(pr.localPos, pr.localQuat, pr.localScale)
                val out = FloatArray(16)
                Matrix.multiplyMM(out, 0, pm, 0, m, 0)
                m = out
                p = pr.parentKey
            }
            return m
        }

        // MARK: Components

        private fun decodeComponent(
            key: Long, rec: NodeRec, index: Int, any: Any?,
        ) {
            val spec = any as? JSONObject ?: return
            val type = spec.optString("type")
            val props = spec.optJSONObject("properties") ?: JSONObject()
            if (type == "camera") rec.cameraDeclarations++
            if (type in listOf("directionalLight", "pointLight", "spotLight", "rectAreaLight"))
                rec.lightDeclarations++
            // Universal `enabled` (W12) — upstream's component wrapper
            // applies it around update/fixedUpdate callbacks only; it
            // does not remove realized state. W18 particle emitters
            // are the first components with a tick surface, so for
            // them `enabled:false` IS applied — no runtime is created
            // (upstream's gate is a no-op update + no repack, which is
            // identical). All other types keep the recorded-only
            // behavior.
            if (props.tag("enabled").d3Bool() == false) {
                disabledComponents.getOrPut(key) { HashSet() }.add(index)
                if (type == "particleEmitter" ||
                    type == "meshParticleEmitter") {
                    logOnce("enabled:$key:$index",
                        "component '$type' on node $key: enabled:false " +
                            "— particle runtime not created")
                    return
                }
                logOnce("enabled:$key:$index",
                    "component '$type' on node $key: enabled:false " +
                        "gates upstream component ticks only; dart3d " +
                        "has no tick surface — recorded, not applied")
            }
            when (type) {
                "mesh" -> decodeMesh(key, rec, props)
                "camera" -> decodeCamera(key, rec, props)
                "directionalLight" -> decodeLight(rec, props, LightManager.Type.DIRECTIONAL)
                "pointLight" -> decodeLight(rec, props, LightManager.Type.POINT)
                "spotLight" -> decodeLight(rec, props, LightManager.Type.FOCUSED_SPOT)
                "rectAreaLight" -> decodeRectAreaLight(key, rec, props)
                "particleEmitter", "meshParticleEmitter" ->
                    decodeParticleEmitter(key, rec, type, props)
                "rigidBody", "collider", "physicsWorld", "characterController" ->
                    physicsDeferred.add(PhysicsItem(key, rec, type, props))
                "fixedJoint", "sphericalJoint", "revoluteJoint",
                "prismaticJoint", "genericJoint" ->
                    jointComponentsDeferred.add(
                        JointItem(key, index, type, props))
                "materialsVariants" ->
                    decodeMaterialsVariants(key, index, props)
                "trail" -> decodeTrail(key, rec, props)
                "lod" -> decodeLod(key, rec, props)
                // W26: the dart3d geometry/instancing vocabulary.
                "d3:procMesh" -> decodeProcMesh(key, rec, props)
                "d3:instances" -> decodeInstances(key, rec, props)
                else -> Log.i(TAG, "unhandled component type '$type'")
            }
        }

        /**
         * W18: `particleEmitter` / `meshParticleEmitter` — builds the
         * CPU particle system from the same tagged property map the
         * Dart reference sim and the iOS SCNParticleSystem mapping
         * decode, then the render-side runtime (a billboard batch for
         * sprites; a baked per-particle pool for meshes — Filament's
         * Java binding has no InstanceBuffer).
         *
         * Scene membership rides the node's visibility through
         * attachIfRenderable/applyVisibility — a hidden node's runtime
         * entities stay out of the scene.
         */
        private fun decodeParticleEmitter(
            key: Long, rec: NodeRec, type: String, props: JSONObject,
        ) {
            val system = ParticleSpec.system(props)
            when (type) {
                "particleEmitter" -> {
                    val spec = SpriteEmitterSpec(props)
                    val rt = host.createSpriteParticle(
                        system, spec, rec.layers)
                    // Texture binding: the resolved texture or the
                    // neutral white fallback; a registered consumer
                    // pair picks up an upsert rebind automatically
                    // (same (instance, param) contract as materials).
                    val texKey = spec.texture
                    val tex = texKey?.let { textures[it] }
                        ?: host.fallbackWhite
                    val sampler = texKey?.let { textureSamplers[it] }
                        ?: host.textureSampler
                    rt.materialInstance.setParameter(
                        "particleMap", tex, sampler)
                    if (texKey != null) {
                        textureConsumers.getOrPut(texKey) { ArrayList() }
                            .add(Pair(rt.materialInstance, "particleMap"))
                    }
                    rec.particleRuntimes.add(rt)
                    particleRuntimes.getOrPut(key) { ArrayList() }.add(rt)
                }
                else -> {
                    val spec = MeshEmitterSpec(props)
                    val buckets = spec.geometries.map { geoKey ->
                        val gm = gpuMesh(geoKey)
                        if (gm == null) {
                            // A pending payload resolves through
                            // redecodeGeometry → onGeometryRebound.
                            logOnce("meshParticle.geo.$geoKey",
                                "meshParticleEmitter on node $key: " +
                                    "geometry $geoKey unresolved")
                        }
                        gm
                    }.toMutableList()
                    val rt = host.createMeshParticle(
                        system, spec, spec.geometries, buckets,
                        spec.material, rec.entity, rec.layers)
                    rec.particleRuntimes.add(rt)
                    particleRuntimes.getOrPut(key) { ArrayList() }.add(rt)
                }
            }
        }

        private fun decodeMesh(key: Long, rec: NodeRec, p: JSONObject) {
            rec.meshProps = p
            // W16: an `lod` decoded earlier in the same component
            // list owns the renderable slot until now — last-write-
            // wins, mirroring iOS's `node.geometry` overwrite order.
            // Its (entity,0) material-consumer entry dies with the
            // foreign renderable so a level-material upsert can't
            // stomp the mesh's slot.
            run {
                val rm = host.engine.renderableManager
                if (rm.hasComponent(rec.entity)) {
                    rm.destroy(rec.entity)
                    for ((_, list) in materialConsumers) {
                        list.removeAll { it.first == rec.entity }
                    }
                    // The lod's slot bookkeeping dies with its
                    // renderable — but it isn't suspended until the
                    // mesh actually builds, so a pending mesh
                    // geometry leaves the lod drawing (iOS's
                    // node.geometry stays the last successful write
                    // too).
                    rec.lod?.let {
                        it.ownsRenderable = false
                        it.bound = -1
                        it.boundMatKey = null
                    }
                }
            }
            // Ordered (geometry, material) pairs across the mesh's
            // primitives — see meshPrimitiveKeys for the upstream
            // tagged-map entry shape.
            val (primGeoKeys, primMatKeys) = meshPrimitiveKeys(p)
            // A consumer link rides on every geometry key — an
            // upsertResource/upsertPayload first-builds the renderable
            // from the retained mesh props once ALL primitives resolve
            // (a partial build would render a fraction of the mesh).
            for (g in primGeoKeys) {
                geometryConsumers.getOrPut(g) { LinkedHashSet() }.add(key)
            }
            val prims = primGeoKeys.mapNotNull { gpuMesh(it) }
            if (prims.size != primGeoKeys.size) {
                Log.w(TAG, "mesh node: geometry unresolved"); return
            }
            rec.meshPrimGeoKeys = primGeoKeys
            // Per-primitive materials — each consumer entry carries its
            // renderable slot so a late material upsert re-attaches at
            // the right index.
            val primInstances = ArrayList<MaterialInstance>(prims.size)
            for (i in prims.indices) {
                val mk = primMatKeys[i]
                primInstances.add(
                    mk?.let { materials[it] }
                        ?: host.litMaterial.defaultInstance)
                mk?.let {
                    materialConsumers.getOrPut(it) { ArrayList() }
                        .add(Pair(rec.entity, i))
                }
            }
            // Collider derivation sees the union of all primitives —
            // a hull or trimesh over primitive 0 alone under-covers a
            // multi-part mesh.
            aggregateGeoState(rec)
            val unionBounds = rec.lastGeoBounds ?: prims[0].bounds
            // Skinning + morphing ride the first primitive's streams —
            // upstream skinned multi-primitive meshes carry the same
            // bone channels in every primitive, and morph weights
            // apply at the renderable level.
            val mesh = prims[0]
            // W11 skin attach — the node's declared `skin` member
            // resolves a skin record and the mesh must carry the bone
            // streams. Joints resolve per-frame at bone-matrix upload
            // (a missing joint reads identity — upstream's
            // null-tolerant rule), so an in-flight IBM payload or
            // late-arriving joint never blocks the attach; the
            // `skinPayloadIds` claim + refreshSkinConsumers cover the
            // rebuild when the record itself lands.
            val skinKey = nodeSkinKeys[key]
            val skin = skinKey?.let { skins[it] }
            var skinBuf: SkinningBuffer? = null
            var boneCount = 0
            if (skinKey != null) {
                when {
                    skin == null -> logOnce("skin.$key.unresolved",
                        "node $key: skin $skinKey not realized")
                    !mesh.hasSkinning -> logOnce("skin.$key.unskinned",
                        "node $key: has skin $skinKey but its geometry" +
                            " carries no bone sources")
                    skin.jointKeys.isEmpty() -> logOnce("skin.$key.empty",
                        "node $key: skin $skinKey has no joints")
                    else -> {
                        boneCount = minOf(skin.jointKeys.size, 256)
                        skinBuf = SkinningBuffer.Builder()
                            .boneCount(boneCount)
                            .initialize(true)
                            .fenced { build(host.engine) }
                    }
                }
            }
            val builder = RenderableManager.Builder(prims.size)
                .boundingBox(Box(unionBounds[0], unionBounds[1],
                    unionBounds[2], unionBounds[3], unionBounds[4],
                    unionBounds[5]))
                // Node `layers` → the renderable's 8-bit Filament mask
                // (the view sees every layer — Dart3dView.init).
                .layerMask(0xFF, rec.layers and 0xFF)
                .castShadows(true)
                .receiveShadows(true)
            for (i in prims.indices) {
                builder.geometry(i, prims[i].primitiveType,
                    prims[i].vertexBuffer, prims[i].indexBuffer)
                    .material(i, primInstances[i])
            }
            if (skinBuf != null) {
                builder.enableSkinningBuffers(true)
                    .skinning(skinBuf, boneCount, 0)
            }
            mesh.morphTargetBuffer?.let { builder.morphing(it) }
            builder.fenced { build(host.engine, rec.entity) }
            // The mesh took the slot — suspend a decoded `lod` (the
            // per-frame pass skips it; a components re-decode
            // restores whichever order the wire sends).
            rec.lod?.let {
                it.suspended = true
                it.ownsRenderable = false
                it.bound = -1
                it.boundMatKey = null
            }
            if (skinBuf != null && skinKey != null) {
                nodeSkinning[key] = Dart3dView.NodeSkin(
                    skinKey, skinBuf, boneCount)
            }
            // Default morph weights land at attach (upstream applies
            // `weights` on morpher creation); the live array then
            // belongs to the node for setMorphWeights + the sampler.
            val mtb = mesh.morphTargetBuffer
            if (mtb != null) {
                val weights = FloatArray(mesh.morphTargetCount) { i ->
                    mesh.morphDefaults.getOrElse(i) { 0f }
                }
                rec.morphWeights = weights
                val rm = host.engine.renderableManager
                rm.setMorphWeights(rm.getInstance(rec.entity),
                    weights, 0)
            }
        }

        private fun gpuMesh(key: Long): GpuMesh? {
            gpuMeshes[key]?.let { return it }
            val md = geometries[key] ?: return null
            if (md.vertexCount == 0) {
                warnOnce("gpuMesh.$key.empty",
                    "geometry $key: empty mesh — nothing realized")
                return null
            }
            return buildGpuMesh(md).also { gpuMeshes[key] = it }
        }

        // MARK: Trails and LOD (W16)

        /**
         * Decodes a `trail` component (upstream `TrailComponent`):
         * the spec fields into a `TrailState` plus a fixed-topology
         * ribbon — 2 verts per anchor, upstream's strip winding,
         * POSITION+COLOR streams the per-frame pass refills. The
         * entity rides no parent (identity transform — the verts
         * ARE world space). Upstream serializes no trail material;
         * the shared vertex-color unlit blend instance binds here.
         * The path itself is runtime state — a re-decode starts
         * empty like upstream's codec.
         */
        private fun decodeTrail(key: Long, rec: NodeRec, p: JSONObject) {
            val maxPoints = maxOf(2,
                p.tag("maxPoints").d3Int() ?: 48)
            val entity = em.create()
            val vb = VertexBuffer.Builder()
                .vertexCount(maxPoints * 2)
                .bufferCount(1)
                .attribute(VertexBuffer.VertexAttribute.POSITION, 0,
                    VertexBuffer.AttributeType.FLOAT3, 0, 28)
                .attribute(VertexBuffer.VertexAttribute.COLOR, 0,
                    VertexBuffer.AttributeType.FLOAT4, 12, 28)
                .fenced { build(host.engine) }
            // Zeroed until the first frame records a path — dead
            // verts collapse to zero width/alpha like upstream's
            // `_TrailGeometry.setTrail`.
            val staging = java.nio.ByteBuffer.allocateDirect(
                maxPoints * 2 * 28)
                .order(java.nio.ByteOrder.nativeOrder())
            vb.setBufferAt(host.engine, 0, staging)
            val indices = ShortArray((maxPoints - 1) * 6)
            for (i in 0 until maxPoints - 1) {
                val a = (i * 2).toShort()
                val o = i * 6
                indices[o] = a; indices[o + 1] = (a + 1).toShort()
                indices[o + 2] = (a + 2).toShort()
                indices[o + 3] = (a + 1).toShort()
                indices[o + 4] = (a + 3).toShort()
                indices[o + 5] = (a + 2).toShort()
            }
            val ib = IndexBuffer.Builder()
                .indexCount(indices.size)
                .bufferType(IndexBuffer.Builder.IndexType.USHORT)
                .fenced { build(host.engine) }
            ib.setBuffer(host.engine,
                java.nio.ByteBuffer.allocateDirect(indices.size * 2)
                    .order(java.nio.ByteOrder.nativeOrder())
                    .also { b -> b.asShortBuffer().put(indices) }
                    .also { it.rewind() })
            RenderableManager.Builder(1)
                // The verts are dynamic world-space data — no static
                // AABB describes them (a zero box at the unparented
                // entity's identity transform is a point at the world
                // origin, which would frustum-cull every off-axis
                // trail). Filament only exempts an empty AABB when
                // culling is off AND the renderable is neither a
                // shadow caster nor receiver — all three flags are
                // required or build() throws.
                .culling(false)
                .layerMask(0xFF, rec.layers and 0xFF)
                .castShadows(false)
                .receiveShadows(false)
                .geometry(0, RenderableManager.PrimitiveType.TRIANGLES,
                    vb, ib)
                .material(0, host.trailMaterial.defaultInstance)
                .fenced { build(host.engine, entity) }
            // Identity world transform — the entity is unparented.
            val ident = FloatArray(16)
            Matrix.setIdentityM(ident, 0)
            tcm.create(entity, 0, ident)
            // Upstream curve `{keys:[{t,v}]}`, gradient
            // `{stops:[{t,color}]}` — decoded to flat (t,v) /
            // (t,r,g,b,a) tuples.
            fun taggedPairs(list: JSONArray?): List<FloatArray> {
                if (list == null) return emptyList()
                val out = ArrayList<FloatArray>(list.length())
                for (i in 0 until list.length()) {
                    val m = list.opt(i).d3Map() ?: continue
                    val t = m.tag("t").d3Double() ?: continue
                    val v = m.tag("v").d3Double() ?: continue
                    out.add(floatArrayOf(t.toFloat(), v.toFloat()))
                }
                return out
            }
            val wk = taggedPairs(p.tag("widthOverTrail").d3Map()
                ?.tag("keys").d3List())
            val widthKeys = if (wk.isEmpty()) null
                else FloatArray(wk.size * 2) { i -> wk[i / 2][i % 2] }
            val stops = ArrayList<FloatArray>()
            p.tag("colorOverTrail").d3Map()
                ?.tag("stops").d3List()?.let { list ->
                    for (i in 0 until list.length()) {
                        val m = list.opt(i).d3Map() ?: continue
                        val t = m.tag("t").d3Double() ?: continue
                        val c = m.tag("color").d3Color() ?: continue
                        stops.add(floatArrayOf(
                            t.toFloat(), c[0], c[1], c[2], c[3]))
                    }
                }
            val colorStops = if (stops.isEmpty()) null
                else FloatArray(stops.size * 5) { i ->
                    stops[i / 5][i % 5]
                }
            rec.trail = TrailState(
                entity = entity,
                vertexBuffer = vb,
                indexBuffer = ib,
                maxPoints = maxPoints,
                width = (p.tag("width").d3Double() ?: 0.25).toFloat(),
                lifetime =
                    (p.tag("lifetime").d3Double() ?: 0.6).toFloat(),
                minVertexDistance =
                    (p.tag("minVertexDistance").d3Double() ?: 0.05)
                        .toFloat(),
                emitting = p.tag("emitting").d3Bool() ?: true,
                widthKeys = widthKeys,
                colorStops = colorStops,
                points = FloatArray(maxPoints * 3),
                born = DoubleArray(maxPoints),
                staging = staging,
            )
        }

        /**
         * Decodes an `lod` component (upstream `LodComponent`): each
         * `levels` entry carries geometry+material refs plus a
         * `screenSize` threshold (fraction of viewport height,
         * descending); entries missing either ref are skipped like
         * upstream's codec. The lod owns the node's renderable slot —
         * a `mesh` decoded earlier in the same component list yields
         * here (iOS's `node.geometry` overwrite order), a later one
         * suspends the pass. Level resources resolve per bind; a
         * landing re-runs [refreshLodConsumers].
         */
        private fun decodeLod(key: Long, rec: NodeRec, p: JSONObject) {
            val levels = ArrayList<LodLevelSpec>()
            val list = p.tag("levels").d3List()
            if (list != null) {
                for (i in 0 until list.length()) {
                    val m = list.opt(i).d3Map() ?: continue
                    val g = m.tag("geometry").d3Ref() ?: continue
                    val mat = m.tag("material").d3Ref() ?: continue
                    // Upstream's _levelEntries drops a level only for
                    // a missing/mistyped geometry or material ref; an
                    // absent/malformed screenSize decodes as 0.0 —
                    // the never-cull threshold, NOT a dropped level.
                    val s = m.tag("screenSize").d3Double() ?: 0.0
                    levels.add(LodLevelSpec(g, mat, s))
                }
            }
            if (levels.isEmpty()) return
            rec.lod = LodState(
                levels = levels,
                lodBias = p.tag("lodBias").d3Double() ?: 1.0,
                // Upstream's dead-band (LodCodec/LodComponent default
                // 0.1) — live now that selection is ours.
                hysteresis = p.tag("hysteresis").d3Double() ?: 0.1,
                // Wire parity only — a documented no-op (hard switch).
                blendRange = p.tag("blendRange").d3Double() ?: 0.0,
            )
            bindLodLevel(key, rec, 0)
        }

        /**
         * Binds level [idx] of the node's `lod` to its renderable
         * slot — the geometry+material swap the per-frame selection
         * pass drives. A foreign renderable (a `mesh` decoded
         * earlier, or none) is destroyed and rebuilt single-
         * primitive; one the lod already owns takes the cheap
         * setGeometryAt/setMaterialInstanceAt path. An unresolved
         * level leaves the current binding — a resource landing
         * retries via [refreshLodConsumers], and the frame pass
         * re-evaluates every step regardless. `idx` -1 is the cull
         * floor: the entity leaves the scene until a later
         * selection re-binds. [force] rebinds the current level —
         * the geometry-upsert path, whose new buffers must replace
         * the bound (about-to-be-destroyed) ones.
         */
        private fun bindLodLevel(key: Long, rec: NodeRec, idx: Int,
                                 force: Boolean = false) {
            val lod = rec.lod ?: return
            if (lod.suspended) return
            if (idx < 0) {
                if (lod.bound >= 0) {
                    host.scene.remove(rec.entity)
                    lod.boundMatKey?.let { mk ->
                        materialConsumers[mk]?.removeAll {
                            it.first == rec.entity
                        }
                    }
                    lod.bound = -1
                    lod.boundMatKey = null
                }
                return
            }
            if (!force && lod.bound == idx) return
            val level = lod.levels[idx]
            val gm = gpuMesh(level.geoKey) ?: return
            val mi = materials[level.matKey] ?: return
            val rm = host.engine.renderableManager
            // Take a foreign renderable over wholesale — the lod
            // renders exactly one level, so a mesh's multi-primitive
            // slots can't ride setGeometryAt.
            if (!lod.ownsRenderable && rm.hasComponent(rec.entity)) {
                rm.destroy(rec.entity)
                for ((_, list) in materialConsumers) {
                    list.removeAll { it.first == rec.entity }
                }
                for ((_, set) in geometryConsumers) set.remove(key)
            }
            val b = gm.bounds
            if (!rm.hasComponent(rec.entity)) {
                RenderableManager.Builder(1)
                    .boundingBox(Box(b[0], b[1], b[2],
                        b[3], b[4], b[5]))
                    .layerMask(0xFF, rec.layers and 0xFF)
                    .castShadows(true)
                    .receiveShadows(true)
                    .geometry(0, gm.primitiveType, gm.vertexBuffer,
                        gm.indexBuffer)
                    .material(0, mi)
                    .fenced { build(host.engine, rec.entity) }
            } else {
                val ri = rm.getInstance(rec.entity)
                rm.setGeometryAt(ri, 0, gm.primitiveType,
                    gm.vertexBuffer, gm.indexBuffer)
                rm.setMaterialInstanceAt(ri, 0, mi)
                rm.setAxisAlignedBoundingBox(ri,
                    Box(b[0], b[1], b[2], b[3], b[4], b[5]))
            }
            // The (entity,0) consumer entry belongs to the bound
            // level's material — one live entry at a time so a
            // material upsert writes the live level's slot.
            lod.boundMatKey?.let { mk ->
                materialConsumers[mk]?.removeAll {
                    it.first == rec.entity
                }
            }
            materialConsumers.getOrPut(level.matKey) { ArrayList() }
                .add(Pair(rec.entity, 0))
            lod.bound = idx
            lod.boundMatKey = level.matKey
            lod.ownsRenderable = true
            if (!isHidden(key)) attachIfRenderable(rec)
        }

        /**
         * Rebinds the live level of every `lod` spec consuming the
         * just-landed resource `key` — a geometry upsert swaps the
         * GpuMesh buffers under the bound renderable (stale buffers
         * are destroyed by the upsert), a material landing re-
         * resolves the instance. Unbound/culled specs need nothing:
         * the frame pass re-resolves per bind.
         */
        fun refreshLodConsumers(resKey: Long) {
            for ((key, rec) in nodes) {
                val lod = rec.lod ?: continue
                if (lod.suspended || lod.bound < 0) continue
                val l = lod.levels[lod.bound]
                if (l.geoKey == resKey || l.matKey == resKey) {
                    bindLodLevel(key, rec, lod.bound, force = true)
                }
            }
        }

        /**
         * Destroys a node's trail/lod runtime state — shared by
         * `teardownComponents`, node removal, and the install sweep.
         * The trail's unparented entity and dynamic buffers die
         * here; the lod's renderable/entity belong to the node and
         * die with it — only its consumer entry drops.
         */
        fun destroyTrailLod(rec: NodeRec) {
            val rm = host.engine.renderableManager
            rec.trail?.let { tr ->
                host.scene.remove(tr.entity)
                if (rm.hasComponent(tr.entity)) rm.destroy(tr.entity)
                host.engine.destroyEntity(tr.entity)
                em.destroy(tr.entity)
                host.engine.destroyVertexBuffer(tr.vertexBuffer)
                host.engine.destroyIndexBuffer(tr.indexBuffer)
            }
            rec.trail = null
            rec.lod?.let { lod ->
                lod.boundMatKey?.let { mk ->
                    materialConsumers[mk]?.removeAll {
                        it.first == rec.entity
                    }
                }
            }
            rec.lod = null
        }

        // MARK: Trails and LOD frame pass (W16)

        /** Per-vertex color scratch for [tickTrail]'s refill — the
         *  pass runs on the frame thread only. */
        private val colorScratch = FloatArray(4)

        /**
         * Samples the flat `widthOverTrail` (t,v) pairs at the
         * head-to-tail fraction [t] — piecewise-linear, clamped to
         * the ends; the absent-ramp fallback is upstream's `1 − t`
         * taper. Port of `sampleTrailStops`.
         */
        private fun sampleTrailKeys(keys: FloatArray?, t: Float): Float {
            if (keys == null || keys.isEmpty()) return 1f - t
            val n = keys.size / 2
            if (t <= keys[0]) return keys[1]
            if (t >= keys[(n - 1) * 2]) return keys[(n - 1) * 2 + 1]
            for (i in 1 until n) {
                val bt = keys[i * 2]
                if (t <= bt) {
                    val at = keys[(i - 1) * 2]
                    val av = keys[(i - 1) * 2 + 1]
                    val bv = keys[i * 2 + 1]
                    return av + (bv - av) * (t - at) / (bt - at)
                }
            }
            return keys[(n - 1) * 2 + 1]
        }

        /**
         * Samples the flat `colorOverTrail` (t,r,g,b,a) tuples at
         * [t] into [out] — piecewise-linear rgba, clamped; the
         * absent-gradient fallback is upstream's white fading
         * alpha `1 − t`. Port of `sampleTrailColorStops`.
         */
        private fun sampleTrailColor(stops: FloatArray?, t: Float,
                                     out: FloatArray) {
            if (stops == null || stops.isEmpty()) {
                out[0] = 1f; out[1] = 1f; out[2] = 1f
                out[3] = 1f - t
                return
            }
            val n = stops.size / 5
            fun cp(i: Int) {
                out[0] = stops[i * 5 + 1]
                out[1] = stops[i * 5 + 2]
                out[2] = stops[i * 5 + 3]
                out[3] = stops[i * 5 + 4]
            }
            if (t <= stops[0]) { cp(0); return }
            if (t >= stops[(n - 1) * 5]) { cp(n - 1); return }
            for (i in 1 until n) {
                val bt = stops[i * 5]
                if (t <= bt) {
                    val at = stops[(i - 1) * 5]
                    val f = (t - at) / (bt - at)
                    for (c in 0..3) {
                        val a = stops[(i - 1) * 5 + 1 + c]
                        val bv = stops[i * 5 + 1 + c]
                        out[c] = a + (bv - a) * f
                    }
                    return
                }
            }
            cp(n - 1)
        }

        /**
         * The per-frame trail/lod pass — the host's `stepFrame`
         * calls it after the camera updates, before render (the
         * same slot iOS's renderer delegate uses). Trails record
         * head-first world points, expire by age/capacity, and
         * refill the camera-facing ribbon; lods project the
         * level-0 bounding sphere and rebind (or cull) the node.
         */
        fun updateTrailsLods(dt: Float, camPos: FloatArray,
                             fovRadY: Double, perspective: Boolean) {
            for ((key, rec) in nodes) {
                rec.trail?.let { tickTrail(key, rec, it, dt, camPos) }
                val lod = rec.lod
                if (lod != null && !lod.suspended) {
                    updateLod(key, rec, lod, camPos, fovRadY,
                        perspective)
                }
            }
        }

        /**
         * Advances one trail: the head follows the node's world
         * position, a new anchor drops after `minVertexDistance`,
         * the tail expires by `lifetime`/`maxPoints` (upstream's
         * `TrailComponent.update` policy — `emitting` false pauses
         * recording while the path still ages out). Then the
         * ribbon refills: two verts per anchor offset `±width·side`
         * where `side = normalize(tangent × toCamera)` — world
         * space, the entity is unparented. Under two live points
         * (or a hidden chain) the entity leaves the scene.
         */
        private fun tickTrail(key: Long, rec: NodeRec,
                              tr: TrailState, dt: Float,
                              camPos: FloatArray) {
            tr.time += dt
            val m = FloatArray(16)
            tcm.getWorldTransform(tcm.getInstance(rec.entity), m)
            val hx = m[12]; val hy = m[13]; val hz = m[14]
            if (tr.emitting) {
                if (tr.count == 0) {
                    tr.points[0] = hx
                    tr.points[1] = hy
                    tr.points[2] = hz
                    tr.born[0] = tr.time
                    tr.count = 1
                } else {
                    // The head follows continuously; a new anchor
                    // drops once the node has moved far enough
                    // from the previous one.
                    tr.points[0] = hx
                    tr.points[1] = hy
                    tr.points[2] = hz
                    tr.born[0] = tr.time
                    val a = if (tr.count > 1) 3 else 0
                    val dx = tr.points[a] - hx
                    val dy = tr.points[a + 1] - hy
                    val dz = tr.points[a + 2] - hz
                    val d2 = dx * dx + dy * dy + dz * dz
                    if (tr.count == 1 ||
                        d2 >= tr.minVertexDistance *
                            tr.minVertexDistance) {
                        // Insert at the head — the tail slot drops
                        // when the buffer is full (upstream's
                        // insert-then-trim, same result).
                        val n = minOf(tr.count + 1, tr.maxPoints)
                        for (i in n - 1 downTo 1) {
                            tr.points[i * 3] = tr.points[(i - 1) * 3]
                            tr.points[i * 3 + 1] =
                                tr.points[(i - 1) * 3 + 1]
                            tr.points[i * 3 + 2] =
                                tr.points[(i - 1) * 3 + 2]
                            tr.born[i] = tr.born[i - 1]
                        }
                        tr.points[0] = hx
                        tr.points[1] = hy
                        tr.points[2] = hz
                        tr.born[0] = tr.time
                        tr.count = n
                    }
                }
            }
            while (tr.count > 0 &&
                tr.time - tr.born[tr.count - 1] > tr.lifetime) {
                tr.count--
            }
            // Refill the ribbon — port of expandTrailRibbon: two
            // verts per anchor, `side = normalize(tangent ×
            // toCamera)`, degenerate tangents reuse the last good
            // side, a camera on the point falls back to any
            // perpendicular.
            val buf = tr.staging
            buf.clear()
            val live = tr.count >= 2
            var sx = 1f; var sy = 0f; var sz = 0f
            if (live) {
                for (i in 0 until tr.count) {
                    val px = tr.points[i * 3]
                    val py = tr.points[i * 3 + 1]
                    val pz = tr.points[i * 3 + 2]
                    val prev = if (i == 0) 0 else i - 1
                    val next = if (i == tr.count - 1)
                        tr.count - 1 else i + 1
                    var tx = tr.points[prev * 3] -
                        tr.points[next * 3]
                    var ty = tr.points[prev * 3 + 1] -
                        tr.points[next * 3 + 1]
                    var tz = tr.points[prev * 3 + 2] -
                        tr.points[next * 3 + 2]
                    var tl2 = tx * tx + ty * ty + tz * tz
                    if (tl2 < 1e-12f && tr.count > 1) {
                        val j = if (i == 0) 0 else i - 1
                        val k = if (i == 0) 1 else i
                        tx = tr.points[j * 3] - tr.points[k * 3]
                        ty = tr.points[j * 3 + 1] -
                            tr.points[k * 3 + 1]
                        tz = tr.points[j * 3 + 2] -
                            tr.points[k * 3 + 2]
                        tl2 = tx * tx + ty * ty + tz * tz
                    }
                    if (tl2 >= 1e-12f) {
                        val vx = camPos[0] - px
                        val vy = camPos[1] - py
                        val vz = camPos[2] - pz
                        var cx = ty * vz - tz * vy
                        var cy = tz * vx - tx * vz
                        var cz = tx * vy - ty * vx
                        var cl2 = cx * cx + cy * cy + cz * cz
                        if (cl2 < 1e-12f) {
                            // Camera on the tangent — any
                            // perpendicular (tangent × up, then
                            // tangent × X).
                            cx = tz; cy = 0f; cz = -tx
                            cl2 = cx * cx + cz * cz
                            if (cl2 < 1e-12f) {
                                cx = 0f; cy = tz; cz = -ty
                                cl2 = cy * cy + cz * cz
                            }
                        }
                        if (cl2 >= 1e-12f) {
                            val inv = (1.0 / kotlin.math.sqrt(
                                cl2.toDouble())).toFloat()
                            sx = cx * inv; sy = cy * inv; sz = cz * inv
                        }
                    }
                    val t = if (tr.count > 1)
                        i.toFloat() / (tr.count - 1) else 0f
                    val w = tr.width *
                        sampleTrailKeys(tr.widthKeys, t)
                    val half = w * 0.5f
                    sampleTrailColor(tr.colorStops, t, colorScratch)
                    buf.putFloat(px + sx * half)
                    buf.putFloat(py + sy * half)
                    buf.putFloat(pz + sz * half)
                    buf.putFloat(colorScratch[0])
                    buf.putFloat(colorScratch[1])
                    buf.putFloat(colorScratch[2])
                    buf.putFloat(colorScratch[3])
                    buf.putFloat(px - sx * half)
                    buf.putFloat(py - sy * half)
                    buf.putFloat(pz - sz * half)
                    buf.putFloat(colorScratch[0])
                    buf.putFloat(colorScratch[1])
                    buf.putFloat(colorScratch[2])
                    buf.putFloat(colorScratch[3])
                }
            }
            // Dead verts collapse to zero width/alpha (upstream's
            // `_TrailGeometry.setTrail` zero-fill).
            while (buf.position() < buf.capacity()) buf.putFloat(0f)
            buf.rewind()
            tr.vertexBuffer.setBufferAt(host.engine, 0, buf)
            val want = live && !isHidden(key)
            if (want && !tr.inScene) {
                host.scene.addEntity(tr.entity)
                tr.inScene = true
            } else if (!want && tr.inScene) {
                host.scene.remove(tr.entity)
                tr.inScene = false
            }
        }

        /**
         * Resolves the node's `lod` selection for this frame —
         * upstream `_resolveLod`: the circumscribed sphere of the
         * level-0 (highest-detail) world AABB projected through
         * `lodScreenSize`, biased by `lodBias`, then the first
         * threshold the size still meets under the `hysteresis`
         * dead-band (upstream `selectLodLevel`); below the smallest
         * is the cull floor (a last threshold of `0` always meets →
         * never culls). A non-perspective camera — or an
         * unresolved level-0 geometry — falls back to highest
         * detail.
         */
        private fun updateLod(key: Long, rec: NodeRec,
                              lod: LodState, camPos: FloatArray,
                              fovRadY: Double, perspective: Boolean) {
            if (!perspective) {
                bindLodLevel(key, rec, 0)
                return
            }
            val gm = gpuMesh(lod.levels[0].geoKey)
            if (gm == null) {
                bindLodLevel(key, rec, 0)
                return
            }
            // World AABB of the level-0 bounds — transform the 8
            // corners (rotation and non-uniform scale both land).
            val m = FloatArray(16)
            tcm.getWorldTransform(tcm.getInstance(rec.entity), m)
            val b = gm.bounds
            var lx = Float.MAX_VALUE
            var ly = Float.MAX_VALUE
            var lz = Float.MAX_VALUE
            var hx = -Float.MAX_VALUE
            var hy = -Float.MAX_VALUE
            var hz = -Float.MAX_VALUE
            for (cxs in intArrayOf(-1, 1)) {
                for (cys in intArrayOf(-1, 1)) {
                    for (czs in intArrayOf(-1, 1)) {
                        val x = b[0] + b[3] * cxs
                        val y = b[1] + b[4] * cys
                        val z = b[2] + b[5] * czs
                        val wx = m[0] * x + m[4] * y + m[8] * z + m[12]
                        val wy = m[1] * x + m[5] * y + m[9] * z + m[13]
                        val wz = m[2] * x + m[6] * y + m[10] * z + m[14]
                        lx = minOf(lx, wx); hx = maxOf(hx, wx)
                        ly = minOf(ly, wy); hy = maxOf(hy, wy)
                        lz = minOf(lz, wz); hz = maxOf(hz, wz)
                    }
                }
            }
            val ccx = (lx + hx) * 0.5f
            val ccy = (ly + hy) * 0.5f
            val ccz = (lz + hz) * 0.5f
            // The circumscribed sphere — upstream's conservative
            // choice (detail kept slightly longer than a tight
            // sphere would).
            val rdx = hx - lx; val rdy = hy - ly; val rdz = hz - lz
            val radius = kotlin.math.sqrt(
                (rdx * rdx + rdy * rdy + rdz * rdz).toDouble()) * 0.5
            val ddx = ccx - camPos[0]
            val ddy = ccy - camPos[1]
            val ddz = ccz - camPos[2]
            val dist = kotlin.math.sqrt(
                (ddx * ddx + ddy * ddy + ddz * ddz).toDouble())
            // lodScreenSize: inside the sphere → infinite (highest
            // detail); else the sphere's angular share of the
            // viewport height.
            val size = if (dist <= radius) Double.MAX_VALUE
                else radius /
                    (dist * kotlin.math.tan(fovRadY * 0.5))
            val scaled = size * lod.lodBias
            // Upstream `LodSelection.resolve`'s hard-switch arm —
            // the hysteresis dead-band reads the bound level as its
            // `_currentLevel` memory.
            val sel = selectLodLevel(
                scaled, lod.levels, lod.hysteresis, lod.bound)
            bindLodLevel(key, rec, sel)
        }

        /**
         * Upstream `selectLodLevel` — the first level whose
         * descending `screenSize` threshold the (already biased)
         * [size] meets, then the [hysteresis] dead-band around
         * [currentLevel]'s boundaries: an adjacent crossing holds
         * until the size clears the boundary by the fractional
         * margin (finer at `t·(1+h)`, coarser at `t·(1−h)`; the cull
         * floor is the boundary below the last level both ways); a
         * non-adjacent jump switches immediately. `-1` culls below
         * the smallest threshold (a last threshold of `0` never
         * culls).
         */
        private fun selectLodLevel(
            size: Double, levels: List<LodLevelSpec>,
            hysteresis: Double, currentLevel: Int,
        ): Int {
            var naive = -1
            for (i in levels.indices) {
                if (size >= levels[i].screenSize) {
                    naive = i
                    break
                }
            }
            if (naive == currentLevel || hysteresis <= 0.0) {
                return naive
            }
            val last = levels.size - 1
            if (currentLevel >= 1 && naive == currentLevel - 1) {
                return if (size >= levels[currentLevel - 1].screenSize *
                    (1 + hysteresis)) naive else currentLevel
            }
            if (currentLevel >= 0 && naive == currentLevel + 1) {
                return if (size < levels[currentLevel].screenSize *
                    (1 - hysteresis)) naive else currentLevel
            }
            if (currentLevel == last && naive == -1) {
                return if (size < levels[last].screenSize *
                    (1 - hysteresis)) -1 else currentLevel
            }
            if (currentLevel == -1 && naive == last) {
                return if (size >= levels[last].screenSize *
                    (1 + hysteresis)) naive else -1
            }
            return naive
        }

        /**
         * Rebuilds the node's collider-facing geometry state —
         * positions concatenated, triangle indices re-based by each
         * primitive's vertex offset, bounds unioned — across the
         * primitives recorded in `meshPrimGeoKeys`. Returns false when
         * a primitive's GPU mesh is missing (caller keeps prior state).
         */
        private fun aggregateGeoState(rec: NodeRec): Boolean {
            val keys = rec.meshPrimGeoKeys ?: return false
            val prims = ArrayList<GpuMesh>(keys.size)
            for (k in keys) prims.add(gpuMeshes[k] ?: return false)
            var posLen = 0
            var idxLen = 0
            for (m in prims) {
                posLen += m.positions.size
                idxLen += m.indices.size
            }
            val pos = FloatArray(posLen)
            val idx = IntArray(idxLen)
            var posOff = 0
            var idxOff = 0
            var vertBase = 0
            val lo = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE,
                Float.MAX_VALUE)
            val hi = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE,
                -Float.MAX_VALUE)
            for (m in prims) {
                System.arraycopy(m.positions, 0, pos, posOff,
                    m.positions.size)
                for (j in m.indices.indices) {
                    idx[idxOff + j] = m.indices[j] + vertBase
                }
                vertBase += m.positions.size / 3
                posOff += m.positions.size
                idxOff += m.indices.size
                // m.bounds = (cx,cy,cz, hx,hy,hz) → AABB union.
                for (a in 0..2) {
                    lo[a] = minOf(lo[a], m.bounds[a] - m.bounds[a + 3])
                    hi[a] = maxOf(hi[a], m.bounds[a] + m.bounds[a + 3])
                }
            }
            rec.lastGeoPositions = pos
            rec.lastGeoIndices = idx
            rec.lastGeoBounds = FloatArray(6) { a ->
                if (a < 3) (lo[a] + hi[a]) / 2f
                else (hi[a - 3] - lo[a - 3]) / 2f
            }
            return true
        }

        private fun buildGpuMesh(md: MeshFactory.MeshData): GpuMesh {
            val vbBuilder = VertexBuffer.Builder()
                .vertexCount(md.vertexCount)
                .bufferCount(1)
                .attribute(VertexBuffer.VertexAttribute.POSITION, 0,
                    VertexBuffer.AttributeType.FLOAT3, 0, md.vertexStrideBytes)
                .attribute(VertexBuffer.VertexAttribute.TANGENTS, 0,
                    VertexBuffer.AttributeType.FLOAT4, 12, md.vertexStrideBytes)
            if (md.hasUvColor) {
                vbBuilder.attribute(VertexBuffer.VertexAttribute.UV0, 0,
                    VertexBuffer.AttributeType.FLOAT2, 28, md.vertexStrideBytes)
                vbBuilder.attribute(VertexBuffer.VertexAttribute.COLOR, 0,
                    VertexBuffer.AttributeType.FLOAT4, 36, md.vertexStrideBytes)
                // W21: uv1 tails the 60-byte base record (zero-filled
                // when the wire layout lacks TEXCOORD_1) — a slot's
                // `texCoord` selects between UV0/UV1 at sample time.
                vbBuilder.attribute(VertexBuffer.VertexAttribute.UV1, 0,
                    VertexBuffer.AttributeType.FLOAT2, 52, md.vertexStrideBytes)
            }
            if (md.hasSkinning) {
                // The skinned repack tails each 60-byte record with
                // [joints u16x4 @60 | weights f32x4 @68]. BONE_INDICES
                // must be an integer attribute — the shader consumes
                // uvec4 (Filament's VertexBuffer.attribute forces
                // FLAG_INTEGER_TARGET for it).
                vbBuilder.attribute(VertexBuffer.VertexAttribute.BONE_INDICES,
                    0, VertexBuffer.AttributeType.USHORT4, 60,
                    md.vertexStrideBytes)
                vbBuilder.attribute(VertexBuffer.VertexAttribute.BONE_WEIGHTS,
                    0, VertexBuffer.AttributeType.FLOAT4, 68,
                    md.vertexStrideBytes)
            }
            val vb = vbBuilder.fenced { build(host.engine) }
            vb.setBufferAt(host.engine, 0, md.vertices)
            val indexType = if (md.indexWidth == MeshFactory.IndexWidth.UINT32) {
                IndexBuffer.Builder.IndexType.UINT
            } else {
                IndexBuffer.Builder.IndexType.USHORT
            }
            val ib = IndexBuffer.Builder()
                .indexCount(md.indexCount)
                .bufferType(indexType)
                .fenced { build(host.engine) }
            ib.setBuffer(host.engine, md.indices)

            val pos = FloatArray(md.vertexCount * 3)
            md.vertices.rewind()
            for (i in 0 until md.vertexCount) {
                val base = i * md.vertexStrideBytes
                pos[i * 3] = md.vertices.getFloat(base)
                pos[i * 3 + 1] = md.vertices.getFloat(base + 4)
                pos[i * 3 + 2] = md.vertices.getFloat(base + 8)
            }
            md.vertices.rewind()
            val idx = IntArray(md.indexCount)
            if (md.indexWidth == MeshFactory.IndexWidth.UINT32) {
                val ints = md.indices.asIntBuffer()
                for (i in 0 until md.indexCount) idx[i] = ints.get(i)
            } else {
                val shorts = md.indices.asShortBuffer()
                for (i in 0 until md.indexCount) {
                    idx[i] = shorts.get(i).toInt() and 0xFFFF
                }
            }
            val primitive = when (md.topology) {
                MeshFactory.Topology.TRIANGLES -> RenderableManager.PrimitiveType.TRIANGLES
                MeshFactory.Topology.TRIANGLE_STRIP -> RenderableManager.PrimitiveType.TRIANGLE_STRIP
                MeshFactory.Topology.LINES -> RenderableManager.PrimitiveType.LINES
                MeshFactory.Topology.LINE_STRIP -> RenderableManager.PrimitiveType.LINE_STRIP
                MeshFactory.Topology.POINTS -> RenderableManager.PrimitiveType.POINTS
            }
            // W11: the decoded deltas become a MorphTargetBuffer —
            // float4 delta positions (+ packed absolute tangent quats
            // when declared) per target.
            var mtb: MorphTargetBuffer? = null
            md.morph?.let { morph ->
                val bb = MorphTargetBuffer.Builder()
                    .vertexCount(md.vertexCount)
                    .count(morph.targetCount)
                    .withPositions(true)
                if (morph.tangents != null) bb.withTangents(true)
                val buf = bb.fenced { build(host.engine) }
                val n = md.vertexCount
                for (t in 0 until morph.targetCount) {
                    buf.setPositionsAt(host.engine, t,
                        morph.positions.copyOfRange(t * n * 4,
                            (t + 1) * n * 4), n)
                    morph.tangents?.let {
                        buf.setTangentsAt(host.engine, t,
                            it.copyOfRange(t * n * 4, (t + 1) * n * 4), n)
                    }
                }
                mtb = buf
            }
            return GpuMesh(
                vb, ib, md.vertexCount, md.indexCount, md.bounds, pos, idx,
                primitive,
                hasSkinning = md.hasSkinning,
                morphTargetBuffer = mtb,
                morphDefaults = md.morph?.defaultWeights ?: FloatArray(0),
                morphTargetCount = md.morph?.targetCount ?: 0)
        }

        private fun decodeCamera(key: Long, rec: NodeRec, p: JSONObject) {
            rec.isCamera = true
            // W14: every camera node's props are retained — view
            // cameras build per-view projections from nodeCameraProps
            // at frame time. The FIRST camera still claims the view's
            // Camera at install (the default path is unchanged).
            nodeCameraProps[key] = RenderTargets.CameraSpec.parse(p)
            if (firstCameraKey == null) {
                firstCameraKey = key
                cameraProps = p
            }
        }

        private fun decodeLight(
            rec: NodeRec, p: JSONObject, type: LightManager.Type,
        ) {
            val builder = LightManager.Builder(type)
            // Travel direction in the node's local (wire) space — the
            // upstream flutter_scene 0.23.0 contract:
            //  * directionalLight: `localDirection` when serialized,
            //    else wire-local +Z (DirectionalLightComponent
            //    .worldDirection = rotation × (0,0,1)).
            //  * spotLight: `direction` (SpotLightComponent; codec
            //    default (0,−1,0)).
            // The z-mirror conversion (S·R·S) maps a wire-local vector
            // v to Filament-local S·v, so wire +Z is Filament (0,0,−1).
            // Filament's builder default is (0,−1,0): left unset (as
            // it was), directional keys grazed the scene and cast
            // shadows away from every receiver — the audit's "inert
            // shadow chain".
            val wireDir: DoubleArray? = when (type) {
                LightManager.Type.DIRECTIONAL ->
                    p.tag("localDirection").d3Vec3()
                        ?: doubleArrayOf(0.0, 0.0, 1.0)
                LightManager.Type.FOCUSED_SPOT, LightManager.Type.SPOT ->
                    p.tag("direction").d3Vec3()
                        ?: doubleArrayOf(0.0, -1.0, 0.0)
                else -> null
            }
            wireDir?.let {
                val d = D3Wire.position(it)
                builder.direction(d[0], d[1], d[2])
            }
            p.tag("color").d3Color()?.let {
                builder.color(it[0], it[1], it[2])
            }
            // Upstream's defaults: 3 for a directional light, 1 for the
            // others (see the unit note at the top of the file).
            val directional = type == LightManager.Type.DIRECTIONAL
            val intensity = (p.tag("intensity").d3Double() ?: if (directional) 3.0 else 1.0).toFloat()
            if (!directional) {
                val range = p.tag("range").d3Double() ?: 0.0
                builder.falloff(
                    if (range > 0) range.toFloat()
                    else UNBOUNDED_LIGHT_RANGE)
            }
            if (type == LightManager.Type.FOCUSED_SPOT) {
                // Half-angles, radians; upstream's defaults.
                val inner = (p.tag("innerConeAngle").d3Double() ?: 0.0)
                val outer = (p.tag("outerConeAngle").d3Double()
                    ?: (kotlin.math.PI / 4))
                builder.spotLightCone(inner.toFloat(), outer.toFloat())
            }
            val castsShadow = p.tag("castsShadow").d3Bool() == true
            if (castsShadow) {
                builder.castShadows(true)
            }
            if (type == LightManager.Type.DIRECTIONAL) {
                // dart3d wire extension — upstream carries it on
                // `sunLight`, deferred here. Light-level, not a
                // shadow option, so it applies whether or not the
                // light casts (matches iOS's decode placement).
                p.tag("angularRadius").d3Double()?.let {
                    // Wire radians → Filament degrees. Filament reads
                    // sunAngularRadius only on SUN lights (the sky
                    // disk); this DIRECTIONAL light keeps its shadow
                    // penumbra from shadowRadius/shadowSoftness — say
                    // so rather than claim the mapping.
                    builder.sunAngularRadius(
                        Math.toDegrees(it).toFloat())
                    warnOnce("w24.directional.angularRadius",
                        "angularRadius has no effect on a Filament " +
                            "DIRECTIONAL light (SUN-only); shadow " +
                            "softness follows shadowSoftness")
                }
                // The contact-shadow extensions still need a casting
                // light — warn rather than drop silently.
                if (!castsShadow &&
                    (p.tag("contactShadows") != null ||
                        p.tag("contactShadowDistance") != null)
                ) {
                    warnOnce("w24.directional.contactShadow.noCast",
                        "contactShadows/contactShadowDistance require " +
                            "castsShadow — ignored on a non-casting " +
                            "directional light")
                }
                // Unmapped upstream `DirectionalLightCodec` members —
                // warned here, outside the castsShadow gate, since
                // they aren't shadow fields: `priority` (feature
                // priority). `localDirection` is honored above.
                for (field in listOf("priority")) {
                    if (p.tag(field) != null) {
                        warnOnce("w24.directional.$field",
                            "directionalLight '$field' is an " +
                                "upstream field with no dart3d " +
                                "mapping; ignored")
                    }
                }
            }
            builder.fenced { build(host.engine, rec.entity) }
            rec.lightOwner = LightOwner(listOf(rec.entity), directional, intensity = intensity).also {
                it.write(host.engine.lightManager, intensity)
            }
            if (castsShadow) {
                val lm = host.engine.lightManager
                val lightInstance = lm.getInstance(rec.entity)
                val so = lm.getShadowOptions(lightInstance)
                so.mapSize =
                    if (host.viewQuality == "high") 2048 else 1024
                p.tag("shadowDepthBias").d3Double()?.let {
                    so.constantBias = it.toFloat()
                    so.normalBias = (it * 0.5).toFloat()
                }
                p.tag("shadowRadius").d3Double()?.let {
                    so.shadowBulbRadius = it.toFloat()
                }
                if (type == LightManager.Type.DIRECTIONAL) {
                    decodeDirectionalShadowOptions(so, p)
                }
                lm.setShadowOptionsPreservingTransform(lightInstance, so)
                Log.i(TAG, "shadow options: mapSize=${so.mapSize}" +
                    " cascades=${so.shadowCascades}" +
                    " far=${so.shadowFar} contactDist=${so.maxShadowDistance}" +
                    " contact=${so.screenSpaceContactShadows}" +
                    " bias=${so.constantBias} normalBias=${so.normalBias}" +
                    " bulbRadius=${so.shadowBulbRadius}")
            }
        }

        private fun decodeDirectionalShadowOptions(
            so: LightManager.ShadowOptions,
            p: JSONObject,
        ) {
            p.tag("shadowMapResolution").d3Double()?.let {
                so.mapSize = it.toInt().coerceIn(64, 4096)
            }
            p.tag("shadowCascadeCount").d3Double()?.let {
                so.shadowCascades = it.toInt().coerceIn(1, 4)
            }
            p.tag("shadowMaxDistance").d3Double()?.let {
                // The camera-distance range the shadow map covers —
                // Filament's `shadowFar`. (`maxShadowDistance` is the
                // CONTACT-shadow ray length; writing the range there
                // left the map spanning the whole camera frustum.)
                so.shadowFar = it.toFloat()
            }
            p.tag("shadowNormalBias").d3Double()?.let {
                // Exact — overrides the shadowDepthBias 2:1 split's
                // normal half when both are authored.
                so.normalBias = it.toFloat()
            }
            p.tag("contactShadows").d3Bool()?.let {
                // dart3d wire extension — upstream carries it on
                // `sunLight`, deferred here. Exact — Filament's
                // screen-space contact-shadow chain.
                so.screenSpaceContactShadows = it
            }
            p.tag("contactShadowDistance").d3Double()?.let {
                // dart3d wire extension — upstream carries it on
                // `sunLight`, deferred here. Exact — Filament's
                // `maxShadowDistance` is the contact-shadow march's
                // world-space reach.
                so.maxShadowDistance = it.toFloat()
            }
            p.tag("shadowSoftness").d3Double()?.let {
                // Precedence: `shadowRadius` (W6) and `shadowSoftness`
                // (W24) write the same knob — this decode runs second,
                // so softness wins when a document authors both.
                so.shadowBulbRadius = it.toFloat()
            }
            p.tag("shadowCascadeSplitLambda").d3Double()?.let { lambda ->
                if (so.shadowCascades > 1) {
                    so.cascadeSplitPositions = cascadeSplits(
                        lambda.toFloat(), so.shadowCascades,
                        so.shadowFar)
                }
            }
            for (field in listOf("shadowFadeRange",
                                 "shadowAmbientStrength",
                                 "shadowCasterFaces",
                                 "cacheStaticShadows")) {
                if (p.tag(field) != null) {
                    warnOnce("w24.directional.$field",
                        "directionalLight '$field' has no Filament " +
                            "equivalent; ignored")
                }
            }
            p.tag("shadowFilter").d3String()?.let { f ->
                if (f != "rotatedPoisson") {
                    warnOnce("w24.shadowFilter.$f",
                        "shadowFilter '$f' is per-view on Filament " +
                            "(the view runs DPCF); ignored")
                }
            }
        }

        /**
         * The practical (log/linear blend) cascade split scheme —
         * `split_i = λ·n·(f/n)^(i/N) + (1−λ)·(n + (f−n)·i/N)` for
         * i = 1..N−1, normalized to (0,1) fractions of the shadow
         * range Filament expects. The split distances are computed in
         * world units over the actual shadow range (`shadowFar`, or a
         * nominal 100 when unset — the camera far isn't known at
         * light decode) and then divided by it; `n` is a nominal
         * 0.1 near (the view camera's near isn't known either).
         */
        internal fun cascadeSplits(
            lambda: Float, cascades: Int, shadowFar: Float,
        ): FloatArray = FsceneRealizer.cascadeSplits(lambda, cascades, shadowFar)

        /**
         * W12 `rectAreaLight` — Filament exposes no area light type in
         * this path, so the approximation is a cluster of four point
         * lights on child entities at the rectangle's corners
         * (±w/2, ±h/2 in the light node's local frame). Upstream's
         * `intensity` is the panel's radiance, so its luminous
         * intensity along the normal is `intensity × width × height`;
         * each point carries a quarter of that. The visible emitter is
         * document-authored (an emissive mesh on the same node) — the
         * approximation covers the lighting contribution only.
         */
        private fun decodeRectAreaLight(key: Long, rec: NodeRec, p: JSONObject) {
            val w = (p.tag("width").d3Double() ?: 1.0).toFloat()
            val h = (p.tag("height").d3Double() ?: 1.0).toFloat()
            val color = p.tag("color").d3Color()
                ?: floatArrayOf(1f, 1f, 1f, 1f)
            val intensity = (p.tag("intensity").d3Double() ?: 1.0).toFloat()
            val owner = LightOwner(rec.lightEntities, false, w, h, true, intensity)
            val range = (p.tag("range").d3Double() ?: 0.0)
                .takeIf { it > 0 }?.toFloat() ?: UNBOUNDED_LIGHT_RANGE
            val identQ = floatArrayOf(0f, 0f, 0f, 1f)
            val unitS = floatArrayOf(1f, 1f, 1f)
            for ((sx, sy) in listOf(-1f to -1f, 1f to -1f,
                                    -1f to 1f, 1f to 1f)) {
                val child = em.create()
                LightManager.Builder(LightManager.Type.POINT)
                    .color(color[0], color[1], color[2])
                    .intensityCandela(owner.convertedIntensity(intensity))
                    .falloff(range)
                    .fenced { build(host.engine, child) }
                tcm.create(
                    child, 0,
                    D3Wire.trs(
                        floatArrayOf(sx * w / 2f, sy * h / 2f, 0f),
                        identQ, unitS))
                tcm.setParent(
                    tcm.getInstance(child), tcm.getInstance(rec.entity))
                host.scene.addEntity(child)
                rec.lightEntities.add(child)
            }
            rec.lightOwner = owner
            logOnce("rectAreaLight:$key",
                "rectAreaLight on node $key: approximated by a 4-point " +
                    "cluster (${w}×${h}); Filament has no area light type")
        }

        // MARK: Material variants (W12)

        /**
         * Decodes a `materialsVariants` component (upstream
         * `KHR_materials_variants`): variant names, the selected name,
         * and bindings — each a node ref + primitive index + declared
         * default + a variant-index → material map. Bindings resolve
         * at apply time so a target that lands later still binds.
         */
        private fun decodeMaterialsVariants(
            key: Long, index: Int, props: JSONObject,
        ) {
            val variants = mutableListOf<String>()
            props.tag("variants").d3List()?.let { list ->
                for (i in 0 until list.length()) {
                    (list.opt(i) as? JSONObject)?.optString("s")
                        ?.takeIf { it.isNotEmpty() }
                        ?.let { variants.add(it) }
                }
            }
            val bindings = mutableListOf<VariantBinding>()
            props.tag("bindings").d3List()?.let { list ->
                for (i in 0 until list.length()) {
                    val m = (list.opt(i) as? JSONObject)?.d3Map()
                        ?: continue
                    val nodeKey = m.tag("node").d3Ref() ?: continue
                    val primitive = m.tag("primitive").d3Int()
                        ?: continue
                    if (primitive < 0) continue
                    val byVariant = HashMap<Int, Long>()
                    m.tag("materials").d3Map()?.let { mats ->
                        for (name in mats.keys()) {
                            val idx = name.toIntOrNull() ?: continue
                            val mk = mats.tag(name).d3Ref() ?: continue
                            byVariant[idx] = mk
                        }
                    }
                    bindings.add(VariantBinding(
                        nodeKey = nodeKey, primitive = primitive,
                        defaultMaterialKey = m.tag("default").d3Ref(),
                        materialsByVariant = byVariant))
                }
            }
            variantComponents[key] = VariantComponent(
                nodeKey = key, compIndex = index, variants = variants,
                selected = props.tag("selected").d3String(),
                bindings = bindings)
            logOnce("variants:$key:$index",
                "materialsVariants on node $key: ${variants.size} " +
                    "variants, ${bindings.size} bindings, " +
                    "selected=${props.tag("selected").d3String() ?: "-"}")
        }

        /**
         * Applies every variant component's selection — after the
         * manifest node pass, after a surgical components decode, and
         * from the `selectVariant` op. Unresolved bindings stay pending
         * and retry on node/geometry landings.
         */
        fun applyVariantComponents() {
            for ((_, vc) in variantComponents.toMap()) {
                val selIdx = vc.selected?.let { vc.variants.indexOf(it) }
                    ?.takeIf { it >= 0 }
                for (b in vc.bindings) {
                    applyVariantBinding(b, selIdx)
                }
            }
        }

        /** One binding → `setMaterialInstanceAt(primitive)` on the
         *  target node's renderable. Upstream's rebase rule: a slot
         *  content that is neither this binding's last write nor a
         *  variant-mapped material wins and becomes the new default. */
        private fun applyVariantBinding(
            b: VariantBinding, variantIndex: Int?,
        ) {
            val rec = nodes[b.nodeKey] ?: run {
                logOnce("variant.unresolved:${b.nodeKey}",
                    "materialsVariants binding: node ${b.nodeKey} not " +
                        "live yet; pending")
                return
            }
            val rm = host.engine.renderableManager
            if (!rm.hasComponent(rec.entity)) {
                logOnce("variant.norenderable:${b.nodeKey}",
                    "materialsVariants binding: node ${b.nodeKey} has " +
                        "no renderable yet; pending")
                return
            }
            val ri = rm.getInstance(rec.entity)
            if (b.primitive >= rm.getPrimitiveCount(ri)) {
                b.resolved = true
                logOnce("variant.binding:${b.nodeKey}:${b.primitive}",
                    "materialsVariants binding: node ${b.nodeKey} has " +
                        "no primitive ${b.primitive}; dropped")
                return
            }
            if (b.defaultMaterial == null) {
                b.defaultMaterial = b.defaultMaterialKey
                    ?.let { materials[it] }
            }
            // getMaterialInstanceAt wraps the native instance fresh per
            // call — compare native pointers, not Kotlin identity. On a
            // d3:instances node with per-chunk material duplicates,
            // consult rec.instanceBaseMaterial so the private duplicate
            // isn't misread as a foreign rebase write.
            val current = if (rec.instancesProps != null && b.primitive == 0 &&
                rec.instanceMaterialInstances.isNotEmpty() &&
                rec.instanceBaseMaterial != null) {
                rec.instanceBaseMaterial
            } else {
                rm.getMaterialInstanceAt(ri, b.primitive)
            }
            val cur = current?.getNativeObject() ?: 0L
            val variantPtrs = b.materialsByVariant.values
                .mapNotNullTo(HashSet()) { materials[it]?.getNativeObject() }
            if (cur != 0L && cur != (b.applied?.getNativeObject() ?: 0L)
                && cur != (b.defaultMaterial?.getNativeObject() ?: 0L)
                && cur !in variantPtrs) {
                b.defaultMaterial = current
            }
            val variantKey = variantIndex?.let { b.materialsByVariant[it] }
            val target = variantKey?.let { materials[it] }
                ?: b.defaultMaterial ?: current ?: return
            Log.i(TAG, "variant apply node=${b.nodeKey} " +
                "prim=${b.primitive} selIdx=$variantIndex " +
                "vkey=$variantKey vmap=${b.materialsByVariant.size} " +
                "target=" + (if (target === b.defaultMaterial) "default"
                    else if (variantKey != null &&
                        target.getNativeObject() ==
                            (materials[variantKey]?.getNativeObject()
                                ?: -1L)) "variant" else "current"))
            applyMaterialToNode(b.nodeKey, rec, b.primitive, target)
            updateMaterialConsumer(rec, b.primitive, target)
            b.applied = target
            b.resolved = true
        }

        private fun updateMaterialConsumer(
            rec: NodeRec, primitive: Int, target: MaterialInstance,
        ) {
            for ((_, list) in materialConsumers) {
                list.removeAll {
                    it.first == rec.entity && it.second == primitive
                }
            }
            val key = materials.entries.firstOrNull {
                it.value.nativeObject == target.nativeObject
            }?.key ?: return
            materialConsumers.getOrPut(key) { ArrayList() }
                .add(Pair(rec.entity, primitive))
        }

        /**
         * W12: tagged joint-component props → the command-joint wire
         * shape [Dart3dView.decodeJoint] consumes (untagged fields —
         * `anchorA`/`axisA`/`basisA` raw arrays, `lower`/`upper` raw
         * doubles — because decodeJoint applies the LH→RH mirror and
         * the per-type limit/motor rules). Upstream component names:
         * `otherNode` (absent → `worldAnchor`), `localAnchorA/B`,
         * `localAxisA/B`, `localBasisA/B`, `collisionsEnabled`,
         * `lowerLimit`/`upperLimit`, `motorTargetVelocity`,
         * `motorMaxForce`, and `axes` (a map keyed `linearX..angularZ`
         * with `lowerLimit`/`upperLimit`/`motor` entries — translated
         * into the 6-element list the command shape expects).
         */
        private fun translateJointComponent(
            key: Long, type: String, props: JSONObject,
        ): JSONObject? {
            val out = JSONObject()
            out.put("type", when (type) {
                "fixedJoint" -> "fixed"
                "sphericalJoint" -> "spherical"
                "revoluteJoint" -> "revolute"
                "prismaticJoint" -> "prismatic"
                "genericJoint" -> "generic"
                else -> return null
            })
            out.put("a", D3Wire.localIdToken(key))
            val other = props.tag("otherNode").d3Ref()
            if (other != null) {
                out.put("b", D3Wire.localIdToken(other))
            } else {
                // Upstream: an absent otherNode anchors to the world.
                out.put("worldAnchor", true)
            }
            out.put("collide",
                props.tag("collisionsEnabled").d3Bool() ?: false)
            fun putVec(name: String, outName: String) {
                props.tag(name).d3Vec3()?.let { v ->
                    if (v.size == 3) out.put(outName, JSONArray(
                        listOf(v[0], v[1], v[2])))
                }
            }
            fun putQuat(name: String, outName: String) {
                props.tag(name).d3Vec4()?.let { v ->
                    if (v.size == 4) out.put(outName, JSONArray(
                        listOf(v[0], v[1], v[2], v[3])))
                }
                // A `{'q':[…]}` tag (QuaternionValue) — same payload.
                (props.tag(name) as? JSONObject)?.optJSONArray("q")
                    ?.let { a ->
                        if (a.length() == 4) out.put(outName, a)
                    }
            }
            fun putDouble(name: String, outName: String) {
                props.tag(name).d3Double()?.let { out.put(outName, it) }
            }
            putVec("localAnchorA", "anchorA")
            putVec("localAnchorB", "anchorB")
            putVec("localAxisA", "axisA")
            putVec("localAxisB", "axisB")
            if (type == "revoluteJoint" || type == "prismaticJoint") {
                // Upstream `_axisField` default — Vector3(1, 0, 0).
                val x = JSONArray(listOf(1.0, 0.0, 0.0))
                if (!out.has("axisA")) out.put("axisA", x)
                if (!out.has("axisB")) out.put("axisB",
                    JSONArray(listOf(1.0, 0.0, 0.0)))
            }
            putQuat("localBasisA", "basisA")
            putQuat("localBasisB", "basisB")
            putDouble("lowerLimit", "lower")
            putDouble("upperLimit", "upper")
            putDouble("motorTargetVelocity", "motorVelocity")
            putDouble("motorMaxForce", "motorMaxForce")
            if (type == "genericJoint") {
                val map = props.tag("axes").d3Map()
                if (map != null) {
                    val order = listOf("linearX", "linearY", "linearZ",
                        "angularX", "angularY", "angularZ")
                    val arr = JSONArray()
                    for (axisName in order) {
                        val a = map.tag(axisName).d3Map()
                        if (a == null) { arr.put(JSONObject.NULL)
                            ; continue }
                        val entry = JSONObject()
                        a.tag("motion").d3String()
                            ?.let { entry.put("motion", it) }
                        a.tag("lowerLimit").d3Double()
                            ?.let { entry.put("lower", it) }
                        a.tag("upperLimit").d3Double()
                            ?.let { entry.put("upper", it) }
                        a.tag("motor").d3Map()?.let { m ->
                            val motor = JSONObject()
                            m.tag("targetPosition").d3Double()
                                ?.let { motor.put("targetPosition", it) }
                            m.tag("targetVelocity").d3Double()
                                ?.let { motor.put("targetVelocity", it) }
                            m.tag("stiffness").d3Double()
                                ?.let { motor.put("stiffness", it) }
                            m.tag("damping").d3Double()
                                ?.let { motor.put("damping", it) }
                            m.tag("maxForce").d3Double()
                                ?.let { motor.put("maxForce", it) }
                            m.tag("model").d3String()
                                ?.let { motor.put("model", it) }
                            entry.put("motor", motor)
                        }
                        arr.put(entry)
                    }
                    out.put("axes", arr)
                }
            }
            return out
        }

        // MARK: Physics (deferred — colliders may read realized meshes)

        /** Per-node collider decode result, consumed by decodeRigidBody. */
        private class ColliderData(
            val shape: ConstShape?,
            val friction: Float,
            val restitution: Float,
            val layer: Int,
            val mask: Int,
            val isTrigger: Boolean,
        )

        fun decodePhysicsDeferred() {
            // Every shape, settings and result wrapper built here holds
            // a reference on native memory. A body takes its own
            // reference on its shape when it is created, so the
            // wrappers all close once the bodies exist.
            nativeScope {
                val colliders = HashMap<Long, ColliderData>()
                for (item in physicsDeferred) {
                    if (item.type == "collider") {
                        colliders[item.key] =
                            decodeCollider(item.rec, item.props)
                    }
                }
                for (item in physicsDeferred) {
                    if (item.type == "rigidBody") {
                        decodeRigidBody(item.key, item.rec, item.props,
                            colliders[item.key])
                    }
                }
                for (item in physicsDeferred) {
                    if (item.type == "characterController") {
                        decodeCharacterController(item.key, item.rec, item.props,
                            colliders[item.key])
                    }
                }
            }
            for (item in physicsDeferred) {
                if (item.type == "physicsWorld") {
                    decodePhysicsWorld(item.props)
                }
            }
            // W12 joint components ride the command-joint registry —
            // the host's registerComponentJoint decodes the translated
            // command-shaped spec and defers until both bodies live.
            for (item in jointComponentsDeferred) {
                translateJointComponent(item.key, item.type, item.props)
                    ?.let {
                        host.registerComponentJoint(item.key, item.index, it)
                    }
            }
            jointComponentsDeferred.clear()
            for ((key, rec) in nodes) {
                val b = rec.body
                val kind = b?.motionType?.toString() ?: "none"
                val p = nodeWorld[key] ?: continue
                Log.i(TAG, "node $key: body=$kind pos=(${p[12]},${p[13]},${p[14]})")
            }
        }

        private fun NativeScope.decodeCollider(
            rec: NodeRec, p: JSONObject,
        ): ColliderData {
            // Surface material: friction/restitution/density plus the
            // combine rules (Jolt applies them per-system — the closest
            // expressible mapping — so they route through JoltWorld).
            val mat = p.tag("material").d3Map()
            val friction = (mat?.tag("friction")?.d3Double() ?: 0.5).toFloat()
            val restitution = (mat?.tag("restitution")?.d3Double() ?: 0.0).toFloat()
            val density = (mat?.tag("density")?.d3Double() ?: 1.0).toFloat()
            applyCombineRule("frictionCombine",
                mat?.tag("frictionCombine")?.d3String() ?: "average") {
                host.world.setFrictionCombine(it)
            }
            applyCombineRule("restitutionCombine",
                mat?.tag("restitutionCombine")?.d3String() ?: "average") {
                host.world.setRestitutionCombine(it)
            }
            var shape = decodeShape(rec, p.tag("shape"), density)
            p.tag("localPose").d3Mat4()?.let { m ->
                val built = shape
                if (m.size == 16 && built != null) {
                    val (pos, rot) = localPoseOf(m)
                    if (pos[0] != 0f || pos[1] != 0f || pos[2] != 0f ||
                        rot[0] != 0f || rot[1] != 0f || rot[2] != 0f || rot[3] != 1f) {
                        shape = shapeOf(RotatedTranslatedShapeSettings(
                            Vec3(pos[0], pos[1], pos[2]),
                            Quat(rot[0], rot[1], rot[2], rot[3]), built,
                        )) { Log.w(TAG, "collider localPose: $it") }
                    }
                }
            }
            return ColliderData(
                shape,
                friction,
                restitution,
                layer = p.tag("collisionLayer").d3Int() ?: -1,
                mask = p.tag("collisionMask").d3Int() ?: -1,
                isTrigger = p.tag("isTrigger").d3Bool() ?: false,
            )
        }

        private inline fun applyCombineRule(
            field: String, rule: String, apply: (String) -> Boolean,
        ) {
            if (!apply(rule)) {
                logOnce("combine:$field:$rule",
                    "collider material $field '$rule' isn't expressible in Jolt; using 'average'")
                apply("average")
            }
        }

        /**
         * Decodes the collider `shape` tagged union (`{'map':{kind,…}}`).
         * [density] comes from collider.material; Jolt multiplies it by
         * the shape's volume for derived body mass — it applies where
         * the shape exposes it (convex shapes; not meshes/compound
         * interiors beyond their children).
         */
        private fun NativeScope.decodeShape(
            rec: NodeRec, shapeVal: Any?, density: Float,
        ): ConstShape? {
            val map = shapeVal.d3Map()
            val kind = map?.tag("kind")?.d3String()
            if (map == null || kind == null) {
                // Upstream falls back to the unit box on a bad union.
                Log.w(TAG, "collider 'shape' is missing or malformed; using unit box")
                return own(BoxShape(Vec3(0.5f, 0.5f, 0.5f)))
            }
            return when (kind) {
                // halfExtents arrive already halved — feed Jolt directly.
                "box" -> {
                    val e = map.tag("halfExtents").d3Vec3()
                        ?: doubleArrayOf(0.5, 0.5, 0.5)
                    own(BoxShape(Vec3(
                        e[0].toFloat(), e[1].toFloat(), e[2].toFloat())))
                        .apply { setDensity(density) }
                }
                "sphere" -> own(SphereShape(
                    (map.tag("radius").d3Double() ?: 0.5).toFloat()))
                        .apply { setDensity(density) }
                "capsule" -> {
                    val r = (map.tag("radius").d3Double() ?: 0.5).toFloat()
                    // Upstream halfHeight IS Jolt's cylindrical
                    // half-height — no h/2-r reduction.
                    val hh = (map.tag("halfHeight").d3Double() ?: 0.5).toFloat()
                    own(CapsuleShape(hh, r)).apply { setDensity(density) }
                }
                "cylinder" -> {
                    val r = (map.tag("radius").d3Double() ?: 0.5).toFloat()
                    val hh = (map.tag("halfHeight").d3Double() ?: 0.5).toFloat()
                    own(CylinderShape(hh, r)).apply { setDensity(density) }
                }
                "convexHull" -> {
                    val token = payloadToken(map.tag("vertices"))
                        ?: payloadToken(map.tag("points"))
                    val payloadPositions = token?.let {
                        decodeColliderPositions("convexHull", it)
                    }
                    val pos = payloadPositions ?: hullPositions(rec)
                    if (pos == null) {
                        Log.w(TAG, "collider 'convexHull': node has no geometry")
                        null
                    } else if (payloadPositions == null) {
                        hullShape(pos, density) {
                            Log.w(TAG, "collider 'convexHull': invalid hull: $it")
                        }
                    } else {
                        hullShape(pos, density) {
                            warnOnce("collider:convexHull:create:$it",
                                "collider 'convexHull': malformed payload ($it); deriving from node geometry")
                        } ?: hullPositions(rec)?.let { fallback ->
                            hullShape(fallback, density) {
                                warnOnce("collider:convexHull:fallback:$it",
                                    "collider 'convexHull': node geometry is not a valid hull: $it")
                            }
                        }
                    }
                }
                "triMesh" -> {
                    val vertexToken = payloadToken(map.tag("vertices"))
                    val indexToken = payloadToken(map.tag("indices"))
                    if (vertexToken != null || indexToken != null) {
                        if (vertexToken == null || indexToken == null) {
                            warnOnce("collider:triMesh:tokens",
                                "collider 'triMesh': payload vertices and indices must both be present; deriving from node geometry")
                            meshShape(rec, kind)
                        } else {
                            val pos = decodeColliderPositions("triMesh", vertexToken)
                            val idx = decodeColliderIndices("triMesh", indexToken)
                            if (pos != null && idx != null) {
                                meshShape(pos, idx, kind) ?: meshShape(rec, kind)
                            } else {
                                meshShape(rec, kind)
                            }
                        }
                    } else {
                        meshShape(rec, kind)
                    }
                }
                "concaveMesh" -> meshShape(rec, kind)
                "compound" -> compoundShape(rec, map, density)
                // Extension kind: a box derived from the node's realized
                // geometry — the historical dart3d default.
                "boundingBox" -> boundingBoxShape(rec, density)
                "heightField" -> {
                    logOnce("heightField",
                        "collider 'heightField' is deferred to W3; skipping")
                    null
                }
                else -> { Log.w(TAG, "unknown collider shape '$kind'"); null }
            }
        }

        private fun payloadToken(value: Any?): String? =
            (value as? String)?.takeIf { it.isNotEmpty() } ?: value.d3String()

        private fun decodeColliderPositions(kind: String, token: String): FloatArray? {
            val key = D3Wire.localIdKey(token)
            if (key == null) {
                warnOnce("collider:$kind:vertexToken:$token",
                    "collider '$kind': invalid vertices payload token '$token'; deriving from node geometry")
                return null
            }
            val meta = payloadSpecs[key]
            if (meta == null) {
                warnOnce("collider:$kind:vertexSpec:$token",
                    "collider '$kind': vertices payload '$token' has no manifest spec; deriving from node geometry")
                return null
            }
            val bytes = host.payloadStore[key] ?: return null
            return try {
                when (meta.encoding) {
                    "floats" -> {
                        if (bytes.isEmpty() || bytes.size % 12 != 0) {
                            throw MeshFactory.PayloadDecodeException(
                                "float vertex payload length ${bytes.size} is not divisible by 12")
                        }
                        val input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        FloatArray(bytes.size / 4) { i ->
                            val value = input.getFloat(i * 4)
                            if (i % 3 == 2) -value else value
                        }
                    }
                    "vertexBuffer" -> MeshFactory.positionsFromPayload(bytes, meta.layout)
                    else -> throw MeshFactory.PayloadDecodeException(
                        "vertices payload encoding '${meta.encoding}' is not floats or vertexBuffer")
                }
            } catch (e: MeshFactory.PayloadDecodeException) {
                warnOnce("collider:$kind:vertices:${e.message}",
                    "collider '$kind': ${e.message}; deriving from node geometry")
                null
            } catch (e: Exception) {
                warnOnce("collider:$kind:vertices:${e.javaClass.name}",
                    "collider '$kind': malformed vertices payload; deriving from node geometry")
                null
            }
        }

        private fun decodeColliderIndices(kind: String, token: String): IntArray? {
            val key = D3Wire.localIdKey(token)
            if (key == null) {
                warnOnce("collider:$kind:indexToken:$token",
                    "collider '$kind': invalid indices payload token '$token'; deriving from node geometry")
                return null
            }
            val meta = payloadSpecs[key]
            if (meta == null) {
                warnOnce("collider:$kind:indexSpec:$token",
                    "collider '$kind': indices payload '$token' has no manifest spec; deriving from node geometry")
                return null
            }
            if (meta.encoding != "indexBuffer") {
                warnOnce("collider:$kind:indexEncoding:${meta.encoding}",
                    "collider '$kind': indices payload encoding '${meta.encoding}' is not indexBuffer; deriving from node geometry")
                return null
            }
            val bytes = host.payloadStore[key] ?: return null
            return try {
                MeshFactory.indicesFromPayload(bytes, meta.format)
            } catch (e: MeshFactory.PayloadDecodeException) {
                warnOnce("collider:$kind:indices:${e.message}",
                    "collider '$kind': ${e.message}; deriving from node geometry")
                null
            }
        }

        /**
         * Builds [settings] into its shape. The settings, the result
         * and both wrappers the result hands back each own native
         * memory, so all four go to the scope. Null, after [onError]
         * with Jolt's reason, when the settings are rejected.
         */
        private inline fun NativeScope.shapeOf(
            settings: ShapeSettings, onError: (String) -> Unit,
        ): ConstShape? {
            own(settings)
            val result = own(settings.create())
            if (result.hasError()) {
                onError(result.error)
                return null
            }
            val ref = own(result.get())
            ownIfCloseable(ref.ptr)
            return ref
        }

        private inline fun NativeScope.hullShape(
            pos: FloatArray, density: Float, onError: (String) -> Unit,
        ): ConstShape? {
            val settings = try {
                ConvexHullShapeSettings(pos.size / 3, floatBufferOf(pos))
            } catch (e: Exception) {
                onError(e.message ?: e.javaClass.simpleName)
                return null
            }
            settings.setDensity(density)
            return shapeOf(settings, onError)
        }

        private fun ensureInstanceColliderGeometry(rec: NodeRec) {
            if (rec.lastGeoPositions != null && rec.lastGeoIndices != null) return
            val basePos = rec.instanceBasePositions ?: return
            val baseIdx = rec.instanceBaseIndices ?: return
            val transforms = rec.instanceTransforms ?: return
            val vertCount = basePos.size / 3
            val triCount = baseIdx.size / 3
            val outPos = FloatArray(transforms.size * basePos.size)
            val outIdx = IntArray(transforms.size * baseIdx.size)
            for ((inst, m) in transforms.withIndex()) {
                val pOff = inst * basePos.size
                for (v in 0 until vertCount) {
                    val px = basePos[v * 3]
                    val py = basePos[v * 3 + 1]
                    val pz = basePos[v * 3 + 2]
                    outPos[pOff + v * 3] = m[0] * px + m[4] * py + m[8] * pz + m[12]
                    outPos[pOff + v * 3 + 1] = m[1] * px + m[5] * py + m[9] * pz + m[13]
                    outPos[pOff + v * 3 + 2] = m[2] * px + m[6] * py + m[10] * pz + m[14]
                }
                val iOff = inst * baseIdx.size
                val vBase = inst * vertCount
                val flip = det3x3(m) < 0f
                for (t in 0 until triCount) {
                    val b = t * 3
                    val i0 = baseIdx[b] + vBase
                    val i1 = baseIdx[b + 1] + vBase
                    val i2 = baseIdx[b + 2] + vBase
                    outIdx[iOff + b] = i0
                    if (flip) {
                        outIdx[iOff + b + 1] = i2
                        outIdx[iOff + b + 2] = i1
                    } else {
                        outIdx[iOff + b + 1] = i1
                        outIdx[iOff + b + 2] = i2
                    }
                }
            }
            rec.lastGeoPositions = outPos
            rec.lastGeoIndices = outIdx
        }

        /** MeshShape from the node's realized geometry (static bodies only). */
        private fun NativeScope.meshShape(rec: NodeRec, kind: String): ConstShape? {
            ensureInstanceColliderGeometry(rec)
            val pos = rec.lastGeoPositions
            val idx = rec.lastGeoIndices
            if (pos == null || idx == null) {
                Log.w(TAG, "collider '$kind': node has no geometry")
                return null
            }
            return meshShape(pos, idx, kind)
        }

        private fun NativeScope.meshShape(
            pos: FloatArray, idx: IntArray, kind: String,
        ): ConstShape? {
            if (pos.isEmpty() || pos.size % 3 != 0 || idx.size < 3 || idx.size % 3 != 0) {
                warnOnce("collider:$kind:meshCounts:${pos.size}:${idx.size}",
                    "collider '$kind': malformed triangle-list payload; deriving from node geometry")
                return null
            }
            val vertexCount = pos.size / 3
            if (idx.any { it < 0 || it >= vertexCount }) {
                warnOnce("collider:$kind:meshIndexRange",
                    "collider '$kind': payload index is outside vertex count $vertexCount; deriving from node geometry")
                return null
            }
            return try {
                val verts = VertexList().apply {
                    resize(vertexCount)
                    for (i in 0 until vertexCount) {
                        set(i, pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2])
                    }
                }
                val tris = own(IndexedTriangleList()).apply {
                    resize(idx.size / 3)
                    for (t in 0 until idx.size / 3) {
                        // set() copies the triangle into the list.
                        IndexedTriangle(
                            idx[t * 3], idx[t * 3 + 1], idx[t * 3 + 2],
                        ).use { set(t, it) }
                    }
                }
                shapeOf(MeshShapeSettings(verts, tris)) {
                    warnOnce("collider:$kind:meshCreate:$it",
                        "collider '$kind': invalid triangle mesh ($it); deriving from node geometry")
                }
            } catch (e: Exception) {
                warnOnce("collider:$kind:meshCreate:${e.message}",
                    "collider '$kind': invalid triangle mesh (${e.message}); deriving from node geometry")
                null
            }
        }

        /** StaticCompoundShape of `{shape, localPose}` children. */
        private fun NativeScope.compoundShape(
            rec: NodeRec, map: JSONObject, density: Float,
        ): ConstShape? {
            val children = map.tag("children").d3List()
            if (children == null || children.length() == 0) {
                Log.w(TAG, "collider 'compound': no children")
                return null
            }
            val settings = own(StaticCompoundShapeSettings())
            var added = 0
            for (i in 0 until children.length()) {
                val entry = children.opt(i).d3Map() ?: continue
                val child = decodeShape(rec, entry.tag("shape"), density)
                    ?: continue
                val (pos, rot) = entry.tag("localPose").d3Mat4()
                    ?.takeIf { it.size == 16 }
                    ?.let { localPoseOf(it) }
                    ?: Pair(floatArrayOf(0f, 0f, 0f), floatArrayOf(0f, 0f, 0f, 1f))
                settings.addShape(
                    Vec3(pos[0], pos[1], pos[2]),
                    Quat(rot[0], rot[1], rot[2], rot[3]), child)
                added++
            }
            if (added == 0) {
                Log.w(TAG, "collider 'compound': no children decoded")
                return null
            }
            return shapeOf(settings) {
                Log.w(TAG, "collider 'compound': $it")
            }
        }

        /**
         * matrix4 `localPose` → RH position + quaternion. The wire's
         * S·M·S handedness flip is the same one node matrices take;
         * scale is dropped (a pose is rigid).
         */
        private fun localPoseOf(m: DoubleArray): Pair<FloatArray, FloatArray> {
            val d = decompose(D3Wire.matrix(m))
            return Pair(d[0], d[1])
        }

        private fun hullPositions(rec: NodeRec): FloatArray? {
            ensureInstanceColliderGeometry(rec)
            return rec.lastGeoPositions
        }

        private fun NativeScope.boundingBoxShape(
            rec: NodeRec, density: Float,
        ): ConstShape? {
            val b = rec.lastGeoBounds ?: return null
            val box = own(BoxShape(Vec3(b[3], b[4], b[5])))
            box.setDensity(density)
            // bounds are (center, halfExtents) — an off-center mesh gets
            // its collider translated to the box center.
            if (b[0] == 0f && b[1] == 0f && b[2] == 0f) return box
            return own(RotatedTranslatedShape(
                Vec3(b[0], b[1], b[2]), Quat.sIdentity(), box))
        }

        private fun NativeScope.decodeRigidBody(
            key: Long, rec: NodeRec, p: JSONObject,
            collider: ColliderData?,
        ) {
            val type = p.tag("type").d3String() ?: "dynamic"
            var motionType = when (type) {
                "fixed" -> EMotionType.Static
                "kinematic" -> EMotionType.Kinematic
                "dynamic" -> EMotionType.Dynamic
                else -> {
                    Log.w(TAG, "rigidBody type '$type' unknown; using dynamic")
                    EMotionType.Dynamic
                }
            }
            // MeshShapes have no mass properties — Jolt only accepts
            // them on static bodies (upstream marks triMesh static-only).
            if (collider?.shape?.mustBeStatic() == true &&
                motionType != EMotionType.Static) {
                Log.w(TAG, "rigidBody on a static-only collider; forcing 'fixed'")
                motionType = EMotionType.Static
            }
            // Jolt requires a shape; SceneKit tolerates a nil one. A
            // collider whose geometry is still deferred (or failed to
            // decode) resolves to no shape here — the body materializes
            // on the payload-arrival re-realize instead of crashing on
            // a shapeless BodyCreationSettings.
            val shape = collider?.shape
            if (shape == null) {
                Log.w(TAG, "node $key: collider has no shape yet; body deferred")
                return
            }
            val bcs = own(BodyCreationSettings())
            bcs.setShape(shape)
            bcs.setMotionType(motionType)
            bcs.setObjectLayer(
                if (motionType == EMotionType.Static) JoltWorld.OBJ_NON_MOVING
                else JoltWorld.OBJ_MOVING)
            if (collider?.isTrigger == true) bcs.setIsSensor(true)
            val wm = nodeWorld[key] ?: FloatArray(16).also {
                Matrix.setIdentityM(it, 0)
            }
            val (wp, wq) = worldPoseOf(wm)
            bcs.setPosition(RVec3(wp[0].toDouble(), wp[1].toDouble(), wp[2].toDouble()))
            bcs.setRotation(Quat(wq[0], wq[1], wq[2], wq[3]))
            p.tag("mass").d3Double()?.let {
                bcs.massPropertiesOverride.setMass(it.toFloat())
                bcs.setOverrideMassProperties(
                    EOverrideMassProperties.CalculateInertia)
            }
            collider?.let {
                bcs.setFriction(it.friction)
                bcs.setRestitution(it.restitution)
            }
            p.tag("linearDamping").d3Double()?.let {
                bcs.setLinearDamping(it.toFloat())
            }
            p.tag("angularDamping").d3Double()?.let {
                bcs.setAngularDamping(it.toFloat())
            }
            p.tag("useGravity").d3Bool()?.let {
                if (!it) bcs.setGravityFactor(0f)
            }
            p.tag("ccdEnabled").d3Bool()?.let {
                if (it) bcs.setMotionQuality(EMotionQuality.LinearCast)
            }
            // allowsResting=false (SCNPhysicsBody) → Jolt never puts
            // the body to sleep. Absent/true keeps Jolt's default.
            if (p.tag("allowsResting").d3Bool() == false) {
                bcs.setAllowSleeping(false)
                Log.i(TAG, "node $key: allowsResting=false → allowSleeping=false")
            }
            // Axis locks (1 = free, 0 = locked) map onto Jolt's
            // allowedDOFs bitmask on BodyCreationSettings.
            val lin = p.tag("linearAxisLocks").d3Vec3()
            val ang = p.tag("angularAxisLocks").d3Vec3()
            if (lin != null || ang != null) {
                var dofs = EAllowedDofs.All
                if (lin != null && lin.size >= 3) {
                    if (lin[0] == 0.0) dofs = dofs and EAllowedDofs.TranslationX.inv()
                    if (lin[1] == 0.0) dofs = dofs and EAllowedDofs.TranslationY.inv()
                    if (lin[2] == 0.0) dofs = dofs and EAllowedDofs.TranslationZ.inv()
                }
                if (ang != null && ang.size >= 3) {
                    if (ang[0] == 0.0) dofs = dofs and EAllowedDofs.RotationX.inv()
                    if (ang[1] == 0.0) dofs = dofs and EAllowedDofs.RotationY.inv()
                    if (ang[2] == 0.0) dofs = dofs and EAllowedDofs.RotationZ.inv()
                }
                if (dofs != EAllowedDofs.All) bcs.setAllowedDofs(dofs)
            }
            // dart3d extensions: initial velocities, which upstream
            // deliberately does not persist. Linear velocity converts
            // through the z-mirror; angular axis+rate mirrors the axis
            // like a quaternion axis.
            p.tag("velocity").d3Vec3()?.let { v ->
                val c = D3Wire.position(v)
                bcs.setLinearVelocity(Vec3(c[0], c[1], c[2]))
            }
            p.tag("angularVelocity").d3Vec4()?.let { a ->
                bcs.setAngularVelocity(Vec3(
                    (-a[0] * a[3]).toFloat(),
                    (-a[1] * a[3]).toFloat(),
                    (a[2] * a[3]).toFloat()))
            }
            val body = host.world.addBody(
                bcs, activate = motionType == EMotionType.Dynamic,
                nodeKey = key,
                layer = collider?.layer ?: -1, mask = collider?.mask ?: -1)
            rec.body = body
            bodies[key] = body
            if (motionType == EMotionType.Dynamic) dynamicBodyKeys.add(key)
        }

        private fun decodeCharacterController(
            key: Long,
            rec: NodeRec,
            p: JSONObject,
            collider: ColliderData?,
        ) {
            val shape = collider?.shape
            if (shape == null) {
                logOnce("character:$key:noshape",
                    "node $key: characterController has no sibling collider shape yet; deferred")
                return
            }
            val w = nodeWorld[key] ?: identity16()
            val (pos, rot) = worldPoseOf(w)
            val rawUp = p.tag("up").d3Vec3() ?: doubleArrayOf(0.0, 1.0, 0.0)
            val rhUp = D3Wire.position(rawUp)
            val upLen = kotlin.math.sqrt(
                (rhUp[0] * rhUp[0] + rhUp[1] * rhUp[1] + rhUp[2] * rhUp[2]).toDouble()
            ).toFloat()
            val normUp = if (upLen > 1e-6f) {
                floatArrayOf(rhUp[0] / upLen, rhUp[1] / upLen, rhUp[2] / upLen)
            } else {
                floatArrayOf(0f, 1f, 0f)
            }
            val halfPi = (Math.PI / 2.0).toFloat()
            val quarterPi = (Math.PI / 4.0).toFloat()
            val spec = CharacterSpec(
                up = normUp,
                offset = (p.tag("offset").d3Double() ?: 0.01)
                    .toFloat().coerceAtLeast(0f),
                slide = p.tag("slide").d3Bool() ?: true,
                maxSlopeClimbAngle = (p.tag("maxSlopeClimbAngle").d3Double()?.toFloat()
                    ?: quarterPi).coerceIn(0f, halfPi),
                minSlopeSlideAngle = (p.tag("minSlopeSlideAngle").d3Double()?.toFloat()
                    ?: quarterPi).coerceIn(0f, halfPi),
                snapToGround = p.tag("snapToGround").d3Double()?.toFloat()
                    ?.takeIf { it >= 0f },
                autostep = p.tag("autostep").d3Bool() ?: false,
                autostepMaxHeight = (p.tag("autostepMaxHeight").d3Double() ?: 0.3)
                    .toFloat().coerceAtLeast(0f),
                autostepMinWidth = (p.tag("autostepMinWidth").d3Double() ?: 0.1)
                    .toFloat().coerceAtLeast(0f),
                autostepIncludeDynamicBodies =
                    p.tag("autostepIncludeDynamicBodies").d3Bool() ?: true,
                mass = (p.tag("mass").d3Double() ?: 0.0)
                    .toFloat().coerceAtLeast(0f),
                layer = collider.layer,
                mask = collider.mask,
            )
            host.world.addCharacter(key, shape, pos, rot, spec)
        }

        private fun decodePhysicsWorld(p: JSONObject) {
            p.tag("backend").d3String()?.let {
                logOnce("backend:$it",
                    "physicsWorld backend '$it' requested; Android always uses Jolt")
            }
            p.tag("gravity").d3Vec3()?.let { g ->
                val v = D3Wire.position(g)
                host.world.setGravity(v[0], v[1], v[2])
            }
            p.tag("fixedTimestep").d3Double()?.let {
                if (it > 0.0) host.world.fixedTimestep = it.toFloat()
            }
            p.tag("maxSubsteps").d3Int()?.let {
                if (it >= 1) host.world.maxSubsteps = it
            }
        }

        // MARK: W5 surgical node ops (shared-maps Context)

        /**
         * `addNode` — decodes one manifest-shape node spec into the
         * live registries, attaches it under [parentKey] (null → scene
         * root), and runs its deferred physics. `spec.children` is NOT
         * wired — each child self-attaches via its own addNode's
         * parent field, so ops are order-independent within a batch.
         */
        fun addNode(key: Long, spec: JSONObject, parentKey: Long?) {
            val rec = decodeNode(key, spec)
            attachNode(key, rec, parentKey)
            resolveParentClaims(key, rec)
            decodeNodePhysics(key)
            applyVariantComponents()
            applyVisibility(key)
        }

        /**
         * `updateNode` — applies only the flagged spec fields (`flags`
         * are upstream NodeChange field names). `reparented` reads
         * [parentKey] (null → root); `components` tears down the
         * realized component state — renderable, light, consumer
         * entries, camera claim, physics body — then re-decodes the
         * components array, so a rebuilt rigid body is a replace
         * matching upstream's component re-realize.
         */
        fun updateNode(
            key: Long, flags: Set<String>,
            spec: JSONObject, parentKey: Long?,
        ) {
            val rec = nodes[key] ?: return
            if ("name" in flags) {
                rec.name = spec.optString("name").takeIf { it.isNotEmpty() }
            }
            if ("reparented" in flags) {
                attachNode(key, rec, parentKey)
                // The body tracks the node's world pose — re-teleport
                // through the new parent chain.
                rec.body?.let { body ->
                    val (wp, wq) = worldPoseOf(worldMatOf(key))
                    host.world.teleport(body, wp, wq)
                }
            }
            if ("transform" in flags) {
                val trs = decodeTrs(spec.optJSONObject("transform"))
                rec.localPos = trs[0]
                rec.localQuat = trs[1]
                rec.localScale = trs[2]
                host.applyLocalTransform(rec)
            }
            if ("layers" in flags) {
                rec.layers = spec.optInt("layers", 1)
                val rm = host.engine.renderableManager
                if (rm.hasComponent(rec.entity)) {
                    rm.setLayerMask(rm.getInstance(rec.entity),
                        0xFF, rec.layers and 0xFF)
                }
                for (ie in rec.instanceEntities) {
                    if (rm.hasComponent(ie)) {
                        rm.setLayerMask(rm.getInstance(ie),
                            0xFF, rec.layers and 0xFF)
                    }
                }
                // W18: runtime-owned entities track the node's layers.
                for (rt in rec.particleRuntimes) rt.applyLayers(rec.layers)
            }
            // `skin` is a node member, not a component — update the
            // binding BEFORE a components re-decode so decodeMesh's
            // attach sees the new value (iOS applyNodeUpdate order).
            // Absent `skin` in the spec means the member cleared.
            if ("skin" in flags) {
                val sk = spec.optString("skin").takeIf { it.isNotEmpty() }
                    ?.let { D3Wire.localIdKey(it) }
                if (sk != null) nodeSkinKeys[key] = sk
                else nodeSkinKeys.remove(key)
                if ("components" !in flags) rebuildRenderable(key)
            }
            if ("components" in flags) {
                teardownComponents(key, rec)
                // The re-encoded spec carries the current `skin`
                // member — refresh the binding so the rebuilt mesh's
                // attach reads it even when the diff didn't flag
                // `skin`.
                val sk = spec.optString("skin").takeIf { it.isNotEmpty() }
                    ?.let { D3Wire.localIdKey(it) }
                if (sk != null) nodeSkinKeys[key] = sk
                else nodeSkinKeys.remove(key)
                spec.optJSONArray("components")?.let { comps ->
                    for (i in 0 until comps.length()) {
                        decodeComponent(key, rec, i, comps.opt(i))
                    }
                }
                decodeNodePhysics(key)
                applyVariantComponents()
            }
            if ("visible" in flags) {
                rec.hidden = spec.has("visible") && !spec.getBoolean("visible")
            }
            for (f in flags) {
                if (f !in NODE_UPDATE_FLAGS) {
                    logOnce("updateNode:flag:$f",
                        "updateNode flag '$f' not implemented")
                }
            }
            // W15: `instance` in the spec is the placeholder tag's
            // post-update state — a dict sets it (an unload's
            // restore), explicit null clears it (the load's instance
            // update), and an absent key preserves it: a reparent-only
            // update carries no spec fields and must not strip the
            // tag.
            if (spec.has("instance")) {
                rec.instanceSpec = spec.optJSONObject("instance")
            }
            applyVisibility(key)
        }

        /**
         * Geometry rebind — re-decodes the resource, rebuilds its
         * GpuMesh, and swaps the buffers onto every consuming
         * renderable (`upsertResource`/`upsertPayload` share this).
         * A consumer without a renderable — its mesh decode hit a
         * pending geometry — first-builds from its retained props.
         */
        fun redecodeGeometry(key: Long, r: JSONObject) {
            val before = geometries[key]
            decodeGeometry(key, r)
            val md = geometries[key]
            // A pending or failed decode leaves the map untouched —
            // consumers keep their old buffers until new data lands.
            if (md == null || md === before) return
            if (md.vertexCount == 0) {
                warnOnce("redecode.$key.empty",
                    "geometry $key: re-decode produced an empty mesh" +
                        " — keeping the previous buffers")
                return
            }
            pendingPayloadRefs.remove(key)
            val old = gpuMeshes[key]
            val gm = buildGpuMesh(md)
            gpuMeshes[key] = gm
            // A morph/skin capability change needs a full renderable
            // rebuild — the MorphTargetBuffer binds at Builder.build
            // and a stale skinned buffer can't take new bone streams.
            val rebuild = old != null &&
                (old.hasSkinning || gm.hasSkinning ||
                    old.morphTargetBuffer != null || gm.morphTargetBuffer != null)
            val rm = host.engine.renderableManager
            var rebound = 0
            for (nodeKey in geometryConsumers[key]?.toList().orEmpty()) {
                val rec = nodes[nodeKey] ?: continue
                val instProps = rec.instancesProps
                if (instProps != null) {
                    // W26: an instances consumer re-bakes — a
                    // setGeometryAt swap can't reproduce transformed
                    // copies.
                    decodeInstances(nodeKey, rec, instProps)
                    applyVisibility(nodeKey)
                } else if (rebuild) {
                    rebuildRenderable(nodeKey)
                } else if (rm.hasComponent(rec.entity)) {
                    // Instance handles aren't entities — resolve per
                    // use, like TransformManager's. A multi-primitive
                    // mesh binds the upserted geometry at its own slot;
                    // the collider state re-unions across primitives.
                    val keys = rec.meshPrimGeoKeys
                    val slot = keys?.indexOf(key) ?: 0
                    val ri = rm.getInstance(rec.entity)
                    rm.setGeometryAt(ri, if (slot >= 0) slot else 0,
                        gm.primitiveType, gm.vertexBuffer, gm.indexBuffer)
                    if (keys != null && keys.size > 1 &&
                        aggregateGeoState(rec)) {
                        rm.setAxisAlignedBoundingBox(ri, Box(
                            rec.lastGeoBounds!![0], rec.lastGeoBounds!![1],
                            rec.lastGeoBounds!![2], rec.lastGeoBounds!![3],
                            rec.lastGeoBounds!![4], rec.lastGeoBounds!![5]))
                    } else {
                        val b = gm.bounds
                        rm.setAxisAlignedBoundingBox(ri,
                            Box(b[0], b[1], b[2], b[3], b[4], b[5]))
                        rec.lastGeoPositions = gm.positions
                        rec.lastGeoIndices = gm.indices
                        rec.lastGeoBounds = gm.bounds
                    }
                } else {
                    val props = rec.meshProps ?: continue
                    decodeMesh(nodeKey, rec, props)
                    applyVisibility(nodeKey)
                }
                rebound++
            }
            // W16: lod levels consuming this geometry rebind BEFORE
            // the old buffers die — the bound renderable's
            // VertexBuffer is the one being swapped out.
            refreshLodConsumers(key)
            // W18: mesh-particle buckets aren't renderable consumers —
            // the runtime holds geoKey → bucket and re-points its pool
            // slots at the fresh buffers (also the late-arrival path
            // for a geometry that decoded pending at component decode).
            for ((_, list) in particleRuntimes) {
                for (rt in list) {
                    (rt as? MeshParticleRuntime)
                        ?.onGeometryRebound(key, gm)
                }
            }
            // Safe only after every consumer swapped — the old buffers
            // were still bound until now.
            old?.destroy(host.engine)
            Log.i(TAG, "geometry $key: rebuilt, rebound $rebound consumer(s)")
        }

        /**
         * Wires the node's transform parent (null → scene root). A
         * parent that isn't live yet leaves a claim in
         * [pendingParents] resolved when its addNode lands. Instance
         * handles go stale across component destruction — resolved per
         * use, never cached; instance 0 is no parent.
         */
        private fun attachNode(key: Long, rec: NodeRec, parentKey: Long?) {
            val parent = parentKey?.let { nodes[it] }
            rec.parentKey = if (parent != null) parentKey else null
            tcm.setParent(
                tcm.getInstance(rec.entity),
                if (parent != null) tcm.getInstance(parent.entity) else 0)
            when {
                parent != null -> pendingParents.remove(key)
                parentKey != null -> {
                    pendingParents[key] = parentKey
                    Log.i(TAG, "node $key: parent $parentKey not live yet; claim parked")
                }
                else -> pendingParents.remove(key)
            }
        }

        /** Children that declared [key] as parent before it existed get
         * wired now — parked claims from [attachNode]. */
        private fun resolveParentClaims(key: Long, rec: NodeRec) {
            val it = pendingParents.entries.iterator()
            while (it.hasNext()) {
                val (childKey, claimed) = it.next()
                if (claimed != key) continue
                it.remove()
                val child = nodes[childKey] ?: continue
                child.parentKey = key
                tcm.setParent(
                    tcm.getInstance(child.entity),
                    tcm.getInstance(rec.entity))
                applyVisibility(childKey)
            }
        }

        /**
         * Re-evaluates scene membership for the node and its
         * descendants — the live-scene slice of [attachToScene]'s
         * [isHidden] walk. Membership follows `visible:false` on the
         * node or any ancestor.
         */
        private fun applyVisibility(key: Long) {
            for ((k, rec) in nodes) {
                if (k != key && !isDescendantOf(k, key)) continue
                if (isHidden(k)) {
                    host.scene.remove(rec.entity)
                    for (ie in rec.instanceEntities) {
                        host.scene.remove(ie)
                    }
                    for (rt in rec.particleRuntimes) {
                        rt.setSceneVisible(false)
                    }
                } else {
                    attachIfRenderable(rec)
                }
            }
        }

        private fun isDescendantOf(key: Long, ancestor: Long): Boolean {
            var p = nodes[key]?.parentKey
            while (p != null) {
                if (p == ancestor) return true
                p = nodes[p]?.parentKey
            }
            return false
        }

        /**
         * Clears the node's realized component state for a
         * `components` re-decode: renderable/light components, scene
         * membership, consumer-map entries, camera claim, and the
         * physics body.
         */
        private fun teardownComponents(key: Long, rec: NodeRec) {
            val entity = rec.entity
            val rm = host.engine.renderableManager
            val lm = host.engine.lightManager
            if (rm.hasComponent(entity)) rm.destroy(entity)
            if (lm.hasComponent(entity)) lm.destroy(entity)
            host.scene.remove(entity)
            for ((_, list) in materialConsumers) {
                list.removeAll { it.first == entity }
            }
            for ((_, set) in geometryConsumers) set.remove(key)
            // W11: the skinning buffer and morph state ride on the
            // renderable — both die with it. The `skin` MEMBER binding
            // (nodeSkinKeys) survives — a rebuilt mesh re-attaches.
            nodeSkinning.remove(key)?.let {
                host.engine.destroySkinningBuffer(it.buffer)
            }
            rec.morphWeights = null
            rec.lastGeoPositions = null
            rec.lastGeoIndices = null
            rec.lastGeoBounds = null
            rec.meshProps = null
            rec.meshPrimGeoKeys = null
            // W26/E1: camera-facing registration, private mesh/index
            // buffers, GPU InstanceBuffers, extra chunk entities, and
            // per-chunk MaterialInstance duplicates die with the
            // component list.
            destroyProcRenderable(key, rec)
            rec.instancesProps = null
            rec.lightOwner = null
            rec.lightDeclarations = 0
            rec.cameraDeclarations = 0
            if (rec.isCamera) {
                rec.isCamera = false
                nodeCameraProps.remove(key)
                if (host.cameraNodeKey == key) host.cameraNodeKey = null
            }
            rec.body?.let { host.world.removeBody(it) }
            rec.body = null
            bodies.remove(key)
            dynamicBodyKeys.remove(key)
            // W12: the node's component-joint registrations, variant
            // component, disabled marks, and rect-cluster light
            // entities die with the component list — a re-decode
            // replaces them wholesale.
            host.dropComponentJointsForNode(key)
            variantComponents.remove(key)
            disabledComponents.remove(key)
            // W18: particle runtimes own entities + GPU buffers the
            // entity teardown doesn't cover — destroy them and prune
            // the registry (the re-decode rebuilds fresh).
            particleRuntimes.remove(key)?.forEach { it.destroy() }
            rec.particleRuntimes.clear()
            for (child in rec.lightEntities) {
                host.scene.remove(child)
                host.engine.destroyEntity(child)
                em.destroy(child)
            }
            rec.lightEntities.clear()
            // W16: trail/lod runtime state dies with the component
            // list — the re-decode rebuilds both (the trail's path
            // is runtime state that never persists, upstream's rule).
            destroyTrailLod(rec)
            host.world.removeCharacter(key)
        }

        /**
         * Runs the deferred-physics pass over this Context's queued
         * items — for a surgical Context that's exactly one node's
         * colliders, rigid bodies and world props, in the manifest
         * pass's colliders → bodies → world order.
         */
        private fun decodeNodePhysics(key: Long) {
            nodeWorld[key] = worldMatOf(key)
            decodePhysicsDeferred()
        }

        // MARK: Stage + install

        /**
         * W14: decodes the top-level `views` list — each entry binds a
         * camera node to a target ('rt:<tok>', or absent for the
         * screen). Called from `realize` after decodeStage and from the
         * host's `updateViews` op; fills [views] wholesale for the
         * install/apply path.
         */
        fun decodeViews(arr: JSONArray?) {
            views.clear()
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                RenderTargets.decodeViewEntry(
                    i, e, nodes::containsKey, renderTargets::containsKey)
                    ?.let(views::add)
            }
        }

        /**
         * Applies the manifest `stage` block: the `environmentRef` →
         * `kind:"environment"` resource drives the lighting env
         * (`scene.indirectLight` = SH irradiance + prefiltered
         * reflections), the skybox background, and the camera
         * exposure/tone mapping. An absent or unresolvable ref defaults
         * to the built-in **studio** env — upstream behavior. Every
         * env-owned object is swapped and destroyed each run so a
         * re-decode — `updateStage`, env `upsertResource`, payload
         * arrival — replaces the previous look without accumulation
         * (mirrors iOS `decodeStage`).
         */
        fun decodeStage(stage: JSONObject?) {
            // A ref swap retires the previous env's deferral/claim —
            // otherwise the old key sits in pendingPayloadRefs and
            // every later payload chunk triggers a full re-realize.
            val oldToken = host.lastStage?.optString("environmentRef")
                ?.takeIf { it.isNotEmpty() }
            if (oldToken != null &&
                stage?.optString("environmentRef") != oldToken) {
                D3Wire.localIdKey(oldToken)?.let {
                    pendingPayloadRefs.remove(it)
                    environmentPayloadIds.remove(it)
                    lutPayloadIds.remove(it)
                }
            }
            host.lastStage = stage
            stageEnvDeferred = false

            // W14: the stage's view-quality defaults — views entries
            // that leave antiAliasing/renderScale/filterQuality absent
            // inherit these. Always applied (updateStage re-runs this
            // and the live views re-resolve).
            host.applyStageQuality(
                stage?.optString("antiAliasing")
                    ?.takeIf { it.isNotEmpty() },
                stage?.takeIf { it.has("renderScale") }
                    ?.optDouble("renderScale", 1.0),
                stage?.optString("filterQuality")
                    ?.takeIf { it.isNotEmpty() } ?: "medium")

            var envKey: Long? = null
            var env: JSONObject? = null
            val token = stage?.optString("environmentRef")
                ?.takeIf { it.isNotEmpty() }
            if (token != null) {
                val ref = D3Wire.localIdKey(token)
                if (ref != null) {
                    envKey = ref
                    env = environments[ref]
                    if (env == null) {
                        logOnce("stage.envRef.$ref",
                            "stage environmentRef '$token' unresolved;" +
                                " using the studio default")
                    }
                } else {
                    logOnce("stage.envRef.token",
                        "stage environmentRef '$token' is malformed;" +
                            " using the studio default")
                }
            }
            // Upstream's zero-config default: a document with no
            // environment still gets the procedural studio IBL.
            val envRes = env ?: JSONObject(
                mapOf("environment" to mapOf("type" to "studio")))

            // Skip the env build when every input is unchanged — a
            // payload arrival for an unrelated resource re-runs the
            // stage, and each run costs ~10ms of equirect→cube→SH GPU
            // work. The payload bytes' hash rides along so an
            // `upsertPayload` replacing the env image under the same
            // token still rebuilds. A skip while the env is deferred
            // keeps its payload claims live (the sets persist).
            val envPayloadKey = envRes.optJSONObject("environment")
                ?.optString("payload")?.takeIf { it.isNotEmpty() }
                ?.let { D3Wire.localIdKey(it) }
            // The claim must be re-registered before the skip below:
            // each re-realize installs this Context's registries
            // wholesale, so an early return would drop the deferred
            // env's claim from `environmentPayloadIds` and its marker
            // from `pendingPayloadRefs` — an env chunk landing after
            // every other payload would then trigger no re-decode and
            // the env would stay unapplied forever.
            if (envPayloadKey != null) {
                envKey?.let { environmentPayloadIds[it] = envPayloadKey }
                if (host.payloadStore[envPayloadKey] == null) {
                    envKey?.let { pendingPayloadRefs.add(it) }
                }
            }
            // W25: the colorGrading LUT rides the env's claim path.
            // A `chunk:`/id-token `lut` ref registers here — before
            // the fingerprint skip, for the same wholesale-reinstall
            // reason as the equirect claim above — and the chunk's
            // arrival re-runs decodeStage through `lutPayloadIds`.
            // An absent `effects` key keeps the prior claim (the
            // decoded stack is retained); a present block without a
            // token-shaped ref clears it (asset-path refs resolve at
            // apply time, never claim). The LUT bytes' hash rides the
            // fingerprint so a chunk rewritten under the same token
            // still rebuilds.
            val lutPayloadKey = envRes.optJSONObject("effects")
                ?.optJSONObject("colorGrading")
                ?.optString("lut")?.takeIf { it.isNotEmpty() }
                ?.let { D3Wire.localIdKey(it) }
            if (lutPayloadKey != null) {
                envKey?.let { lutPayloadIds[it] = lutPayloadKey }
            } else if (envRes.has("effects")) {
                envKey?.let { lutPayloadIds.remove(it) }
            }
            // An env upsert without `effects` retains the prior LUT
            // claim — fingerprint the retained chunk too, or a rewrite
            // of it would hit the early return and keep the old LUT.
            val lutClaimKey = lutPayloadKey
                ?: envKey?.let { lutPayloadIds[it] }
            val envFingerprint = listOf(
                stage?.toString() ?: "∅", envRes.toString(),
                envPayloadKey?.let {
                    host.payloadStore[it]?.contentHashCode() },
                lutClaimKey?.let {
                    host.payloadStore[it]?.contentHashCode() })
                .hashCode()
            if (envFingerprint == host.lastEnvFingerprint) return
            host.lastEnvFingerprint = envFingerprint

            // The "look" fields serialize as plain JSON values (the
            // tagged {'d': …} form is only for node/material
            // properties).
            val exposure = envRes.optDouble("exposure", 1.0)
            val toneMapping = envRes.optString("toneMapping")
                .ifEmpty { "pbrNeutral" }
            val agxWhite = envRes.optDouble("agxWhite", 16.29)
            val agxContrast = envRes.optDouble("agxContrast", 1.25)
            // W13: the env's `effects` post-stack. Absent keeps the
            // prior decoded stack (retain-on-absent); present — even
            // `{}` — wholesale-replaces it.
            StageEffects.decode(envRes.optJSONObject("effects"))?.let {
                host.lastEffects = it
            }

            val intensity = envRes.optDouble("environmentIntensity", 1.0)
            val rotationY = envRes.optDouble("environmentRotationY", 0.0)
            if (envRes.has("radianceCubeSize")) {
                logOnce("stage.radianceCubeSize",
                    "radianceCubeSize isn't settable through the Java" +
                        " IBLPrefilterContext (cube is fixed 256²); ignored")
            }

            val skyEnv = envRes.optJSONObject("skyEnvironment")
            val skyEnvSource = skyEnv?.optJSONObject("source")
            val skyEnvType = skyEnvSource?.optString("type")?.takeIf { it.isNotEmpty() }
            val hasSkyEnv = skyEnv != null &&
                (skyEnvType == "physical" || skyEnvType == "gradient")
            if (skyEnv != null && !hasSkyEnv) {
                when (skyEnvType) {
                    "environment" -> warnOnce("stage.skyEnvironment.environment",
                        "skyEnvironment source 'environment' cannot light itself;" +
                            " falling back to stage environment")
                    "fmat" -> logOnce("stage.skyEnvironment.fmat",
                        "skyEnvironment source 'fmat' is deferred;" +
                            " falling back to stage environment")
                    else -> warnOnce("stage.skyEnvironment.${skyEnvType ?: "?"}",
                        "skyEnvironment source '${skyEnvType ?: "?"}' unknown;" +
                            " falling back to stage environment")
                }
            }

            // W17: stage-owned directional sun light (`skyEnvironment.sunLight`).
            val sunLightSpec = if (hasSkyEnv) skyEnv?.optJSONObject("sunLight") else null
            host.applyStageSunLight(skyEnvSource, sunLightSpec)

            var sh: FloatArray? = null
            var envCube: Texture? = null
            var skyEnvPixels: EnvironmentFactory.EnvPixels? = null
            val iblTextures = ArrayList<Texture>()
            var deferIblToProgressiveSweep = false

            if (hasSkyEnv) {
                val refresh = skyEnv!!.optString("refresh").ifEmpty { "manual" }
                val intervalSeconds =
                    skyEnv.optDouble("intervalSeconds", 1.0).coerceAtLeast(0.0)
                val equirectWidth =
                    skyEnv.optInt("equirectWidth", 512).coerceIn(64, 512)
                val forceStep = skyEnv.optInt("d3ProgressiveStep", 0)
                val sourceSig = listOf(
                    skyEnvSource.toString(), intensity, rotationY,
                    equirectWidth, forceStep,
                ).hashCode()
                val spec = Dart3dView.PendingSkyEnvSpec(
                    source = JSONObject(skyEnvSource.toString()),
                    sourceType = skyEnvType!!,
                    intensity = intensity,
                    rotationY = rotationY,
                    refresh = refresh,
                    intervalSeconds = intervalSeconds,
                    equirectWidth = equirectWidth,
                    sig = sourceSig,
                )
                val needsSyncBake = forceStep in 1..3 ||
                    host.skyEnvBakedSig == null ||
                    (intensity > 0.0 && host.envIndirectLight == null)
                if (needsSyncBake) {
                    // Unbind any old environment-sourced skybox before
                    // buildSkyEnvPrefilterStep replaces envIblTextures.
                    if (host.skyboxUsesEnvCube) {
                        host.scene.skybox = null
                    }
                    if (forceStep == 1) {
                        host.envReflectionCube = null
                    }
                    val targetStep = if (forceStep in 1..3) forceStep else 3
                    host.buildSkyEnvPrefilterStep(
                        spec, targetStep, updateSkyboxIfEnvSourced = false)
                    host.activeSkyEnvSpec = spec
                    host.skyEnvBakedSig = sourceSig
                    val now = System.nanoTime()
                    host.skyEnvLastBakeNs = now
                    host.skyEnvLastStepNs = now
                    host.skyEnvProgressiveStep = targetStep
                    host.pendingSkyEnvSpec = null
                    envCube = host.envReflectionCube
                    skyEnvPixels = host.envShiftedPixels
                    deferIblToProgressiveSweep = true
                } else {
                    // Subsequent skyEnvironment update (e.g. sun sweep):
                    // queue for rate-limited 3-step progressive prefilter in
                    // stepFrame so the current frame updates only the skybox
                    // and directional sunLight (< 1.5 ms total).
                    if (sourceSig == host.skyEnvBakedSig &&
                        host.skyEnvProgressiveStep == 3) {
                        host.pendingSkyEnvSpec = null
                    } else {
                        host.pendingSkyEnvSpec = spec
                    }
                    envCube = host.envReflectionCube
                    skyEnvPixels = host.envShiftedPixels
                    deferIblToProgressiveSweep = true
                }
            } else {
                host.clearSkyEnvState()
                // Lighting env → CPU pixels → SH3 + prefiltered cube. The
                // z-mirror + environmentRotationY bake into the equirect as
                // one column shift (see EnvironmentFactory.filamentShifted)
                // — Filament's Skybox has no rotation knob, so the bake
                // keeps the background and the reflections agreeing where
                // IndirectLight.rotation would rotate lighting alone.
                val pixels = realizeEnvironmentSource(envRes, envKey)
                if (pixels != null) {
                    val start = System.nanoTime()
                    val shifted =
                        EnvironmentFactory.filamentShifted(pixels, rotationY)
                    sh = EnvironmentFactory.projectEquirectSH(shifted)
                    val eq = EnvironmentFactory.normalizeEquirect(shifted)
                    val src =
                        EnvironmentFactory.equirectTexture(host.engine, eq)
                    iblTextures.add(src)
                    // run() can fail (non-2:1, missing mips — both
                    // pre-conditioned above, but the Java return is a
                    // platform type): degrade to SH-only rather than crash.
                    val cube = host.iblEquirect().run(src)
                    if (cube != null) {
                        iblTextures.add(cube)
                        envCube = host.iblSpecular().run(cube)
                        if (envCube != null) iblTextures.add(envCube)
                    } else {
                        warnOnce("env.cube.${envKey ?: 0}",
                            "equirect→cubemap conversion failed;" +
                                " irradiance-only IBL")
                    }
                    skyEnvPixels = shifted
                    val elapsedMs = (System.nanoTime() - start) / 1_000_000
                    Log.i(TAG, "environment ${envKey ?: "default"}:" +
                        " ${eq.width}×${eq.height} equirect →" +
                        " ${envCube?.getWidth(0) ?: 0}² cube + SH3 in" +
                        " ${elapsedMs}ms")
                }
                host.envReflectionCube = envCube
            }

            // --- skybox ------------------------------------------------
            // A separate draw of (usually) the same env —
            // `skybox.intensity` stacks on `environmentIntensity`
            // (upstream's skybox encoder multiplies the two).
            val sky = envRes.optJSONObject("skybox")
            val source = sky?.optJSONObject("source")
            val skyIntensity = sky?.optDouble("intensity", 1.0) ?: 1.0
            // Whether an IndirectLight will be bound (below). A zero
            // intensity binds none: it would light nothing and black
            // out the sky.
            val lightsScene = (hasSkyEnv || sh != null) && intensity > 0
            val skyType = source?.optString("type")
            val skyTextures = ArrayList<Texture>()
            var skybox: Skybox? = null
            host.skyboxUsesEnvCube = false
            host.skyboxSharesSkyEnvCube = false
            val sharesSkyEnv = hasSkyEnv &&
                source != null &&
                skyEnvSource != null &&
                source.toString() == skyEnvSource.toString() &&
                kotlin.math.abs(rotationY) < 1e-6 &&
                kotlin.math.abs(skyIntensity - 1.0) < 1e-6 &&
                kotlin.math.abs(intensity - 1.0) < 1e-6
            // A deferred env leaves the `environment`-sourced
            // background untouched — its cube is still owned by the
            // previous decode. Every other source applies normally.
            var skyboxTouched =
                !stageEnvDeferred || skyType != "environment"
            when (skyType) {
                "environment" -> if (!stageEnvDeferred) {
                    var cube = envCube
                    val blurriness =
                        source?.optDouble("blurriness", 0.0) ?: 0.0
                    host.skyboxEnvIntensity = (intensity * skyIntensity).toFloat()
                    host.skyboxEnvBlurriness = blurriness
                    if (cube != null && blurriness > 0 &&
                        skyEnvPixels != null) {
                        // Filament's Skybox always samples lod 0 (no
                        // mip knob) — approximate blurriness with a CPU
                        // box blur on a dedicated equirect→cube.
                        val blurred = EnvironmentFactory.boxBlurredPixels(
                            skyEnvPixels,
                            maxOf(1, Math.round(blurriness *
                                skyEnvPixels.width / 32).toInt()))
                        val bt = EnvironmentFactory.equirectTexture(
                            host.engine,
                            EnvironmentFactory.normalizeEquirect(blurred))
                        val bc = host.iblEquirect().run(bt)
                        if (bc != null) {
                            cube = bc
                            skyTextures.add(bt)
                            skyTextures.add(bc)
                            logOnce("skybox.blurriness",
                                "skybox blurriness $blurriness:" +
                                    " approximated with a CPU box blur" +
                                    " on the equirect")
                        } else {
                            host.engine.destroyTexture(bt)
                        }
                    }
                    if (envCube != null) {
                        host.skyboxUsesEnvCube = true
                    }
                    if (cube != null) {
                        // Filament draws the skybox at the
                        // IndirectLight's intensity, which is the
                        // environment's; its own applies only without
                        // one.
                        if (skyIntensity != 1.0 && lightsScene) {
                            logOnce("skybox.environment.intensity",
                                "skybox.intensity $skyIntensity on an" +
                                    " environment sky: Filament draws" +
                                    " the sky at the environment's" +
                                    " intensity; ignored")
                        }
                        skybox = Skybox.Builder()
                            .environment(cube)
                            .intensity((intensity * skyIntensity).toFloat())
                            .fenced { build(host.engine) }
                    }
                }
                "gradient" -> {
                    if (sharesSkyEnv && host.envUnfilteredCube != null) {
                        host.skyboxSharesSkyEnvCube = true
                        host.skyboxEnvIntensity = skyIntensity.toFloat()
                        if (host.pendingSkyEnvSpec != null) {
                            skyboxTouched = false
                        } else {
                            skybox = Skybox.Builder()
                                .environment(host.envUnfilteredCube!!)
                                .intensity(skyIntensity.toFloat())
                                .fenced { build(host.engine) }
                        }
                    } else {
                        val gp = EnvironmentFactory.filamentShifted(
                            EnvironmentFactory.gradientEquirectPixels(
                                source,
                                if (lightsScene) skyIntensity / maxOf(intensity, 1e-3)
                                else 1.0),
                            0.0)
                        val gc = EnvironmentFactory.cubemapTextureFromEquirect(
                            host.engine, gp, faceSize = 64, maxMipLevels = 1)
                        skyTextures.add(gc)
                        skybox = Skybox.Builder()
                            .environment(gc)
                            .intensity(skyIntensity.toFloat())
                            .fenced { build(host.engine) }
                    }
                }
                "physical" -> {
                    if (sharesSkyEnv && host.envUnfilteredCube != null) {
                        host.skyboxSharesSkyEnvCube = true
                        host.skyboxEnvIntensity = skyIntensity.toFloat()
                        if (host.pendingSkyEnvSpec != null) {
                            skyboxTouched = false
                        } else {
                            skybox = Skybox.Builder()
                                .environment(host.envUnfilteredCube!!)
                                .intensity(skyIntensity.toFloat())
                                .fenced { build(host.engine) }
                        }
                    } else {
                        val pp = EnvironmentFactory.filamentShifted(
                            EnvironmentFactory.physicalEquirectPixels(
                                source,
                                scale = if (lightsScene)
                                    skyIntensity / maxOf(intensity, 1e-3)
                                else 1.0,
                                width = 256,
                                height = 128,
                                conserveSunEnergy = false),
                            0.0)
                        val pc = EnvironmentFactory.cubemapTextureFromEquirect(
                            host.engine, pp, faceSize = 128, maxMipLevels = 1)
                        skyTextures.add(pc)
                        skybox = Skybox.Builder()
                            .environment(pc)
                            .intensity(skyIntensity.toFloat())
                            .fenced { build(host.engine) }
                    }
                }
                "fmat" -> logOnce("skybox.$skyType",
                    "skybox source '$skyType' is deferred; background cleared")
                else -> if (source != null) {
                    logOnce("skybox.${skyType ?: "?"}",
                        "skybox source '${skyType ?: "?"}' unknown;" +
                            " background cleared")
                }
            }

            // Apply: skybox first (unbinds the old background — which
            // may sample the old env cube — before its textures die),
            // then the indirect light + its texture set. A deferred
            // env leaves both untouched (the old env stays live until
            // the payload lands); non-environment skies still apply.
            if (skyboxTouched) host.applySkybox(skybox, skyTextures)
            if (!stageEnvDeferred && !deferIblToProgressiveSweep) {
                val il = sh?.takeIf { intensity > 0 }?.let {
                    val b = IndirectLight.Builder()
                        .irradiance(3, it)
                        .intensity(intensity.toFloat())
                    if (envCube != null) b.reflections(envCube)
                    b.fenced { build(host.engine) }
                }
                envKey?.let { pendingPayloadRefs.remove(it) }
                host.applyEnvironment(il, iblTextures)
            } else if (!stageEnvDeferred) {
                envKey?.let { pendingPayloadRefs.remove(it) }
            }
            // Look + effects apply even while an env payload is
            // deferred (outside the !stageEnvDeferred guard) — they're
            // JSON-decoded state, not env-owned GPU objects.
            host.applyStageLook(exposure.toFloat(), toneMapping,
                agxWhite, agxContrast, host.lastEffects)
            host.applyStageEffects()
        }

        /**
         * Realizes the env resource's `environment` member into
         * equirect pixels. Returns null for `empty` and for sources
         * that fail to decode; a `payload` whose bytes haven't landed
         * sets [stageEnvDeferred] and records the payload claim so an
         * `upsertPayload` chunk re-runs the stage.
         */
        private fun realizeEnvironmentSource(
            envRes: JSONObject,
            envKey: Long?,
        ): EnvironmentFactory.EnvPixels? {
            val spec = envRes.optJSONObject("environment")
                ?: JSONObject(mapOf("type" to "studio"))
            val type = spec.optString("type").ifEmpty { "studio" }
            val tag = envKey?.let { "environment $it" } ?: "environment"
            return when (type) {
                "studio" -> EnvironmentFactory.EnvPixels(256, 128,
                    isFloat = false,
                    data = EnvironmentFactory.studioEquirectPixels(
                        256, 128))
                "constant" -> {
                    // The wire color is linear radiance; the equirect
                    // stores sRGB like every LDR source here.
                    val c = EnvironmentFactory.rawVec3(
                        spec.optJSONArray("color"))
                        ?: doubleArrayOf(0.0, 0.0, 0.0)
                    EnvironmentFactory.EnvPixels(16, 8, isFloat = false,
                        data = EnvironmentFactory.solidEquirectPixels(
                            c, 16, 8))
                }
                "empty" -> null
                "asset" -> {
                    val ref = spec.optString("ref")
                        .takeIf { it.isNotEmpty() }
                    if (ref == null) {
                        logOnce("env.${envKey ?: 0}.asset",
                            "$tag: asset environment lacks 'ref'")
                        null
                    } else {
                        val bytes =
                            FlutterAssets.readBytes(host.context, ref)
                        if (bytes == null) {
                            logOnce("env.asset.$ref",
                                "$tag: asset '$ref' not found")
                            null
                        } else {
                            EnvironmentFactory.envPixelsFromBytes(
                                bytes, tag)
                        }
                    }
                }
                "payload" -> {
                    val pid = spec.optString("payload")
                        .takeIf { it.isNotEmpty() }
                        ?.let { D3Wire.localIdKey(it) }
                    if (pid == null) {
                        logOnce("env.${envKey ?: 0}.payloadToken",
                            "$tag: invalid payload token")
                        return null
                    }
                    envKey?.let { environmentPayloadIds[it] = pid }
                    val data = host.payloadStore[pid]
                    if (data == null) {
                        stageEnvDeferred = true
                        envKey?.let { pendingPayloadRefs.add(it) }
                        logOnce("env.${envKey ?: 0}.awaiting",
                            "$tag: awaiting payload")
                        null
                    } else {
                        EnvironmentFactory.envPixelsFromBytes(data, tag)
                    }
                }
                else -> {
                    logOnce("env.${envKey ?: 0}.type",
                        "$tag: unknown environment type '$type';" +
                            " using studio")
                    EnvironmentFactory.EnvPixels(256, 128,
                        isFloat = false,
                        data = EnvironmentFactory.studioEquirectPixels(
                            256, 128))
                }
            }
        }

        fun install() {
            host.fsceneVersion = fsceneVersion
            host.install(
                nodes = nodes,
                gpuMeshes = gpuMeshes,
                materials = materials,
                resources = InstalledResources(
                    materialColors = materialColors,
                    textures = textures,
                    textureSamplers = textureSamplers,
                    textureConsumers = textureConsumers,
                    materialConsumers = materialConsumers,
                    textureResources = textureResources,
                    materialResources = materialResources,
                    texturePayloadIds = texturePayloadIds,
                    geometries = geometries,
                    geometryResources = geometryResources,
                    geometryConsumers = geometryConsumers,
                    geometryPayloadIds = geometryPayloadIds,
                    environments = environments,
                    environmentPayloadIds = environmentPayloadIds,
                    lutPayloadIds = lutPayloadIds,
                    payloadSpecs = payloadSpecs,
                    skins = skins,
                    animations = animations,
                    skinPayloadIds = skinPayloadIds,
                    animPayloadIds = animPayloadIds,
                    skinDefs = skinDefs,
                    animDefs = animDefs,
                    nodeSkinKeys = nodeSkinKeys,
                    variantComponents = variantComponents,
                    disabledComponents = disabledComponents,
                ),
                nodeSkins = nodeSkinning,
                cameraFacingSpecs = cameraFacing,
                particles = particleRuntimes,
                pending = pendingPayloadRefs,
                cameraKey = firstCameraKey,
                cameraProps = cameraProps,
                renderTargets = renderTargets,
                views = views,
                nodeCameraProps = nodeCameraProps,
                bodies = bodies,
                dynamicBodies = dynamicBodyKeys,
                bakedCatcherSettings = bakedCatcherSettings,
            )
        }
    }

    /**
     * Builds a `MaterialInstance` for one material resource — shared by
     * the manifest pass and the host's `upsertResource` surgical path.
     * Every texture slot binds a real upload or a neutral 1×1 fallback so
     * the shader always samples (missing texture == factor-only). When
     * [consumers] is non-null each bound slot records
     * texKey → (instance, slotParam) for surgical rebinding.
     */
    fun buildMaterialInstance(
        host: Dart3dView,
        key: Long,
        r: JSONObject,
        textures: Map<Long, Texture>,
        samplers: Map<Long, TextureSampler>,
        consumers: MutableMap<Long, MutableList<Pair<MaterialInstance, String>>>?,
        catcherSettings: ShadowCatcherSettings? = null,
    ): MaterialInstance {
        val type = r.optString("type").ifEmpty { "physicallyBased" }
        val props = r.optJSONObject("properties") ?: JSONObject()
        if (type == "d3:sprite") {
            val mi = host.spriteMaterial.createInstance()
            val tint = props.tag("baseColor").d3Color()
                ?: floatArrayOf(1f, 1f, 1f, 1f)
            mi.setParameter("tint", tint[0], tint[1], tint[2], tint[3])
            val rect = props.tag("baseColorTextureTransform").d3Map()
            val offset = rect?.tag("offset").d3Vec2()
            val scale = rect?.tag("scale").d3Vec2()
            mi.setParameter("spriteRect",
                offset?.get(0)?.toFloat() ?: 0f,
                offset?.get(1)?.toFloat() ?: 0f,
                scale?.get(0)?.toFloat() ?: 1f,
                scale?.get(1)?.toFloat() ?: 1f)
            mi.setParameter("additive",
                if (props.tag("blendMode").d3String() == "additive") 1f else 0f)
            mi.setDepthCulling(true)
            bindTextureSlot(host, mi, props, textures, samplers,
                "baseColorTexture", "spriteMap", host.fallbackWhite, consumers)
            warnUnhandledMaterialProps(key, props)
            return mi
        }
        if (type == "shadowCatcher") {
            val baked = catcherSettings?.mode == ShadowCatcherMode.BAKED
            val base = if (baked) host.bakedCatcherMaterial
                else host.catcherMaterial
            if (base == null) {
                warnOnce("w24.catcher.unavailable",
                    "shadowCatcher material unavailable; " +
                        "surface degrades to transparent")
                val mi = host.unlitBlendMaterial.createInstance()
                mi.setParameter("baseColor", 0f, 0f, 0f, 0f)
                return mi
            }
            val mi = base.createInstance()
            val c = props.tag("shadowColor").d3Color()
                ?: floatArrayOf(0f, 0f, 0f, 1f)
            mi.setParameter("shadowColor", c[0], c[1], c[2], c[3])
            mi.setParameter("shadowIntensity",
                (props.tag("shadowIntensity").d3Double()
                    ?: 0.8).toFloat())
            if (baked) {
                mi.setParameter("bakedShadowTexture",
                    host.bakedCatcherZeroShadowTexture,
                    host.bakedCatcherTextureSampler)
                mi.setParameter("bakedRegion", 0f, 1f, 1f, 1f)
            }
            mi.setDoubleSided(
                props.tag("doubleSided").d3Bool() ?: false)
            val unsupported = listOf("aoStrength", "fadeStart", "fadeEnd") +
                if (baked) emptyList() else listOf("softness")
            for (field in unsupported) {
                if (props.tag(field) != null) {
                    warnOnce("w24.catcher.$field",
                        "shadowCatcher '$field' unsupported; ignored")
                }
            }
            return mi
        }
        val unlit = type == "unlit"
        // W21 alphaMode: Filament bakes the blending mode into the
        // compiled Material, so the wire string picks the host's
        // variant; `mask` adds the per-instance discard threshold.
        // Filament sorts TRANSPARENT renderables back-to-front itself,
        // so `blend` needs no render-order fix-up here.
        val alphaMode = props.tag("alphaMode").d3String() ?: "opaque"
        if (alphaMode.lowercase() !in ALPHA_MODES) {
            warnOnce("alphaMode:$alphaMode",
                "material $key: alphaMode '$alphaMode' unknown;" +
                    " treating as opaque")
        }
        // W22: active KHR_materials_* features select a lazily
        // compiled variant — a base material stays on the prebuilts.
        // W22-r3: the variant declares samplers only for bound slots;
        // the pick reports the flags/slot mask the shader actually
        // carries — a material that can't fit the sampler cap (or
        // fails to compile) degrades to the base prebuilt and both
        // collapse to the base contract, so instance writes never
        // name a parameter the shader lacks.
        val extFlags = if (unlit) 0 else extFlagsFor(key, props)
        val boundMask = if (extFlags == 0) 0
            else boundTextureMask(props, extFlags)
        val pick = host.materialForVariant(
            unlit, alphaMode, extFlags, boundMask, key)
        val mi = pick.material.createInstance()
        val shaderFlags = pick.extFlags
        fun slotBound(i: Int) = pick.boundSlots and (1 shl i) != 0
        fun extBound(i: Int) = pick.boundSlots and extSlotBit(i) != 0
        if (alphaMode.equals("mask", ignoreCase = true)) {
            mi.setMaskThreshold(
                (props.tag("alphaCutoff").d3Double() ?: 0.5).toFloat())
        }

        // Factor × texture always applies — never texture-instead-of —
        // and uniforms zero-init, so every parameter is written with its
        // spec default when the property is absent. Sampler binds are
        // bound-only on ext variants (unbound slots aren't declared);
        // base prebuilts — and degrades reporting the base contract —
        // keep the fallback binding on all five slots.
        val bc = props.tag("baseColor").d3Color()
            ?: floatArrayOf(1f, 1f, 1f, 1f)
        mi.setParameter("baseColor", bc[0], bc[1], bc[2], bc[3])
        setUvTransform(mi, props, "baseColorTextureTransform", "baseColor")
        if (slotBound(0)) {
            bindTextureSlot(host, mi, props, textures, samplers,
                "baseColorTexture", "baseColorMap", host.fallbackWhite,
                consumers)
        }

        val doubleSided = props.tag("doubleSided").d3Bool() ?: false
        mi.setDoubleSided(doubleSided)
        // The packages are compiled doubleSided, which bakes culling to
        // NONE: setDoubleSided(false) alone leaves every single-sided
        // material unculled (a translucent die's far side showed through
        // its top face on the A142). Restore back-face culling explicitly.
        if (!doubleSided) {
            mi.setCullingMode(
                com.google.android.filament.Material.CullingMode.BACK)
        }

        if (!unlit) {
            mi.setParameter("metallic",
                (props.tag("metallic").d3Double() ?: 0.0).toFloat())
            mi.setParameter("roughness",
                (props.tag("roughness").d3Double() ?: 0.5).toFloat())
            mi.setParameter("normalScale",
                (props.tag("normalScale").d3Double() ?: 1.0).toFloat())
            mi.setParameter("occlusionStrength",
                (props.tag("occlusionStrength").d3Double() ?: 1.0).toFloat())
            mi.setParameter("emissiveStrength",
                (props.tag("emissiveStrength").d3Double() ?: 1.0).toFloat())
            val em = props.tag("emissive").d3Color()
                ?: floatArrayOf(0f, 0f, 0f, 1f)
            mi.setParameter("emissiveColor", em[0], em[1], em[2], em[3])

            setUvTransform(mi, props, "normalTextureTransform", "normal")
            setUvTransform(mi, props,
                "metallicRoughnessTextureTransform", "mr")
            setUvTransform(mi, props, "occlusionTextureTransform", "occlusion")
            setUvTransform(mi, props, "emissiveTextureTransform", "emissive")

            if (slotBound(1)) {
                bindTextureSlot(host, mi, props, textures, samplers,
                    "normalTexture", "normalMap", host.fallbackNormal,
                    consumers)
            }
            if (slotBound(2)) {
                bindTextureSlot(host, mi, props, textures, samplers,
                    "metallicRoughnessTexture", "metallicRoughnessMap",
                    host.fallbackWhite, consumers)
            }
            if (slotBound(3)) {
                bindTextureSlot(host, mi, props, textures, samplers,
                    "occlusionTexture", "occlusionMap",
                    host.fallbackWhite, consumers)
            }
            if (slotBound(4)) {
                // Without an emissive texture the factor emits on its
                // own (upstream: factor × texture-or-white). With one
                // that has not arrived yet, nothing emits until it does.
                bindTextureSlot(host, mi, props, textures, samplers,
                    "emissiveTexture", "emissiveMap",
                    if (props.has("emissiveTexture")) host.fallbackEmissive
                    else host.fallbackWhite,
                    consumers)
            }

            // W22: extension writes ride the same registry the
            // variant declares — gated on the pick's *effective* flags
            // so a degraded instance never writes a uniform its
            // (base) shader lacks. Spec defaults fill absent props
            // (uniforms zero-init otherwise).
            for (f in EXT_FACTORS) {
                if (shaderFlags and f.mask == 0) continue
                if (f.isColor) {
                    val c = props.tag(f.prop).d3Color() ?: f.default
                    mi.setParameter(f.uniform, c[0], c[1], c[2], c[3])
                } else {
                    // clearcoatNormalScale travels as a duplicated v2 —
                    // read the scalar from either wire form.
                    val v = props.tag(f.prop).d3Vec2()?.get(0)?.toDouble()
                        ?: props.tag(f.prop).d3Double()
                        ?: f.default[0].toDouble()
                    mi.setParameter(f.uniform, v.toFloat())
                }
            }
            if (shaderFlags and EXT_ANISOTROPY != 0) {
                mi.setParameter("anisotropyUseMap",
                    if (props.tag("anisotropyTexture").d3Ref() != null)
                        1f else 0f)
            }
            if (shaderFlags and EXT_TRANSMISSION != 0) {
                // KHR_materials_volume → Beer–Lambert: transmittance is
                // attenuationColor^(d/attenuationDistance), so the
                // absorption coefficient is -ln(color)/distance.
                val ac = props.tag("attenuationColor").d3Color()
                    ?: floatArrayOf(1f, 1f, 1f, 1f)
                val ad = props.tag("attenuationDistance").d3Double()
                    ?: Double.POSITIVE_INFINITY
                mi.setParameter("absorption",
                    (-ln(ac[0].toDouble().coerceAtLeast(1e-5)) / ad)
                        .toFloat(),
                    (-ln(ac[1].toDouble().coerceAtLeast(1e-5)) / ad)
                        .toFloat(),
                    (-ln(ac[2].toDouble().coerceAtLeast(1e-5)) / ad)
                        .toFloat())
            }
            for ((i, slot) in EXT_TEXTURE_SLOTS.withIndex()) {
                if (shaderFlags and slot.flag == 0) continue
                setUvTransform(mi, props, "${slot.prop}Transform",
                    slot.prefix)
                if (extBound(i)) {
                    bindTextureSlot(host, mi, props, textures, samplers,
                        slot.prop, "${slot.prefix}Map",
                        if (slot.prop == "clearcoatNormalTexture" ||
                            slot.prop == "anisotropyTexture")
                            host.fallbackNormal else host.fallbackWhite,
                        consumers)
                }
            }
        }
        warnUnhandledMaterialProps(key, props)
        return mi
    }

    /**
     * `<slot>TextureTransform` (KHR_texture_transform vocabulary) → the
     * `<prefix>UVTransform`/`UVRotation`/`UVSet` uniforms. The map's
     * tagged values are `offset`/`scale` (`v2`), `rotation` (`d`),
     * `texCoord` (`i`). W21 realizes `texCoord`: 0 → uv0, ≥1 → uv1 —
     * the vertex record always carries both channels (zero-filled when
     * the wire layout lacks TEXCOORD_1); a value above 1 clamps to the
     * highest realized set with a warning.
     */
    private fun setUvTransform(
        mi: MaterialInstance, props: JSONObject,
        propName: String, prefix: String,
    ) {
        var tx = 0f; var ty = 0f
        var sx = 1f; var sy = 1f
        var rot = 0f
        var uvSet = 0f
        val map = props.tag(propName).d3Map()
        if (map != null) {
            map.tag("offset").d3Vec2()?.let {
                tx = it[0].toFloat(); ty = it[1].toFloat()
            }
            map.tag("scale").d3Vec2()?.let {
                sx = it[0].toFloat(); sy = it[1].toFloat()
            }
            rot = (map.tag("rotation").d3Double() ?: 0.0).toFloat()
            val tc = map.tag("texCoord").d3Int() ?: 0
            if (tc > 1) {
                warnOnce("texCoord:$tc",
                    "textureTransform texCoord=$tc: uv1 is the highest" +
                        " realized set; clamped to 1")
            }
            if (tc > 0) uvSet = 1f
        }
        mi.setParameter("${prefix}UVTransform", tx, ty, sx, sy)
        mi.setParameter("${prefix}UVRotation", rot)
        mi.setParameter("${prefix}UVSet", uvSet)
    }

    private fun bindTextureSlot(
        host: Dart3dView,
        mi: MaterialInstance,
        props: JSONObject,
        textures: Map<Long, Texture>,
        samplers: Map<Long, TextureSampler>,
        refProp: String,
        param: String,
        fallback: Texture,
        consumers: MutableMap<Long,
            MutableList<Pair<MaterialInstance, String>>>?,
    ) {
        val texKey = props.tag(refProp).d3Ref()
        val tex = texKey?.let { textures[it] } ?: fallback
        if (texKey != null && tex === fallback) {
            Log.w(TAG, "material slot $refProp: texture $texKey not " +
                "realized — binding fallback")
        }
        // W14: a per-resource sampler (a renderTexture's filter/wrap)
        // wins over the shared host sampler.
        mi.setParameter(param, tex,
            host.materialTextureSampler(param, texKey?.let { samplers[it] }))
        if (texKey != null && consumers != null) {
            consumers.getOrPut(texKey) { ArrayList() }.add(mi to param)
        }
    }

    private fun floatBufferOf(values: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(values.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .also { it.put(values); it.flip() }

    /** Decomposes a column-major mat4 into [pos, quat, scale]. */
    fun decompose(m: FloatArray): Array<FloatArray> {
        val p = floatArrayOf(m[12], m[13], m[14])
        val sx = sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2])
        val sy = sqrt(m[4] * m[4] + m[5] * m[5] + m[6] * m[6])
        val sz = sqrt(m[8] * m[8] + m[9] * m[9] + m[10] * m[10])
        val s = floatArrayOf(sx, sy, sz)
        val r = floatArrayOf(
            m[0] / sx, m[1] / sx, m[2] / sx,
            m[4] / sy, m[5] / sy, m[6] / sy,
            m[8] / sz, m[9] / sz, m[10] / sz,
        )
        val q = quatFromMat3(r)
        return arrayOf(p, q, s)
    }

    fun worldPoseOf(m: FloatArray): Pair<FloatArray, FloatArray> {
        val d = decompose(m)
        return Pair(d[0], d[1])
    }

    private fun quatFromMat3(r: FloatArray): FloatArray {
        // r is column-major rotation [r00,r10,r20, r01,r11,r21, r02,r12,r22]
        val m00 = r[0]; val m10 = r[1]; val m20 = r[2]
        val m01 = r[3]; val m11 = r[4]; val m21 = r[5]
        val m02 = r[6]; val m12 = r[7]; val m22 = r[8]
        val trace = m00 + m11 + m22
        val q = FloatArray(4)
        if (trace > 0) {
            val s = sqrt(trace + 1f) * 2f
            q[3] = 0.25f * s
            q[0] = (m21 - m12) / s
            q[1] = (m02 - m20) / s
            q[2] = (m10 - m01) / s
        } else if (m00 > m11 && m00 > m22) {
            val s = sqrt(1f + m00 - m11 - m22) * 2f
            q[3] = (m21 - m12) / s
            q[0] = 0.25f * s
            q[1] = (m01 + m10) / s
            q[2] = (m02 + m20) / s
        } else if (m11 > m22) {
            val s = sqrt(1f + m11 - m00 - m22) * 2f
            q[3] = (m02 - m20) / s
            q[0] = (m01 + m10) / s
            q[1] = 0.25f * s
            q[2] = (m12 + m21) / s
        } else {
            val s = sqrt(1f + m22 - m00 - m11) * 2f
            q[3] = (m10 - m01) / s
            q[0] = (m02 + m20) / s
            q[1] = (m12 + m21) / s
            q[2] = 0.25f * s
        }
        return q
    }

    private fun sqrt(v: Float) = kotlin.math.sqrt(v)
}
