import CoreImage
import Foundation
import Metal
import MetalKit
import SceneKit
import simd
import UIKit

/// Realizes a `.fscene` manifest (canonical JSON) into a live `SCNScene`.
///
/// The manifest shape mirrors `encodeDocument` in package:scene:
/// `resources`/`nodes`/`skins`/`animations`/`payloads` are id-token-keyed
/// maps, `roots` orders the root node ids, `stage` holds scene-wide
/// settings. Property values are single-key tagged objects
/// (`{'d': …}`, `{'c': [r,g,b,a]}`, `{'rref': token}`, …).
///
/// Component types mirror the upstream flutter_scene vocabulary so
/// documents stay interchangeable: `mesh`, `camera`, `directionalLight`,
/// `pointLight`, `spotLight`, `rectAreaLight`,
/// `rigidBody`, `collider`, `physicsWorld`. Unknown types log and skip —
/// a document never fails to load over an unsupported component.
enum FsceneRealizer {

    // MARK: - Entry

    /// Replaces `host`'s scene with the realized manifest. Payload-backed
    /// resources whose bytes have not arrived stay deferred and are
    /// re-realized when a payload lands (`SceneViewHost.applyPayload`).
    /// - Parameter preserveStage: W25 fix-2 — set only by the
    ///   payload-arrival re-realize. That pass is a deferred-resource
    ///   retry, not a stage re-apply: the live stage (updateStage
    ///   mutations, op-added env resources, LUT/effects state) carries
    ///   forward instead of the manifest's stale stage being
    ///   re-decoded on top of it.
    static func realize(manifest: Data, into host: SceneViewHost,
                        preserveStage: Bool = false,
                        preserveBakedShadowCaches: Bool = false) {
        guard let json = try? JSONSerialization.jsonObject(with: manifest)
                as? [String: Any] else {
            d3Log("loadScene: manifest is not a JSON object"); return
        }

        let version = (json["fscene"] as? NSNumber)?.intValue ?? 5
        // The decode writes into the bound scene itself, cleared back
        // to defaults first. SceneKit forbids mutating one scene
        // inside a rendering callback of another — a fresh SCNScene
        // built on this drain is still 'another scene' to it — while
        // mutating the rendered scene in its own update callback is
        // the sanctioned window.
        host.beginSceneReset()
        let ctx = Context(
            host: host, formatVersion: version,
            scene: host.scene ?? SCNScene(),
            preserveBakedShadowCaches: preserveBakedShadowCaches)
        // W12: the installing document re-declares its component
        // joints — drop the previous document's registrations so a
        // re-install never duplicates them.
        host.beginComponentJointRegistration()
        host.characterControllers.removeAll()
        host.pendingCharacterControllers.removeAll()
        host.colliderLayerMaskByKey.removeAll()
        ctx.decodePayloadSpecs(json["payloads"] as? [String: Any] ?? [:])
        ctx.decodeResources(json["resources"] as? [String: Any] ?? [:])
        if preserveStage {
            // Op-added env resources aren't in the manifest —
            // overlay the live defs so the preserved stage's
            // environmentRef still resolves (and the defs stay
            // installed for later surgical stage decodes).
            for (k, r) in host.resourceDefs
            where (r["kind"] as? String) == "environment" {
                ctx.resourceDefs[k] = r
                ctx.environments[k] = r
            }
        }
        ctx.decodeNodes(json["nodes"] as? [String: Any] ?? [:])
        ctx.decodeSkins(json["skins"] as? [String: Any] ?? [:])
        ctx.decodeAnimations(json["animations"] as? [String: Any] ?? [:])
        ctx.attachRoots(json["roots"] as? [Any] ?? [])
        ctx.resolveSkinAttachments()
        ctx.decodePhysicsDeferred()
        ctx.applyVariantComponents()
        ctx.decodeStage(preserveStage ? host.lastStage
                        : json["stage"] as? [String: Any])
        // W14: view decode runs after stage (it needs nothing from it,
        // but the rt records and node registry must already exist).
        ctx.decodeViews(json["views"])
        ctx.installScene()
    }

    /// A realized texture: the `UIImage` material slots bind plus, for
    /// `rgba8` payloads, the straight-alpha source pixels so factor
    /// bakes and channel splits skip a GPU round-trip. Encoded
    /// containers and `ref` assets leave `rgba` nil — `sourcePixels`
    /// re-decodes the image when a slot needs raw bytes.
    ///
    /// W21: `mtlTexture` carries a Metal-side copy when one was
    /// uploaded — a KTX2 container decode (which may be the ONLY
    /// realized form, e.g. ASTC blocks with no CPU image) or the
    /// renormalized mip chain sRGB sources get. `image` is nil for
    /// GPU-only textures, and `contents` is what a slot binds.
    struct DecodedTexture {
        let key: UInt64
        let image: UIImage?      // nil on GPU-only (compressed) decodes
        let mtlTexture: MTLTexture?
        let rgba: Data?          // straight RGBA8, rgba8 payloads only
        let width: Int
        let height: Int
        let content: String      // 'color' | 'data' | 'normal'

        /// What a material slot binds: the MTLTexture when one exists
        /// (it carries the mip chain), else the UIImage.
        var contents: Any? { mtlTexture ?? image }
    }

    /// One material slot's texture dependency. `upsertResource`
    /// re-applies every recorded binding so a texture swap re-does the
    /// factor bake; `materialKey` reaches back into `resourceDefs` for
    /// the material's raw properties (the factors).
    struct TextureBinding {
        let material: SCNMaterial
        let materialKey: UInt64
        let slot: String         // wire name: 'baseColorTexture', …
    }

    /// An equirect environment image in the upstream (.fscene, LH)
    /// convention: row 0 is the up pole (+y), column u maps longitude
    /// (u−0.5)·2π with dirX=cosLat·cos(λ), dirZ=cosLat·sin(λ). Two
    /// storages: sRGB-encoded RGBA8 bytes (LDR and generated sources)
    /// or linear float32 RGBA (Radiance HDR payloads).
    struct EnvPixels {
        var width: Int
        var height: Int
        var isFloat: Bool       // false → sRGB8 bytes, true → RGBA float32
        var data: Data
    }

    /// W12: one decoded `materialsVariants` binding — upstream's
    /// `MaterialsVariantBinding` shape: the target node + primitive
    /// index, the declared default material ref, and the variant-index
    /// → material-ref map. `resolved` records the applied state (the
    /// geometry/material actually written + the default in force after
    /// the rebase rule), so a select can restore the right material
    /// and a mesh-material rebind can rebase onto it.
    struct VariantBindingSpec {
        let nodeKey: UInt64
        let primitive: Int
        let defaultMaterialKey: UInt64?
        let materialsByVariant: [Int: UInt64]
        /// Last material this binding wrote (nil until first apply).
        var applied: SCNMaterial?
        /// The default currently in force — the declared default, or
        /// a mesh material the rebase rule adopted.
        var defaultMaterial: SCNMaterial?
        var defaultMaterialSource: (key: UInt64, isSnapshotClone: Bool)?
        weak var appliedGeometry: SCNGeometry?
        /// False while the target node/geometry hasn't resolved — the
        /// landing retries re-attempt it.
        var resolved = false
    }

    /// W12: a decoded `materialsVariants` component — the variant name
    /// list, the selected name, and the (possibly still-unresolved)
    /// bindings.
    struct VariantComponentSpec {
        let nodeKey: UInt64
        let compIndex: Int
        var variants: [String]
        var selected: String?
        var bindings: [VariantBindingSpec]
    }

    /// A decoded `skins` entry (W11): joint node keys in authored order,
    /// the per-joint inverse-bind matrices (already z-mirrored, identity
    /// when the `matrices` payload is absent — upstream's null-tolerant
    /// rule), and the optional skeleton root key. A null joint upstream
    /// renders as identity — `attachSkin` substitutes a detached node
    /// for unresolved joints and keeps the consumer pending.
    struct DecodedSkin {
        var jointKeys: [UInt64]
        var ibms: [SCNMatrix4]
        var skeletonKey: UInt64?
        var awaitingIBM: Bool
    }

    /// A decoded `morphTargets` block (W11): absolute target geometries
    /// (`base + delta`, positions always, normals/tangents when the
    /// spec declares those slabs), the mesh `defaultWeights`, and the
    /// target count. Keyed by the geometry id, like `geometries`.
    struct DecodedMorph {
        var targets: [SCNGeometry]
        var defaultWeights: [Float]
        var targetCount: Int
    }

    /// One animation channel's decoded timeline + values, converted to
    /// SceneKit space at decode: translation negates z, rotation takes
    /// the pseudovector map (−x,−y,z,w), scale and weights pass through.
    /// `vec3`/`quat`/`weights` are populated by kind; `times` is f32
    /// seconds widened to Double.
    struct DecodedChannel {
        enum Kind: String {
            case translation, rotation, scale, weights
            case materialBaseColor, lightIntensity, cameraFovRadiansY
        }
        var target: UInt64
        var targetName: String?
        var kind: Kind
        var times: [Double] = []
        var vec3: [simd_float3] = []
        var quat: [simd_quatf] = []
        var weights: [Float] = []
        var targetCount = 0
        var propertyValues: [simd_float4] = []
    }

    struct AnimationChannelDefinition {
        let target: UInt64
        let targetName: String?
        let kind: DecodedChannel.Kind
        let timeline: UInt64
        let keyframes: UInt64
    }

    struct AnimationDefinition {
        let name: String
        let channels: [AnimationChannelDefinition]

        init?(_ json: [String: Any]) {
            var parsed: [AnimationChannelDefinition] = []
            if let ordinary = json["channels"], !(ordinary is [Any]) { return nil }
            if let properties = json["d3:properties"], !(properties is [Any]) { return nil }
            var endpoints = Set<String>()
            for (isProperty, entries) in [
                (false, json["channels"] as? [Any] ?? []),
                (true, json["d3:properties"] as? [Any] ?? [])
            ] {
                for entry in entries {
                    guard let c = entry as? [String: Any],
                          let spelling = c[isProperty ? "kind" : "property"] as? String,
                          let kind = DecodedChannel.Kind(rawValue: spelling)
                    else { return nil }
                    let targetField: String
                    switch kind {
                    case .translation, .rotation, .scale, .weights:
                        guard !isProperty else { return nil }
                        targetField = "target"
                    case .materialBaseColor:
                        guard isProperty else { return nil }
                        targetField = "material"
                    case .lightIntensity, .cameraFovRadiansY:
                        guard isProperty else { return nil }
                        targetField = "node"
                    }
                    guard let token = c[targetField] as? String,
                          let target = D3Wire.localIdKey(token),
                          let timeline = c["timeline"] as? String,
                          let t = D3Wire.localIdKey(timeline),
                          let keyframes = c["keyframes"] as? String,
                          let k = D3Wire.localIdKey(keyframes) else { return nil }
                    if isProperty {
                        guard Set(c.keys) == Set(["kind", targetField, "timeline", "keyframes"]),
                              endpoints.insert("\(spelling).\(target)").inserted
                        else { return nil }
                    }
                    parsed.append(AnimationChannelDefinition(
                        target: target, targetName: c["targetName"] as? String,
                        kind: kind, timeline: t, keyframes: k))
                }
            }
            name = json["name"] as? String ?? ""
            channels = parsed
        }
    }

    final class MaterialColorOwner {
        let material: SCNMaterial
        let rest: simd_float4
        var effective: simd_float4
        var animationBound = false
        let sprite: Bool
        let supportsAnimation: Bool

        init(_ material: SCNMaterial, color: [Double], sprite: Bool,
             supportsAnimation: Bool) {
            self.material = material
            rest = simd_float4(color.map(Float.init))
            effective = rest
            self.sprite = sprite
            self.supportsAnimation = supportsAnimation
            apply(rest)
        }

        func apply(_ value: simd_float4) {
            effective = value
            material.setValue(SCNVector4(value.x, value.y, value.z, value.w),
                forKey: sprite ? "d3SpriteTint" : "d3BaseColorFactor")
        }

        func copyFactor(to copy: SCNMaterial) {
            copy.setValue(SCNVector4(effective.x, effective.y, effective.z, effective.w),
                forKey: sprite ? "d3SpriteTint" : "d3BaseColorFactor")
        }
    }

    final class LightIntensityOwner {
        let light: SCNLight
        let rest: Float
        var effective: Float
        var animationBound = false
        let declarationCount: Int

        init(_ light: SCNLight, intensity: Double, declarationCount: Int) {
            self.light = light
            rest = Float(intensity)
            effective = rest
            self.declarationCount = declarationCount
            apply(rest)
        }

        func apply(_ value: Float) {
            effective = value
            switch light.type {
            case .directional: light.intensity = CGFloat(Double(value) * 1000 / .pi)
            case .area: light.intensity = CGFloat(value) * 1000
            default: light.intensity = CGFloat(value)
            }
        }
    }

    final class CameraFovOwner {
        let camera: SCNCamera
        let rest: Float
        var effective: Float
        var animationBound = false
        let declarationCount: Int

        init(_ camera: SCNCamera, fov: Double, declarationCount: Int) {
            self.camera = camera
            rest = Float(fov)
            effective = rest
            self.declarationCount = declarationCount
            apply(rest)
        }

        func apply(_ value: Float) {
            effective = value
            camera.projectionDirection = .vertical
            camera.fieldOfView = CGFloat(Double(value) * 180 / .pi)
        }
    }

    /// A decoded `animations` entry (W11): the channels plus
    /// `endTime` (max channel last-key — upstream's
    /// `Animation.endTime`). The doc's clips aren't created until an
    /// `anim` op asks (no autoplay).
    struct DecodedAnimation {
        var name: String
        var channels: [DecodedChannel]
        var endTime: Double
    }

    /// W16: one live `trail` component — the decoded spec plus the
    /// recorded world-space path (head-first) and the `d3trail:`
    /// child node whose ribbon geometry the host rebuilds each frame.
    /// The update policy ports upstream `TrailComponent.update`: the
    /// head follows the node continuously, a new anchor drops once the
    /// node travels `minVertexDistance`, and the tail expires by age
    /// (`lifetime`) and capacity (`maxPoints`).
    final class TrailState {
        var width = 0.25
        var lifetime = 0.6
        var minVertexDistance = 0.05
        let maxPoints: Int
        /// While false no new points record; the path ages out.
        var emitting = true
        /// `widthOverTrail` decoded — (t, v) pairs sorted by t;
        /// nil → upstream's `1 − t` taper.
        var widthKeys: [(t: Double, v: Double)]?
        /// `colorOverTrail` decoded — (t, r, g, b, a) sorted by t;
        /// nil → upstream's white fading `1 − t` in alpha.
        var colorStops:
            [(t: Double, r: Double, g: Double, b: Double, a: Double)]?
        /// Head-first world positions — `points[0]` follows the node.
        var points: [simd_float3] = []
        /// Parallel birth clock of `points` (accumulated seconds).
        var born: [Double] = []
        var time = 0.0
        /// The `d3trail:` child — its geometry renders under the
        /// node's transform while the verts rebase to node-local
        /// each frame (upstream's world-anchored rebase).
        let child: SCNNode
        /// Static strip topology — 2 verts per anchor, upstream's
        /// `_stripIndices` winding.
        let indexElement: SCNGeometryElement
        /// Static +Z normals, one per strip vertex (upstream
        /// `_initialNormals`) — the constant-lit material doesn't
        /// read them but SceneKit wants the semantic present.
        let normalSource: SCNGeometrySource
        /// The shared translucent unlit material — upstream's
        /// `_TrailDefaultMaterial`: vertex color (incl. alpha)
        /// drives base color, double-sided because a camera-facing
        /// strip's winding flips where the path doubles back.
        static let material: SCNMaterial = {
            let m = SCNMaterial()
            m.lightingModel = .constant
            m.diffuse.contents = UIColor.white
            m.isDoubleSided = true
            m.transparencyMode = .default
            return m
        }()

        init(maxPoints: Int) {
            self.maxPoints = maxPoints
            child = SCNNode()
            // `d3prim:`-style prefix — clearComponentState/removal
            // purge by name, and the child never enters nodesById.
            child.name = "d3trail:"
            child.castsShadow = false
            var indices: [UInt16] = []
            indices.reserveCapacity((maxPoints - 1) * 6)
            for i in 0..<maxPoints - 1 {
                let a = UInt16(i * 2)
                indices.append(contentsOf:
                    [a, a + 1, a + 2, a + 1, a + 3, a + 2])
            }
            indexElement = SCNGeometryElement(
                data: indices.withUnsafeBytes { Data($0) },
                primitiveType: .triangles,
                primitiveCount: (maxPoints - 1) * 2,
                bytesPerIndex: MemoryLayout<UInt16>.size)
            var normals = [Float](repeating: 0, count: maxPoints * 6)
            for i in 0..<maxPoints * 2 { normals[i * 3 + 2] = 1 }
            normalSource = SCNGeometrySource(
                data: normals.withUnsafeBytes { Data($0) },
                semantic: .normal,
                vectorCount: maxPoints * 2,
                usesFloatComponents: true,
                componentsPerVector: 3,
                bytesPerComponent: 4,
                dataOffset: 0,
                dataStride: 12)
        }

        /// Forgets the recorded path — the ribbon disappears.
        func clear() {
            points.removeAll()
            born.removeAll()
        }

        /// Records `world` at `time + dt` — upstream's update ported.
        func record(dt: Double, world: simd_float3) {
            time += dt
            if emitting {
                if points.isEmpty {
                    points.insert(world, at: 0)
                    born.insert(time, at: 0)
                } else {
                    points[0] = world
                    born[0] = time
                    let anchored = points.count > 1
                        ? points[1] : points[0]
                    if points.count == 1 ||
                        simd_distance(anchored, world) >=
                            Float(minVertexDistance) {
                        points.insert(world, at: 0)
                        born.insert(time, at: 0)
                    }
                }
            }
            while points.count > maxPoints ||
                (born.last.map { time - $0 > lifetime } ?? false) {
                points.removeLast()
                born.removeLast()
                if points.isEmpty { break }
            }
        }

        /// `widthOverTrail` at the head-to-tail fraction — piecewise-
        /// linear, clamped to the ends; `1 − t` when no curve shipped.
        func widthAt(_ t: Double) -> Double {
            guard let keys = widthKeys, !keys.isEmpty else {
                return 1.0 - t
            }
            if t <= keys[0].t { return keys[0].v }
            if t >= keys[keys.count - 1].t {
                return keys[keys.count - 1].v
            }
            for i in 1..<keys.count where t <= keys[i].t {
                let f = (t - keys[i - 1].t) / (keys[i].t - keys[i - 1].t)
                return keys[i - 1].v + (keys[i].v - keys[i - 1].v) * f
            }
            return keys[keys.count - 1].v
        }

        /// `colorOverTrail` at the head-to-tail fraction — piecewise-
        /// linear rgba; the absent gradient is white fading `1 − t`.
        func colorAt(_ t: Double) -> simd_float4 {
            guard let stops = colorStops, !stops.isEmpty else {
                return simd_float4(1, 1, 1, Float(1.0 - t))
            }
            if t <= stops[0].t {
                return simd_float4(Float(stops[0].r), Float(stops[0].g),
                                   Float(stops[0].b), Float(stops[0].a))
            }
            let last = stops[stops.count - 1]
            if t >= last.t {
                return simd_float4(Float(last.r), Float(last.g),
                                   Float(last.b), Float(last.a))
            }
            for i in 1..<stops.count where t <= stops[i].t {
                let a = stops[i - 1], b = stops[i]
                let f = Float((t - a.t) / (b.t - a.t))
                return simd_float4(
                    Float(a.r) + Float(b.r - a.r) * f,
                    Float(a.g) + Float(b.g - a.g) * f,
                    Float(a.b) + Float(b.b - a.b) * f,
                    Float(a.a) + Float(b.a - a.a) * f)
            }
            return simd_float4(Float(last.r), Float(last.g),
                               Float(last.b), Float(last.a))
        }
    }

    /// W16: a decoded `lod` component — upstream `LodComponent`. The
    /// level list is highest detail first with descending
    /// `screenSize` thresholds (fraction of viewport height). Selection
    /// is dart3d's own per-frame pass (the Android `updateLod` port in
    /// `SceneViewHost.updateLods`): SceneKit's `levelsOfDetail` is NOT
    /// used — probe-verified, its `screenSpaceRadius` is a
    /// max-projection-axis, half-viewport-diagonal metric measured on
    /// view depth, which can't reproduce upstream's height-fraction
    /// Euclidean selection, and its level-0 tight bounding sphere
    /// isn't overridable.
    final class LodSpec {
        struct Level {
            let geoKey: UInt64
            let matKey: UInt64
            let screenSize: Double
        }
        var levels: [Level] = []
        var lodBias = 1.0
        /// Upstream's dead-band fraction — the wire default is 0.1
        /// (LodCodec/LodComponent); the frame pass's `selectLodLevel`
        /// applies it with `bound` as the memory.
        var hysteresis = 0.1
        /// Decoded for wire parity — a documented no-op: upstream's
        /// cross-fade needs a per-material dither slot
        /// (`Material.lodFade`) the natives don't carry, so dart3d
        /// hard-switches (Android matches).
        var blendRange = 0.0
        /// False while a level's geometry/material hasn't landed —
        /// `lodResourceConsumers` routes its arrival to `rebindLod`.
        var resolved = false
        /// The level geometry copies in force — the frame pass binds
        /// by swapping `node.geometry` among them; kept so a teardown
        /// or rebind can purge them from `materialConsumers`.
        var geoCopies: [SCNGeometry] = []
        /// Level-0's local-space AABB — cached at rebind so the frame
        /// pass transforms its 8 corners per frame instead of
        /// re-reading `SCNGeometry.boundingBox`.
        var boundMin = simd_float3()
        var boundMax = simd_float3()
        /// The level currently bound to `node.geometry` — -1 while
        /// culled or never bound. Doubles as the hysteresis
        /// dead-band's memory (upstream `_currentLevel`).
        var bound = -1
        /// The node's draw slot is lod-owned once a level has bound —
        /// a culled node STILL owns the slot (bound -1 only parks its
        /// geometry). The mesh geometry-consumer rebind lane skips
        /// lod-owned nodes (Android's `ownsRenderable`).
        var ownsRenderable = false
        /// A `mesh` decoded after this `lod` took the slot back —
        /// last-write-wins (Android's `suspended`); the frame pass
        /// and resource-landing rebinds skip it until a fresh `lod`
        /// decodes.
        var suspended = false
    }

    // MARK: - Context

    final class Context {
        typealias PayloadSpec =
            (encoding: String, layout: String?, format: String?,
             width: Int?, height: Int?, length: Int?)

        let host: SceneViewHost
        let formatVersion: Int
        let scene: SCNScene
        let preserveBakedShadowCaches: Bool
        var nodes: [UInt64: SCNNode] = [:]
        var geometries: [UInt64: SCNGeometry] = [:]
        var materials: [UInt64: SCNMaterial] = [:]
        var materialColorOwners: [UInt64: MaterialColorOwner] = [:]
        var lightIntensityOwners: [UInt64: LightIntensityOwner] = [:]
        var cameraFovOwners: [UInt64: CameraFovOwner] = [:]
        var shadowCatcherConfigurations:
            [UInt64: ShadowCatcherConfiguration] = [:]
        var shadowCatcherBindings:
            [UInt64: [ShadowCatcherMaterialBinding]] = [:]
        var textures: [UInt64: DecodedTexture] = [:]
        var environments: [UInt64: [String: Any]] = [:]
        var payloadSpecs: [UInt64: PayloadSpec] = [:]
        var deferredResourceIds: Set<UInt64> = []
        var firstCameraNode: SCNNode?
        var dynamicBodyKeys: Set<UInt64> = []

        /// Node key → index of its `collider` component inside the
        /// spec's `components` array — the `ca`/`cb`/`collider` fields
        /// W8 contact events and query hits report (absent → 0).
        var colliderIndexByKey: [UInt64: Int] = [:]

        /// W15: node key → the raw `instance` spec member — the lazy
        /// prefab placeholder tag. Recorded at node decode and
        /// refreshed by spec-carrying updates; never decoded here
        /// (Dart composes the subtree and streams it as standard ops).
        var instanceSpecs: [UInt64: [String: Any]] = [:]

        /// Raw manifest entry per resource id — the surgical ops
        /// (`upsertResource`, `upsertPayload`) re-decode a single
        /// resource out of this map, and slot rebinding reads material
        /// factors back out of it.
        var resourceDefs: [UInt64: [String: Any]] = [:]

        /// Texture id → every (material, slot) that consumed it — a
        /// texture `upsertResource` re-applies each binding.
        var textureConsumers: [UInt64: [TextureBinding]] = [:]

        /// Material id → geometries whose `.materials` reference it —
        /// a material `upsertResource` re-attaches the re-decoded
        /// material on each.
        var materialConsumers: [UInt64: [SCNGeometry]] = [:]

        /// Geometry id → every node whose mesh consumed it — a
        /// geometry `upsertResource`/`upsertPayload` re-decodes the
        /// resource and swaps the result onto each consumer's
        /// `.geometry`. Recorded at `decodeMesh` even when the
        /// geometry is still unresolved, so a deferred resource
        /// rebinds when its payload lands.
        var geometryConsumers: [UInt64: [SCNNode]] = [:]

        /// Texture id → payload id backing it, so an `upsertPayload`
        /// chunk can find the textures it unblocks.
        var texturePayloadKeys: [UInt64: UInt64] = [:]

        /// Geometry id → the payload ids backing it (vertices plus
        /// indices), so an `upsertPayload` chunk can find the
        /// geometries it unblocks.
        var geometryPayloadKeys: [UInt64: Set<UInt64>] = [:]

        /// Environment id → payload id backing its equirect source,
        /// so an `upsertPayload` chunk can re-run `decodeStage` on the
        /// env it unblocks (W7).
        var environmentPayloadKeys: [UInt64: UInt64] = [:]

        /// W25: environment id → payload id backing its
        /// `effects.colorGrading.lut` `.cube` table, so the chunk's
        /// arrival re-runs `decodeStage` (and the host re-applies the
        /// effects stack). Asset-path LUT refs don't claim — they
        /// resolve through the host's bundle lookup.
        var lutPayloadKeys: [UInt64: UInt64] = [:]

        /// Decoded `skins` entries (W11) — joint keys, IBMs, optional
        /// skeleton. Populated by `decodeSkins` after the node pass.
        var skins: [UInt64: DecodedSkin] = [:]

        /// Decoded `animations` entries (W11) — the defs the `anim`
        /// op instantiates clips from.
        var animations: [UInt64: DecodedAnimation] = [:]

        /// Geometry id → absolute morph targets for `SCNMorpher` (W11).
        var morphTargets: [UInt64: DecodedMorph] = [:]

        /// Node key → its `skin` member's skin key (W11) — the node's
        /// declared binding, tracked separately from the attached
        /// `SCNSkinner` so skin removal/upsert can re-drive it.
        var nodeSkinKeys: [UInt64: UInt64] = [:]

        /// Nodes whose skinner attach isn't fully resolved (geometry
        /// pending, joint nodes missing, skeleton unresolved, IBM
        /// payload in flight) — retried on node landings and payload
        /// arrivals, the W9-deferred-joint pattern.
        var pendingSkinNodes: Set<UInt64> = []

        /// Skin id → its `inverseBindMatrices` payload key, so an
        /// `upsertPayload` chunk re-decodes the skin it unblocks.
        var skinPayloadKeys: [UInt64: UInt64] = [:]

        /// Animation id → its channels' payload keys (timelines +
        /// keyframes), so an `upsertPayload` chunk re-decodes the
        /// animation it unblocks.
        var animPayloadKeys: [UInt64: Set<UInt64>] = [:]

        /// Raw manifest entries per skin/animation id — the surgical
        /// ops (`upsertSkin`, `upsertAnimation`, `upsertPayload`)
        /// re-decode a single entry out of these, like `resourceDefs`.
        var skinDefs: [UInt64: [String: Any]] = [:]
        var animDefs: [UInt64: AnimationDefinition] = [:]

        /// Set on surgical contexts (seeded from live registries): node
        /// lookups fall back to `host.nodesById`. Manifest decode leaves
        /// it false — `nodes` is the new scene's complete map, and the
        /// host registry still holds the OLD scene's nodes then.
        var resolvesLiveNodes = false

        /// The last `stage` JSON decoded — `updateStage` ops and
        /// payload-arrival re-decodes replay it against the live scene.
        var stageJSON: [String: Any]? = nil

        /// Linear pre-tonemap exposure from the decoded environment —
        /// the caller applies it to the view camera (`exposureOffset =
        /// log2(exposure)`, `wantsHDR = true`) once `pointOfView` is
        /// known (after `install`, or live for `updateStage`).
        var stageExposure: Double = 1.0

        /// The decoded environment's tone-mapping operator; the host's
        /// resolve pass applies it.
        var stageToneMap = StageToneMap()

        /// Set by `decodeStage` when the env's equirect payload hasn't
        /// arrived — the stage application defers env/skybox contents
        /// and re-runs on payload arrival (W4 deferral pattern).
        var stageEnvDeferred = false

        /// W13: the env resource's decoded `effects` post stack — nil
        /// when the wire key is absent ("don't touch live settings"),
        /// wholesale-decoded when present. The host applies it to the
        /// point-of-view camera and scene after install / on
        /// `updateStage` (retention rule: absent → keep prior values).
        var stageEffects: StageEffects? = nil

        /// W14: `rt:` render-target records decoded from
        /// `kind:'renderTexture'` resources — the Metal texture pair
        /// plus update/sampling spec; the decoded `views` attach to
        /// them at the host's `installViews`.
        var renderTargets: [UInt64: RenderTargetRec] = [:]

        /// W14: the decoded top-level `views` list — wholesale-
        /// replaced by `decodeViews` on both the manifest path and the
        /// `updateViews` op.
        var views: [ViewRec] = []

        /// W14 stage quality fields — decoded off `stage` itself (NOT
        /// the env resource). `antiAliasing` 'auto' defers to
        /// viewConfig; `filterQuality` has no SceneKit counterpart.
        var stageAntiAliasing = "auto"
        var stageRenderScale = 1.0
        var stageFilterQuality = "medium"

        /// Physics components deferred until after mesh decode — a
        /// `convexHull`/`concaveMesh` collider reads the node's geometry,
        /// and a body reads its collider, so neither can be built inline.
        var physicsDeferred:
            [(key: UInt64, node: SCNNode, type: String, props: [String: Any])] =
            []

        /// W12 declarative joint components — translated to the wire
        /// joint shape and registered under a reserved handle range in
        /// `decodePhysicsDeferred` (bodies must exist first, and an
        /// `otherNode` may land after the declaring node).
        var jointComponentsDeferred:
            [(key: UInt64, index: Int, type: String, props: [String: Any])] =
            []

        /// W12: components decoded with `enabled:false` — nodeKey →
        /// component indices. Upstream `Component.enabled` gates the
        /// component's update/fixedUpdate callbacks only; dart3d's
        /// realized components have no per-component tick surface, so
        /// the flag is recorded (for parity reporting and any future
        /// tick-bearing component) rather than applied to the render,
        /// light or physics state.
        var disabledComponents: [UInt64: Set<Int>] = [:]

        /// W12: decoded `materialsVariants` components — component
        /// node key → the spec. Bindings resolve against `nodes`/
        /// `geometries` lazily at apply time (an unresolved binding is
        /// retried on node/geometry landings, like a deferred payload
        /// claim).
        var variantComponents: [UInt64: VariantComponentSpec] = [:]

        /// W16: node key → its live `trail` component state (decoded
        /// spec + recorded path + the `d3trail:` child). The host's
        /// per-frame pass records the world position and rebuilds the
        /// ribbon geometry.
        var trails: [UInt64: TrailState] = [:]

        /// W16: node key → its decoded `lod` component. Level
        /// resources resolve through `rebindLod` — unresolved specs
        /// sit in `pendingLodNodes` and retry on resource landings.
        var lods: [UInt64: LodSpec] = [:]

        /// Resource id (geometry OR material) → node keys whose `lod`
        /// references it — the consumer-map lane for surgical
        /// rebinds, parallel to `geometryConsumers`/`materialConsumers`
        /// (an LOD level can't ride those: a landing re-resolves the
        /// whole level list, not a single slot).
        var lodResourceConsumers: [UInt64: Set<UInt64>] = [:]

        /// LOD nodes waiting on a level resource — retried by
        /// `redecodeResource`/payload arrivals, the
        /// `pendingSkinNodes` pattern.
        var pendingLodNodes: Set<UInt64> = []
        /// W26: node key → raw `d3:instances` properties — recorded
        /// at decode so a geometry `upsertResource`/`upsertPayload`
        /// arriving after the component can re-bake the instance
        /// mesh instead of rebinding the raw geometry onto the node.
        var instancesProps: [UInt64: [String: Any]] = [:]

        /// `scene` is the host's bound scene for every caller — the
        /// manifest path decodes into it in place (a second SCNScene
        /// built inside the render callback trips SceneKit's
        /// cross-scene mutation guard) and the surgical ops need the
        /// live graph so a `physicsWorld` component or a `pointOfView`
        /// camera lands on the real scene. The `SCNScene()` default
        /// only backs a pre-setup call where the view has none yet.
        init(host: SceneViewHost, formatVersion: Int,
             scene: SCNScene = SCNScene(),
             preserveBakedShadowCaches: Bool = false) {
            self.host = host
            self.formatVersion = formatVersion
            self.scene = scene
            self.preserveBakedShadowCaches = preserveBakedShadowCaches
        }

        func installScene() {
            host.install(scene: scene, nodes: nodes,
                         resources: (geometries: geometries,
                                     materials: materials,
                                     materialColorOwners: materialColorOwners,
                                     lightIntensityOwners: lightIntensityOwners,
                                     cameraFovOwners: cameraFovOwners,
                                     shadowCatcherConfigurations:
                                        shadowCatcherConfigurations,
                                     shadowCatcherBindings:
                                        shadowCatcherBindings,
                                     textures: textures,
                                     defs: resourceDefs,
                                     payloadSpecs: payloadSpecs,
                                     instanceSpecs: instanceSpecs,
                                     textureConsumers: textureConsumers,
                                     materialConsumers: materialConsumers,
                                     geometryConsumers: geometryConsumers,
                                     texturePayloadKeys: texturePayloadKeys,
                                     geometryPayloadKeys: geometryPayloadKeys,
                                     environmentPayloadKeys:
                                        environmentPayloadKeys,
                                     lutPayloadKeys: lutPayloadKeys,
                                     skins: skins,
                                     animations: animations,
                                     morphTargets: morphTargets,
                                     nodeSkinKeys: nodeSkinKeys,
                                     pendingSkinNodes: pendingSkinNodes,
                                     skinPayloadKeys: skinPayloadKeys,
                                     animPayloadKeys: animPayloadKeys,
                                     skinDefs: skinDefs,
                                     animDefs: animDefs,
                                     variantComponents:
                                        variantComponents,
                                     disabledComponents:
                                        disabledComponents,
                                     trails: trails,
                                     lods: lods,
                                     lodResourceConsumers:
                                        lodResourceConsumers,
                                     pendingLodNodes: pendingLodNodes,
                                     instancesProps: instancesProps,
                                     renderTargets: renderTargets),
                         deferred: deferredResourceIds,
                         camera: firstCameraNode,
                         dynamicBodies: dynamicBodyKeys,
                         colliderIndices: colliderIndexByKey,
                         formatVersion: formatVersion,
                         preserveBakedShadowCaches:
                            preserveBakedShadowCaches,
                         stage: (json: stageJSON, exposure: stageExposure,
                                 toneMap: stageToneMap,
                                 effects: stageEffects,
                                 antiAliasing: stageAntiAliasing,
                                 renderScale: stageRenderScale,
                                 filterQuality: stageFilterQuality),
                         views: views)
        }

        // MARK: Resources

        func decodePayloadSpecs(_ map: [String: Any]) {
            for (token, any) in map {
                guard let key = D3Wire.localIdKey(token),
                      let spec = any as? [String: Any],
                      let encoding = spec["encoding"] as? String else {
                    d3Log("payload spec '\(token)' is malformed")
                    continue
                }
                payloadSpecs[key] = (
                    encoding, spec["layout"] as? String,
                    spec["format"] as? String,
                    (spec["width"] as? NSNumber)?.intValue,
                    (spec["height"] as? NSNumber)?.intValue,
                    (spec["length"] as? NSNumber)?.intValue)
            }
        }

        func decodeResources(_ map: [String: Any]) {
            // Textures decode ahead of every other kind: material slots
            // resolve texture refs at material-decode time and map
            // iteration order is arbitrary. Raw defs are retained for
            // the surgical ops (upsertResource/upsertPayload), which
            // re-decode a single resource out of `resourceDefs`.
            var rest: [(UInt64, [String: Any])] = []
            for (token, any) in map {
                guard let key = D3Wire.localIdKey(token),
                      let r = any as? [String: Any],
                      let kind = r["kind"] as? String else { continue }
                resourceDefs[key] = r
                if kind == "texture" {
                    decodeTexture(key, r)
                } else if kind == "renderTexture" {
                    // W14: decode with the textures so material slots
                    // resolve rt refs in the rest pass below.
                    decodeRenderTexture(key, r)
                } else {
                    rest.append((key, r))
                }
            }
            for (key, r) in rest {
                switch r["kind"] as? String ?? "" {
                case "geometry":   decodeGeometry(key, r)
                case "material":   decodeMaterial(key, r)
                case "environment":
                    // Retained raw — `decodeStage` consumes the entry
                    // the stage's `environmentRef` names, and the
                    // surgical ops rebuild `environments` from
                    // `resourceDefs`.
                    environments[key] = r
                default:
                    d3Log("unknown resource kind "
                        + "'\(r["kind"] ?? "<absent>")'")
                }
            }
        }

        struct DecodedVertices {
            var positions: [Float] = []
            var normals: [Float] = []
            var uv0: [Float] = []
            /// TEXCOORD_1 — populated only by the `*_uv1_tangent`
            /// layouts; lands as the geometry's second `.texcoord`
            /// source so `mappingChannel` 1 selects it.
            var uv1: [Float] = []
            var colors: [Float] = []
            var tangents: [Float] = []
            /// JOINTS — the four bone indices per vertex the
            /// `skinned*` layouts carry as f32 (converted to int32 for
            /// the `.boneIndices` source). Empty on unskinned layouts.
            var boneIndices: [Int32] = []
            /// WEIGHTS — four bone weights per vertex (`.boneWeights`).
            var boneWeights: [Float] = []
            let count: Int
            let nativeSpace: Bool

            init(count: Int, nativeSpace: Bool) {
                self.count = count
                self.nativeSpace = nativeSpace
                positions.reserveCapacity(count * 3)
                normals.reserveCapacity(count * 3)
                uv0.reserveCapacity(count * 2)
                colors.reserveCapacity(count * 4)
                tangents.reserveCapacity(count * 4)
            }
        }

        enum ElementResult {
            case ready(SCNGeometryElement)
            case deferred
            case invalid
        }

        /// Stored bytes must match the manifest's declared `length` —
        /// a mismatch means the chunk under `payloadKey` isn't this
        /// document's (a stale key from a previous doc, or a partial
        /// write), so the consumer defers until the real chunk lands
        /// rather than decoding garbage. Undeclared lengths pass.
        func payloadLengthMatches(
            _ key: UInt64, payloadKey: UInt64,
            spec: PayloadSpec, bytes: Data
        ) -> Bool {
            guard let declared = spec.length else { return true }
            if declared == bytes.count { return true }
            host.logOnce("geometry.\(key).payloadLen.\(payloadKey)",
                "geometry \(key): payload \(payloadKey) is "
                + "\(bytes.count) B, manifest declares \(declared) B — "
                + "awaiting real chunk")
            return false
        }

        func decodeGeometry(_ key: UInt64, _ r: [String: Any]) {
            if let proc = r["procedural"] as? [String: Any],
               let shape = proc["shape"] as? String {
                geometries[key] = procedural(key, shape, proc)
                return
            }
            guard let token = r["vertices"] as? String,
                  let payloadKey = D3Wire.localIdKey(token) else {
                host.logOnce("geometry.\(key).vertices",
                    "geometry \(key): missing or invalid vertices payload token")
                return
            }
            // Record the claim before resolution — an `upsertPayload`
            // chunk re-decodes every geometry that references it.
            geometryPayloadKeys[key, default: []].insert(payloadKey)
            guard let spec = payloadSpecs[payloadKey] else {
                host.logOnce("geometry.\(key).vertexSpec",
                    "geometry \(key): vertices payload has no spec")
                return
            }
            guard spec.encoding == "vertexBuffer" else {
                host.logOnce("geometry.\(key).vertexEncoding",
                    "geometry \(key): vertices payload encoding "
                    + "'\(spec.encoding)' is not vertexBuffer")
                return
            }
            guard let bytes = host.payloadStore[payloadKey],
                  payloadLengthMatches(key, payloadKey: payloadKey,
                                       spec: spec, bytes: bytes) else {
                deferredResourceIds.insert(key)
                host.logOnce("geometry.\(key).awaiting",
                    "geometry \(key): awaiting payload")
                return
            }

            let started = DispatchTime.now().uptimeNanoseconds
            guard let decoded = decodeVertexPayload(
                bytes, layout: spec.layout, geometryKey: key) else { return }
            guard case let .ready(element) = decodeGeometryElement(
                key, r, vertexCount: decoded.count,
                nativeSpace: decoded.nativeSpace) else { return }

            var sources = [
                floatSource(decoded.positions, .vertex, decoded.count, 3),
                floatSource(decoded.normals, .normal, decoded.count, 3),
                floatSource(decoded.uv0, .texcoord, decoded.count, 2),
                floatSource(decoded.colors, .color, decoded.count, 4),
                floatSource(decoded.tangents, .tangent, decoded.count, 4),
            ]
            // W21: a second `.texcoord` source is UV set 1 —
            // `SCNMaterialProperty.mappingChannel` indexes texcoord
            // sources in declaration order.
            if decoded.uv1.count == decoded.count * 2 {
                sources.append(
                    floatSource(decoded.uv1, .texcoord, decoded.count, 2))
            }
            if decoded.boneWeights.count == decoded.count * 4,
               decoded.boneIndices.count == decoded.count * 4 {
                sources.append(floatSource(
                    decoded.boneWeights, .boneWeights, decoded.count, 4))
                sources.append(intSource(
                    decoded.boneIndices, .boneIndices, decoded.count, 4))
            }
            let geometry = SCNGeometry(sources: sources, elements: [element])
            if let bounds = decodeBounds(r["bounds"],
                                         nativeSpace: decoded.nativeSpace) {
                geometry.boundingBox = bounds
            }
            if let morph = r["morphTargets"] as? [String: Any] {
                decodeMorphTargets(key, morph, decoded: decoded,
                                   element: element)
            } else if r["morphTargets"] != nil {
                host.logOnce("geometry.\(key).morphTargets",
                    "geometry \(key): malformed morphTargets block")
            }
            geometries[key] = geometry

            let elapsed = Double(DispatchTime.now().uptimeNanoseconds - started)
                / 1_000_000.0
            d3Log("geometry \(key): decoded \(decoded.count) verts in "
                + "\(String(format: "%.2f", elapsed))ms")
        }

        func decodeVertexPayload(_ data: Data, layout rawLayout: String?,
                                 geometryKey key: UInt64)
            -> DecodedVertices?
        {
            let layout = rawLayout ?? "unskinned"
            let stride: Int
            switch layout {
            case "unskinned_uv1_tangent", "unskinned_soa_uv1_tangent":
                stride = 72
            case "skinned_uv1_tangent":
                stride = 104
            case "unskinned", "unskinned_soa":
                stride = 48
            case "skinned":
                stride = 80
            case "p3t4":
                stride = 28
            default:
                host.logOnce("geometry.\(key).layout.\(layout)",
                    "geometry \(key): unknown vertex layout '\(layout)'")
                return nil
            }
            guard !data.isEmpty else {
                host.logOnce("geometry.\(key).emptyVertices",
                    "geometry \(key): vertex payload is empty")
                return nil
            }
            guard data.count % stride == 0 else {
                host.logOnce("geometry.\(key).stride.\(layout)",
                    "geometry \(key): layout '\(layout)' stride \(stride) "
                    + "does not divide \(data.count) bytes")
                return nil
            }

            let count = data.count / stride
            var out = DecodedVertices(count: count,
                                      nativeSpace: layout == "p3t4")
            func f(_ offset: Int) -> Float {
                D3Wire.f32LE(data, data.startIndex + offset)
            }
            func appendPosition(_ offset: Int, mirror: Bool = true) {
                out.positions.append(f(offset))
                out.positions.append(f(offset + 4))
                out.positions.append(mirror ? -f(offset + 8) : f(offset + 8))
            }
            func appendNormal(_ offset: Int, mirror: Bool = true) {
                out.normals.append(f(offset))
                out.normals.append(f(offset + 4))
                out.normals.append(mirror ? -f(offset + 8) : f(offset + 8))
            }
            func appendUv(_ offset: Int) {
                out.uv0.append(f(offset))
                out.uv0.append(f(offset + 4))
            }
            func appendUv1(_ offset: Int) {
                out.uv1.append(f(offset))
                out.uv1.append(f(offset + 4))
            }
            func appendColor(_ offset: Int) {
                for j in 0..<4 { out.colors.append(f(offset + j * 4)) }
            }
            func appendTangent(_ offset: Int) {
                out.tangents.append(f(offset))
                out.tangents.append(f(offset + 4))
                out.tangents.append(-f(offset + 8))
                out.tangents.append(-f(offset + 12))
            }
            func appendNeutralTangent() {
                out.tangents.append(contentsOf: [1, 0, 0, -1])
            }
            // JOINTS are f32 on the wire; the `.boneIndices` source takes
            // integer components (upstream stores them float-typed but the
            // values are whole).
            func appendJoints(_ offset: Int) {
                for j in 0..<4 {
                    out.boneIndices.append(
                        Int32(clamping: max(0, Int(f(offset + j * 4)
                            .rounded()))))
                }
            }
            func appendWeights(_ offset: Int) {
                for j in 0..<4 { out.boneWeights.append(f(offset + j * 4)) }
            }

            switch layout {
            case "unskinned_uv1_tangent", "skinned_uv1_tangent":
                let skinned = layout == "skinned_uv1_tangent"
                if skinned {
                    out.boneIndices.reserveCapacity(count * 4)
                    out.boneWeights.reserveCapacity(count * 4)
                }
                out.uv1.reserveCapacity(count * 2)
                for i in 0..<count {
                    let base = i * stride
                    appendPosition(base)
                    appendNormal(base + 12)
                    appendUv(base + 24)
                    appendUv1(base + 32)
                    appendColor(base + 40)
                    appendTangent(base + 56)
                    if skinned {
                        appendJoints(base + 72)
                        appendWeights(base + 88)
                    }
                }
            case "unskinned_soa_uv1_tangent":
                let normalBase = count * 12
                let uv0Base = normalBase + count * 12
                let uv1Base = uv0Base + count * 8
                let colorBase = uv1Base + count * 8
                let tangentBase = colorBase + count * 16
                out.uv1.reserveCapacity(count * 2)
                for i in 0..<count {
                    appendPosition(i * 12)
                    appendNormal(normalBase + i * 12)
                    appendUv(uv0Base + i * 8)
                    appendUv1(uv1Base + i * 8)
                    appendColor(colorBase + i * 16)
                    appendTangent(tangentBase + i * 16)
                }
            case "unskinned", "skinned":
                let skinned = layout == "skinned"
                if skinned {
                    out.boneIndices.reserveCapacity(count * 4)
                    out.boneWeights.reserveCapacity(count * 4)
                }
                for i in 0..<count {
                    let base = i * stride
                    appendPosition(base)
                    appendNormal(base + 12)
                    appendUv(base + 24)
                    appendColor(base + 32)
                    appendNeutralTangent()
                    if skinned {
                        appendJoints(base + 48)
                        appendWeights(base + 64)
                    }
                }
            case "unskinned_soa":
                let normalBase = count * 12
                let uvBase = normalBase + count * 12
                let colorBase = uvBase + count * 8
                for i in 0..<count {
                    appendPosition(i * 12)
                    appendNormal(normalBase + i * 12)
                    appendUv(uvBase + i * 8)
                    appendColor(colorBase + i * 16)
                    appendNeutralTangent()
                }
            case "p3t4":
                for i in 0..<count {
                    let base = i * stride
                    appendPosition(base, mirror: false)
                    let x = f(base + 12), y = f(base + 16)
                    let z = f(base + 20), w = f(base + 24)
                    let norm = x * x + y * y + z * z + w * w
                    let s: Float = norm > 0 ? 2 / norm : 0
                    out.tangents.append(1 - s * (y * y + z * z))
                    out.tangents.append(s * (x * y + z * w))
                    out.tangents.append(s * (x * z - y * w))
                    out.tangents.append(1)
                    out.normals.append(s * (x * z + y * w))
                    out.normals.append(s * (y * z - x * w))
                    out.normals.append(1 - s * (x * x + y * y))
                    out.uv0.append(contentsOf: [0, 0])
                    out.colors.append(contentsOf: [1, 1, 1, 1])
                }
            default:
                return nil
            }
            return out
        }

        func decodeGeometryElement(
            _ key: UInt64, _ r: [String: Any], vertexCount: Int,
            nativeSpace: Bool
        ) -> ElementResult {
            let topology = r["topology"] as? String ?? "triangle"
            let primitiveType: SCNGeometryPrimitiveType
            switch topology {
            case "triangle":      primitiveType = .triangles
            case "triangleStrip": primitiveType = .triangleStrip
            case "lineStrip":     primitiveType = .line
            // `.line` is unconnected pairs — upstream 'line' is already
            // pairs; 'lineStrip' is expanded below.
            case "line":          primitiveType = .line
            case "point":         primitiveType = .point
            default:
                host.logOnce("geometry.\(key).topology.\(topology)",
                    "geometry \(key): unknown topology '\(topology)'")
                return .invalid
            }

            var indices: [UInt32] = []
            var bytesPerIndex: Int
            let indexed = r["indices"] != nil
            if indexed {
                guard let token = r["indices"] as? String,
                      let payloadKey = D3Wire.localIdKey(token) else {
                    host.logOnce("geometry.\(key).indices",
                        "geometry \(key): invalid indices payload token")
                    return .invalid
                }
                geometryPayloadKeys[key, default: []].insert(payloadKey)
                guard let spec = payloadSpecs[payloadKey] else {
                    host.logOnce("geometry.\(key).indexSpec",
                        "geometry \(key): indices payload has no spec")
                    return .invalid
                }
                guard spec.encoding == "indexBuffer" else {
                    host.logOnce("geometry.\(key).indexEncoding",
                        "geometry \(key): indices payload encoding "
                        + "'\(spec.encoding)' is not indexBuffer")
                    return .invalid
                }
                let format = spec.format ?? "uint16"
                switch format {
                case "uint16": bytesPerIndex = 2
                case "uint32": bytesPerIndex = 4
                default:
                    host.logOnce("geometry.\(key).indexFormat.\(format)",
                        "geometry \(key): unknown index format '\(format)'")
                    return .invalid
                }
                guard let data = host.payloadStore[payloadKey],
                      payloadLengthMatches(key, payloadKey: payloadKey,
                                           spec: spec, bytes: data) else {
                    deferredResourceIds.insert(key)
                    host.logOnce("geometry.\(key).awaiting",
                        "geometry \(key): awaiting payload")
                    return .deferred
                }
                guard !data.isEmpty, data.count % bytesPerIndex == 0 else {
                    host.logOnce("geometry.\(key).indexStride",
                        "geometry \(key): index payload size \(data.count) "
                        + "is invalid for \(format)")
                    return .invalid
                }
                indices.reserveCapacity(data.count / bytesPerIndex)
                for offset in stride(from: 0, to: data.count,
                                     by: bytesPerIndex) {
                    if bytesPerIndex == 2 {
                        let lo = UInt16(data[data.startIndex + offset])
                        let hi = UInt16(data[data.startIndex + offset + 1])
                        indices.append(UInt32(lo | hi << 8))
                    } else {
                        indices.append(D3Wire.u32LE(
                            data, data.startIndex + offset))
                    }
                }
            } else {
                bytesPerIndex = vertexCount <= Int(UInt16.max) ? 2 : 4
                indices = (0..<vertexCount).map(UInt32.init)
            }

            if !nativeSpace {
                if topology == "triangle", indexed {
                    let legacy = (r["legacyWinding"] as? Bool == true)
                        || formatVersion < 5
                    if !legacy {
                        for i in stride(from: 0, to: indices.count - 2, by: 3) {
                            indices.swapAt(i + 1, i + 2)
                        }
                    }
                } else {
                    host.logOnce("geometry.\(key).winding.\(topology).\(indexed)",
                        "geometry \(key): winding migration does not apply "
                        + "to \(indexed ? topology : "non-indexed") geometry")
                }
            }

            // `.line` takes pairs; a strip index list expands to pairs.
            if topology == "lineStrip" {
                var pairs: [UInt32] = []
                if indices.count >= 2 {
                    pairs.reserveCapacity((indices.count - 1) * 2)
                    for i in 0..<(indices.count - 1) {
                        pairs.append(indices[i]); pairs.append(indices[i + 1])
                    }
                }
                indices = pairs
            }
            let primitiveCount: Int
            switch topology {
            case "triangle":
                guard indices.count % 3 == 0 else {
                    host.logOnce("geometry.\(key).triangleIndices",
                        "geometry \(key): triangle index count is not "
                        + "divisible by 3")
                    return .invalid
                }
                primitiveCount = indices.count / 3
            case "triangleStrip": primitiveCount = max(indices.count - 2, 0)
            case "line", "lineStrip": primitiveCount = indices.count / 2
            case "point": primitiveCount = indices.count
            default: return .invalid
            }
            guard primitiveCount > 0 else {
                host.logOnce("geometry.\(key).emptyElements",
                    "geometry \(key): topology '\(topology)' has no primitives")
                return .invalid
            }

            var elementData = Data(capacity: indices.count * bytesPerIndex)
            for index in indices {
                if bytesPerIndex == 2 {
                    guard index <= UInt32(UInt16.max) else {
                        host.logOnce("geometry.\(key).indexOverflow",
                            "geometry \(key): uint16 index exceeds 65535")
                        return .invalid
                    }
                    var value = UInt16(index).littleEndian
                    withUnsafeBytes(of: &value) {
                        elementData.append(contentsOf: $0)
                    }
                } else {
                    var value = index.littleEndian
                    withUnsafeBytes(of: &value) {
                        elementData.append(contentsOf: $0)
                    }
                }
            }
            return .ready(SCNGeometryElement(
                data: elementData, primitiveType: primitiveType,
                primitiveCount: primitiveCount, bytesPerIndex: bytesPerIndex))
        }

        func floatSource(_ values: [Float],
                         _ semantic: SCNGeometrySource.Semantic,
                         _ count: Int, _ components: Int) -> SCNGeometrySource {
            let data = values.withUnsafeBufferPointer {
                Data(bytes: $0.baseAddress!,
                     count: $0.count * MemoryLayout<Float>.size)
            }
            return SCNGeometrySource(
                data: data, semantic: semantic, vectorCount: count,
                usesFloatComponents: true, componentsPerVector: components,
                bytesPerComponent: MemoryLayout<Float>.size,
                dataOffset: 0,
                dataStride: components * MemoryLayout<Float>.size)
        }

        /// Integer-component source — the `.boneIndices` lane of a
        /// skinned geometry. SceneKit caps bone index components at
        /// 2 bytes, so the f32-decoded indices pack as uint16.
        func intSource(_ values: [Int32],
                       _ semantic: SCNGeometrySource.Semantic,
                       _ count: Int, _ components: Int) -> SCNGeometrySource {
            var packed = [UInt16](repeating: 0, count: values.count)
            for i in values.indices {
                packed[i] = UInt16(clamping: max(values[i], 0))
            }
            let data = packed.withUnsafeBufferPointer {
                Data(bytes: $0.baseAddress!,
                     count: $0.count * MemoryLayout<UInt16>.size)
            }
            return SCNGeometrySource(
                data: data, semantic: semantic, vectorCount: count,
                usesFloatComponents: false,
                componentsPerVector: components,
                bytesPerComponent: MemoryLayout<UInt16>.size,
                dataOffset: 0,
                dataStride: components * MemoryLayout<UInt16>.size)
        }

        /// Reads a payload's bytes as little-endian f32s — the `floats`
        /// and `matrices` encodings' shared storage.
        func f32List(_ data: Data) -> [Float] {
            (0..<data.count / 4).map {
                D3Wire.f32LE(data, data.startIndex + $0 * 4)
            }
        }

        func decodeBounds(_ any: Any?, nativeSpace: Bool)
            -> (min: SCNVector3, max: SCNVector3)?
        {
            guard let map = any as? [String: Any],
                  let min = rawVec3(map["min"]),
                  let max = rawVec3(map["max"]) else { return nil }
            if nativeSpace {
                return (SCNVector3(min[0], min[1], min[2]),
                        SCNVector3(max[0], max[1], max[2]))
            }
            return (SCNVector3(min[0], min[1], -max[2]),
                    SCNVector3(max[0], max[1], -min[2]))
        }

        func rawVec3(_ any: Any?) -> [Float]? {
            guard let values = any as? [Any], values.count == 3 else {
                return nil
            }
            let floats = values.compactMap { ($0 as? NSNumber)?.floatValue }
            return floats.count == 3 ? floats : nil
        }

        /// Decodes a geometry's `morphTargets` block into absolute
        /// target geometries for `SCNMorpher` — the wire carries
        /// target-major delta slabs (all position deltas, then normal
        /// deltas when `normals`, then tangent deltas when `tangents`,
        /// each `targetCount × vertexCount × 3` f32), and SceneKit's
        /// targets hold absolute attributes, so each target is
        /// `base + delta`. Delta z negates like positions on the base
        /// decode — unless the geometry is `nativeSpace` (already
        /// right-handed). A missing deltas payload defers the geometry
        /// like any other claim.
        func decodeMorphTargets(_ key: UInt64, _ m: [String: Any],
                                decoded: DecodedVertices,
                                element: SCNGeometryElement) {
            guard let token = m["deltas"] as? String,
                  let pid = D3Wire.localIdKey(token),
                  let targetCount = (m["targetCount"] as? NSNumber)?
                      .intValue,
                  targetCount > 0 else {
                host.logOnce("geometry.\(key).morph.malformed",
                    "geometry \(key): morphTargets lacks deltas/"
                    + "targetCount")
                return
            }
            // Record the claim before resolution — an `upsertPayload`
            // chunk re-decodes this whole geometry on arrival.
            geometryPayloadKeys[key, default: []].insert(pid)
            guard let data = host.payloadStore[pid] else {
                deferredResourceIds.insert(key)
                host.logOnce("geometry.\(key).morph.awaiting",
                    "geometry \(key): awaiting morph delta payload")
                return
            }
            let floats = f32List(data)
            // Wire flags size the delta slabs; a slab is only applied
            // when the base actually carries that attribute.
            let hasN = m["normals"] as? Bool == true
            let hasT = m["tangents"] as? Bool == true
            let canN = decoded.normals.count >= decoded.count * 3
            let canT = decoded.tangents.count >= decoded.count * 4
            let slab = targetCount * decoded.count * 3
            let sections = 1 + (hasN ? 1 : 0) + (hasT ? 1 : 0)
            guard floats.count >= slab * sections else {
                host.logOnce("geometry.\(key).morph.size",
                    "geometry \(key): morph delta payload has "
                    + "\(floats.count) floats; expected "
                    + "\(slab * sections) for \(targetCount) targets")
                return
            }
            let mirror = !decoded.nativeSpace
            let normalBase = slab
            let tangentBase = slab + (hasN ? slab : 0)
            let names = m["names"] as? [String] ?? []
            var targets: [SCNGeometry] = []
            targets.reserveCapacity(targetCount)
            for ti in 0..<targetCount {
                var pos = [Float](repeating: 0, count: decoded.count * 3)
                var nrm: [Float]? =
                    hasN && canN
                        ? [Float](repeating: 0, count: decoded.count * 3)
                        : nil
                var tan: [Float]? =
                    hasT && canT
                        ? [Float](repeating: 0, count: decoded.count * 4)
                        : nil
                for v in 0..<decoded.count {
                    let vb3 = v * 3
                    let d3 = (ti * decoded.count + v) * 3
                    pos[vb3]     = decoded.positions[vb3]
                        + floats[d3]
                    pos[vb3 + 1] = decoded.positions[vb3 + 1]
                        + floats[d3 + 1]
                    pos[vb3 + 2] = decoded.positions[vb3 + 2]
                        + (mirror ? -floats[d3 + 2] : floats[d3 + 2])
                    if nrm != nil {
                        nrm![vb3]     = decoded.normals[vb3]
                            + floats[normalBase + d3]
                        nrm![vb3 + 1] = decoded.normals[vb3 + 1]
                            + floats[normalBase + d3 + 1]
                        nrm![vb3 + 2] = decoded.normals[vb3 + 2]
                            + (mirror ? -floats[normalBase + d3 + 2]
                                      : floats[normalBase + d3 + 2])
                    }
                    if tan != nil {
                        // Tangent deltas are xyz slabs; the handedness
                        // w stays the base's (base decode already
                        // negated it for the z-mirror).
                        let vb4 = v * 4
                        tan![vb4]     = decoded.tangents[vb4]
                            + floats[tangentBase + d3]
                        tan![vb4 + 1] = decoded.tangents[vb4 + 1]
                            + floats[tangentBase + d3 + 1]
                        tan![vb4 + 2] = decoded.tangents[vb4 + 2]
                            + (mirror ? -floats[tangentBase + d3 + 2]
                                      : floats[tangentBase + d3 + 2])
                        tan![vb4 + 3] = decoded.tangents[vb4 + 3]
                    }
                }
                var tsrcs = [
                    floatSource(pos, .vertex, decoded.count, 3)
                ]
                if let nrm {
                    tsrcs.append(
                        floatSource(nrm, .normal, decoded.count, 3))
                }
                if let tan {
                    tsrcs.append(
                        floatSource(tan, .tangent, decoded.count, 4))
                }
                let target = SCNGeometry(sources: tsrcs,
                                         elements: [element])
                if ti < names.count { target.name = names[ti] }
                targets.append(target)
            }
            let weights = (m["weights"] as? [NSNumber] ?? [])
                .map { $0.floatValue }
            morphTargets[key] = DecodedMorph(
                targets: targets, defaultWeights: weights,
                targetCount: targetCount)
        }

        /// Segment-count params clamp to ≥1 — a zero/negative on the
        /// wire would NaN the generators' `s / segments` divisions
        /// (the Dart-side contract floors at 1 too).
        /// Wire tessellation counts clamp to `[1, maxProcSegments]` —
        /// the Dart `limits.dart` contract (`kD3MaxProcSegments`):
        /// clamp, never reject, so every platform degrades to the same
        /// capped mesh instead of hanging on a hostile count.
        static let maxProcSegments = 512
        static let maxIcosphereSubdivisions = 6
        private func seg(_ p: [String: Any], _ name: String,
                         _ def: Int) -> Int {
            min(max(1, d3Int(p[name]) ?? def), Self.maxProcSegments)
        }

        private func stations(_ p: [String: Any]) -> Int {
            min(max(2, d3Int(p["stations"]) ?? 64), Self.maxProcSegments)
        }

        func procedural(_ key: UInt64, _ shape: String,
                        _ p: [String: Any]) -> SCNGeometry? {
            switch shape {
            case "cuboid":
                let e = d3Vec3(p["extents"]) ?? [1, 1, 1]
                // `debugColors` is a d3 extension — corner-keyed vertex
                // colors; SCNBox can't carry a color stream so both
                // paths use the CPU port (same verts as Android).
                return GeometryFactory.makeGeometry(
                    GeometryFactory.cuboid(
                        extents: SIMD3(Float(e[0]), Float(e[1]),
                                       Float(e[2])),
                        debugColors: d3Bool(p["debugColors"]) == true))
            case "wedge":
                let size = d3Vec3(p["size"]) ?? [1, 1, 1]
                return GeometryFactory.makeGeometry(
                    GeometryFactory.wedge(
                        SIMD3(Float(size[0]), Float(size[1]), Float(size[2]))))
            case "ring":
                let innerRadius = Float(d3Double(p["innerRadius"]) ?? 0.25)
                let outerRadius = Float(d3Double(p["outerRadius"]) ?? 0.5)
                guard innerRadius >= 0, outerRadius > 0,
                      innerRadius < outerRadius else {
                    d3Log("ring: requires 0 <= innerRadius < outerRadius")
                    return nil
                }
                return GeometryFactory.makeGeometry(
                    GeometryFactory.ring(
                        innerRadius: innerRadius,
                        outerRadius: outerRadius,
                        segments: max(3, seg(p, "segments", 32))))
            case "sphere":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.sphere(
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        segments: seg(p, "segments", 32),
                        rings: seg(p, "rings", 16)))
            case "icosphere":
                // W26: a real subdivided icosahedron replaces the
                // high-segment UV-sphere stand-in (same algorithm
                // proc.dart + MeshFactory.kt generate).
                return GeometryFactory.makeGeometry(
                    GeometryFactory.icosphere(
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        subdivisions: min(max(0,
                            d3Int(p["subdivisions"]) ?? 2),
                            Self.maxIcosphereSubdivisions)))
            case "plane":
                // XZ +Y — the wire contract; SCNPlane's XY/+Z never
                // matched it.
                return GeometryFactory.makeGeometry(
                    GeometryFactory.plane(
                        width: Float(d3Double(p["width"]) ?? 1),
                        depth: Float(d3Double(p["depth"]) ?? 1),
                        segmentsX: seg(p, "segmentsX", 1),
                        segmentsZ: seg(p, "segmentsZ", 1)))
            case "torus":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.torus(
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        tubeRadius: Float(d3Double(p["tubeRadius"]) ?? 0.15),
                        radialSegments: seg(p, "radialSegments", 32),
                        tubularSegments: seg(p, "tubularSegments", 16)))
            // W26 vocabulary — `d3:procMesh` components and
            // upstream-style `procedural` geometry resources share
            // the same shape/param names.
            case "cylinder":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.cylinder(
                        bottomRadius: Float(d3Double(p["bottomRadius"]) ?? 0.5),
                        topRadius: Float(d3Double(p["topRadius"]) ?? 0.5),
                        height: Float(d3Double(p["height"]) ?? 1),
                        radialSegments: seg(p, "radialSegments", 32),
                        heightSegments: seg(p, "heightSegments", 1),
                        bottomCap: d3Bool(p["bottomCap"]) != false,
                        topCap: d3Bool(p["topCap"]) != false))
            case "cone":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.cylinder(
                        bottomRadius: Float(d3Double(p["radius"]) ?? 0.5),
                        topRadius: 0,
                        height: Float(d3Double(p["height"]) ?? 1),
                        radialSegments: seg(p, "radialSegments", 32),
                        heightSegments: seg(p, "heightSegments", 1),
                        bottomCap: d3Bool(p["bottomCap"]) != false,
                        topCap: false))
            case "capsule":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.capsule(
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        height: Float(d3Double(p["height"]) ?? 1),
                        radialSegments: seg(p, "radialSegments", 32),
                        capRings: seg(p, "capRings", 8)))
            case "disc":
                return GeometryFactory.makeGeometry(
                    GeometryFactory.disc(
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        segments: seg(p, "segments", 32)))
            case "extrude":
                guard let pts = d3PointList(p["points"]), pts.count >= 2,
                      let profile = d3ProfileList(p["profile"]),
                      profile.count >= 3 else {
                    d3Log("extrude: needs at least two path points and three profile points")
                    return nil
                }
                return GeometryFactory.makeGeometry(
                    GeometryFactory.extrude(
                        pts, profile: profile, stations: stations(p),
                        caps: d3Bool(p["caps"]) != false))
            case "tube":
                guard let pts = d3PointList(p["points"]), pts.count >= 2
                else {
                    d3Log("tube: needs at least two points")
                    return nil
                }
                return GeometryFactory.makeGeometry(
                    GeometryFactory.tube(pts,
                        radius: Float(d3Double(p["radius"]) ?? 0.5),
                        radialSegments: seg(p, "radialSegments", 12),
                        stations: stations(p),
                        caps: d3Bool(p["caps"]) != false,
                        closed: d3Bool(p["closed"]) == true))
            case "ribbon":
                guard let pts = d3PointList(p["points"]), pts.count >= 2
                else {
                    d3Log("ribbon: needs at least two points")
                    return nil
                }
                let u = d3Vec3(p["up"]) ?? [0, 1, 0]
                return GeometryFactory.makeGeometry(
                    GeometryFactory.ribbon(pts,
                        width: Float(d3Double(p["width"]) ?? 1),
                        stations: stations(p),
                        up: SIMD3(Float(u[0]), Float(u[1]), Float(-u[2])),
                        closed: d3Bool(p["closed"]) == true))
            case let s where FsceneRealizer.Context.facingShapes
                .contains(s):
                // A camera-facing shape as a static geometry
                // resource can't reface per frame — bake once toward
                // +Z, the same fallback the instances path uses.
                host.logOnce("geometry.facing.\(s)",
                    "geometry \(key): camera-facing shape '\(s)'"
                        + " bakes once toward +Z")
                var fp = parseFacing(p)
                warnFacingDrops(site: "geometry", noun: "geometry",
                                key: key, shape: s, p, fp)
                fp.facing = facingMode(key, fp.facing)
                return facingMesh(s, fp,
                    viewDir: SIMD3(0, 0, 1),
                    right: SIMD3(1, 0, 0), up: SIMD3(0, 1, 0))
                    .map(GeometryFactory.makeGeometry)
            default:
                d3Log("unknown procedural shape '\(shape)'"); return nil
            }
        }

        // MARK: W26 `d3:procMesh` / `d3:instances`

        /// `d3:procMesh` shapes that re-expand toward the live camera
        /// each frame — the rest build once like the upstream
        /// procedural resources above.
        /// d3:instances bakes N copies into one vertex buffer on CPU —
        /// over the cap the tail is truncated with a log-once
        /// (mirrors Android's MAX_BAKED_INSTANCES; documented in
        /// payload-geometry-spec).
        private static let maxBakedInstances = 16384
        private static let facingShapes: Set<String> = [
            "polyline", "lineSegments", "billboard",
        ]

        /// A `{'v3':[…]}` list → native-space points (z-mirrored at
        /// the wire boundary, like every vertex source).
        func d3PointList(_ v: Any?) -> [SIMD3<Float>]? {
            guard let list = d3List(v) else { return nil }
            var out: [SIMD3<Float>] = []
            out.reserveCapacity(list.count)
            for e in list {
                guard let p = d3Vec3(e), p.count >= 3 else { return nil }
                out.append(SIMD3(Float(p[0]), Float(p[1]), Float(-p[2])))
            }
            return out
        }

        func d3ProfileList(_ v: Any?) -> [SIMD2<Float>]? {
            guard let list = d3List(v) else { return nil }
            var out: [SIMD2<Float>] = []
            out.reserveCapacity(list.count)
            for item in list {
                guard let point = d3Vec2(item), point.count >= 2 else {
                    return nil
                }
                out.append(SIMD2(Float(point[0]), Float(point[1])))
            }
            return out
        }

        /// A `{'c':[rgba]}` list → per-point colors.
        func d3ColorList(_ v: Any?) -> [SIMD4<Float>]? {
            guard let list = d3List(v) else { return nil }
            var out: [SIMD4<Float>] = []
            out.reserveCapacity(list.count)
            for e in list {
                guard let c = d3ColorComponents(e) else { return nil }
                out.append(SIMD4(Float(c[0]), Float(c[1]),
                                 Float(c[2]), Float(c[3])))
            }
            return out
        }

        /// A `{'d':x}` list → per-point widths.
        func d3FloatList(_ v: Any?) -> [Float]? {
            guard let list = d3List(v) else { return nil }
            var out: [Float] = []
            out.reserveCapacity(list.count)
            for e in list {
                guard let d = d3Double(e) else { return nil }
                out.append(Float(d))
            }
            return out
        }

        /// The parsed parameters of a camera-facing shape — retained
        /// so the per-frame pass can re-expand the vertex data toward
        /// the live camera basis. `facing` is the billboard mode
        /// (`spherical`/`axisY`/`screen`); validated at the call site.
        struct FacingParams {
            var points: [SIMD3<Float>] = []
            var colors: [SIMD4<Float>]?
            var widths: [Float]?
            var width: Float = 1
            var dashes: (Float, Float)?
            var closed = false
            var sizeX: Float = 1, sizeY: Float = 1
            var rotation: Float = 0
            var tint = SIMD4<Float>(1, 1, 1, 1)
            var facing = "spherical"
        }

        /// The billboard facing modes the wire recognizes — anything
        /// else warns once and reads as the `spherical` default.
        private static let facingModes: Set<String> = [
            "spherical", "axisY", "screen",
        ]

        /// Validates a wire `facing` value — unknown strings warn once
        /// and resolve to `spherical` (the D3BillboardProc default).
        func facingMode(_ key: UInt64, _ raw: String?) -> String {
            guard let raw else { return "spherical" }
            if Context.facingModes.contains(raw) { return raw }
            host.logOnce("facing.\(key).\(raw)",
                "d3 node \(key): unknown billboard facing '\(raw)'"
                    + " — using 'spherical'")
            return "spherical"
        }

        func parseFacing(_ p: [String: Any]) -> FacingParams {
            var fp = FacingParams()
            fp.points = d3PointList(p["points"]) ?? []
            fp.colors = d3ColorList(p["colors"])
            fp.widths = d3FloatList(p["widths"])
            fp.width = Float(d3Double(p["width"]) ?? 1)
            if let d = d3Vec2(p["dashes"]), d.count >= 2 {
                fp.dashes = (Float(d[0]), Float(d[1]))
            }
            fp.closed = d3Bool(p["closed"]) == true
            let s = d3Vec2(p["size"]) ?? [1, 1]
            fp.sizeX = Float(s[0]); fp.sizeY = Float(s[1])
            fp.rotation = Float(d3Double(p["rotation"]) ?? 0)
            if let c = d3ColorComponents(p["color"]) {
                fp.tint = SIMD4(Float(c[0]), Float(c[1]),
                                Float(c[2]), Float(c[3]))
            }
            fp.facing = d3String(p["facing"]) ?? "spherical"
            return fp
        }

        /// Builds a facing mesh for [shape] from [fp] expanded along
        /// the supplied basis — the decode-time call uses a neutral
        /// viewDir; the per-frame pass passes the live camera basis
        /// and node-local camera position.
        func facingMesh(
            _ shape: String, _ fp: FacingParams,
            viewDir: SIMD3<Float>,
            right: SIMD3<Float>, up: SIMD3<Float>,
            camPos: SIMD3<Float> = .zero
        ) -> GeometryFactory.MeshParts? {
            switch shape {
            case "polyline":
                if let (onLen, offLen) = fp.dashes {
                    return GeometryFactory.dashedPolyline(
                        fp.points, width: fp.width, viewDir: viewDir,
                        onLen: onLen, offLen: offLen,
                        colors: fp.colors, widths: fp.widths,
                        closed: fp.closed)
                }
                return GeometryFactory.polyline(
                    fp.points, width: fp.width, viewDir: viewDir,
                    colors: fp.colors, widths: fp.widths,
                    closed: fp.closed)
            case "lineSegments":
                return GeometryFactory.lineSegments(
                    fp.points, width: fp.width, viewDir: viewDir,
                    colors: fp.colors)
            case "billboard":
                return GeometryFactory.billboardQuad(
                    sizeX: fp.sizeX, sizeY: fp.sizeY,
                    rotation: fp.rotation, color: fp.tint,
                    right: right, up: up,
                    facing: fp.facing, camPos: camPos)
            default:
                return nil
            }
        }

        /// Wire fields the facing-shape expanders can't honor —
        /// logged once per node on EVERY path that parses a facing
        /// shape (procMesh component, procedural resource bake,
        /// d3:instances shape), not just the component.
        func warnFacingDrops(site: String, noun: String, key: UInt64,
                             shape: String, _ p: [String: Any],
                             _ fp: FacingParams) {
            if d3Bool(p["widthInPixels"]) == true {
                host.logOnce("\(site).\(key).widthInPixels",
                    "\(noun) \(key): widthInPixels is"
                        + " unsupported — `width` is world units")
            }
            if shape == "polyline", d3String(p["caps"]) != nil {
                host.logOnce("\(site).\(key).caps",
                    "\(noun) \(key): 'caps' is unsupported"
                        + " — line ends are butt")
            }
            if shape == "lineSegments", fp.points.count % 2 != 0 {
                host.logOnce("\(site).\(key).oddLineTail",
                    "\(noun) \(key): lineSegments got an"
                        + " odd point count — trailing point"
                        + " dropped")
            }
        }

        /**
         * `d3:procMesh` — one node, one procedural mesh built from the
         * component's `shape` + params. Camera-facing shapes register
         * a `FacingSpec` so the willRenderScene pass re-expands their
         * vertex data toward the live camera (SceneKit lines are
         * thin; thick lines ride ribbon quads).
         */
        /// Removes `geometry` from every material's consumer list.
        func dropMaterialConsumer(_ geometry: SCNGeometry) {
            for mk in materialConsumers.keys {
                materialConsumers[mk]?.removeAll { $0 === geometry }
            }
            dropShadowCatcherBindings(geometry)
        }

        func dropShadowCatcherBindings(_ geometry: SCNGeometry) {
            for key in shadowCatcherBindings.keys {
                shadowCatcherBindings[key]?.removeAll {
                    $0.geometry === geometry
                }
            }
        }

        func recordShadowCatcherBinding(
            key: UInt64,
            node: SCNNode,
            geometry: SCNGeometry,
            material: SCNMaterial,
            materialIndex: Int,
            isSnapshotClone: Bool
        ) {
            guard resourceDefs[key]?["type"] as? String == "shadowCatcher"
            else { return }
            let bindings = shadowCatcherBindings[key] ?? []
            if bindings.contains(where: {
                $0.geometry === geometry && $0.materialIndex == materialIndex
            }) { return }
            shadowCatcherBindings[key] = bindings + [
                ShadowCatcherMaterialBinding(
                    node: node, geometry: geometry, material: material,
                    materialIndex: materialIndex,
                    isSnapshotClone: isSnapshotClone)
            ]
        }

        func registerCurrentShadowCatcherConsumers(
            key: UInt64, previousMaterial: SCNMaterial
        ) {
            let consumerGeometryIds = Set(
                (materialConsumers[key] ?? []).map(ObjectIdentifier.init))
            guard !consumerGeometryIds.isEmpty else { return }
            scene.rootNode.enumerateHierarchy { targetNode, _ in
                guard let geometry = targetNode.geometry,
                      consumerGeometryIds.contains(ObjectIdentifier(geometry))
                else { return }
                let ownerNode: SCNNode
                let primitiveIndex: Int
                if let name = targetNode.name,
                   name.hasPrefix("d3prim:"),
                   let index = Int(name.dropFirst("d3prim:".count)),
                   let parent = targetNode.parent {
                    ownerNode = parent
                    primitiveIndex = index
                } else {
                    ownerNode = targetNode
                    primitiveIndex = 0
                }
                guard let nodeKey = host.nodesById.first(where: {
                    $0.value === ownerNode
                })?.key else { return }
                let hasVariantOwner = variantComponents.values.contains {
                    $0.bindings.contains {
                        $0.nodeKey == nodeKey
                            && $0.primitive == primitiveIndex
                    }
                }
                let hasActiveLodOwner = lods[nodeKey].map {
                    $0.ownsRenderable && !$0.suspended
                } ?? false
                guard !hasVariantOwner, !hasActiveLodOwner else { return }
                let isDoubleSidedInstance =
                    primitiveIndex == 0
                    && d3Bool(instancesProps[nodeKey]?["doubleSided"]) == true
                for (materialIndex, material) in geometry.materials.enumerated() {
                    let isSnapshotClone = material !== previousMaterial
                    guard material === previousMaterial
                        || (isDoubleSidedInstance
                            && materialIndex == 0 && isSnapshotClone)
                    else { continue }
                    recordShadowCatcherBinding(
                        key: key, node: targetNode, geometry: geometry,
                        material: material, materialIndex: materialIndex,
                        isSnapshotClone: isSnapshotClone)
                }
            }
        }

        func rebindShadowCatcherMaterial(_ key: UInt64,
                                        to material: SCNMaterial) {
            for binding in shadowCatcherBindings[key] ?? [] {
                guard let geometry = binding.geometry,
                      geometry.materials.indices.contains(binding.materialIndex),
                      geometry.materials[binding.materialIndex] === binding.material
                else { continue }
                let rebound: SCNMaterial
                if binding.isSnapshotClone {
                    rebound = material.copy() as! SCNMaterial
                    materialColorOwners[key]?.copyFactor(to: rebound)
                    rebound.isDoubleSided = binding.material.isDoubleSided
                } else {
                    rebound = material
                }
                var materials = geometry.materials
                materials[binding.materialIndex] = rebound
                geometry.materials = materials
                binding.material = rebound
            }
        }

        func refreshLiveCatcherMaterialReference(
            _ key: UInt64, old: SCNMaterial, new: SCNMaterial
        ) {
            for binding in shadowCatcherBindings[key] ?? []
            where !binding.isSnapshotClone && binding.material === old {
                binding.material = new
            }
        }

        func decodeProcMesh(key: UInt64, node: SCNNode,
                            _ p: [String: Any]) {
            guard let shape = d3String(p["shape"]) else {
                d3Log("d3:procMesh node \(key): missing shape")
                return
            }
            let facing = FsceneRealizer.Context.facingShapes.contains(shape)
            var fp = facing ? parseFacing(p) : nil
            if fp != nil {
                warnFacingDrops(site: "procMesh", noun: "d3:procMesh node",
                                key: key, shape: shape, p, fp!)
                fp!.facing = facingMode(key, fp!.facing)
            }
            let geometry: SCNGeometry?
            if let fpu = fp {
                geometry = facingMesh(shape, fpu,
                    viewDir: SIMD3(0, 0, 1),
                    right: SIMD3(1, 0, 0), up: SIMD3(0, 1, 0))
                    .map(GeometryFactory.makeGeometry)
            } else {
                geometry = procedural(key, shape, p)
            }
            guard let geometry else {
                d3Log("d3:procMesh node \(key): shape '\(shape)' failed")
                return
            }
            if let ref = d3Ref(p["material"]), let m = materials[ref] {
                geometry.materials = [m]
                recordShadowCatcherBinding(
                    key: ref, node: node, geometry: geometry,
                    material: m, materialIndex: 0,
                    isSnapshotClone: false)
                let existing = materialConsumers[ref] ?? []
                if !existing.contains(where: { $0 === geometry }) {
                    materialConsumers[ref] = existing + [geometry]
                }
            }
            if let old = node.geometry, old !== geometry {
                // A rebake/re-decode replaces the geometry — its
                // material-consumer entries go too, or every update
                // leaks a retained retired geometry that later
                // material upserts keep rebinding.
                dropMaterialConsumer(old)
                host.retire(old)
            }
            node.geometry = geometry
            if shape == "billboard" {
                node.castsShadow = geometry.firstMaterial?.name != "d3.sprite"
            }
            if let t = host.pendingColliderShapes.removeValue(forKey: key) {
                let s = derivedShape(node, t, "deferred")
                if let body = node.physicsBody, body.physicsShape == nil {
                    body.physicsShape = s
                }
                if let ccProps = host.pendingCharacterControllers.removeValue(forKey: key) {
                    let lm = host.colliderLayerMaskByKey[key]
                    decodeCharacterController(
                        key, node, ccProps,
                        collider: (shape: s, friction: nil, restitution: nil,
                                   layer: lm?.layer, mask: lm?.mask, trigger: false))
                }
            }
            if let fp {
                host.cameraFacing[key] = SceneViewHost.FacingSpec(
                    shape: shape, node: node,
                    points: fp.points, colors: fp.colors,
                    widths: fp.widths, width: fp.width,
                    dashes: fp.dashes, closed: fp.closed,
                    sizeX: fp.sizeX, sizeY: fp.sizeY,
                    rotation: fp.rotation, tint: fp.tint,
                    facing: fp.facing)
            }
        }

        /// Instance transforms: an inline `{'m4':[16]}` list or a
        /// `matrices` payload ref — each S·M·S mirrored into native
        /// space like every other transform crossing the wire.
        func d3InstanceTransforms(_ key: UInt64, _ p: [String: Any])
            -> [simd_float4x4]?
        {
            guard let t = p["transforms"] else { return nil }
            if let list = d3List(t) {
                var out: [simd_float4x4] = []
                out.reserveCapacity(list.count)
                for e in list {
                    guard let m = d3Mat4(e) else { return nil }
                    out.append(simd_float4x4(m))
                }
                return out
            }
            guard let ref = d3Ref(t) else { return nil }
            guard let bytes = host.payloadStore[ref], bytes.count % 64 == 0
            else {
                deferredResourceIds.insert(key)
                return nil
            }
            let n = bytes.count / 64
            return (0..<n).map { i in
                var m = [Double](repeating: 0, count: 16)
                for k in 0..<16 {
                    m[k] = Double(D3Wire.f32LE(
                        bytes, bytes.startIndex + i * 64 + k * 4))
                }
                return simd_float4x4(D3Wire.matrix(m))
            }
        }

        /// The `color` per-instance attribute — inline `{'v4':[…]}`
        /// list, a `floats` payload (4×f32 per instance), or a `bytes`
        /// payload (4×u8 normalized).
        func d3InstanceColors(_ key: UInt64, _ p: [String: Any])
            -> [SIMD4<Float>]?
        {
            guard let attrs = d3Map(p["attributes"]),
                  let color = attrs["color"] else { return nil }
            if let list = d3List(color) {
                var out: [SIMD4<Float>] = []
                for e in list {
                    guard let v = d3Vec4(e), v.count >= 4 else { return nil }
                    out.append(SIMD4(Float(v[0]), Float(v[1]),
                                     Float(v[2]), Float(v[3])))
                }
                return out
            }
            guard let ref = d3Ref(color),
                  let bytes = host.payloadStore[ref]
            else {
                if d3Ref(color) != nil { deferredResourceIds.insert(key) }
                return nil
            }
            if payloadSpecs[ref]?.encoding == "bytes" {
                return (0..<bytes.count / 4).map { i in
                    SIMD4(Float(bytes[bytes.startIndex + i * 4]) / 255,
                          Float(bytes[bytes.startIndex + i * 4 + 1]) / 255,
                          Float(bytes[bytes.startIndex + i * 4 + 2]) / 255,
                          Float(bytes[bytes.startIndex + i * 4 + 3]) / 255)
                }
            }
            return (0..<bytes.count / 16).map { i in
                SIMD4(
                    D3Wire.f32LE(bytes, bytes.startIndex + i * 16),
                    D3Wire.f32LE(bytes, bytes.startIndex + i * 16 + 4),
                    D3Wire.f32LE(bytes, bytes.startIndex + i * 16 + 8),
                    D3Wire.f32LE(bytes, bytes.startIndex + i * 16 + 12))
            }
        }

        /**
         * `d3:instances` — one node, one draw, N copies of a mesh.
         * SceneKit has no per-instance draw call on `SCNGeometry`, so
         * the instance data bakes into a single geometry: transforms
         * applied to the CPU vertex copies, per-instance `color`
         * stamped into the color stream (the W26 contract — same one
         * node/draw path as Android's baked renderable).
         * `billboard: true` swaps the mesh for camera-facing quads
         * re-faced per frame (FacingSpec).
         */
        func decodeInstances(key: UInt64, node: SCNNode,
                             _ p: [String: Any]) {
            guard var transforms = d3InstanceTransforms(key, p) else {
                d3Log("d3:instances node \(key): transforms unresolved")
                return
            }
            if transforms.count > Self.maxBakedInstances {
                host.logOnce("instances.\(key).countCap",
                    "d3:instances node \(key): \(transforms.count)"
                        + " instances exceeds the baked-instance cap"
                        + " \(Self.maxBakedInstances) — truncated")
                transforms = Array(transforms.prefix(Self.maxBakedInstances))
            }
            instancesProps[key] = p
            let colors = d3InstanceColors(key, p)
            let billboard = d3Bool(p["billboard"]) == true
            let s = d3Vec2(p["size"]) ?? [1, 1]
            let rotation = Float(d3Double(p["rotation"]) ?? 0)
            let facing = facingMode(key, d3String(p["facing"]))
            let doubleSided = d3Bool(p["doubleSided"]) == true
            // Precedence + wire-carried-but-unread fields — warned
            // once per node so the drops aren't silent.
            if billboard, p["shape"] != nil || p["geometry"] != nil {
                host.logOnce("instances.\(key).billboardPrecedence",
                    "d3:instances node \(key): 'billboard' overrides"
                        + " shape/geometry")
            }
            if !billboard, d3String(p["shape"]) != nil,
               p["geometry"] != nil {
                host.logOnce("instances.\(key).shapePrecedence",
                    "d3:instances node \(key): 'shape' and 'geometry'"
                        + " both present — 'shape' wins")
            }
            if let attrs = d3Map(p["attributes"]),
               attrs.keys.contains(where: { $0 != "color" }) {
                host.logOnce("instances.\(key).attrs",
                    "d3:instances node \(key): attr1–attr3 are carried"
                        + " on the wire but not rendered")
            }

            let parts: GeometryFactory.MeshParts?
            if billboard {
                let centers = transforms.map {
                    SIMD3<Float>($0.columns.3.x,
                                 $0.columns.3.y, $0.columns.3.z)
                }
                parts = GeometryFactory.bakeBillboardInstances(
                    centers, sizeX: Float(s[0]), sizeY: Float(s[1]),
                    rotation: rotation, colors: colors,
                    right: SIMD3(1, 0, 0), up: SIMD3(0, 1, 0),
                    facing: facing)
            } else {
                let shape = d3String(p["shape"])
                var base: GeometryFactory.MeshParts?
                if let shape, FsceneRealizer.Context.facingShapes.contains(shape) {
                    host.logOnce("instances.\(key).facingShape",
                        "d3:instances node \(key): facing shape '\(shape)'"
                            + " bakes once toward +Z")
                    var fp = parseFacing(p)
                    warnFacingDrops(site: "instances",
                                    noun: "d3:instances node",
                                    key: key, shape: shape, p, fp)
                    fp.facing = facing
                    base = facingMesh(shape, fp,
                        viewDir: SIMD3(0, 0, 1),
                        right: SIMD3(1, 0, 0), up: SIMD3(0, 1, 0))
                } else if let shape {
                    if let geo = procedural(key, shape, p) {
                        base = GeometryFactory.extractParts(geo)
                    }
                } else if let gk = d3Ref(p["geometry"]) {
                    var list = geometryConsumers[gk] ?? []
                    if !list.contains(where: { $0 === node }) {
                        list.append(node)
                        geometryConsumers[gk] = list
                    }
                    if let geo = geometries[gk] {
                        // `extractParts` drops skinning/morph streams —
                        // warn before they're silently lost (Android
                        // parity: instances.<key>.skinning/.morph).
                        if !geo.sources(for: .boneIndices).isEmpty ||
                           !geo.sources(for: .boneWeights).isEmpty {
                            host.logOnce("instances.\(key).skinning",
                                "d3:instances node \(key): skinned"
                                    + " geometry bakes unskinned —"
                                    + " joint/weight streams are"
                                    + " dropped")
                        }
                        if morphTargets[gk] != nil {
                            host.logOnce("instances.\(key).morph",
                                "d3:instances node \(key): morphed"
                                    + " geometry bakes unmorphed —"
                                    + " morph targets are dropped")
                        }
                        base = GeometryFactory.extractParts(geo)
                    }
                } else {
                    d3Log("d3:instances node \(key): needs geometry or shape")
                    return
                }
                guard let base else {
                    d3Log("d3:instances node \(key): geometry unresolved")
                    return
                }
                let keep = GeometryFactory.bakedInstanceCount(
                    transforms.count, baseVertexCount: base.vertexCount)
                if keep < transforms.count {
                    host.logOnce("instances.\(key).vertexCap",
                        "d3:instances node \(key): \(transforms.count)"
                            + " instances × \(base.vertexCount) base"
                            + " vertices exceeds the"
                            + " \(GeometryFactory.maxBakedVertices)-vertex"
                            + " bake budget — truncated to \(keep)")
                }
                parts = GeometryFactory.bakeInstances(
                    base, transforms, colors: colors)
            }
            guard let parts, !parts.indices.isEmpty else {
                d3Log("d3:instances node \(key): empty bake")
                return
            }
            let geometry = GeometryFactory.makeGeometry(parts)
            if let ref = d3Ref(p["material"]), let m = materials[ref] {
                // A component `doubleSided` can't ride the shared
                // material (every consumer would turn two-sided), so
                // the node binds a clone — a snapshot: surgical
                // updates to the source material after this bind
                // don't propagate (the payload-geometry contract doc
                // records the limitation).
                let bound: SCNMaterial
                var isSnapshotClone = false
                if doubleSided && !m.isDoubleSided,
                   let clone = m.copy() as? SCNMaterial {
                    materialColorOwners[ref]?.copyFactor(to: clone)
                    clone.isDoubleSided = true
                    bound = clone
                    isSnapshotClone = true
                } else {
                    bound = m
                }
                geometry.materials = [bound]
                recordShadowCatcherBinding(
                    key: ref, node: node, geometry: geometry,
                    material: bound, materialIndex: 0,
                    isSnapshotClone: isSnapshotClone)
                let existing = materialConsumers[ref] ?? []
                if !existing.contains(where: { $0 === geometry }) {
                    materialConsumers[ref] = existing + [geometry]
                }
            } else if doubleSided {
                // No material ref — the default material is shared, so
                // a fresh double-sided material stands in for it.
                let dm = SCNMaterial()
                dm.isDoubleSided = true
                geometry.materials = [dm]
            }
            if let old = node.geometry, old !== geometry {
                // A rebake/re-decode replaces the geometry — its
                // material-consumer entries go too, or every update
                // leaks a retained retired geometry that later
                // material upserts keep rebinding.
                dropMaterialConsumer(old)
                host.retire(old)
            }
            node.geometry = geometry
            if billboard {
                host.cameraFacing[key] = SceneViewHost.FacingSpec(
                    shape: "billboardInstances", node: node,
                    points: transforms.map {
                        SIMD3<Float>($0.columns.3.x,
                                     $0.columns.3.y, $0.columns.3.z)
                    },
                    colors: colors, widths: nil, width: 1,
                    dashes: nil, closed: false,
                    sizeX: Float(s[0]), sizeY: Float(s[1]),
                    rotation: rotation,
                    tint: SIMD4<Float>(1, 1, 1, 1),
                    facing: facing)
            }
        }

        func decodeMaterial(_ key: UInt64, _ r: [String: Any]) {
            materialColorOwners.removeValue(forKey: key)
            let m = SCNMaterial()
            let type = r["type"] as? String ?? "physicallyBased"
            if type == "shadowCatcher" {
                let props = r["properties"] as? [String: Any] ?? [:]
                let authoredMode = d3String(props["mode"])
                    ?? props["mode"] as? String ?? "live"
                let mode: ShadowCatcherConfiguration.Mode
                if authoredMode == "baked" {
                    mode = .baked
                    m.lightingModel = .constant
                    m.diffuse.contents = UIColor.clear
                    m.blendMode = .alpha
                    m.transparencyMode = .aOne
                    m.writesToDepthBuffer = true
                    m.readsFromDepthBuffer = true
                } else {
                    mode = .live
                    m.lightingModel = .shadowOnly
                    m.shaderModifiers = [.fragment: "#pragma transparent\n#pragma body\n"]
                    if authoredMode != "live" {
                        host.logOnce("w24.catcher.mode.\(authoredMode)",
                            "shadowCatcher mode '\(authoredMode)' unknown; "
                            + "using live")
                    }
                }
                let softness = d3Double(props["softness"])
                    ?? (props["softness"] as? NSNumber)?.doubleValue ?? 0
                shadowCatcherConfigurations[key] =
                    ShadowCatcherConfiguration(mode: mode,
                                               softness: softness)
                m.name = "d3.shadowCatcher:\(key)"
                if d3Bool(props["doubleSided"]) == true {
                    m.isDoubleSided = true
                }
                for field in ["shadowColor", "shadowIntensity",
                              "aoStrength", "fadeStart", "fadeEnd"]
                where props[field] != nil {
                    host.logOnce("w24.catcher.\(field)",
                        "shadowCatcher '\(field)' unsupported on "
                        + "SceneKit; captured RGBA values drive the "
                        + "baked footprint")
                }
                if mode == .live, props["softness"] != nil {
                    host.logOnce("w24.catcher.liveSoftness",
                        "shadowCatcher live softness unsupported on "
                        + "SceneKit's shadowOnly material")
                }
                materials[key] = m
                return
            }
            shadowCatcherConfigurations.removeValue(forKey: key)
            if type == "d3:sprite" {
                let props = r["properties"] as? [String: Any] ?? [:]
                let additive = d3String(props["blendMode"]) == "additive"
                m.name = "d3.sprite"
                m.lightingModel = .constant
                m.isDoubleSided = true
                m.readsFromDepthBuffer = true
                m.writesToDepthBuffer = false
                m.blendMode = additive ? .add : .alpha
                // SceneKit's .add also adds alpha; preserve destination coverage.
                m.colorBufferWriteMask = additive ? [.red, .green, .blue] : .all
                m.transparencyMode = .aOne
                m.diffuse.contents = UIColor.white
                let tint = d3ColorComponents(props["baseColor"])
                    ?? [1, 1, 1, 1]
                materialColorOwners[key] = MaterialColorOwner(m, color: tint,
                    sprite: true, supportsAnimation: true)
                m.setValue(0.0, forKey: "d3SpriteSourcePremultiplied")
                // SceneKit's transparent modifier requires premultiplied RGB.
                m.shaderModifiers = [.geometry: """
                    #pragma varyings
                    float4 d3SpriteColor;
                    #pragma body
                    out.d3SpriteColor = _geometry.color;
                    _geometry.color = float4(1.0);
                    """, .fragment: """
                    #pragma arguments
                    float4 d3SpriteTint;
                    float d3SpriteSourcePremultiplied;
                    #pragma transparent
                    #pragma body
                    float4 d3SampledSpriteColor = _surface.diffuse * d3SpriteTint
                        * in.d3SpriteColor;
                    float weight = d3SpriteSourcePremultiplied > 0.5
                        ? d3SpriteTint.a * in.d3SpriteColor.a : d3SampledSpriteColor.a;
                    _output.color = float4(d3SampledSpriteColor.rgb * weight, d3SampledSpriteColor.a);
                    """]
                if props["baseColorTexture"] != nil {
                    applyTextureSlot(m, materialKey: key,
                                     slot: "baseColorTexture")
                }
                warnUnhandledMaterialProps(key, props)
                materials[key] = m
                return
            }
            m.lightingModel = type == "unlit"
                ? .constant : .physicallyBased
            let props = r["properties"] as? [String: Any] ?? [:]
            m.diffuse.contents = UIColor.white
            if let v = d3Double(props["metallic"]) {
                m.metalness.contents = NSNumber(value: v)
            }
            if let v = d3Double(props["roughness"]) {
                m.roughness.contents = NSNumber(value: v)
            }
            if let v = d3Double(props["emissiveStrength"]) {
                m.emission.intensity = CGFloat(v)
            }
            if let c = d3Color(props["emissive"]) { m.emission.contents = c }
            if d3Bool(props["doubleSided"]) == true { m.isDoubleSided = true }
            // W21: glTF alphaMode (wire values are lowercase
            // 'opaque|mask|blend'; compared case-insensitively).
            // `blend` puts the material in SceneKit's alpha-blended
            // transparent pass with depth writes OFF — a blended
            // surface that writes depth occludes the surfaces sorted
            // behind it and visibly disappears; depth reads stay on
            // so it still hides behind opaque geometry.
            // `mask` is a true alpha test: SCNTransparencyMode has no
            // alpha-test mode (.aOne/.rgbZero pick a transparency
            // source, they don't discard), so a `.fragment` shader
            // modifier drops texels below `alphaCutoff` and pins the
            // survivors to a=1 — a mask is binary-opaque where it
            // survives even if the material still lands in the blend
            // pass on texture-alpha contents.
            let alphaMode = d3String(props["alphaMode"])
                ?? (props["alphaMode"] as? String)
            switch (alphaMode ?? "opaque").lowercased() {
            case "opaque":
                // glTF OPAQUE ignores source alpha entirely. SceneKit's
                // default `.alpha` blendMode would composite contents
                // alpha, so a semi-alpha texture on an opaque material
                // renders translucent — `.replace` writes the shaded
                // color as-is and keeps the material out of the blend
                // pass.
                m.blendMode = .replace
            case "blend":
                m.blendMode = .alpha
                m.transparencyMode = .aOne
                m.writesToDepthBuffer = false
                m.readsFromDepthBuffer = true
            case "mask":
                let cutoff = d3Double(props["alphaCutoff"])
                    ?? (props["alphaCutoff"] as? NSNumber)?.doubleValue
                    ?? 0.5
                m.shaderModifiers = [
                    .fragment: String(format:
                        "if (_output.color.a < %.6f) "
                        + "{ discard_fragment(); }\n"
                        + "_output.color.a = 1.0;", cutoff)
                ]
            default:
                // Forward-compatible/unknown mode → opaque, and opaque
                // means `.replace` (the explicit case's reasoning): the
                // default `.alpha` would still composite source alpha.
                m.blendMode = .replace
                host.logOnce("material.\(key).alphaMode.\(alphaMode ?? "?")",
                    "material \(key): unknown alphaMode "
                    + "'\(alphaMode ?? "?")'; kept opaque")
            }
            for slot in ["baseColorTexture", "metallicRoughnessTexture",
                         "normalTexture", "occlusionTexture",
                         "emissiveTexture"]
            where props[slot] != nil {
                applyTextureSlot(m, materialKey: key, slot: slot)
            }
            // W22: KHR_materials_* — clearcoat maps onto SceneKit's
            // real coat inputs (`clearCoat`/`clearCoatRoughness`/
            // `clearCoatNormal` — PBR properties since iOS 13); sheen
            // gets a `.fragment` shader-modifier fresnel rim; the rest
            // lands on its nearest documented approximation (each logs
            // once). `unlit` skips extensions the way the importer
            // drops them.
            if type != "unlit" {
                decodeMaterialExtensions(m, key, props,
                    alphaBlended: (alphaMode ?? "opaque").lowercased() == "blend")
                for slot in ["clearcoatTexture",
                             "clearcoatRoughnessTexture",
                             "clearcoatNormalTexture",
                             "sheenColorTexture",
                             "sheenRoughnessTexture",
                             "transmissionTexture"]
                where props[slot] != nil {
                    applyTextureSlot(m, materialKey: key, slot: slot)
                }
            }
            var modifiers = m.shaderModifiers ?? [:]
            modifiers[.surface] = """
                #pragma arguments
                float4 d3BaseColorFactor;
                #pragma body
                _surface.diffuse *= d3BaseColorFactor;
                """ + "\n" + (modifiers[.surface] ?? "")
            if (alphaMode ?? "opaque").lowercased() == "blend" {
                let fragment = modifiers[.fragment] ?? ""
                modifiers[.fragment] = "#pragma transparent\n" + fragment
            }
            m.shaderModifiers = modifiers
            materialColorOwners[key] = MaterialColorOwner(m,
                color: d3ColorComponents(props["baseColor"]) ?? [1, 1, 1, 1],
                sprite: false, supportsAnimation: type == "physicallyBased" || type == "unlit")
            warnUnhandledMaterialProps(key, props)
            materials[key] = m
        }

        /// W22 KHR_materials_* realization under SceneKit's PBR model.
        /// Clearcoat is REALIZED — `clearCoat`/`clearCoatRoughness`/
        /// `clearCoatNormal` are real `.physicallyBased` inputs (SCN-
        /// Material properties since iOS 13, in Apple's PBR set — NOT
        /// on its `reflective`/`specular`/`ambient`/`shininess`/
        /// `fresnelExponent` ignore list). Sheen is approximated
        /// post-lighting in a `.fragment` shader modifier — a fresnel
        /// rim — with its textures bound into the modifier as
        /// `texture2d` arguments (SCNShadable binds `texture2d` args
        /// from SCNMaterialProperty values set via KVC). Transmission
        /// keeps the thin-blend `transparent` approximation. What
        /// still can't map gets one per-material log naming the drop —
        /// the conformance matrix's `approx` rows are these messages.
        ///
        /// W22-r4: the round-3 `reflective`/`fresnelExponent` writes
        /// were inert — `.physicallyBased` ignores both (documented),
        /// so the approximations logged honestly but produced no
        /// pixels. The `reflectiveClaimed` slot arbitration is gone:
        /// coat and sheen live on separate mechanisms now and combine
        /// freely on one material.
        func decodeMaterialExtensions(_ m: SCNMaterial, _ key: UInt64,
                                      _ props: [String: Any], alphaBlended: Bool) {
            // KHR_materials_clearcoat → the real coat lobe. Factor
            // contents here are the texture-absent values; the texture
            // slots bind in applyTextureSlot (R×factor → clearCoat,
            // G×factor → clearCoatRoughness, rgb → clearCoatNormal).
            let coat = d3Double(props["clearcoat"]) ?? 0
            let hasTransmission = (d3Double(props["transmission"]) ?? 0)
                > 0 || d3Ref(props["transmissionTexture"]) != nil
            if coat > 0 || d3Ref(props["clearcoatTexture"]) != nil {
                m.clearCoat.contents = UIColor(white: coat, alpha: 1)
            }
            if let cr = d3Double(props["clearcoatRoughness"]) {
                m.clearCoatRoughness.contents = NSNumber(value: cr)
            }
            // sheen → post-lighting fresnel rim via a `.fragment`
            // shader modifier — `.physicallyBased` has no sheen lobe.
            // rim = pow(1 − saturate(N·V), e) · tint, added after
            // lighting; sheenRoughness maps to e — smoother sheen →
            // tighter rim (e up), rougher → broader (the r3 comment
            // had the direction backwards). Bound sheen textures
            // become texture2d arguments sampled at the diffuse uv —
            // a uniform-bound texture can't carry a contentsTransform,
            // so `<slot>Transform` on sheen drops (applyTextureSlot
            // logs). Divergence from a true sheen lobe, documented:
            // the rim is view-dependent only — no light response, and
            // it adds energy rather than shading what's underneath.
            let sheen = d3ColorComponents(props["sheenColor"])
            let sheenColorTex = d3Ref(props["sheenColorTexture"]) != nil
            let sheenRoughTex =
                d3Ref(props["sheenRoughnessTexture"]) != nil
            let sheenOn =
                (sheen.map { $0[0] + $0[1] + $0[2] > 0 } ?? false)
                || sheenColorTex || sheenRoughTex
            if sheenOn {
                let c = sheen ?? [1, 1, 1, 1]
                let rough = d3Double(props["sheenRoughness"]) ?? 0
                var decl = ""
                var texBody = ""
                if sheenColorTex {
                    decl += "texture2d d3SheenColorTex;\n"
                    texBody += "tint *= d3SheenColorTex.sample("
                        + "d3SheenS, _surface.diffuseTexcoord).rgb;\n"
                }
                if sheenRoughTex {
                    decl += "texture2d d3SheenRoughTex;\n"
                    texBody += "rough *= d3SheenRoughTex.sample("
                        + "d3SheenS, _surface.diffuseTexcoord).a;\n"
                }
                var body = String(format:
                    "float3 tint = float3(%.6f, %.6f, %.6f);\n"
                    + "float rough = %.6f;\n", c[0], c[1], c[2], rough)
                    + texBody
                    + "float rim = pow(1.0 - saturate(dot("
                    + "normalize(_surface.normal),"
                    + " normalize(_surface.view))),"
                    + " 1.0 + (1.0 - saturate(rough)) * 3.0);\n"
                    + "_output.color.rgb += tint * rim"
                    + (alphaBlended ? " * _output.color.a;" : ";")
                if !decl.isEmpty {
                    body = "constexpr sampler d3SheenS(filter::linear,"
                        + " mip_filter::linear, address::repeat);\n"
                        + body
                }
                // Merge with the mask-alpha modifier when both apply —
                // `#pragma arguments`/`#pragma body` lead the combined
                // source; the mask snippet carries no pragmas.
                let prior = m.shaderModifiers?[.fragment] ?? ""
                var mods = m.shaderModifiers ?? [:]
                mods[.fragment] = decl.isEmpty
                    ? prior + "\n" + body
                    : "#pragma arguments\n" + decl + "#pragma body\n"
                        + prior + "\n" + body
                m.shaderModifiers = mods
                host.logOnce("material.\(key).sheen",
                    "material \(key): sheen → fresnel rim in a "
                    + ".fragment shader modifier (no sheen lobe — "
                    + "view-dependent rim, not a light-responding "
                    + "lobe)"
                    + (sheenColorTex || sheenRoughTex
                        ? "; sheen textures bind as modifier args "
                          + "sampling the diffuse uv (slot transforms "
                          + "drop)"
                        : ""))
            }
            // specular → no dielectric-F0 lever under .physicallyBased.
            let spec = d3Double(props["specular"]) ?? 1
            let specColor = d3ColorComponents(props["specularColor"])
            if spec != 1
                || (specColor.map {
                    $0[0] != 1 || $0[1] != 1 || $0[2] != 1 } ?? false)
                || d3Ref(props["specularTexture"]) != nil
                || d3Ref(props["specularColorTexture"]) != nil {
                host.logOnce("material.\(key).specular",
                    "material \(key): KHR_materials_specular has no "
                    + "dielectric-F0 lever under .physicallyBased — "
                    + "dropped")
            }
            if (d3Double(props["anisotropy"]) ?? 0) != 0
                || d3Ref(props["anisotropyTexture"]) != nil {
                host.logOnce("material.\(key).anisotropy",
                    "material \(key): anisotropy has no SceneKit lobe "
                    + "— dropped")
            }
            if (d3Double(props["iridescence"]) ?? 0) > 0
                || d3Ref(props["iridescenceTexture"]) != nil
                || d3Ref(props["iridescenceThicknessTexture"]) != nil {
                host.logOnce("material.\(key).iridescence",
                    "material \(key): iridescence has no SceneKit "
                    + "input — dropped")
            }
            // transmission → thin-blend approximation: the surface
            // joins the alpha pass and `transparent` carries
            // alpha = 1 − transmission (the texture path bakes it
            // per-texel in applyTextureSlot). No refraction, so the
            // volume lobe (thickness/attenuation) drops with it.
            if hasTransmission {
                host.logOnce("material.\(key).transmission",
                    "material \(key): transmission → alpha-blend "
                    + "approximation via `transparent` (no refraction "
                    + "or volume)")
                m.blendMode = .alpha
                m.transparencyMode = .aOne
                m.writesToDepthBuffer = false
                m.readsFromDepthBuffer = true
                if d3Ref(props["transmissionTexture"]) == nil {
                    let trans = d3Double(props["transmission"]) ?? 0
                    m.transparent.contents = UIColor(
                        white: 1, alpha: CGFloat(1 - trans))
                }
            }
            let thick = d3Double(props["thickness"]) ?? 0
            if thick > 0 || d3Ref(props["thicknessTexture"]) != nil
                || props["attenuationColor"] != nil
                || props["attenuationDistance"] != nil {
                host.logOnce("material.\(key).volume",
                    hasTransmission
                    ? "material \(key): volume thickness/attenuation "
                        + "drop with the refraction approximation"
                    : "material \(key): volume props without "
                        + "transmission are inert — dropped")
            }
            if (d3Double(props["dispersion"]) ?? 0) != 0 {
                host.logOnce("material.\(key).dispersion",
                    "material \(key): dispersion has no SceneKit "
                    + "input — dropped")
            }
            if let ior = d3Double(props["ior"]), ior != 1.5 {
                host.logOnce("material.\(key).ior",
                    "material \(key): KHR_materials_ior=\(ior) has no "
                    + "IOR lever — dropped")
            }
            if (d3Double(props["diffuseTransmission"]) ?? 0) > 0
                || d3Ref(props["diffuseTransmissionTexture"]) != nil
                || d3Ref(props["diffuseTransmissionColorTexture"])
                    != nil {
                host.logOnce("material.\(key).diffuseTransmission",
                    "material \(key): diffuse transmission has no "
                    + "SceneKit input — dropped")
            }
        }

        /// Every wire property name material decode claims — the
        /// pre-W22 vocabulary plus the extension set (mapped or
        /// logged). `<slot>Transform` rides its base slot. Anything
        /// else warn-onces as unhandled — the conformance matrix's
        /// `warn` row.
        static let handledMaterialProps: Set<String> = [
            "baseColor", "baseColorTexture", "blendMode",
            "metallic", "roughness", "metallicRoughnessTexture",
            "normalTexture", "normalScale",
            "occlusionTexture", "occlusionStrength",
            "emissive", "emissiveStrength", "emissiveTexture",
            "doubleSided", "alphaMode", "alphaCutoff",
            "clearcoat", "clearcoatRoughness", "clearcoatTexture",
            "clearcoatRoughnessTexture", "clearcoatNormalTexture",
            "clearcoatNormalScale",
            "sheenColor", "sheenRoughness",
            "sheenColorTexture", "sheenRoughnessTexture",
            "specular", "specularColor",
            "specularTexture", "specularColorTexture",
            "anisotropy", "anisotropyRotation", "anisotropyTexture",
            "iridescence", "iridescenceIor",
            "iridescenceThicknessMinimum",
            "iridescenceThicknessMaximum", "iridescenceTexture",
            "iridescenceThicknessTexture",
            "transmission", "transmissionTexture",
            "thickness", "thicknessTexture",
            "attenuationColor", "attenuationDistance",
            "dispersion", "ior",
            "diffuseTransmission", "diffuseTransmissionColor",
            "diffuseTransmissionTexture",
            "diffuseTransmissionColorTexture",
        ]

        func warnUnhandledMaterialProps(_ key: UInt64,
                                        _ props: [String: Any]) {
            for name in props.keys {
                let base = name.hasSuffix("Transform")
                    ? String(name.dropLast("Transform".count)) : name
                if !Self.handledMaterialProps.contains(base) {
                    host.logOnce("material.\(key).unhandled.\(name)",
                        "material \(key): unhandled property '\(name)'")
                }
            }
        }

        func applyTextureSlot(_ m: SCNMaterial, materialKey: UInt64,
                              slot: String) {
            let props = (resourceDefs[materialKey]?["properties"]
                         as? [String: Any]) ?? [:]
            guard let texKey = d3Ref(props[slot]) else { return }
            var list = textureConsumers[texKey] ?? []
            if !list.contains(where: {
                $0.material === m && $0.slot == slot
            }) {
                list.append(TextureBinding(
                    material: m, materialKey: materialKey, slot: slot))
                textureConsumers[texKey] = list
            }
            if m.name == "d3.sprite", slot == "baseColorTexture" {
                m.setValue(renderTargets[texKey] == nil ? 0.0 : 1.0,
                           forKey: "d3SpriteSourcePremultiplied")
                if let rt = renderTargets[texKey] {
                    applyRenderTextureSlot(m, rt: rt, slot: slot)
                } else {
                    if let tex = textures[texKey] {
                        bindTextureContents(m.diffuse, tex: tex, baked: nil,
                            logKey: "material.\(materialKey).sprite.mips")
                    } else {
                        m.diffuse.contents = UIColor.white
                    }
                    m.diffuse.minificationFilter = .linear
                    m.diffuse.magnificationFilter = .linear
                    m.diffuse.wrapS = .clamp
                    m.diffuse.wrapT = .clamp
                }
                applyContentsTransform(m.diffuse,
                    props["baseColorTextureTransform"],
                    materialKey: materialKey, slot: slot)
                return
            }
            // W14: a renderTexture ref binds the live color texture —
            // the slot samples whatever the offscreen passes last drew.
            // A renderTexture def without a live rec (failed decode)
            // falls through to the image path → factor-only fallback.
            if let rt = renderTargets[texKey] {
                applyRenderTextureSlot(m, rt: rt, slot: slot)
                return
            }
            let tex = textures[texKey]
            let transform = props["\(slot)Transform"]
            switch slot {
            case "baseColorTexture":
                if let tex {
                    bindTextureContents(
                        m.diffuse, tex: tex,
                        baked: nil,
                        logKey: "material.\(materialKey).diffuse.mips")
                    applyContentsTransform(
                        m.diffuse, transform, materialKey: materialKey,
                        slot: slot)
                } else {
                    m.diffuse.contents = UIColor.white
                }
            case "metallicRoughnessTexture":
                if let tex {
                    let mf = d3Double(props["metallic"]) ?? 0.0
                    let rf = d3Double(props["roughness"]) ?? 0.5
                    let (metal, rough) = splitMetallicRoughness(
                        tex, metallic: mf, roughness: rf)
                    // A failed split keeps the factor-only contents.
                    m.metalness.contents = metal ?? NSNumber(value: mf)
                    m.roughness.contents = rough ?? NSNumber(value: rf)
                    applyContentsTransform(
                        m.metalness, transform, materialKey: materialKey,
                        slot: slot)
                    applyContentsTransform(
                        m.roughness, transform, materialKey: materialKey,
                        slot: slot)
                } else {
                    m.metalness.contents = d3Double(props["metallic"])
                        .map { NSNumber(value: $0) }
                    m.roughness.contents = d3Double(props["roughness"])
                        .map { NSNumber(value: $0) }
                }
            case "normalTexture":
                // W21: upstream ships renormalized mips for normal
                // maps — a box-filtered mip shrinks average normal
                // length, softening the map at distance. SceneKit
                // generates its own chain and can't steer it, so the
                // chain is built CPU-side with renormalized texels
                // and bound as an MTLTexture. Falls back to the plain
                // image (SceneKit's unrenormalized mips) when pixels
                // or Metal are unavailable — `renormalizedNormalMips`
                // logs once per cause.
                m.normal.contents = tex.flatMap {
                    $0.mtlTexture
                        ?? renormalizedNormalMips($0, materialKey: materialKey)
                } ?? tex?.contents
                if tex != nil {
                    m.normal.mipFilter = .linear
                    applyContentsTransform(
                        m.normal, transform, materialKey: materialKey,
                        slot: slot)
                }
                if let v = d3Double(props["normalScale"]) {
                    m.normal.intensity = CGFloat(v)
                }
            case "occlusionTexture":
                m.ambientOcclusion.contents = tex?.contents
                if tex != nil {
                    applyContentsTransform(
                        m.ambientOcclusion, transform,
                        materialKey: materialKey, slot: slot)
                }
                if let v = d3Double(props["occlusionStrength"]) {
                    m.ambientOcclusion.intensity = CGFloat(v)
                }
            case "emissiveTexture":
                let strength = d3Double(props["emissiveStrength"])
                if let tex {
                    // The emissive factor default is black — a lone
                    // emissiveTexture emits nothing (glTF semantics).
                    let fc = d3ColorComponents(props["emissive"])
                        ?? [0, 0, 0, 1]
                    if fc[0] == fc[1] && fc[1] == fc[2] {
                        // A grey factor is a scalar: bind the texture
                        // unbaked and carry the factor in the
                        // property's intensity (exact — SceneKit
                        // multiplies contents by it). Skips a CPU
                        // factor × texture bake per decode, which made
                        // a live emissive re-send (the P4 hero's
                        // breath) cost ~100s of ms per material.
                        bindTextureContents(
                            m.emission, tex: tex, baked: nil,
                            logKey: "material.\(materialKey).emission.mips")
                        m.emission.intensity = CGFloat(fc[0] * (strength ?? 1))
                    } else {
                        bindTextureContents(
                            m.emission, tex: tex,
                            baked: bakeFactor(tex, color: fc, rgbOnly: true),
                            logKey: "material.\(materialKey).emission.mips")
                        if let strength {
                            m.emission.intensity = CGFloat(strength)
                        }
                    }
                    applyContentsTransform(
                        m.emission, transform, materialKey: materialKey,
                        slot: slot)
                } else {
                    m.emission.contents = d3Color(props["emissive"])
                    if let strength {
                        m.emission.intensity = CGFloat(strength)
                    }
                }
            // W22-r4 extension slots. clearcoat is REAL — the textures
            // bind SceneKit's `clearCoat` inputs with the same
            // channel-split/factor-bake rules as the base slots
            // (glTF: coat intensity in R, coat roughness in G).
            // Sheen textures bind into the `.fragment` rim modifier as
            // `texture2d` arguments via `setValue(_:forKey:)` — the
            // modifier multiplies them by the factor literals it
            // baked at decode, so an unresolved texture binds a
            // neutral 1×1 (factor-only) until the upsert rebind.
            // transmission keeps the thin-blend `transparent` bake.
            case "clearcoatTexture":
                let f = d3Double(props["clearcoat"]) ?? 0
                if let tex {
                    m.clearCoat.contents =
                        channelGray(tex, channel: 0, factor: f)
                        ?? UIColor(white: f, alpha: 1)
                    applyContentsTransform(
                        m.clearCoat, transform,
                        materialKey: materialKey, slot: slot)
                } else {
                    m.clearCoat.contents = UIColor(white: f, alpha: 1)
                }
            case "clearcoatRoughnessTexture":
                let f = d3Double(props["clearcoatRoughness"]) ?? 0
                if let tex {
                    m.clearCoatRoughness.contents =
                        channelGray(tex, channel: 1, factor: f)
                        ?? NSNumber(value: f)
                    applyContentsTransform(
                        m.clearCoatRoughness, transform,
                        materialKey: materialKey, slot: slot)
                } else {
                    m.clearCoatRoughness.contents = NSNumber(value: f)
                }
            case "clearcoatNormalTexture":
                // The coat normal binds like `occlusionTexture` — raw
                // contents, no renormalized-mip pass (the base
                // normal's chain builder is normal-specific; SceneKit
                // generates this slot's own chain).
                m.clearCoatNormal.contents = tex?.contents
                if let tex {
                    if tex.mtlTexture != nil {
                        m.clearCoatNormal.mipFilter = .linear
                    }
                    applyContentsTransform(
                        m.clearCoatNormal, transform,
                        materialKey: materialKey, slot: slot)
                }
                // The wire sends the scale as a duplicated v2
                // (xy-pair convention); the property's scalar
                // `intensity` takes .x. A scale without the map is
                // inert — glTF agrees.
                if let s = d3Vec2(props["clearcoatNormalScale"])?.first
                        ?? d3Double(props["clearcoatNormalScale"]) {
                    m.clearCoatNormal.intensity = CGFloat(s)
                }
            case "sheenColorTexture", "sheenRoughnessTexture":
                // Bound into the rim modifier as a texture2d argument
                // (declared there iff this slot was referenced, so the
                // key always has a declared arg). A transform on a
                // uniform-bound texture can't reach a texcoord — the
                // modifier samples the diffuse uv; log the drop.
                let arg = slot == "sheenColorTexture"
                    ? "d3SheenColorTex" : "d3SheenRoughTex"
                if props["\(slot)Transform"] != nil {
                    host.logOnce("material.\(materialKey).\(slot).xform",
                        "material \(materialKey): \(slot)Transform "
                        + "drops — modifier-bound textures sample the "
                        + "diffuse uv channel")
                }
                if let contents = tex?.contents {
                    m.setValue(SCNMaterialProperty(contents: contents),
                               forKey: arg)
                } else {
                    m.setValue(neutralTexProperty(), forKey: arg)
                }
            case "transmissionTexture":
                let f = d3Double(props["transmission"]) ?? 0
                if let tex {
                    m.transparent.contents =
                        transmissionAlpha(tex, factor: f)
                        ?? UIColor(white: 1, alpha: CGFloat(1 - f))
                    applyContentsTransform(
                        m.transparent, transform,
                        materialKey: materialKey, slot: slot)
                } else {
                    m.transparent.contents = UIColor(
                        white: 1, alpha: CGFloat(1 - f))
                }
            default:
                break
            }
        }

        /// Binds a texture's contents on `prop` (W21). An unbaked
        /// bind takes `tex.contents` — the MTLTexture when one was
        /// uploaded (a KTX2 decode, or the sRGB renormalized mip
        /// chain `color` contents get) so the GPU chain is what
        /// samples. A `baked` factor×texture image re-uploads
        /// through `mipRenormalizedTexture` so the slot keeps the
        /// renorm semantic; a failed upload keeps the UIImage and
        /// SceneKit's own chain. `mipFilter` pins `.linear` whenever
        /// a GPU chain backs the slot (a mipmapped MTLTexture with
        /// `mipFilter == .none` would alias at distance).
        func bindTextureContents(_ prop: SCNMaterialProperty,
                                 tex: DecodedTexture, baked: UIImage?,
                                 logKey: String) {
            if let baked {
                prop.contents = mipRenormalizedTexture(
                    baked, srgb: tex.content == "color",
                    logKey: logKey) ?? baked
                prop.mipFilter = .linear
            } else {
                prop.contents = tex.contents
                if tex.mtlTexture != nil { prop.mipFilter = .linear }
            }
        }

        func applyRenderTextureSlot(_ m: SCNMaterial,
                                    rt: RenderTargetRec, slot: String) {
            // Sheen textures live in the rim modifier's texture2d
            // args, not material slots — bind the live color texture
            // through KVC. The modifier's constexpr sampler is fixed
            // (linear/repeat), so the rt's filter/wrap can't apply.
            if slot == "sheenColorTexture" || slot == "sheenRoughnessTexture" {
                m.setValue(
                    SCNMaterialProperty(contents: rt.colorTex),
                    forKey: slot == "sheenColorTexture"
                        ? "d3SheenColorTex" : "d3SheenRoughTex")
                return
            }
            let props: [SCNMaterialProperty]
            switch slot {
            case "baseColorTexture":         props = [m.diffuse]
            case "metallicRoughnessTexture":
                props = [m.metalness, m.roughness]
            case "normalTexture":            props = [m.normal]
            case "occlusionTexture":         props = [m.ambientOcclusion]
            case "emissiveTexture":          props = [m.emission]
            // W22-r4: clearcoat slots are real properties — the rt
            // path can bind them like the base slots.
            case "clearcoatTexture":         props = [m.clearCoat]
            case "clearcoatRoughnessTexture":
                props = [m.clearCoatRoughness]
            case "clearcoatNormalTexture":   props = [m.clearCoatNormal]
            default:                         props = []
            }
            let f: SCNFilterMode =
                rt.filter == "nearest" ? .nearest : .linear
            let w: SCNWrapMode
            switch rt.wrap {
            case "repeat": w = .repeat
            case "mirror": w = .mirror
            default: w = .clamp   // 'clampToEdge' (+ decode-normalized)
            }
            for p in props {
                p.contents = rt.colorTex
                p.minificationFilter = f
                p.magnificationFilter = f
                p.wrapS = w
                p.wrapT = w
            }
        }

        /// KHR_texture_transform → `contentsTransform`: the glTF uv is
        /// `uv' = offset + Rz(rotation)·scale ⊙ uv` (offset applied
        /// after scale+rotation). `SCNMatrix4` uses the row-vector
        /// convention — `SCNMatrix4Mult(a, b)` applies `a` first — so
        /// the chain is scale → rotate → translate, built left to
        /// right. `texCoord` selects the UV set: `mappingChannel` N
        /// samples the geometry's Nth `.texcoord` source (uv1-carrying
        /// layouts land one — `decodeVertexPayload`). The wire tops
        /// out at two sets, so `texCoord` ≥ 2 can't resolve today; it
        /// is passed through unclamped rather than silently sampled as
        /// uv0, and logged once.
        func applyContentsTransform(
            _ prop: SCNMaterialProperty, _ any: Any?,
            materialKey: UInt64, slot: String
        ) {
            guard let tm = d3Map(any) ?? (any as? [String: Any])
            else { return }
            let offset = d3Vec2(tm["offset"]) ?? [0, 0]
            let scale = d3Vec2(tm["scale"]) ?? [1, 1]
            let rotation = d3Double(tm["rotation"])
                ?? (tm["rotation"] as? NSNumber)?.doubleValue ?? 0
            let texCoord = d3Int(tm["texCoord"])
                ?? (tm["texCoord"] as? NSNumber)?.intValue ?? 0
            if texCoord >= 2 {
                host.logOnce("material.\(materialKey).\(slot).texCoord",
                    "material \(materialKey) \(slot): texCoord \(texCoord) "
                    + "exceeds the wire's two UV sets — passed through; "
                    + "a geometry without that UV set won't resolve it")
            }
            prop.mappingChannel = texCoord
            var t = SCNMatrix4MakeScale(Float(scale[0]), Float(scale[1]), 1)
            t = SCNMatrix4Mult(
                t, SCNMatrix4MakeRotation(Float(rotation), 0, 0, 1))
            t = SCNMatrix4Mult(
                t, SCNMatrix4MakeTranslation(
                    Float(offset[0]), Float(offset[1]), 0))
            prop.contentsTransform = t
        }

        /// Realizes one `texture` resource. A `payload` source resolves
        /// against `payloadStore` by the spec's `format`: `rgba8` wraps
        /// the raw bytes in a CGImage (dims from the payload spec),
        /// `ktx2` goes through `decodeKTX2` (W21 — MTKTextureLoader or
        /// the in-tree non-supercompressed upload; BasisU warns once),
        /// and anything else — png/jpg or an absent format — goes
        /// through `UIImage`'s container sniffing. A `ref` source loads
        /// from the asset catalog, then the main bundle. `color`
        /// contents also get a GPU upload carrying a renormalized mip
        /// chain (`mipRenormalizedTexture`, W21). A payload whose bytes
        /// haven't landed defers (re-realized when they do); malformed
        /// content logs once and leaves the slot empty — the material
        /// keeps its factor-only fallback.
        func decodeTexture(_ key: UInt64, _ r: [String: Any]) {
            let started = DispatchTime.now().uptimeNanoseconds
            let content = r["content"] as? String ?? "color"
            if r["payload"] != nil {
                guard let token = r["payload"] as? String,
                      let pid = D3Wire.localIdKey(token) else {
                    host.logOnce("texture.\(key).payloadToken",
                        "texture \(key): invalid payload token")
                    return
                }
                texturePayloadKeys[key] = pid
                guard let data = host.payloadStore[pid] else {
                    deferredResourceIds.insert(key)
                    host.logOnce("texture.\(key).awaiting",
                        "texture \(key): awaiting payload")
                    return
                }
                let spec = payloadSpecs[pid]
                switch spec?.format {
                case "rgba8":
                    guard let w = spec?.width, let h = spec?.height,
                          w > 0, h > 0 else {
                        host.logOnce("texture.\(key).rgba8.dims",
                            "texture \(key): rgba8 payload spec lacks "
                            + "width/height")
                        return
                    }
                    guard data.count == w * h * 4 else {
                        host.logOnce("texture.\(key).rgba8.size",
                            "texture \(key): rgba8 needs w*h*4 bytes")
                        return
                    }
                    guard let cg = rgbaCGImage(
                        data, width: w, height: h, content: content)
                    else {
                        host.logOnce("texture.\(key).rgba8.cg",
                            "texture \(key): rgba8 CGImage failed")
                        return
                    }
                    let image = UIImage(cgImage: cg)
                    recordTexture(key, DecodedTexture(
                        key: key, image: image,
                        mtlTexture: content == "color"
                            ? mipRenormalizedTexture(
                                image, logKey: "texture.\(key).mips")
                            : nil,
                        rgba: data,
                        width: w, height: h, content: content),
                        format: "rgba8", bytes: data.count,
                        since: started)
                case "ktx2":
                    if let tex = decodeKTX2(data, key: key,
                                            content: content) {
                        recordTexture(key, tex, format: "ktx2",
                                      bytes: data.count,
                                      since: started)
                    }
                default:
                    // Encoded container (png/jpg) or an undeclared
                    // format — UIImage decides by the magic bytes and
                    // tags the colorspace itself.
                    guard let image = UIImage(data: data),
                          let cg = image.cgImage else {
                        host.logOnce("texture.\(key).undecodable",
                            "texture \(key): undecodable image payload")
                        return
                    }
                    recordTexture(key, DecodedTexture(
                        key: key, image: image,
                        mtlTexture: content == "color"
                            ? mipRenormalizedTexture(
                                image, logKey: "texture.\(key).mips")
                            : nil,
                        rgba: nil, width: cg.width,
                        height: cg.height, content: content),
                        format: spec?.format ?? "encoded",
                        bytes: data.count, since: started)
                }
                return
            }
            if let asset = r["ref"] as? String {
                var image = UIImage(named: asset)
                if image == nil,
                   let url = FlutterAssets.url(forResource: asset) {
                    image = UIImage(contentsOfFile: url.path)
                }
                guard let image, let cg = image.cgImage else {
                    host.logOnce("texture.\(key).ref",
                        "texture \(key): asset '\(asset)' not found")
                    return
                }
                recordTexture(key, DecodedTexture(
                    key: key, image: image,
                    mtlTexture: content == "color"
                        ? mipRenormalizedTexture(
                            image, logKey: "texture.\(key).mips")
                        : nil,
                    rgba: nil, width: cg.width,
                    height: cg.height, content: content),
                    format: "ref", bytes: 0, since: started)
                return
            }
            host.logOnce("texture.\(key).source",
                "texture \(key): neither payload nor ref — slot absent")
        }

        /// Records a decoded texture and logs the upload line.
        func recordTexture(_ key: UInt64, _ tex: DecodedTexture,
                           format: String, bytes: Int, since start: UInt64) {
            textures[key] = tex
            let ms = Double(DispatchTime.now().uptimeNanoseconds - start)
                / 1_000_000.0
            d3Log("texture \(key): \(tex.width)x\(tex.height) \(format) "
                + "(\(bytes) B in \(String(format: "%.2f", ms)) ms)")
        }

        /// W21 mip renormalization for sRGB sources that ship without
        /// a chain (`rgba8`, encoded, `ref`): `MTKTextureLoader`
        /// uploads the image with `generateMipmaps` — on the
        /// `*_srgb` pixel format Metal produces, each downsample
        /// filters the decoded (linear) values and re-encodes, which
        /// is upstream's renormalizing-mip semantic. SceneKit's own
        /// implicit chain makes no sRGB-filtering guarantee, so the
        /// uploaded texture is what material slots bind. Returns nil
        /// when Metal can't take the image — the caller keeps the
        /// `UIImage` contents and SceneKit generates its own chain;
        /// `logKey` scopes the warn-once.
        func mipRenormalizedTexture(_ image: UIImage, srgb: Bool = true,
                                    logKey: String) -> MTLTexture? {
            guard let cg = image.cgImage else {
                host.logOnce("\(logKey).cg",
                    "\(logKey): no CGImage — SceneKit's own mip chain "
                    + "(sRGB-aware filtering not guaranteed)")
                return nil
            }
            guard let device = host.renderDevice() else {
                host.logOnce("\(logKey).device",
                    "\(logKey): no Metal device — SceneKit's own mip "
                    + "chain (sRGB-aware filtering not guaranteed)")
                return nil
            }
            guard let tex = try? MTKTextureLoader(device: device)
                .newTexture(cgImage: cg, options: [
                    .generateMipmaps: NSNumber(value: true),
                    .SRGB: NSNumber(value: srgb),
                    .textureUsage: NSNumber(
                        value: MTLTextureUsage.shaderRead.rawValue
                            | MTLTextureUsage.pixelFormatView.rawValue),
                ])
            else {
                host.logOnce("\(logKey).mtl",
                    "\(logKey): MTK mip upload failed — SceneKit's own "
                    + "mip chain (sRGB-aware filtering not guaranteed)")
                return nil
            }
            return srgb ? srgbTexture(tex, device: device) : tex
        }

        /// [tex] as an sRGB texture. `MTKTextureLoader` returns
        /// `rgba8Unorm` for a `CGImage` whatever `.SRGB` says (iOS 27
        /// and macOS 27 SDKs), so SceneKit sampled every colour
        /// texture without decoding it: (181, 199, 94) rendered as
        /// (220, 229, 164). A view with the sRGB format over the same
        /// storage decodes on sampling, and the mip chain is rebuilt
        /// through it so each level is filtered in linear light.
        func srgbTexture(_ tex: MTLTexture, device: MTLDevice) -> MTLTexture {
            let format: MTLPixelFormat
            switch tex.pixelFormat {
            case .rgba8Unorm: format = .rgba8Unorm_srgb
            case .bgra8Unorm: format = .bgra8Unorm_srgb
            default: return tex
            }
            guard let view = tex.makeTextureView(pixelFormat: format)
            else { return tex }
            if view.mipmapLevelCount > 1,
               let queue = host.commandQueue ?? device.makeCommandQueue(),
               let buffer = queue.makeCommandBuffer(),
               let blit = buffer.makeBlitCommandEncoder() {
                blit.generateMipmaps(for: view)
                blit.endEncoding()
                buffer.commit()
            }
            return view
        }

        /// Level-0 readback of an uncompressed 8-bit MTLTexture into
        /// straight RGBA8 — the `sourcePixels` lane for textures that
        /// only exist GPU-side (a decoded KTX2). BGRA swaps to RGBA;
        /// the sRGB variants' bytes are already encoded like the
        /// `rgba8` path's. Private or non-8-bit formats return nil.
        func rgbaPixels(fromMetal tex: MTLTexture)
            -> (data: Data, width: Int, height: Int)?
        {
            guard tex.storageMode != .private else { return nil }
            let bgra: Bool
            switch tex.pixelFormat {
            case .rgba8Unorm, .rgba8Unorm_srgb: bgra = false
            case .bgra8Unorm, .bgra8Unorm_srgb: bgra = true
            default: return nil
            }
            let w = tex.width, h = tex.height
            var data = Data(count: w * h * 4)
            data.withUnsafeMutableBytes { ptr in
                guard let base = ptr.baseAddress else { return }
                tex.getBytes(base, bytesPerRow: w * 4,
                             from: MTLRegionMake2D(0, 0, w, h),
                             mipmapLevel: 0)
            }
            if bgra {
                data.withUnsafeMutableBytes { ptr in
                    guard let p = ptr.baseAddress?
                        .assumingMemoryBound(to: UInt8.self)
                    else { return }
                    for i in stride(from: 0, to: w * h * 4, by: 4) {
                        let b = p[i]
                        p[i] = p[i + 2]
                        p[i + 2] = b
                    }
                }
            }
            return (data, w, h)
        }

        /// One parsed KTX2 level-index row.
        struct KTX2Level {
            let offset: Int
            let length: Int
        }

        /// Parsed KTX2 fixed header (Khronos KTX 2.0 spec §3.2): the
        /// 12-byte identifier, then `vkFormat`/`typeSize`, the pixel
        /// dims, `layerCount`/`faceCount`/`levelCount`,
        /// `supercompressionScheme`, DFD/KVD/SGD offsets, and at byte
        /// 80 the `levelCount` × 24-byte levelIndex rows (offset,
        /// length, uncompressedLength — level 0 is the base/largest
        /// level regardless of file order). All little-endian.
        struct KTX2Header {
            let vkFormat: UInt32
            let pixelWidth, pixelHeight, pixelDepth: Int
            let layerCount, faceCount: Int
            let supercompression: UInt32
            let levels: [KTX2Level]
        }

        /// KTX2 (Basis Universal container) — W21. Dispatch order:
        /// `MTKTextureLoader` first — it reads any texture container
        /// the SDK understands natively — then an in-tree upload for
        /// NON-supercompressed 2D files whose `vkFormat` maps to an
        /// `MTLPixelFormat` (uncompressed RGBA 8/16/32-bit and ASTC
        /// LDR blocks, each mip level landed via `replace`).
        /// BasisU-supercompressed payloads — ETC1S
        /// (`supercompressionScheme` 1) and UASTC (`vkFormat`
        /// UNDEFINED) — need a transcoder the pod doesn't vendor;
        /// they warn once and the slot keeps its factor-only
        /// fallback. No silent drop at any stage.
        func decodeKTX2(_ data: Data, key: UInt64, content: String)
            -> DecodedTexture?
        {
            if let device = host.renderDevice(),
               let tex = try? MTKTextureLoader(device: device)
                   .newTexture(data: data, options: [
                       .SRGB: NSNumber(value: content == "color"),
                       .textureUsage: NSNumber(
                           value: MTLTextureUsage.shaderRead.rawValue),
                   ]) {
                return DecodedTexture(key: key, image: nil,
                                      mtlTexture: tex, rgba: nil,
                                      width: tex.width,
                                      height: tex.height,
                                      content: content)
            }
            guard let h = parseKTX2(data) else {
                host.logOnce("texture.\(key).ktx2.parse",
                    "texture \(key): malformed KTX2 container")
                return nil
            }
            guard h.vkFormat != 0, h.supercompression == 0 else {
                host.logOnce("texture.\(key).ktx2.basisu",
                    "texture \(key): KTX2 carries BasisU "
                    + "supercompression (vkFormat \(h.vkFormat), "
                    + "scheme \(h.supercompression)) — a transcode "
                    + "path isn't vendored; slot keeps factor-only")
                return nil
            }
            guard h.pixelDepth == 0, h.layerCount == 0,
                  h.faceCount == 1 else {
                host.logOnce("texture.\(key).ktx2.dims",
                    "texture \(key): KTX2 cubes/arrays/3D unsupported "
                    + "(faces \(h.faceCount), layers \(h.layerCount), "
                    + "depth \(h.pixelDepth))")
                return nil
            }
            guard let fmt = ktx2PixelFormat(h.vkFormat) else {
                host.logOnce("texture.\(key).ktx2.vk\(h.vkFormat)",
                    "texture \(key): KTX2 vkFormat \(h.vkFormat) has "
                    + "no MTLPixelFormat mapping")
                return nil
            }
            guard let device = host.renderDevice() else {
                host.logOnce("texture.\(key).ktx2.device",
                    "texture \(key): no Metal device for KTX2 upload")
                return nil
            }
            let desc = MTLTextureDescriptor.texture2DDescriptor(
                pixelFormat: fmt.format, width: h.pixelWidth,
                height: h.pixelHeight, mipmapped: h.levels.count > 1)
            desc.storageMode = .shared   // CPU readback for factor bakes
            desc.usage = .shaderRead
            desc.mipmapLevelCount = h.levels.count
            guard let mtl = device.makeTexture(descriptor: desc) else {
                host.logOnce("texture.\(key).ktx2.alloc",
                    "texture \(key): MTLTexture allocation failed")
                return nil
            }
            // KTX2 stores level rows tightly packed; `bytesPerRow` is
            // the row-of-blocks pitch for block formats, w·bpp for
            // uncompressed.
            var rgba: Data? = nil
            for (i, level) in h.levels.enumerated() {
                let lw = max(1, h.pixelWidth >> i)
                let lh = max(1, h.pixelHeight >> i)
                let blocksW = (lw + fmt.blockW - 1) / fmt.blockW
                let blocksH = (lh + fmt.blockH - 1) / fmt.blockH
                let rowBytes = blocksW * fmt.blockBytes
                let needed = rowBytes * blocksH
                guard level.length >= needed else {
                    host.logOnce("texture.\(key).ktx2.level\(i)",
                        "texture \(key): KTX2 level \(i) is "
                        + "\(level.length) B, expected ≥ \(needed) B")
                    return nil
                }
                let start = data.startIndex + level.offset
                let bytes = data.subdata(in: start..<start + needed)
                bytes.withUnsafeBytes { buf in
                    guard let base = buf.baseAddress else { return }
                    mtl.replace(region: MTLRegionMake2D(0, 0, lw, lh),
                                mipmapLevel: i, withBytes: base,
                                bytesPerRow: rowBytes)
                }
                if i == 0, fmt.format == .rgba8Unorm
                    || fmt.format == .rgba8Unorm_srgb {
                    rgba = bytes   // already straight RGBA8
                }
            }
            return DecodedTexture(key: key, image: nil,
                                  mtlTexture: mtl, rgba: rgba,
                                  width: h.pixelWidth,
                                  height: h.pixelHeight,
                                  content: content)
        }

        /// Parses the KTX2 fixed header + level index. Returns nil on
        /// a bad identifier, a truncated header, `levelCount` < 1, or
        /// a level range running past the data. `typeSize`, DFD, KVD
        /// and SGD fields are skipped — vkFormat carries the format.
        func parseKTX2(_ data: Data) -> KTX2Header? {
            let magic: [UInt8] = [0xAB, 0x4B, 0x54, 0x58, 0x20, 0x32,
                                  0x30, 0xBB, 0x0D, 0x0A, 0x1A, 0x0A]
            guard data.count >= 80 else { return nil }
            for (i, b) in magic.enumerated()
            where data[data.startIndex + i] != b {
                return nil
            }
            func u32(_ o: Int) -> UInt32 {
                D3Wire.u32LE(data, data.startIndex + o)
            }
            func u64(_ o: Int) -> UInt64 {
                UInt64(u32(o)) | UInt64(u32(o + 4)) << 32
            }
            let levelCount = Int(u32(40))
            guard levelCount >= 1,
                  levelCount <= 64,   // sanity — caps the index walk
                  data.count >= 80 + levelCount * 24
            else { return nil }
            var levels: [KTX2Level] = []
            for i in 0..<levelCount {
                let off = u64(80 + i * 24)
                let len = u64(80 + i * 24 + 8)
                guard len <= UInt64(Int.max), off <= UInt64(Int.max),
                      off + len <= UInt64(data.count)
                else { return nil }
                levels.append(KTX2Level(offset: Int(off),
                                        length: Int(len)))
            }
            return KTX2Header(
                vkFormat: u32(12),
                pixelWidth: Int(u32(20)), pixelHeight: Int(u32(24)),
                pixelDepth: Int(u32(28)),
                layerCount: Int(u32(32)), faceCount: Int(u32(36)),
                supercompression: u32(44), levels: levels)
        }

        /// KTX2 `vkFormat` → `MTLPixelFormat` plus the block geometry
        /// `replace` needs. Covers uncompressed RGBA 8/16/32-bit and
        /// every ASTC LDR block size (Vulkan's ASTC range is
        /// contiguous UNORM/sRGB pairs in the same block-size order as
        /// Metal's). Everything else — BCn, ETC, PVRTC, HDR ASTC —
        /// returns nil and the caller warns.
        func ktx2PixelFormat(_ vk: UInt32)
            -> (format: MTLPixelFormat, blockW: Int, blockH: Int,
                blockBytes: Int)?
        {
            switch vk {
            // VK_FORMAT_R8G8B8A8_{UNORM,SRGB}, B8G8R8A8_{UNORM,SRGB},
            // R16G16B16A16_SFLOAT, R32G32B32A32_SFLOAT.
            case 37:  return (.rgba8Unorm,      1, 1, 4)
            case 43:  return (.rgba8Unorm_srgb, 1, 1, 4)
            case 44:  return (.bgra8Unorm,      1, 1, 4)
            case 50:  return (.bgra8Unorm_srgb, 1, 1, 4)
            case 97:  return (.rgba16Float,     1, 1, 8)
            case 109: return (.rgba32Float,     1, 1, 16)
            case 157...184:   // VK_FORMAT_ASTC_{4x4…12x12}_{UNORM,SRGB}
                let i = Int(vk - 157) / 2
                let srgb = (vk - 157) % 2 == 1
                let blocks: [(Int, Int)] = [
                    (4, 4), (5, 4), (5, 5), (6, 5), (6, 6), (8, 5),
                    (8, 6), (8, 8), (10, 5), (10, 6), (10, 8),
                    (10, 10), (12, 10), (12, 12)]
                let ldrFormats: [MTLPixelFormat] = [
                    .astc_4x4_ldr, .astc_5x4_ldr, .astc_5x5_ldr,
                    .astc_6x5_ldr, .astc_6x6_ldr, .astc_8x5_ldr,
                    .astc_8x6_ldr, .astc_8x8_ldr, .astc_10x5_ldr,
                    .astc_10x6_ldr, .astc_10x8_ldr, .astc_10x10_ldr,
                    .astc_12x10_ldr, .astc_12x12_ldr]
                let srgbFormats: [MTLPixelFormat] = [
                    .astc_4x4_srgb, .astc_5x4_srgb, .astc_5x5_srgb,
                    .astc_6x5_srgb, .astc_6x6_srgb, .astc_8x5_srgb,
                    .astc_8x6_srgb, .astc_8x8_srgb, .astc_10x5_srgb,
                    .astc_10x6_srgb, .astc_10x8_srgb, .astc_10x10_srgb,
                    .astc_12x10_srgb, .astc_12x12_srgb]
                let f = srgb ? srgbFormats[i] : ldrFormats[i]
                return (f, blocks[i].0, blocks[i].1, 16)
            default:
                return nil
            }
        }

        /// Raw RGBA8 access for a decoded texture — the payload buffer
        /// for `rgba8` sources, a CPU re-decode of the UIImage for
        /// encoded/`ref` ones. `wantAlpha` picks the re-decode format:
        /// premultiplied-last when the caller needs real alpha (a
        /// baseColor bake), none-skip-last when it only reads RGB (the
        /// MR channel split — premultiplying would corrupt G/B under
        /// transparent pixels).
        func sourcePixels(_ tex: DecodedTexture, wantAlpha: Bool)
            -> (data: Data, width: Int, height: Int, premultiplied: Bool)?
        {
            if let rgba = tex.rgba {
                return (rgba, tex.width, tex.height, false)
            }
            // GPU-only textures (a KTX2 that never made a UIImage)
            // read back level 0 when the pixel format is an
            // uncompressed 8-bit one — bakes and channel splits keep
            // working. Compressed/float formats return nil here and
            // the caller's fallback (factor-only) logs itself.
            if let mt = tex.mtlTexture,
               let p = rgbaPixels(fromMetal: mt) {
                return (p.data, p.width, p.height, false)
            }
            guard let image = tex.image,
                  let (data, w, h) = rgbaPixels(image, alpha: wantAlpha)
            else { return nil }
            return (data, w, h, wantAlpha)
        }

        /// Factor × texture, baked CPU-side — a texture-backed
        /// `SCNMaterialProperty` never multiplies a color factor.
        /// `rgbOnly` leaves alpha alone (emissive); otherwise the
        /// factor's alpha multiplies too (baseColor). Returns nil when
        /// no factor is given (texture binds unbaked); when a factor
        /// IS given but the pixels are unreachable (a GPU-only
        /// compressed decode) the bind falls back to the raw texture
        /// and the factor is lost — logged once.
        func bakeFactor(_ tex: DecodedTexture, color fc: [Double]?,
                        rgbOnly: Bool) -> UIImage? {
            guard let fc else { return nil }
            // An identity factor bakes to the texture itself — skip
            // the per-pixel pass (a material re-send used to re-bake
            // a white-factored 1024² base color every time).
            if fc[0] == 1, fc[1] == 1, fc[2] == 1, rgbOnly || fc[3] == 1 {
                return nil
            }
            guard let src = sourcePixels(tex, wantAlpha: !rgbOnly)
            else {
                host.logOnce("texture.\(tex.key).bake",
                    "texture \(tex.key): factor×texture bake needs CPU "
                    + "pixels — binding the texture unbaked "
                    + "(approximation)")
                return nil
            }
            var data = src.data
            let fa = fc[3]
            // Colour textures hold sRGB bytes; data textures are linear.
            let srgb = tex.content == "color"
            let alphaFold = src.premultiplied ? fa : 1
            let tables: [[UInt8]]? = srgb
                ? (0..<3).map { srgbScaleTable(fc[$0]) } : nil
            data.withUnsafeMutableBytes { ptr in
                guard let p = ptr.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                for i in stride(from: 0, to: src.width * src.height * 4,
                                by: 4) {
                    if let tables {
                        // The tables take a straight encoded colour. A
                        // premultiplied texel is that colour times its
                        // alpha, so the alpha comes off first and goes
                        // back on, with the factor's, afterwards.
                        let alpha = src.premultiplied ? Double(p[i + 3]) : 255
                        for c in 0..<3 {
                            guard alpha > 0 else { p[i + c] = 0; continue }
                            let straight = min(255, Int(
                                (Double(p[i + c]) * 255 / alpha).rounded()))
                            p[i + c] = scaleByte(
                                tables[c][straight],
                                alpha / 255 * alphaFold)
                        }
                    } else {
                        // A premultiplied p.rgb already carries the tex
                        // alpha; the straight result r·fR·fA comes out
                        // as pR·fR·fA.
                        p[i]     = scaleByte(p[i],     fc[0] * alphaFold)
                        p[i + 1] = scaleByte(p[i + 1], fc[1] * alphaFold)
                        p[i + 2] = scaleByte(p[i + 2], fc[2] * alphaFold)
                    }
                    if src.premultiplied || !rgbOnly {
                        p[i + 3] = scaleByte(p[i + 3], fa)
                    }
                }
            }
            return rgbaCGImage(data, width: src.width, height: src.height,
                               content: tex.content,
                               premultiplied: src.premultiplied)
                .map { UIImage(cgImage: $0) }
        }

        /// glTF packs metallic in B and roughness in G; SceneKit samples
        /// `metalness`/`roughness` as scalars, so the channels split
        /// into two gray images CPU-side — with the factors baked in,
        /// since a texture-backed property can't multiply them either.
        /// A nil half keeps the factor-only contents — for a GPU-only
        /// texture (a compressed KTX2) that drops the map entirely,
        /// so the miss warns once.
        func splitMetallicRoughness(_ tex: DecodedTexture,
                                    metallic mf: Double,
                                    roughness rf: Double)
            -> (metal: UIImage?, rough: UIImage?)
        {
            guard let src = sourcePixels(tex, wantAlpha: false)
            else {
                host.logOnce("texture.\(tex.key).mrSplit",
                    "texture \(tex.key): metallic/roughness channel "
                    + "split needs CPU pixels — binding factors only "
                    + "(approximation)")
                return (nil, nil)
            }
            var metal = Data(count: src.width * src.height)
            var rough = Data(count: src.width * src.height)
            src.data.withUnsafeBytes { ptr in
                guard let p = ptr.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                metal.withUnsafeMutableBytes { mp in
                    rough.withUnsafeMutableBytes { rp in
                        let m = mp.baseAddress!
                            .assumingMemoryBound(to: UInt8.self)
                        let r = rp.baseAddress!
                            .assumingMemoryBound(to: UInt8.self)
                        for i in 0..<src.width * src.height {
                            m[i] = scaleByte(p[i * 4 + 2], mf)
                            r[i] = scaleByte(p[i * 4 + 1], rf)
                        }
                    }
                }
            }
            return (grayCGImage(metal, width: src.width, height: src.height)
                        .map { UIImage(cgImage: $0) },
                    grayCGImage(rough, width: src.width, height: src.height)
                        .map { UIImage(cgImage: $0) })
        }

        /// Byte channel × unit factor, clamped to 0…255.
        func scaleByte(_ b: UInt8, _ f: Double) -> UInt8 {
            UInt8(clamping: Int((Double(b) * f).rounded()))
        }

        /// Every sRGB-encoded byte × a linear factor: decode, scale,
        /// encode. The factor is linear light, so multiplying the
        /// encoded byte would darken it by about the factor squared.
        func srgbScaleTable(_ f: Double) -> [UInt8] {
            (0..<256).map { encodeSrgb(srgbToLinear(Double($0) / 255) * f) }
        }

        /// Neutral 1×1 white bound to a shader-modifier `texture2d`
        /// argument whose texture hasn't decoded yet — the modifier
        /// samples it as ×1 (factor-only) until the deferred texture
        /// lands and `applyTextureSlot` rebinds the real contents.
        func neutralTexProperty() -> SCNMaterialProperty {
            let img = rgbaCGImage(Data([255, 255, 255, 255]),
                                  width: 1, height: 1, content: "data")
                .map { UIImage(cgImage: $0) }
            return SCNMaterialProperty(contents: img ?? UIColor.white)
        }

        /// W22: single channel × factor → gray image for a scalar
        /// slot's intensity map (clearcoat → `clearCoat`,
        /// clearcoatRoughness → `clearCoatRoughness`). GPU-only
        /// textures (KTX2) have no CPU pixels — nil + warn-once, the
        /// same rule splitMetallicRoughness follows.
        func channelGray(_ tex: DecodedTexture, channel: Int,
                         factor f: Double) -> UIImage? {
            guard let src = sourcePixels(tex, wantAlpha: false) else {
                host.logOnce("texture.\(tex.key).channelBake",
                    "texture \(tex.key): channel bake needs CPU "
                    + "pixels — binding the factor only "
                    + "(approximation)")
                return nil
            }
            var gray = Data(count: src.width * src.height)
            src.data.withUnsafeBytes { ptr in
                guard let p = ptr.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                gray.withUnsafeMutableBytes { gp in
                    let g = gp.baseAddress!
                        .assumingMemoryBound(to: UInt8.self)
                    for i in 0..<src.width * src.height {
                        g[i] = scaleByte(p[i * 4 + channel], f)
                    }
                }
            }
            return grayCGImage(gray, width: src.width,
                               height: src.height)
                .map { UIImage(cgImage: $0) }
        }

        /// W22: KHR_materials_transmission → `transparent` contents
        /// under .aOne — alpha = 1 − R·transmissionFactor per texel
        /// (RGB pinned white; .aOne reads the alpha channel). Missing
        /// pixels warn once + nil → the caller's factor-only gray.
        func transmissionAlpha(_ tex: DecodedTexture,
                               factor f: Double) -> UIImage? {
            guard let src = sourcePixels(tex, wantAlpha: false) else {
                host.logOnce("texture.\(tex.key).transmissionBake",
                    "texture \(tex.key): transmission bake needs CPU "
                    + "pixels — binding the factor only "
                    + "(approximation)")
                return nil
            }
            var data = Data(count: src.width * src.height * 4)
            src.data.withUnsafeBytes { ptr in
                guard let p = ptr.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                data.withUnsafeMutableBytes { dp in
                    let d = dp.baseAddress!
                        .assumingMemoryBound(to: UInt8.self)
                    for i in 0..<src.width * src.height {
                        d[i * 4] = 255
                        d[i * 4 + 1] = 255
                        d[i * 4 + 2] = 255
                        d[i * 4 + 3] = UInt8(clamping: Int(
                            (255.0 - Double(p[i * 4]) * f).rounded()))
                    }
                }
            }
            return rgbaCGImage(data, width: src.width,
                               height: src.height,
                               content: tex.content,
                               premultiplied: false)
                .map { UIImage(cgImage: $0) }
        }

        /// Builds a full mip chain for a normal-map texture CPU-side
        /// and returns it as an `MTLTexture` (W21). Each level is a
        /// 2×2 box average of the previous one with the averaged
        /// normal renormalized — decode → [-1,1], normalize,
        /// re-encode — so distant mips keep unit-length normals
        /// instead of the shrunken vectors a plain box filter
        /// produces. A degenerate (near-zero) average falls back to
        /// the flat +z normal rather than inventing a direction.
        /// Alpha is box-averaged unrenormalized. Level 0 ships
        /// verbatim. Returns nil (caller binds `tex.contents`) when the
        /// pixels are unreachable or Metal can't make the texture —
        /// each cause logs once.
        func renormalizedNormalMips(_ tex: DecodedTexture,
                                  materialKey: UInt64) -> MTLTexture? {
            guard let src = sourcePixels(tex, wantAlpha: false)
            else {
                host.logOnce("material.\(materialKey).normal.mips.pixels",
                    "material \(materialKey): normal texture pixels "
                    + "unreachable; SceneKit's unrenormalized mips "
                    + "(approximation — upstream renormalizes)")
                return nil
            }
            guard let device = host.renderDevice() else {
                host.logOnce("material.\(materialKey).normal.mips.device",
                    "material \(materialKey): no Metal device; "
                    + "SceneKit's unrenormalized mips (approximation — "
                    + "upstream renormalizes)")
                return nil
            }
            var levels: [[UInt8]] = [[UInt8](src.data)]
            var w = src.width, h = src.height
            while w > 1 || h > 1 {
                let prev = levels[levels.count - 1]
                let nw = max(1, w / 2), nh = max(1, h / 2)
                var next = [UInt8](repeating: 0, count: nw * nh * 4)
                for y in 0..<nh {
                    for x in 0..<nw {
                        var sx = 0.0, sy = 0.0, sz = 0.0
                        var sa = 0
                        // Each destination texel averages its FULL
                        // source footprint [x·w/nw, (x+1)·w/nw) — on an
                        // odd (NPOT) edge that is 3 texels, so the last
                        // row/column is never dropped (a 3×3 → 1×1
                        // step covers all 9).
                        let x0 = x * w / nw, x1 = (x + 1) * w / nw
                        let y0 = y * h / nh, y1 = (y + 1) * h / nh
                        for py in y0..<max(y1, y0 + 1) {
                            for px in x0..<max(x1, x0 + 1) {
                                let o = (py * w + px) * 4
                                sx += Double(prev[o]) / 127.5 - 1.0
                                sy += Double(prev[o + 1]) / 127.5 - 1.0
                                sz += Double(prev[o + 2]) / 127.5 - 1.0
                                sa += Int(prev[o + 3])
                            }
                        }
                        let taps = max(x1 - x0, 1) * max(y1 - y0, 1)
                        let d = (y * nw + x) * 4
                        let len = (sx * sx + sy * sy + sz * sz)
                            .squareRoot()
                        if len > 1e-6 {
                            next[d] = UInt8(clamping: Int(
                                ((sx / len + 1.0) * 127.5).rounded()))
                            next[d + 1] = UInt8(clamping: Int(
                                ((sy / len + 1.0) * 127.5).rounded()))
                            next[d + 2] = UInt8(clamping: Int(
                                ((sz / len + 1.0) * 127.5).rounded()))
                        } else {
                            // Cancelled-out average — flat +z normal.
                            next[d] = 128; next[d + 1] = 128
                            next[d + 2] = 255
                        }
                        next[d + 3] = UInt8(clamping: sa / taps)
                    }
                }
                levels.append(next)
                w = nw; h = nh
            }
            let desc = MTLTextureDescriptor.texture2DDescriptor(
                pixelFormat: .rgba8Unorm,  // linear — normal data, no sRGB
                width: src.width, height: src.height, mipmapped: true)
            desc.storageMode = .shared
            desc.usage = .shaderRead
            desc.mipmapLevelCount = levels.count
            guard let mtl = device.makeTexture(descriptor: desc) else {
                host.logOnce("material.\(materialKey).normal.mips.mtl",
                    "material \(materialKey): MTLTexture creation "
                    + "failed; SceneKit's unrenormalized mips "
                    + "(approximation — upstream renormalizes)")
                return nil
            }
            for (level, pixels) in levels.enumerated() {
                let lw = max(1, src.width >> level)
                let lh = max(1, src.height >> level)
                pixels.withUnsafeBytes { buf in
                    guard let base = buf.baseAddress else { return }
                    mtl.replace(
                        region: MTLRegionMake2D(0, 0, lw, lh),
                        mipmapLevel: level, withBytes: base,
                        bytesPerRow: lw * 4)
                }
            }
            return mtl
        }

        /// Re-decodes an encoded/`ref` image to raw 8-bit RGBA.
        /// `alpha: true` draws premultiplied-last; `false` draws
        /// none-skip-last for channel-split reads where premultiplying
        /// would corrupt the G/B channels.
        func rgbaPixels(_ image: UIImage, alpha: Bool)
            -> (data: Data, width: Int, height: Int)?
        {
            guard let cg = image.cgImage else { return nil }
            let w = cg.width, h = cg.height
            var data = Data(count: w * h * 4)
            let info = CGBitmapInfo(rawValue:
                (alpha ? CGImageAlphaInfo.premultipliedLast
                       : CGImageAlphaInfo.noneSkipLast).rawValue
                | CGBitmapInfo.byteOrder32Big.rawValue)
            let ok = data.withUnsafeMutableBytes { ptr -> Bool in
                guard let base = ptr.baseAddress,
                      let space = CGColorSpace(name: CGColorSpace.sRGB),
                      let ctx = CGContext(
                          data: base, width: w, height: h,
                          bitsPerComponent: 8, bytesPerRow: w * 4,
                          space: space, bitmapInfo: info.rawValue)
                else { return false }
                ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
                return true
            }
            return ok ? (data, w, h) : nil
        }

        /// Wraps raw RGBA8 bytes as a CGImage — 8bpc/32bpp, w·4 bytes a
        /// row, `byteOrder32Big | alphaLast` for straight alpha (the
        /// wire convention) or `premultipliedLast` for re-decoded
        /// sources. Colorspace comes from `content`: `color` → sRGB,
        /// `data`/`normal` → linear sRGB.
        func rgbaCGImage(_ data: Data, width w: Int, height h: Int,
                         content: String, premultiplied: Bool = false)
            -> CGImage?
        {
            guard let provider = CGDataProvider(data: data as CFData),
                  let space = CGColorSpace(name:
                      content == "color" ? CGColorSpace.sRGB
                                         : CGColorSpace.linearSRGB)
            else { return nil }
            let info = CGBitmapInfo(rawValue:
                (premultiplied ? CGImageAlphaInfo.premultipliedLast
                               : CGImageAlphaInfo.last).rawValue
                | CGBitmapInfo.byteOrder32Big.rawValue)
            return CGImage(width: w, height: h,
                           bitsPerComponent: 8, bitsPerPixel: 32,
                           bytesPerRow: w * 4, space: space,
                           bitmapInfo: info, provider: provider,
                           decode: nil, shouldInterpolate: true,
                           intent: .defaultIntent)
        }

        /// Float RGBA CGImage for HDR environment pixels — 32bpc/128bpp
        /// linear sRGB. `floatComponents` requires premultiplied alpha;
        /// env pixels are opaque, so the flag is a no-op on the data.
        /// Preferred over `MDLTexture` for env contents: the CGImage
        /// path keeps full float range through SceneKit's radiance
        /// conversion and needs no extra framework surface.
        func rgbaFloatCGImage(_ data: Data, width w: Int, height h: Int)
            -> CGImage?
        {
            guard let provider = CGDataProvider(data: data as CFData),
                  let space = CGColorSpace(name: CGColorSpace.linearSRGB)
            else { return nil }
            let info = CGBitmapInfo(rawValue:
                CGImageAlphaInfo.premultipliedLast.rawValue
                | CGBitmapInfo.floatComponents.rawValue
                | CGBitmapInfo.byteOrder32Little.rawValue)
            return CGImage(width: w, height: h,
                           bitsPerComponent: 32, bitsPerPixel: 128,
                           bytesPerRow: w * 16, space: space,
                           bitmapInfo: info, provider: provider,
                           decode: nil, shouldInterpolate: true,
                           intent: .defaultIntent)
        }

        /// One-channel gray image for the metallic/roughness split —
        /// scalar data, so linear gray (no sRGB decode). Emitted as
        /// RGBA8 (gray replicated, opaque alpha): SceneKit maps an
        /// 8bpp gray CGImage to R8Unorm_sRGB, which Metal validation
        /// rejects in renderResourceForImage (W22 lane-4 SIGABRT).
        func grayCGImage(_ data: Data, width w: Int, height h: Int)
            -> CGImage?
        {
            var rgba = Data(count: w * h * 4)
            data.withUnsafeBytes { sp in
                guard let s = sp.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                rgba.withUnsafeMutableBytes { dp in
                    let d = dp.baseAddress!
                        .assumingMemoryBound(to: UInt8.self)
                    for i in 0..<w * h {
                        let v = s[i]
                        d[i * 4] = v; d[i * 4 + 1] = v
                        d[i * 4 + 2] = v; d[i * 4 + 3] = 255
                    }
                }
            }
            return rgbaCGImage(rgba, width: w, height: h,
                               content: "data")
        }

        // MARK: Nodes

        func decodeNodes(_ map: [String: Any]) {
            // Pass 1: create every node so children/animation bindings can
            // reference ids declared later in the map.
            for (token, any) in map {
                guard let key = D3Wire.localIdKey(token),
                      let spec = any as? [String: Any] else { continue }
                let node = SCNNode()
                decodeNodeFields(key: key, node: node, spec: spec)
                nodes[key] = node
            }
            // Pass 2: wire the hierarchy.
            for (token, any) in map {
                guard let key = D3Wire.localIdKey(token),
                      let parent = nodes[key],
                      let spec = any as? [String: Any] else { continue }
                for childToken in spec["children"] as? [Any] ?? [] {
                    guard let ct = childToken as? String,
                          let ck = D3Wire.localIdKey(ct),
                          let child = nodes[ck] else { continue }
                    parent.addChildNode(child)
                }
            }
        }

        /// Pass-1 decode of one node entry — name, transform,
        /// visibility, layers, then components. Children are wired
        /// separately: the manifest's pass 2 handles `spec.children`,
        /// while an `addNode` command attaches via its own `parent`
        /// field, so the surgical ops share this body.
        func decodeNodeFields(key: UInt64, node: SCNNode,
                              spec: [String: Any]) {
            if let name = spec["name"] as? String { node.name = name }
            decodeTransform(node, spec["transform"])
            if spec["visible"] as? Bool == false { node.isHidden = true }
            if let layers = spec["layers"] as? Int, layers != 1 {
                node.categoryBitMask = layers
            }
            // `skin` is a node member, not a component — record the
            // binding; the skinner attaches once the skin record and
            // the mesh's geometry both exist (`resolveSkinAttachments`
            // on the manifest path, the op paths re-attach inline).
            if let token = spec["skin"] as? String,
               let skinKey = D3Wire.localIdKey(token) {
                nodeSkinKeys[key] = skinKey
            } else {
                nodeSkinKeys.removeValue(forKey: key)
            }
            // W15: a surviving `instance` member tags the node as a
            // lazy prefab placeholder — recorded raw, resolved by the
            // streaming layer (Dart-side compose → standard ops).
            if let inst = spec["instance"] as? [String: Any] {
                instanceSpecs[key] = inst
            } else {
                instanceSpecs.removeValue(forKey: key)
            }
            let comps = spec["components"] as? [Any] ?? []
            colliderIndexByKey[key] = comps.firstIndex {
                ($0 as? [String: Any])?["type"] as? String == "collider"
            }
            for (i, c) in comps.enumerated() {
                decodeComponent(key: key, node: node, index: i, spec: c)
            }
        }

        func attachRoots(_ roots: [Any]) {
            for any in roots {
                guard let token = any as? String,
                      let key = D3Wire.localIdKey(token),
                      let node = nodes[key] else { continue }
                scene.rootNode.addChildNode(node)
            }
        }

        func decodeTransform(_ node: SCNNode, _ any: Any?) {
            guard let t = any as? [String: Any] else { return }
            if let trs = t["trs"] as? [String: Any] {
                if let v = trs["t"] as? [Double] { node.position = D3Wire.position(v) }
                if let v = trs["r"] as? [Double] { node.orientation = D3Wire.quaternion(v) }
                if let v = trs["s"] as? [Double] { node.scale = D3Wire.scale(v) }
            } else if let m = t["matrix"] as? [Double], m.count == 16 {
                node.transform = D3Wire.matrix(m)
            }
        }

        // MARK: Components

        func decodeComponent(key: UInt64, node: SCNNode, index: Int,
                             spec any: Any) {
            guard let spec = any as? [String: Any],
                  let type = spec["type"] as? String else { return }
            let props = spec["properties"] as? [String: Any] ?? [:]
            // Universal `enabled` (W12) — upstream's component wrapper
            // applies it around update/fixedUpdate callbacks only; it
            // does not remove the realized state (an enabled:false
            // light still lights). W18 gave the flag its first real
            // consumer: particle emitters own a tick, so enabled:false
            // attaches no SCNParticleSystem (decodeParticleEmitter
            // logs and returns). Other components have no tick surface
            // — the flag is recorded for parity, not applied.
            if d3Bool(props["enabled"]) == false {
                disabledComponents[key, default: []].insert(index)
                if type != "particleEmitter"
                    && type != "meshParticleEmitter" {
                    host.logOnce("enabled.\(key).\(index)",
                        "component '\(type)' on node \(key): "
                        + "enabled:false gates upstream component ticks "
                        + "only; dart3d has no tick surface — recorded, "
                        + "not applied")
                }
            }
            switch type {
            case "mesh":            decodeMesh(key, node, props)
            case "camera":          decodeCamera(key, node, props)
            case "directionalLight": decodeLight(key, node, props, .directional)
            case "pointLight":       decodeLight(key, node, props, .omni)
            case "spotLight":        decodeLight(key, node, props, .spot)
            case "rectAreaLight":    decodeLight(key, node, props, .area)
            case "particleEmitter":
                decodeParticleEmitter(key: key, node: node, index: index,
                                      props: props, mesh: false)
            case "meshParticleEmitter":
                decodeParticleEmitter(key: key, node: node, index: index,
                                      props: props, mesh: true)
            case "rigidBody", "collider", "physicsWorld", "characterController":
                physicsDeferred.append((key, node, type, props))
            case "fixedJoint", "sphericalJoint", "revoluteJoint",
                 "prismaticJoint", "genericJoint":
                jointComponentsDeferred.append((key, index, type, props))
            case "materialsVariants":
                decodeMaterialsVariants(key: key, index: index, props: props)
            case "trail":           decodeTrail(key, node, props)
            case "lod":             decodeLod(key, node, props)
            // W26: generic `ComponentSpec` extension components —
            // properties arrive through the standard tagged codec.
            case "d3:procMesh":
                decodeProcMesh(key: key, node: node, props)
            case "d3:instances":
                decodeInstances(key: key, node: node, props)
            default:
                d3Log("unhandled component type '\(type)'")
            }
        }

        /// W12: maps a declarative joint component's upstream property
        /// names onto the `addJoint`/`updateJoint` wire shape, so the
        /// host's one constraint path serves both. An absent or
        /// self-referencing `otherNode` produces no `b` — the record
        /// anchors to the world, matching upstream's fixed world body.
        private func translateJointComponent(
            key: UInt64, type: String, props: [String: Any]
        ) -> [String: Any]? {
            let jt: String
            switch type {
            case "fixedJoint":     jt = "fixed"
            case "sphericalJoint": jt = "spherical"
            case "revoluteJoint":  jt = "revolute"
            case "prismaticJoint": jt = "prismatic"
            case "genericJoint":   jt = "generic"
            default: return nil
            }
            var json: [String: Any] = [
                "type": jt,
                "a": D3Wire.localIdToken(key),
                "collide": d3Bool(props["collisionsEnabled"]) ?? false,
            ]
            if let b = d3Ref(props["otherNode"]) {
                json["b"] = D3Wire.localIdToken(b)
            }
            if let v = d3Vec3(props["localAnchorA"]) { json["anchorA"] = v }
            if let v = d3Vec3(props["localAnchorB"]) { json["anchorB"] = v }
            if let v = d3Vec3(props["localAxisA"]) { json["axisA"] = v }
            if let v = d3Vec3(props["localAxisB"]) { json["axisB"] = v }
            if let d = d3Double(props["lowerLimit"]) { json["lower"] = d }
            if let d = d3Double(props["upperLimit"]) { json["upper"] = d }
            if let d = d3Double(props["motorTargetVelocity"]) {
                json["motorVelocity"] = d
            }
            if let d = d3Double(props["motorMaxForce"]) {
                json["motorMaxForce"] = d
            }
            if let q = d3Quat(props["localBasisA"]) { json["basisA"] = q }
            if let q = d3Quat(props["localBasisB"]) { json["basisB"] = q }
            // Generic axes arrive keyed by name; the wire carries them
            // as the ordered array decodeJointAxes expects. An absent
            // axis (or a wholly absent `axes` member) defaults to free
            // — upstream's GenericJointDesc default.
            if jt == "generic" {
                let cfg = d3Map(props["axes"]) ?? [:]
                var axes: [[String: Any]] = []
                for name in ["linearX", "linearY", "linearZ",
                             "angularX", "angularY", "angularZ"] {
                    let m = d3Map(cfg[name]) ?? [:]
                    var axis: [String: Any] = [
                        "motion": d3String(m["motion"]) ?? "free"
                    ]
                    if let d = d3Double(m["lowerLimit"]) {
                        axis["lower"] = d
                    }
                    if let d = d3Double(m["upperLimit"]) {
                        axis["upper"] = d
                    }
                    if let motor = d3Map(m["motor"]) {
                        var mj: [String: Any] = [:]
                        for f in ["targetPosition", "targetVelocity",
                                  "stiffness", "damping", "maxForce"] {
                            if let d = d3Double(motor[f]) { mj[f] = d }
                        }
                        if let s = d3String(motor["model"]) {
                            mj["model"] = s
                        }
                        if !mj.isEmpty { axis["motor"] = mj }
                    }
                    axes.append(axis)
                }
                json["axes"] = axes
            }
            return json
        }

        // MARK: Material variants (W12)

        /// Decodes a `materialsVariants` component (upstream
        /// `KHR_materials_variants`): the variant name list, the
        /// selected name, and the bindings — each a node ref +
        /// primitive index + declared default material + a
        /// variant-index → material map. Bindings resolve at apply
        /// time so a target node that lands later still binds.
        private func decodeMaterialsVariants(
            key: UInt64, index: Int, props: [String: Any]
        ) {
            let variants = (d3List(props["variants"]) ?? [])
                .compactMap { d3String($0) }
            var bindings: [VariantBindingSpec] = []
            for entry in d3List(props["bindings"]) ?? [] {
                guard let m = d3Map(entry),
                      let nodeKey = d3Ref(m["node"]),
                      let primitive = d3Int(m["primitive"]),
                      primitive >= 0 else { continue }
                var byVariant: [Int: UInt64] = [:]
                for (name, ref) in d3Map(m["materials"]) ?? [:] {
                    guard let idx = Int(name),
                          let matKey = d3Ref(ref) else { continue }
                    byVariant[idx] = matKey
                }
                bindings.append(VariantBindingSpec(
                    nodeKey: nodeKey, primitive: primitive,
                    defaultMaterialKey: d3Ref(m["default"]),
                    materialsByVariant: byVariant))
            }
            variantComponents[key] = VariantComponentSpec(
                nodeKey: key, compIndex: index, variants: variants,
                selected: d3String(props["selected"]),
                bindings: bindings)
            host.logOnce("variants.\(key).\(index)",
                "materialsVariants on node \(key): \(variants.count) "
                + "variants, \(bindings.count) bindings"
                + ", selected=\(d3String(props["selected"]) ?? "-")")
        }

        /// Applies every variant component's selection — called after
        /// the node pass on the manifest path, after a surgical
        /// components decode, and by the host's `selectVariant` op.
        /// Unresolved bindings (target node or geometry not yet live)
        /// stay pending; the landing retries re-attempt them.
        func applyVariantComponents() {
            for key in variantComponents.keys.sorted() {
                guard var vc = variantComponents[key] else { continue }
                let selIdx = vc.selected
                    .flatMap { vc.variants.firstIndex(of: $0) }
                for i in vc.bindings.indices {
                    applyVariantBinding(&vc.bindings[i],
                                        variantIndex: selIdx)
                }
                variantComponents[key] = vc
            }
        }

        func refreshVariantDefaults(
            key: UInt64, material: SCNMaterial
        ) {
            for componentKey in Array(variantComponents.keys) {
                guard var component = variantComponents[componentKey]
                else { continue }
                for index in component.bindings.indices {
                    var binding = component.bindings[index]
                    guard binding.defaultMaterialSource?.key == key,
                          let previousDefault = binding.defaultMaterial
                    else { continue }
                    let replacement: SCNMaterial
                    if binding.defaultMaterialSource?.isSnapshotClone == true {
                        replacement = material.copy() as! SCNMaterial
                        materialColorOwners[key]?.copyFactor(to: replacement)
                        replacement.isDoubleSided = previousDefault.isDoubleSided
                    } else {
                        replacement = material
                    }
                    binding.defaultMaterial = replacement
                    if let geometry = binding.appliedGeometry,
                       geometry.materials.first === previousDefault {
                        dropShadowCatcherBindings(geometry)
                    }
                    component.bindings[index] = binding
                }
                variantComponents[componentKey] = component
            }
        }

        /// Applies one binding: writes `geometry.materials[primitive]`
        /// with the variant's mapped material, or the binding's default
        /// when the variant has no mapping (or none is selected).
        /// Upstream's rebase rule: a slot content that is neither this
        /// binding's last write nor a variant-mapped material wins and
        /// becomes the new default — an explicitly assigned mesh
        /// material is not silently reverted.
        private func applyVariantBinding(
            _ b: inout VariantBindingSpec, variantIndex: Int?
        ) {
            guard let node = resolveNode(b.nodeKey) else {
                host.logOnce("variant.unresolved.\(b.nodeKey)",
                    "materialsVariants binding: node \(b.nodeKey) not "
                    + "live yet; pending")
                return
            }
            // The binding's `primitive` indexes the mesh's primitives —
            // prim 0 rides node.geometry; extras park on `d3prim:i`
            // children, each carrying exactly one material slot.
            let geo: SCNGeometry?
            let targetNode: SCNNode?
            if b.primitive == 0 {
                targetNode = node
                geo = targetNode?.geometry
            } else {
                targetNode = node.childNodes
                    .first { $0.name == "d3prim:\(b.primitive)" }
                geo = targetNode?.geometry
            }
            guard let geo, let targetNode else {
                host.logOnce("variant.unresolved.\(b.nodeKey)",
                    "materialsVariants binding: node \(b.nodeKey) or its "
                    + "geometry not live yet; pending")
                return
            }
            guard !geo.materials.isEmpty else {
                b.resolved = true
                host.logOnce("variant.binding.\(b.nodeKey).\(b.primitive)",
                    "materialsVariants binding: node \(b.nodeKey) has "
                    + "no primitive \(b.primitive); dropped")
                return
            }
            let current = geo.materials[0]
            if b.defaultMaterial == nil {
                b.defaultMaterial =
                    b.defaultMaterialKey.flatMap { materials[$0] }
                b.defaultMaterialSource = b.defaultMaterialKey.map { ($0, false) }
            }
            let variantMats = b.materialsByVariant.values
                .compactMap { materials[$0] }
            if current !== b.applied
                && current !== b.defaultMaterial
                && !variantMats.contains(where: { $0 === current }) {
                b.defaultMaterial = current
                b.defaultMaterialSource = materials.first {
                    $0.value === current
                }.map { ($0.key, false) }
                if b.defaultMaterialSource == nil,
                   geo !== b.appliedGeometry, b.primitive == 0,
                   d3Bool(instancesProps[b.nodeKey]?["doubleSided"]) == true,
                   let sourceKey = d3Ref(instancesProps[b.nodeKey]?["material"]),
                   materials[sourceKey]?.isDoubleSided == false,
                   current.isDoubleSided,
                   materialConsumers[sourceKey]?.contains(where: {
                       $0 === geo
                   }) == true {
                    b.defaultMaterialSource = (sourceKey, true)
                }
            }
            let variantKey = variantIndex
                .flatMap { b.materialsByVariant[$0] }
            let target = variantKey
                .flatMap { materials[$0] }
                ?? b.defaultMaterial ?? current
            var which = "current"
            if target === b.defaultMaterial { which = "default" }
            else if let vk = variantKey,
                    target === materials[vk] { which = "variant" }
            d3Log("variant apply node=\(b.nodeKey) prim=\(b.primitive) "
                + "selIdx=\(variantIndex.map(String.init) ?? "-") "
                + "vkey=\(variantKey.map(String.init) ?? "-") "
                + "vmap=\(b.materialsByVariant.count) target=\(which)")
            dropShadowCatcherBindings(geo)
            geo.materials[0] = target
            host.applyBillboardMaterialPolicy(b.nodeKey)
            b.applied = target
            b.appliedGeometry = geo
            b.resolved = true
            let materialKey = target === b.defaultMaterial
                ? b.defaultMaterialSource?.key
                : materials.first(where: { $0.value === target })?.key
            if let materialKey {
                recordShadowCatcherBinding(
                    key: materialKey, node: targetNode, geometry: geo,
                    material: target, materialIndex: 0,
                    isSnapshotClone: target !== materials[materialKey])
            }
        }

        // MARK: Physics

        /// Runs after the node pass: colliders produce shapes (possibly
        /// from node geometry), bodies attach those shapes, `physicsWorld`
        /// configures the scene. Upstream keeps surface material and the
        /// collision layer/mask on the collider; SceneKit has no per-shape
        /// material, so they fold onto the body at attach time.
        func decodePhysicsDeferred() {
            var colliders: [UInt64:
                (shape: SCNPhysicsShape?, friction: Double?,
                 restitution: Double?, layer: Int?, mask: Int?,
                 trigger: Bool)] = [:]
            for item in physicsDeferred where item.type == "collider" {
                let c = decodeCollider(item.node, item.props)
                colliders[item.key] = c
                host.colliderLayerMaskByKey[item.key] = (
                    layer: c.layer ?? -1,
                    mask: c.mask ?? -1
                )
                // Geometry-derived kinds return a nil shape while the
                // node's geometry is still payload-deferred — the body
                // then attaches shapeless and SceneKit never re-derives
                // it (Android defers the body instead). Record the
                // intended derivation; `decodeMesh` refills the shape
                // when the geometry lands.
                if colliders[item.key]?.shape == nil,
                   item.node.geometry == nil,
                   let kind = d3String(
                       d3Map(item.props["shape"])?["kind"]) {
                    let t: SCNPhysicsShape.ShapeType?
                    switch kind {
                    case "boundingBox": t = .boundingBox
                    case "convexHull": t = .convexHull
                    case "triMesh", "concaveMesh":
                        t = .concavePolyhedron
                    default: t = nil
                    }
                    if let t {
                        host.pendingColliderShapes[item.key] = t
                    }
                }
            }
            for item in physicsDeferred where item.type == "rigidBody" {
                decodeRigidBody(item.key, item.node, item.props,
                                collider: colliders[item.key])
            }
            for item in physicsDeferred where item.type == "characterController" {
                decodeCharacterController(item.key, item.node, item.props,
                                          collider: colliders[item.key])
            }
            for item in physicsDeferred where item.type == "physicsWorld" {
                if let g = d3Vec3(item.props["gravity"]), g.count >= 3 {
                    scene.physicsWorld.gravity = D3Wire.position(g)
                    host.worldGravityScale =
                        (g[0] * g[0] + g[1] * g[1] + g[2] * g[2])
                            .squareRoot()
                }
                if let dt = d3Double(item.props["fixedTimestep"]),
                   dt > 0 {
                    // SceneKit steps the world at this fixed interval —
                    // halving it quarters the contact-overshoot noise
                    // that keeps mm-scale bodies awake forever.
                    scene.physicsWorld.timeStep = dt
                }
                if let backend = d3String(item.props["backend"]),
                   backend != "basic" {
                    host.logOnce("world.backend.\(backend)",
                        "physicsWorld backend '\(backend)' requested; "
                        + "iOS always uses SceneKit physics")
                }
                // `maxSubsteps` is accepted but advisory: SceneKit
                // clamps substeps internally (and drops time rather
                // than spiral).
            }
            // W12 declarative joint components ride the command-built
            // constraint machinery — translated to the wire joint shape
            // and registered under the component handle range, so
            // deferral, rebinding and the break sweep apply unchanged.
            for item in jointComponentsDeferred {
                guard let json = translateJointComponent(
                    key: item.key, type: item.type, props: item.props)
                else { continue }
                host.registerComponentJoint(
                    nodeKey: item.key, componentIndex: item.index,
                    json: json)
            }
            for (key, node) in nodes {
                let b = node.physicsBody
                let kind = b.map { String(describing: $0.type) } ?? "nil"
                let hasShape = b?.physicsShape != nil
                d3Log("node \(key): body=\(kind)"
                    + " shape=\(hasShape) pos=\(node.position.y)"
                    + " cat=\(b.map { String($0.categoryBitMask, radix: 16) } ?? "-")"
                    + " mask=\(b.map { String($0.collisionBitMask, radix: 16) } ?? "-")")
            }
        }

        func decodeCharacterController(
            _ key: UInt64,
            _ node: SCNNode,
            _ p: [String: Any],
            collider: (shape: SCNPhysicsShape?, friction: Double?,
                       restitution: Double?, layer: Int?, mask: Int?,
                       trigger: Bool)?
        ) {
            guard let shape = collider?.shape else {
                host.pendingCharacterControllers[key] = p
                host.logOnce("character.\(key).noshape",
                    "node \(key): characterController has no sibling collider shape; deferred")
                return
            }
            host.pendingCharacterControllers.removeValue(forKey: key)
            if node.physicsBody == nil {
                let kb = SCNPhysicsBody(type: .kinematic, shape: shape)
                let layer = collider?.layer ?? 1
                let mask = collider?.mask ?? -1
                kb.categoryBitMask = (layer >= 0 ? (layer << 2) : (1 << 2))
                kb.collisionBitMask = (mask >= 0 ? (mask << 2) : ~0)
                node.physicsBody = kb
            }
            let rawUp = d3Vec3(p["up"]) ?? [0, 1, 0]
            let scnUp = D3Wire.position(rawUp)
            let upVec = simd_float3(Float(scnUp.x), Float(scnUp.y), Float(scnUp.z))
            let upLen = simd_length(upVec)
            let normUp = upLen > 1e-6 ? (upVec / upLen) : simd_float3(0, 1, 0)
            let halfPi = Float.pi / 2.0
            let quarterPi = Float.pi / 4.0
            let maxClimb = min(max(Float(d3Double(p["maxSlopeClimbAngle"]) ?? Double(quarterPi)), 0), halfPi)
            let minSlide = min(max(Float(d3Double(p["minSlopeSlideAngle"]) ?? Double(quarterPi)), 0), halfPi)
            let snap = d3Double(p["snapToGround"]).flatMap { $0 >= 0 ? Float($0) : nil }
            host.characterControllers[key] = SceneViewHost.CharacterControllerState(
                shape: shape,
                up: normUp,
                offset: max(0, Float(d3Double(p["offset"]) ?? 0.01)),
                slide: d3Bool(p["slide"]) ?? true,
                maxSlopeClimbAngle: maxClimb,
                minSlopeSlideAngle: minSlide,
                snapToGround: snap,
                autostep: d3Bool(p["autostep"]) ?? false,
                autostepMaxHeight: max(0, Float(d3Double(p["autostepMaxHeight"]) ?? 0.3)),
                autostepMinWidth: max(0, Float(d3Double(p["autostepMinWidth"]) ?? 0.1)),
                autostepIncludeDynamicBodies: d3Bool(p["autostepIncludeDynamicBodies"]) ?? true,
                mass: max(0, Float(d3Double(p["mass"]) ?? 0.0)),
                layer: collider?.layer ?? -1,
                mask: collider?.mask ?? -1
            )
        }

        /// Decodes one collider component: the `shape` tagged union, the
        /// `material` map (friction/restitution fold onto the body;
        /// density and combine rules have no SceneKit home), the
        /// `collisionLayer`/`collisionMask` bitmasks, `isTrigger`, and the
        /// `localPose` offset applied as a shape transform.
        func decodeCollider(_ node: SCNNode, _ p: [String: Any])
            -> (shape: SCNPhysicsShape?, friction: Double?,
                restitution: Double?, layer: Int?, mask: Int?,
                trigger: Bool)
        {
            var shape: SCNPhysicsShape?
            if let m = d3Map(p["shape"]) {
                shape = decodeShape(m, node: node)
            } else if p["shape"] != nil {
                d3Log("collider 'shape': expected a tagged-union map")
            } else {
                // Absent → the schema default: unit box.
                shape = decodeShape(["kind": ["s": "box"]], node: node)
            }
            if let pose = d3Mat4(p["localPose"]) {
                if let built = shape {
                    // Per-shape transforms only exist on compound shapes,
                    // so a lone shape wraps as a one-child compound.
                    shape = SCNPhysicsShape(
                        shapes: [built],
                        transforms: [NSValue(scnMatrix4: pose)])
                } else {
                    d3Log("collider localPose: no concrete shape to offset")
                }
            }
            var friction: Double?
            var restitution: Double?
            if let material = d3Map(p["material"]) {
                friction = d3Double(material["friction"])
                restitution = d3Double(material["restitution"])
                for key in ["frictionCombine", "restitutionCombine"] {
                    if let rule = d3String(material[key]),
                       rule != "average" {
                        host.logOnce("material.\(key).\(rule)",
                            "collider material \(key) '\(rule)' is not "
                            + "expressible on SceneKit; using average")
                    }
                }
                // `density` is accepted and ignored — SceneKit derives
                // no mass from it; body.mass is the only override.
            }
            let layer = d3Int(p["collisionLayer"])
            let mask = d3Int(p["collisionMask"])
            // A trigger gives no contact response — bodies pass through.
            // SceneKit expresses that as a zero collisionBitMask; the
            // category stays intact so W8's contact events can still
            // sense the overlap.
            let trigger = d3Bool(p["isTrigger"]) == true
            if trigger {
                host.logOnce("collider.isTrigger",
                    "collider isTrigger: pass-through via "
                    + "collisionBitMask=0; trigger events land in W8")
            }
            return (shape, friction, restitution, layer, mask, trigger)
        }

        /// One level of the collider `shape` tagged union; `compound`
        /// recurses through it for each child. `convexHull`/`triMesh`
        /// (and the `concaveMesh` extension) keep the dart3d behaviour of
        /// deriving the shape from the node's realized geometry — explicit
        /// payload tokens resolve in W3. `boundingBox` returns nil so the
        /// body falls back to the geometry's box.
        func decodeShape(_ m: [String: Any], node: SCNNode)
            -> SCNPhysicsShape?
        {
            let kind = d3String(m["kind"]) ?? "box"
            switch kind {
            case "box":
                // `halfExtents` is already half size — the old `extents`
                // field was full size and is gone.
                let h = d3Vec3(m["halfExtents"]) ?? [0.5, 0.5, 0.5]
                return SCNPhysicsShape(geometry: SCNBox(
                    width: CGFloat(h[0] * 2), height: CGFloat(h[1] * 2),
                    length: CGFloat(h[2] * 2), chamferRadius: 0))
            case "sphere":
                return SCNPhysicsShape(geometry: SCNSphere(
                    radius: CGFloat(d3Double(m["radius"]) ?? 0.5)))
            case "capsule":
                let r = d3Double(m["radius"]) ?? 0.5
                // `halfHeight` is the cylindrical section's half length;
                // SCNCapsule wants the total height, caps included.
                let h = d3Double(m["halfHeight"]) ?? 0.5
                return SCNPhysicsShape(geometry: SCNCapsule(
                    capRadius: CGFloat(r),
                    height: CGFloat(2 * h + 2 * r)))
            case "cylinder":
                let r = d3Double(m["radius"]) ?? 0.5
                let h = d3Double(m["halfHeight"]) ?? 0.5
                return SCNPhysicsShape(geometry: SCNCylinder(
                    radius: CGFloat(r), height: CGFloat(2 * h)))
            case "convexHull":
                let value = m["vertices"] ?? m["points"]
                if let token = payloadToken(value),
                   let geometry = colliderGeometry(
                        vertices: token, indices: nil, kind: kind) {
                    return SCNPhysicsShape(
                        geometry: geometry,
                        options: [.type: SCNPhysicsShape.ShapeType.convexHull])
                }
                if value != nil, payloadToken(value) == nil {
                    host.logOnce("shape.\(kind).vertexToken",
                        "collider '\(kind)': invalid vertices payload token; "
                        + "deriving from node geometry")
                }
                return derivedShape(node, .convexHull, kind)
            case "triMesh", "concaveMesh":
                let vertexValue = m["vertices"]
                let indexValue = m["indices"]
                if let vertexToken = payloadToken(vertexValue),
                   let indexToken = payloadToken(indexValue),
                   let geometry = colliderGeometry(
                        vertices: vertexToken, indices: indexToken,
                        kind: kind) {
                    return SCNPhysicsShape(
                        geometry: geometry,
                        options: [.type:
                            SCNPhysicsShape.ShapeType.concavePolyhedron])
                }
                if vertexValue != nil || indexValue != nil,
                   payloadToken(vertexValue) == nil
                    || payloadToken(indexValue) == nil {
                    host.logOnce("shape.\(kind).payloadTokens",
                        "collider '\(kind)': vertices and indices payload "
                        + "tokens are required; deriving from node geometry")
                }
                return derivedShape(node, .concavePolyhedron, kind)
            case "heightField":
                host.logOnce("shape.heightField",
                    "collider 'heightField': deferred to W3+; skipped")
                return nil
            case "compound":
                var shapes: [SCNPhysicsShape] = []
                var transforms: [NSValue] = []
                for entry in d3List(m["children"]) ?? [] {
                    guard let child = d3Map(entry),
                          let childShape = d3Map(child["shape"])
                            .flatMap({ decodeShape($0, node: node) })
                    else { continue }
                    shapes.append(childShape)
                    transforms.append(NSValue(scnMatrix4:
                        d3Mat4(child["localPose"]) ?? SCNMatrix4Identity))
                }
                guard !shapes.isEmpty else {
                    d3Log("collider 'compound': no decodable children")
                    return nil
                }
                return SCNPhysicsShape(shapes: shapes,
                                       transforms: transforms)
            case "boundingBox":
                // Upstream semantics: the geometry's *declared* bounds
                // (payload `bounds` spec), which may be wider than the
                // vertices. `.boundingBox` shape-type derives from the
                // vertex box instead, so build the box explicitly.
                if let geo = node.geometry { return boundsBoxShape(geo) }
                return nil   // deferred fill when the geometry lands
            default:
                d3Log("unknown collider shape kind '\(kind)'")
                return nil
            }
        }

        func payloadToken(_ any: Any?) -> String? {
            any as? String ?? d3String(any)
        }

        func colliderGeometry(vertices token: String, indices: String?,
                              kind: String) -> SCNGeometry? {
            guard let key = D3Wire.localIdKey(token) else {
                host.logOnce("shape.\(kind).vertices.id",
                    "collider '\(kind)': invalid vertices payload token; "
                    + "deriving from node geometry")
                return nil
            }
            guard let spec = payloadSpecs[key] else {
                host.logOnce("shape.\(kind).vertices.spec.\(key)",
                    "collider '\(kind)': vertices payload has no spec; "
                    + "deriving from node geometry")
                return nil
            }
            guard let data = host.payloadStore[key] else {
                host.logOnce("shape.\(kind).vertices.awaiting.\(key)",
                    "collider '\(kind)': vertices payload unavailable; "
                    + "deriving from node geometry")
                return nil
            }
            guard let positions = colliderPositions(
                data, spec: spec, payloadKey: key, kind: kind) else {
                return nil
            }
            let count = positions.count / 3
            let source = floatSource(positions, .vertex, count, 3)
            guard let indexToken = indices else {
                return SCNGeometry(sources: [source], elements: [])
            }
            guard let element = colliderElement(
                indexToken, vertexCount: count, kind: kind) else { return nil }
            return SCNGeometry(sources: [source], elements: [element])
        }

        func colliderPositions(
            _ data: Data, spec: PayloadSpec, payloadKey: UInt64, kind: String
        ) -> [Float]? {
            let layout = spec.layout ?? "unskinned"
            let stride: Int
            let soa: Bool
            let nativeSpace: Bool
            switch spec.encoding {
            case "floats":
                stride = 12; soa = false; nativeSpace = false
            case "vertexBuffer":
                switch layout {
                case "unskinned_uv1_tangent":
                    stride = 72; soa = false; nativeSpace = false
                case "unskinned_soa_uv1_tangent":
                    stride = 72; soa = true; nativeSpace = false
                case "skinned_uv1_tangent":
                    stride = 104; soa = false; nativeSpace = false
                case "unskinned":
                    stride = 48; soa = false; nativeSpace = false
                case "unskinned_soa":
                    stride = 48; soa = true; nativeSpace = false
                case "skinned":
                    stride = 80; soa = false; nativeSpace = false
                case "p3t4":
                    stride = 28; soa = false; nativeSpace = true
                default:
                    host.logOnce("shape.\(kind).layout.\(layout)",
                        "collider '\(kind)': unknown vertex layout "
                        + "'\(layout)'; deriving from node geometry")
                    return nil
                }
            default:
                host.logOnce("shape.\(kind).encoding.\(spec.encoding)",
                    "collider '\(kind)': vertices encoding "
                    + "'\(spec.encoding)' is not floats or vertexBuffer; "
                    + "deriving from node geometry")
                return nil
            }
            guard !data.isEmpty, data.count % stride == 0 else {
                host.logOnce("shape.\(kind).vertexStride.\(payloadKey)",
                    "collider '\(kind)': malformed vertices payload; "
                    + "deriving from node geometry")
                return nil
            }
            let count = data.count / stride
            var positions: [Float] = []
            positions.reserveCapacity(count * 3)
            for i in 0..<count {
                let offset = data.startIndex + (soa ? i * 12 : i * stride)
                positions.append(D3Wire.f32LE(data, offset))
                positions.append(D3Wire.f32LE(data, offset + 4))
                let z = D3Wire.f32LE(data, offset + 8)
                positions.append(nativeSpace ? z : -z)
            }
            return positions
        }

        func colliderElement(_ token: String, vertexCount: Int, kind: String)
            -> SCNGeometryElement? {
            guard let key = D3Wire.localIdKey(token) else {
                host.logOnce("shape.\(kind).indices.id",
                    "collider '\(kind)': invalid indices payload token; "
                    + "deriving from node geometry")
                return nil
            }
            guard let spec = payloadSpecs[key] else {
                host.logOnce("shape.\(kind).indices.spec.\(key)",
                    "collider '\(kind)': indices payload has no spec; "
                    + "deriving from node geometry")
                return nil
            }
            guard spec.encoding == "indexBuffer" else {
                host.logOnce("shape.\(kind).indices.encoding.\(key)",
                    "collider '\(kind)': indices encoding "
                    + "'\(spec.encoding)' is not indexBuffer; deriving "
                    + "from node geometry")
                return nil
            }
            let format = spec.format ?? "uint16"
            let bytesPerIndex: Int
            switch format {
            case "uint16": bytesPerIndex = 2
            case "uint32": bytesPerIndex = 4
            default:
                host.logOnce("shape.\(kind).indices.format.\(format)",
                    "collider '\(kind)': unknown index format '\(format)'; "
                    + "deriving from node geometry")
                return nil
            }
            guard let data = host.payloadStore[key] else {
                host.logOnce("shape.\(kind).indices.awaiting.\(key)",
                    "collider '\(kind)': indices payload unavailable; "
                    + "deriving from node geometry")
                return nil
            }
            guard !data.isEmpty, data.count % (bytesPerIndex * 3) == 0 else {
                host.logOnce("shape.\(kind).indexStride.\(key)",
                    "collider '\(kind)': malformed triangle indices; "
                    + "deriving from node geometry")
                return nil
            }
            for offset in stride(from: 0, to: data.count,
                                 by: bytesPerIndex) {
                let index: UInt32
                if bytesPerIndex == 2 {
                    let lo = UInt16(data[data.startIndex + offset])
                    let hi = UInt16(data[data.startIndex + offset + 1])
                    index = UInt32(lo | hi << 8)
                } else {
                    index = D3Wire.u32LE(data, data.startIndex + offset)
                }
                guard index < UInt32(vertexCount) else {
                    host.logOnce("shape.\(kind).indexRange.\(key)",
                        "collider '\(kind)': triangle index is out of range; "
                        + "deriving from node geometry")
                    return nil
                }
            }
            return SCNGeometryElement(
                data: data, primitiveType: .triangles,
                primitiveCount: data.count / (bytesPerIndex * 3),
                bytesPerIndex: bytesPerIndex)
        }

        /// Builds a physics shape from the node's realized geometry.
        func derivedShape(_ node: SCNNode, _ t: SCNPhysicsShape.ShapeType,
                          _ kind: String) -> SCNPhysicsShape? {
            guard let geo = node.geometry else {
                d3Log("collider '\(kind)': node has no geometry")
                return nil
            }
            // Multi-primitive meshes park extra primitives on `d3prim:`
            // children — the shape covers every primitive; deriving
            // from primitive 0 alone under-covers the mesh.
            let extras = node.childNodes
                .filter { $0.name?.hasPrefix("d3prim:") == true }
                .compactMap { $0.geometry }
            guard !extras.isEmpty else {
                if t == .boundingBox { return boundsBoxShape(geo) }
                return SCNPhysicsShape(geometry: geo, options: [.type: t])
            }
            if t == .boundingBox {
                var lo = geo.boundingBox.min
                var hi = geo.boundingBox.max
                for g in extras {
                    lo = SCNVector3(
                        min(lo.x, g.boundingBox.min.x),
                        min(lo.y, g.boundingBox.min.y),
                        min(lo.z, g.boundingBox.min.z))
                    hi = SCNVector3(
                        max(hi.x, g.boundingBox.max.x),
                        max(hi.y, g.boundingBox.max.y),
                        max(hi.z, g.boundingBox.max.z))
                }
                return boundsBoxShape(min: lo, max: hi)
            }
            // Compound of per-primitive shapes — exact for
            // concaveMesh, a conservative union for convexHull.
            let parts = ([geo] + extras).map {
                SCNPhysicsShape(geometry: $0, options: [.type: t])
            }
            return SCNPhysicsShape(shapes: parts, transforms: nil)
        }

        /// A box collider matching the geometry's *declared* bounds —
        /// authored `bounds` win over vertex extents (that's the margin
        /// behavior boundsQuad-style colliders exist for). Falls back
        /// to nil for a degenerate (zero-size) box so callers can
        /// choose the auto-derive path.
        func boundsBoxShape(_ geo: SCNGeometry) -> SCNPhysicsShape? {
            boundsBoxShape(min: geo.boundingBox.min,
                           max: geo.boundingBox.max)
        }

        func boundsBoxShape(min bMin: SCNVector3,
                            max bMax: SCNVector3) -> SCNPhysicsShape? {
            let w = bMax.x - bMin.x
            let h = bMax.y - bMin.y
            let l = bMax.z - bMin.z
            guard w > 0, h > 0, l > 0 else { return nil }
            let shape = SCNPhysicsShape(geometry: SCNBox(
                width: CGFloat(w), height: CGFloat(h),
                length: CGFloat(l), chamferRadius: 0))
            let cx = (bMin.x + bMax.x) / 2
            let cy = (bMin.y + bMax.y) / 2
            let cz = (bMin.z + bMax.z) / 2
            if cx == 0 && cy == 0 && cz == 0 { return shape }
            return SCNPhysicsShape(shapes: [shape], transforms: [
                NSValue(scnMatrix4: SCNMatrix4Translate(
                    SCNMatrix4Identity, cx, cy, cz)),
            ])
        }

        /// Decodes one rigidBody component. Surface material and
        /// collision masks live on the sibling collider upstream;
        /// `velocity`/`angularVelocity` are dart3d extension properties
        /// (initial launch state upstream chooses not to persist).
        func decodeRigidBody(
            _ key: UInt64, _ node: SCNNode, _ p: [String: Any],
            collider: (shape: SCNPhysicsShape?, friction: Double?,
                       restitution: Double?, layer: Int?, mask: Int?,
                       trigger: Bool)?
        ) {
            let typeName = d3String(p["type"]) ?? "dynamic"
            let type: SCNPhysicsBodyType
            switch typeName {
            case "fixed":     type = .static
            case "kinematic": type = .kinematic
            case "dynamic":   type = .dynamic
            default:
                d3Log("unknown rigidBody type '\(typeName)'; using dynamic")
                type = .dynamic
            }
            let body = SCNPhysicsBody(type: type, shape: collider?.shape ?? nil)
            if let v = d3Double(p["mass"]) { body.mass = CGFloat(v) }
            if let v = collider?.friction { body.friction = CGFloat(v) }
            if let v = collider?.restitution { body.restitution = CGFloat(v) }
            if let v = d3Double(p["linearDamping"]) {
                body.damping = CGFloat(v)
            }
            if let v = d3Double(p["angularDamping"]) {
                body.angularDamping = CGFloat(v)
            }
            // Axis locks are per-axis motion factors (1 free, 0 locked) —
            // applied unmirrored, like every other factor field.
            if let v = d3Vec3(p["linearAxisLocks"]) {
                body.velocityFactor = SCNVector3(
                    Float(v[0]), Float(v[1]), Float(v[2]))
            }
            if let v = d3Vec3(p["angularAxisLocks"]) {
                body.angularVelocityFactor = SCNVector3(
                    Float(v[0]), Float(v[1]), Float(v[2]))
            }
            if let v = d3Bool(p["useGravity"]) {
                body.isAffectedByGravity = v
            }
            if let v = d3Bool(p["allowsResting"]) {
                body.allowsResting = v
            }
            if d3Bool(p["ccdEnabled"]) == true {
                // The threshold is the minimum per-step travel that
                // engages CCD — and 0.0 is Apple's "off" sentinel
                // ("discrete collision detection at all times"), not
                // always-on. The smallest nonzero threshold is the
                // closest SceneKit gets to the spec's always-on intent.
                body.continuousCollisionDetectionThreshold =
                    .leastNonzeroMagnitude
            }
            // SceneKit reserves category bits 0 (Default) and 1 (Static),
            // and static bodies force-exclude bit 1 from their collision
            // mask — a body categorised exactly 0x2 can never contact any
            // static. The wire's layer space shifts left 2 to clear the
            // reserved bits; an absent layer maps to user bit 0 so an
            // explicit mask of 0x1 still reaches unlayered bodies.
            body.categoryBitMask = (collider?.layer ?? 1) << 2
            if let v = collider?.mask { body.collisionBitMask = v << 2 }
            if collider?.trigger == true { body.collisionBitMask = 0 }
            // Upstream reports every contact, so the delegate gate is
            // open for all pairs — sensors included (their zero
            // collisionBitMask suppresses only the response).
            body.contactTestBitMask = ~0
            // dart3d extensions: initial velocities. Both convert through
            // the LH→RH z-mirror — linear as a vector, angular as
            // axis+rate with the axis mirrored like a quaternion axis.
            if let v = d3Vec3(p["velocity"]) {
                let w = D3Wire.position(v)
                body.velocity = SCNVector3(w.x, w.y, w.z)
            }
            if let a = d3Vec4(p["angularVelocity"]) {
                body.angularVelocity = SCNVector4(
                    Float(-a[0]), Float(-a[1]), Float(a[2]), Float(a[3]))
            }
            node.physicsBody = body
            // W23: a body rebuilt while a `collide:false` joint lives
            // must re-take its private category / mask adjustments.
            host.applyJointPairMasks(key, body)
            if type == .dynamic { dynamicBodyKeys.insert(key) }
        }

        func decodeMesh(_ key: UInt64, _ node: SCNNode,
                        _ p: [String: Any]) {
            // Upstream mesh vocab: a single-primitive mesh carries
            // direct `geometry`/`material` refs; a multi-primitive
            // mesh carries `primitives` — a tagged list whose entries
            // are `{"map":{geometry,material}}` PropertyValues.
            var primGeoKeys: [UInt64] = []
            var primMatKeys: [UInt64?] = []
            if let g = d3Ref(p["geometry"]) {
                primGeoKeys = [g]
                primMatKeys = [d3Ref(p["material"])]
            } else if let list = d3List(p["primitives"]) {
                for e in list {
                    guard let m = d3Map(e),
                          let g = d3Ref(m["geometry"]) else { continue }
                    primGeoKeys.append(g)
                    primMatKeys.append(d3Ref(m["material"]))
                }
            }
            // The consumer registers on the first primitive's key even
            // while the geometry is unresolved — a deferred geometry
            // still rebinds this node when its upsert/payload lands.
            // Extra primitives' consumers are their own child nodes,
            // registered once those children exist below.
            if let g0 = primGeoKeys.first {
                var list = geometryConsumers[g0] ?? []
                if !list.contains(where: { $0 === node }) {
                    list.append(node)
                    geometryConsumers[g0] = list
                }
            }
            // All-or-nothing — a partial build renders a fraction of
            // the mesh. Unresolved primitives defer the whole decode;
            // the manifest re-realizes when the payload lands.
            var primGeos: [SCNGeometry] = []
            for gk in primGeoKeys {
                guard let base = geometries[gk] else {
                    // No geometry yet — a skinned node can't take its
                    // skinner (the skinner holds the base geometry), so
                    // hold it pending for the geometry's arrival.
                    if nodeSkinKeys[key] != nil {
                        pendingSkinNodes.insert(key)
                    }
                    d3Log("mesh node '\(node.name ?? "?")': geometry unresolved")
                    return
                }
                primGeos.append((base.copy() as? SCNGeometry) ?? base)
            }
            guard let geo = primGeos.first else {
                if nodeSkinKeys[key] != nil {
                    pendingSkinNodes.insert(key)
                }
                d3Log("mesh node '\(node.name ?? "?")': geometry unresolved")
                return
            }
            // Per-primitive materials — each geometry copy registers
            // itself as the material's consumer so a surgical upsert
            // retargets the right primitive.
            for (i, g) in primGeos.enumerated() {
                guard let ref = primMatKeys[i],
                      let m = materials[ref] else { continue }
                g.materials = [m]
                if i == 0 {
                    recordShadowCatcherBinding(
                        key: ref, node: node, geometry: g,
                        material: m, materialIndex: 0,
                        isSnapshotClone: false)
                }
                let existing = materialConsumers[ref] ?? []
                if !existing.contains(where: { $0 === g }) {
                    materialConsumers[ref] = existing + [g]
                }
            }
            // SceneKit binds one geometry per node — extra primitives
            // ride anonymous children that inherit the node transform.
            // Rebuilt each decode so re-realizes don't duplicate them;
            // stale children are purged from the consumer maps so a
            // surgical upsert never retargets a detached node.
            let stalePrims = node.childNodes.filter {
                $0.name?.hasPrefix("d3prim:") == true
            }
            for child in stalePrims {
                for gk in geometryConsumers.keys {
                    geometryConsumers[gk]?.removeAll { $0 === child }
                }
                for mk in materialConsumers.keys {
                    materialConsumers[mk]?.removeAll {
                        $0 === child.geometry
                    }
                }
                if let geometry = child.geometry {
                    dropShadowCatcherBindings(geometry)
                }
                child.removeFromParentNode()
            }
            for i in 1..<primGeos.count {
                let child = SCNNode(geometry: primGeos[i])
                child.name = "d3prim:\(i)"
                child.categoryBitMask = node.categoryBitMask
                node.addChildNode(child)
                if let ref = primMatKeys[i],
                   let material = materials[ref] {
                    recordShadowCatcherBinding(
                        key: ref, node: child, geometry: primGeos[i],
                        material: material, materialIndex: 0,
                        isSnapshotClone: false)
                }
                var list = geometryConsumers[primGeoKeys[i]] ?? []
                if !list.contains(where: { $0 === child }) {
                    list.append(child)
                    geometryConsumers[primGeoKeys[i]] = list
                }
                if let morph = morphTargets[primGeoKeys[i]] {
                    attachMorph(child, morph)
                }
            }
            // A replaced geometry goes to the graveyard — the in-flight
            // pass's frozen storage can still reference it.
            if let old = node.geometry, old !== geo { host.retire(old) }
            node.geometry = geo
            // W16: the mesh took the draw slot — a decoded `lod`
            // suspends (last-write-wins, Android's `suspended`); a
            // pending mesh leaves the lod's binding live (the early
            // returns above never reach this write), and a later `lod`
            // re-decode restores itself through a fresh spec.
            if let spec = lods[key] {
                spec.suspended = true
                spec.ownsRenderable = false
                spec.bound = -1
                pendingLodNodes.remove(key)
            }
            // A collider decoded a nil shape while this geometry was
            // payload-deferred, so the body attached shapeless. Refit
            // the recorded derivation now that the geometry exists.
            if let t = host.pendingColliderShapes.removeValue(forKey: key) {
                let s = derivedShape(node, t, "deferred")
                if let body = node.physicsBody, body.physicsShape == nil {
                    body.physicsShape = s
                }
                if let ccProps = host.pendingCharacterControllers.removeValue(forKey: key) {
                    let lm = host.colliderLayerMaskByKey[key]
                    decodeCharacterController(
                        key, node, ccProps,
                        collider: (shape: s, friction: nil, restitution: nil,
                                   layer: lm?.layer, mask: lm?.mask, trigger: false))
                }
            }
            // W11: the geometry may carry morph targets; the node may
            // carry a `skin` member. Attach what's resolvable; anything
            // short registers in `pendingSkinNodes`. Morphs ride the
            // first primitive's streams (upstream's morphing contract).
            if let g0 = primGeoKeys.first,
               let morph = morphTargets[g0] {
                attachMorph(node, morph)
            } else if let old = node.morpher {
                host.retire(old)
                node.morpher = nil
            }
            attachSkin(key, node)
        }

        // MARK: Trails and LOD (W16)

        /// Decodes a `trail` component (upstream `TrailComponent`):
        /// spec fields into a `TrailState` and a `d3trail:` child to
        /// carry the ribbon. The path is runtime state — upstream's
        /// codec persists none of it, so a re-decode starts empty.
        /// Upstream does not serialize a trail material; the natives
        /// draw the translucent vertex-color unlit default.
        func decodeTrail(_ key: UInt64, _ node: SCNNode,
                         _ p: [String: Any]) {
            let st = TrailState(
                maxPoints: max(2, d3Int(p["maxPoints"]) ?? 48))
            st.width = d3Double(p["width"]) ?? 0.25
            st.lifetime = d3Double(p["lifetime"]) ?? 0.6
            st.minVertexDistance =
                d3Double(p["minVertexDistance"]) ?? 0.05
            st.emitting = d3Bool(p["emitting"]) ?? true
            // Upstream curve shape: `{keys: [{t, v}, …]}`.
            if let curve = d3Map(p["widthOverTrail"]),
               let keys = d3List(curve["keys"]) {
                var parsed: [(t: Double, v: Double)] = []
                for e in keys {
                    guard let m = d3Map(e),
                          let t = d3Double(m["t"]),
                          let v = d3Double(m["v"]) else { continue }
                    parsed.append((t, v))
                }
                st.widthKeys = parsed.isEmpty ? nil : parsed
            }
            // Upstream gradient shape: `{stops: [{t, color}, …]}`.
            if let grad = d3Map(p["colorOverTrail"]),
               let stops = d3List(grad["stops"]) {
                var parsed:
                    [(t: Double, r: Double, g: Double,
                      b: Double, a: Double)] = []
                for e in stops {
                    guard let m = d3Map(e),
                          let t = d3Double(m["t"]),
                          let c = d3ColorComponents(m["color"])
                    else { continue }
                    parsed.append((t, c[0], c[1], c[2], c[3]))
                }
                st.colorStops = parsed.isEmpty ? nil : parsed
            }
            node.addChildNode(st.child)
            trails[key] = st
        }

        /// Decodes an `lod` component (upstream `LodComponent`):
        /// `levels` entries carry geometry+material refs and a
        /// `screenSize` threshold (fraction of viewport height,
        /// descending); entries missing either ref are skipped like
        /// upstream's codec, while an absent/malformed `screenSize`
        /// decodes as `0.0` — upstream's fallback, the never-cull
        /// threshold (NOT a dropped level). `hysteresis` is
        /// upstream's dead-band (wire default 0.1); `blendRange`
        /// decodes for wire parity but is a documented no-op —
        /// dart3d hard-switches (upstream's cross-fade needs the
        /// per-material dither slot the natives don't carry).
        func decodeLod(_ key: UInt64, _ node: SCNNode,
                       _ p: [String: Any]) {
            let spec = LodSpec()
            for e in d3List(p["levels"]) ?? [] {
                guard let m = d3Map(e),
                      let g = d3Ref(m["geometry"]),
                      let mat = d3Ref(m["material"])
                else { continue }
                spec.levels.append(.init(
                    geoKey: g, matKey: mat,
                    screenSize: d3Double(m["screenSize"]) ?? 0.0))
            }
            spec.lodBias = d3Double(p["lodBias"]) ?? 1.0
            spec.hysteresis = d3Double(p["hysteresis"]) ?? 0.1
            spec.blendRange = d3Double(p["blendRange"]) ?? 0.0
            guard !spec.levels.isEmpty else { return }
            // A re-decode replaces the spec wholesale — purge the
            // outgoing level copies' material-consumer entries (they
            // die with the spec).
            if let old = lods[key] {
                for copy in old.geoCopies {
                    for mk in materialConsumers.keys {
                        materialConsumers[mk]?.removeAll { $0 === copy }
                    }
                    dropShadowCatcherBindings(copy)
                }
            }
            lods[key] = spec
            for l in spec.levels {
                lodResourceConsumers[l.geoKey, default: []].insert(key)
                lodResourceConsumers[l.matKey, default: []].insert(key)
            }
            rebindLod(key, node)
            // The initial draw is level 0 — upstream's base
            // MeshComponent mesh — until the frame pass selects
            // (Android's `decodeLod` binds 0 the same way). A pending
            // spec leaves the slot alone: the pass re-evaluates once
            // the resources land.
            host.bindLodLevel(spec, node, 0)
        }

        /// (Re)resolves a node's `lod` levels against the resource
        /// maps — every level's geometry copies and binds its
        /// material, and level 0's local AABB caches onto the spec
        /// for the frame pass. Called at decode and on every
        /// geometry/material landing that the spec consumes; a
        /// partial resolve leaves the node untouched and parks the
        /// key in `pendingLodNodes`. A resolved spec re-applies its
        /// bound level onto the fresh copies (Android's
        /// `refreshLodConsumers` force-rebind); a culled or
        /// never-bound spec leaves `node.geometry` alone — the frame
        /// pass re-evaluates it.
        func rebindLod(_ key: UInt64, _ node: SCNNode) {
            guard let spec = lods[key], !spec.suspended else { return }
            var geos: [SCNGeometry] = []
            geos.reserveCapacity(spec.levels.count)
            for l in spec.levels {
                guard let base = geometries[l.geoKey],
                      let mat = materials[l.matKey]
                else {
                    spec.resolved = false
                    pendingLodNodes.insert(key)
                    return
                }
                let g = (base.copy() as? SCNGeometry) ?? base
                g.materials = [mat]
                // Selection is dart3d's own — a SceneKit LOD set
                // copied off a base geometry must never drive.
                g.levelsOfDetail = nil
                geos.append(g)
            }
            // Fully resolved — swap the realized state wholesale: the
            // outgoing level copies purge their material-consumer
            // entries, the new copies register theirs.
            for old in spec.geoCopies {
                for mk in materialConsumers.keys {
                    materialConsumers[mk]?.removeAll { $0 === old }
                }
                dropShadowCatcherBindings(old)
            }
            for (i, g) in geos.enumerated() {
                let mk = spec.levels[i].matKey
                if !(materialConsumers[mk] ?? []).contains(where: {
                    $0 === g
                }) {
                    materialConsumers[mk] =
                        (materialConsumers[mk] ?? []) + [g]
                }
                if let material = materials[mk] {
                    recordShadowCatcherBinding(
                        key: mk, node: node, geometry: g,
                        material: material, materialIndex: 0,
                        isSnapshotClone: false)
                }
            }
            spec.geoCopies = geos
            spec.resolved = true
            pendingLodNodes.remove(key)
            // Cache level 0's local AABB — upstream's selection sphere
            // is the circumscribed sphere of the level-0 world AABB,
            // which the frame pass derives by transforming these 8
            // corners rather than re-reading `boundingBox`.
            let bb = geos[0].boundingBox
            spec.boundMin = simd_float3(
                Float(bb.min.x), Float(bb.min.y), Float(bb.min.z))
            spec.boundMax = simd_float3(
                Float(bb.max.x), Float(bb.max.y), Float(bb.max.z))
            if spec.bound >= 0 {
                host.bindLodLevel(spec, node, spec.bound, force: true)
            }
        }

        func decodeCamera(_ key: UInt64, _ node: SCNNode, _ p: [String: Any]) {
            let cam = SCNCamera()
            cameraFovOwners[key] = CameraFovOwner(cam,
                fov: d3Double(p["fovRadiansY"]) ?? .pi / 3,
                declarationCount: (cameraFovOwners[key]?.declarationCount ?? 0) + 1)
            if let n = d3Double(p["near"]) { cam.zNear = n }
            if let f = d3Double(p["far"]) { cam.zFar = f }
            if (p["projection"] as? [String: Any])?["s"] as? String == "orthographic" {
                cam.usesOrthographicProjection = true
                if let s = d3Double(p["orthoScale"] ?? p["orthographicScale"]) {
                    cam.orthographicScale = CGFloat(s)
                }
            }
            node.camera = cam
            if firstCameraNode == nil { firstCameraNode = node }
        }

        /// Light units are upstream's (flutter_scene 0.23): `intensity`
        /// scales the light's colour into the radiance a surface
        /// receives. SceneKit's physically based lights, measured:
        ///
        ///  * directional — a white Lambert surface facing the light
        ///    leaves `intensity / 1000`; upstream's leaves
        ///    `intensity / π`. Hence `× 1000 / π`.
        ///  * omni and spot — the surface receives `intensity / d²`,
        ///    which is upstream's definition. No scale.
        ///  * area — a panel of area A lights like an omni of
        ///    `A × intensity / 1000`; upstream's `intensity` is the
        ///    panel's radiance. Hence `× 1000`.
        ///
        /// SceneKit windows a light's range with the function upstream
        /// uses, `(1 − (d / range)⁴)²`, and ignores the falloff
        /// exponent for these lights. Its cone angles are whole
        /// angles in degrees; the wire's are half-angles in radians.
        /// Its ramp between the inner and the outer angle is wider
        /// than upstream's (0.64 where upstream's is 0.43, a third of
        /// the way in from the edge of a 15°/30° cone), so the cone is
        /// made hard at the outer angle and upstream's ramp is
        /// projected through it as the light's gobo.
        private static let spotConeImagesLock = NSLock()
        private static var spotConeImages: [String: CGImage] = [:]

        /// Upstream's (and Filament's) spot cone as an image a spot
        /// light projects: `sat((cos θ − cos outer) / (cos inner −
        /// cos outer))²` at the angle θ each texel is seen under, the
        /// image's edge lying on the outer angle.
        static func spotConeImage(inner: Double, outer: Double) -> CGImage? {
            let key = String(format: "%.4f|%.4f", inner, outer)
            spotConeImagesLock.lock()
            defer { spotConeImagesLock.unlock() }
            if let image = spotConeImages[key] { return image }
            let n = 256
            let tanOuter = tan(outer)
            let cosOuter = cos(outer)
            let span = max(cos(inner) - cosOuter, 1.0 / 1024.0)
            var bytes = [UInt8](repeating: 255, count: n * n * 4)
            for y in 0..<n {
                let v = (Double(y) + 0.5) / Double(n) * 2 - 1
                for x in 0..<n {
                    let u = (Double(x) + 0.5) / Double(n) * 2 - 1
                    let angle = atan((u * u + v * v).squareRoot() * tanOuter)
                    let t = min(max((cos(angle) - cosOuter) / span, 0), 1)
                    let value = UInt8((t * t * 255).rounded())
                    let i = (y * n + x) * 4
                    bytes[i] = value
                    bytes[i + 1] = value
                    bytes[i + 2] = value
                }
            }
            guard let provider = CGDataProvider(data: Data(bytes) as CFData),
                  let space = CGColorSpace(name: CGColorSpace.linearSRGB),
                  let image = CGImage(
                      width: n, height: n, bitsPerComponent: 8,
                      bitsPerPixel: 32, bytesPerRow: n * 4, space: space,
                      bitmapInfo: CGBitmapInfo(
                          rawValue: CGImageAlphaInfo.noneSkipLast.rawValue),
                      provider: provider, decode: nil,
                      shouldInterpolate: true, intent: .defaultIntent)
            else { return nil }
            spotConeImages[key] = image
            return image
        }

        func decodeLight(_ key: UInt64, _ node: SCNNode, _ p: [String: Any],
                         _ type: SCNLight.LightType) {
            let light = SCNLight()
            light.type = type
            if let c = d3Color(p["color"]) { light.color = c }
            lightIntensityOwners[key] = LightIntensityOwner(light,
                intensity: d3Double(p["intensity"]) ?? (type == .directional ? 3 : 1),
                declarationCount: (lightIntensityOwners[key]?.declarationCount ?? 0) + 1)
            if type != .directional {
                let range = d3Double(p["range"]) ?? 0
                light.attenuationStartDistance = 0
                light.attenuationEndDistance = CGFloat(max(range, 0))
            }
            if type == .spot {
                let outer = min(max(
                    d3Double(p["outerConeAngle"]) ?? .pi / 4, 0.01), 1.55)
                let inner = min(max(
                    d3Double(p["innerConeAngle"]) ?? 0, 0), outer)
                light.spotInnerAngle = CGFloat(outer * 2 * 180.0 / .pi)
                light.spotOuterAngle = CGFloat(outer * 2 * 180.0 / .pi)
                if let gobo = light.gobo {
                    gobo.contents = Self.spotConeImage(
                        inner: inner, outer: outer)
                    gobo.intensity = 1
                    gobo.wrapS = .clamp
                    gobo.wrapT = .clamp
                }
            }
            if type == .area {
                // rectAreaLight (W12): the emitter's rectangle — the
                // width/height pair SceneKit's area light needs before
                // it illuminates; drawsArea renders the source itself.
                light.areaType = .rectangle
                light.areaExtents = simd_float3(
                    Float(d3Double(p["width"]) ?? 1),
                    Float(d3Double(p["height"]) ?? 1), 0)
                light.drawsArea = true
            }
            if d3Bool(p["castsShadow"]) == true {
                // The 'low' view tier suppresses shadow casting;
                // 'high' doubles the map. `shadowAuthored` remembers
                // the flag so a tier change restores the light.
                host.shadowAuthored.insert(ObjectIdentifier(light))
                light.castsShadow = host.viewQuality != "low"
                if host.viewQuality == "high" {
                    light.shadowMapSize = CGSize(width: 2048,
                                                 height: 2048)
                }
                if let v = d3Double(p["shadowRadius"]) {
                    light.shadowRadius = CGFloat(v)
                }
                if let v = d3Double(p["shadowDepthBias"]) {
                    light.shadowBias = CGFloat(v)
                }
                // SceneKit stops drawing shadows 100 units from the
                // camera unless told otherwise. The wire has no such
                // default (Filament shadows the whole view frustum),
                // and a scene in larger units — the dice table's
                // camera sits 316 above the felt — got none at all.
                // A directional light's authored `shadowMaxDistance`
                // replaces this in `decodeDirectionalShadow`.
                light.maximumShadowDistance = 1e6
                // iOS takes one shadow sample per fragment by default,
                // which ignores `shadowRadius` and leaves the map's
                // texels as stair steps.
                light.shadowSampleCount = 16
            }
            if type == .directional {
                decodeDirectionalShadow(light, p)
            }
            node.light = light
        }

        /// W24: the upstream directional-light shadow vocabulary
        /// (flutter_scene `DirectionalLightCodec`, defaults noted per
        /// field) plus three dart3d wire extensions upstream keeps on
        /// `stage.skyEnvironment.sunLight` (`SunLightSpec`):
        /// `contactShadows`, `contactShadowDistance`, `angularRadius`
        /// — the sun block stays deferred on both platforms, so the
        /// fields ride the light component here. `priority` and
        /// `localDirection` are upstream codec members dart3d doesn't
        /// map — they warn below like the other unmapped fields.
        /// SceneKit renders ONE shadow map per directional — the
        /// cascade/contact/fade/ambient fields have no native
        /// counterpart and log once instead of pretending parity;
        /// what maps, maps absolutely (re-decode under diff updates
        /// writes the same state).
        func decodeDirectionalShadow(_ light: SCNLight,
                                     _ p: [String: Any]) {
            if let res = d3Double(p["shadowMapResolution"])
                ?? (p["shadowMapResolution"] as? NSNumber)?.doubleValue {
                let s = min(4096, max(64, res.rounded()))
                light.shadowMapSize = CGSize(width: s, height: s)
            }
            if let v = d3Double(p["shadowSoftness"]) {
                // World-space penumbra radius → SceneKit's blur
                // factor (texel-space-ish): direct assignment is the
                // closest analog, same convention 'shadowRadius'
                // already uses. Precedence: `shadowRadius` (W6) and
                // `shadowSoftness` (W24) write the same knob — this
                // decode runs second, so softness wins when a
                // document authors both.
                light.shadowRadius = CGFloat(v)
            }
            if let v = d3Double(p["shadowMaxDistance"]) {
                // Approximation: pin the ortho shadow projection at
                // the authored coverage — SceneKit's auto-fit
                // otherwise reframes the map every frame (the
                // wire field is a view-camera distance; the ortho
                // scale is the projection half-extent, so the map
                // covers roughly ±v around the fitted center).
                light.automaticallyAdjustsShadowProjection = false
                light.orthographicScale = CGFloat(v)
                // The field itself is a distance from the view camera
                // (Filament's `shadowFar` on Android).
                if v > 0 { light.maximumShadowDistance = CGFloat(v) }
            }
            // Dart-authored StringValues arrive tagged ({"s": …}) —
            // d3String first, a bare string as the fallback.
            let casterFaces = d3String(p["shadowCasterFaces"])
                ?? p["shadowCasterFaces"] as? String ?? "front"
            switch casterFaces {
            case "back":
                // Second-depth shadow mapping — SceneKit's one
                // native analog of the wire enum.
                light.forcesBackFaceCasters = true
            case "both":
                host.logOnce("w24.shadowCasterFaces.both",
                    "shadowCasterFaces 'both' approximated as 'front' "
                    + "on SceneKit")
            case "front":
                break
            default:
                host.logOnce(
                    "w24.shadowCasterFaces.\(casterFaces)",
                    "shadowCasterFaces '\(casterFaces)' "
                    + "unknown; kept 'front'")
            }
            // Present-but-unsupported members — one warning per field
            // per scene, not per light. The last three are the dart3d
            // wire extensions (upstream home: `sunLight`, deferred).
            for field in ["shadowCascadeCount",
                          "shadowCascadeSplitLambda",
                          "shadowFadeRange",
                          "shadowAmbientStrength",
                          "shadowNormalBias",
                          "cacheStaticShadows",
                          "contactShadows",
                          "contactShadowDistance",
                          "angularRadius"]
            where p[field] != nil {
                host.logOnce("w24.directional.\(field)",
                    "directionalLight '\(field)' has no SceneKit "
                    + "equivalent; ignored")
            }
            // Unmapped upstream `DirectionalLightCodec` members —
            // `priority` (feature priority) and `localDirection`
            // (travel dir; dart3d aims lights by node transform).
            for field in ["priority", "localDirection"]
            where p[field] != nil {
                host.logOnce("w24.directional.\(field)",
                    "directionalLight '\(field)' is an upstream field "
                    + "with no dart3d mapping; ignored")
            }
            if let f = p["shadowFilter"] as? String,
               f != "rotatedPoisson" {
                host.logOnce("w24.directional.shadowFilter.\(f)",
                    "shadowFilter '\(f)' unsupported on SceneKit — "
                    + "its PCF kernel is fixed; shadowSoftness still "
                    + "applies")
            }
        }

        // MARK: Particle emitters (W18)
        //
        // `particleEmitter`/`meshParticleEmitter` map onto
        // `SCNParticleSystem`. SceneKit simulates the system itself on
        // the render clock, so `fixedStep`/`maxFrameTime`/`seed`/
        // `bursts`/`maxParticles` have no native knob — those decode
        // but are reported once as unsupported (the Kotlin runtime
        // honors all of them; docs/particles-spec.md carries the
        // matrix). `enabled` is the first real `enabled` consumer in
        // dart3d: false attaches nothing (upstream gates update AND
        // repack — the equivalent is no system at all). `paused` maps
        // to speedFactor 0 — a frozen sim whose live particles keep
        // rendering.

        /// `{'kind': constant|uniform|curve|uniformCurve}` →
        /// (mean, halfVariation): SceneKit expresses a per-particle
        /// distribution as base ± uniform variation, so uniform maps
        /// exactly and curves collapse to their t=0 value (over-life
        /// shaping goes to the property controllers, which take the
        /// full curve).
        private func d3DistMeanVar(
            _ v: Any?, _ fallback: Double
        ) -> (CGFloat, CGFloat) {
            guard let m = d3Map(v) else {
                return (CGFloat(fallback), 0)
            }
            switch d3String(m["kind"]) ?? "constant" {
            case "uniform":
                let lo = d3Double(m["min"]) ?? fallback
                let hi = d3Double(m["max"]) ?? fallback
                return (CGFloat((lo + hi) / 2),
                        CGFloat(abs(hi - lo) / 2))
            case "curve":
                let scale = d3Double(m["scale"]) ?? 1
                return (CGFloat(
                    d3CurveSample(m["curve"], t: 0,
                                  fallback: fallback) * scale), 0)
            case "uniformCurve":
                let lo = d3CurveSample(m["min"], t: 0,
                                       fallback: fallback)
                let hi = d3CurveSample(m["max"], t: 0,
                                       fallback: fallback)
                return (CGFloat((lo + hi) / 2),
                        CGFloat(abs(hi - lo) / 2))
            default:
                return (CGFloat(d3Double(m["value"]) ?? fallback), 0)
            }
        }

        /// `{keys:[{t,v},…]}` piecewise-linear sample — the Dart
        /// `ParticleCurve` twin minus the LUT (SceneKit only needs the
        /// endpoints for the base±variation fold and the raw keys for
        /// property-controller keyframes).
        private func d3CurveKeys(_ v: Any?) -> [(t: Double, v: Double)] {
            guard let m = d3Map(v),
                  let keys = d3List(m["keys"]) else { return [] }
            var out: [(Double, Double)] = []
            for e in keys {
                guard let k = d3Map(e) else { continue }
                out.append((d3Double(k["t"]) ?? 0,
                            d3Double(k["v"]) ?? 0))
            }
            out.sort { $0.0 < $1.0 }
            return out
        }

        private func d3CurveSample(
            _ v: Any?, t: Double, fallback: Double
        ) -> Double {
            let keys = d3CurveKeys(v)
            guard let first = keys.first, let last = keys.last else {
                return fallback
            }
            if t <= first.t { return first.v }
            if t >= last.t { return last.v }
            for i in 0..<(keys.count - 1) {
                let a = keys[i], b = keys[i + 1]
                if t >= a.t && t <= b.t {
                    let span = b.t - a.t
                    if span <= 0 { return b.v }
                    return a.v + (b.v - a.v) * ((t - a.t) / span)
                }
            }
            return last.v
        }

        /// `{stops:[{t,color},…]}` → [(t, UIColor)] for the color-over-
        /// life property controller.
        private func d3GradientStops(_ v: Any?) -> [(t: Double, c: UIColor)] {
            guard let m = d3Map(v),
                  let stops = d3List(m["stops"]) else { return [] }
            var out: [(Double, UIColor)] = []
            for e in stops {
                guard let s = d3Map(e) else { continue }
                out.append((d3Double(s["t"]) ?? 0,
                            d3Color(s["color"]) ?? .white))
            }
            out.sort { $0.0 < $1.0 }
            return out
        }

        /// A decoded color distribution, split the way SceneKit can
        /// carry it: a base color ± a normalized HSB+alpha variation
        /// (`particleColorVariation` is hue/saturation/brightness/
        /// alpha — NOT per-channel RGBA), or a gradient over life.
        private enum ParticleColor {
            case fixed(UIColor, SCNVector4)
            case gradient([(t: Double, c: UIColor)])
        }

        /// `{'kind': constant|uniform|gradient}` → `ParticleColor`.
        /// `uniform` is the reference's correlated lerp `a + (b−a)·r`
        /// (one random scalar for the whole RGBA tuple); SceneKit has
        /// no such knob, so it approximates as the RGB midpoint ±
        /// half the HSB/alpha distance between the endpoints — each
        /// dimension varies independently, so colors off the a→b
        /// segment are possible (documented limit).
        private func d3ParticleColor(_ v: Any?) -> ParticleColor {
            guard let m = d3Map(v) else { return .fixed(.white, .init()) }
            switch d3String(m["kind"]) ?? "constant" {
            case "uniform":
                let a = d3ColorComponents(m["a"]) ?? [1, 1, 1, 1]
                let b = d3ColorComponents(m["b"]) ?? [1, 1, 1, 1]
                let mid = Self.linearColor(
                    (a[0] + b[0]) / 2, (a[1] + b[1]) / 2,
                    (a[2] + b[2]) / 2, (a[3] + b[3]) / 2)
                return .fixed(mid, hsbVariation(a, b))
            case "gradient":
                let stops = d3GradientStops(m["gradient"])
                guard !stops.isEmpty else { return .fixed(.white, .init()) }
                return .gradient(stops)
            default:
                return .fixed(d3Color(m["color"]) ?? .white, .init())
            }
        }

        /// Half the HSB/alpha distance between two RGBA endpoints, in
        /// SceneKit's normalized variation units. Hue wraps (the
        /// shorter way round the wheel).
        private func hsbVariation(_ a: [Double], _ b: [Double])
            -> SCNVector4 {
            func hsb(_ c: [Double]) -> (CGFloat, CGFloat, CGFloat) {
                var h: CGFloat = 0, s: CGFloat = 0, v: CGFloat = 0
                var al: CGFloat = 0
                UIColor(red: c[0], green: c[1], blue: c[2], alpha: 1)
                    .getHue(&h, saturation: &s, brightness: &v,
                            alpha: &al)
                return (h, s, v)
            }
            let ha = hsb(a), hb = hsb(b)
            var dh = abs(ha.0 - hb.0)
            if dh > 0.5 { dh = 1 - dh }
            return SCNVector4(Float(dh / 2),
                              Float(abs(ha.1 - hb.1) / 2),
                              Float(abs(ha.2 - hb.2) / 2),
                              Float(abs(b[3] - a[3]) / 2))
        }

        /// The color-over-life keyframe animation for gradient stops.
        private func gradientAnimation(
            _ stops: [(t: Double, c: UIColor)]
        ) -> CAKeyframeAnimation {
            let anim = CAKeyframeAnimation()
            anim.keyTimes = stops.map { NSNumber(value: $0.t) }
            anim.values = stops.map { $0.c }
            return anim
        }

        /// Applies one decoded module's contribution — acceleration
        /// folds into `sys.acceleration`, linearDrag into
        /// `dampingFactor`, size-over-life into a property
        /// controller, flipbook into the image-sequence knobs.
        /// `colorOverLife` is resolved by the caller (it interacts
        /// with startColor). `turbulence` has no SceneKit counterpart.
        private func applyParticleModule(
            _ sys: SCNParticleSystem, _ m: [String: Any],
            sizeMean: CGFloat, lifeSpan: CGFloat,
            flipbookCols: Int, flipbookRows: Int,
            logKey: String
        ) {
            switch d3String(m["kind"]) ?? "" {
            case "acceleration":
                if let a = d3Vec3(m["acceleration"]), a.count == 3 {
                    sys.acceleration = SCNVector3(
                        sys.acceleration.x + Float(a[0]),
                        sys.acceleration.y + Float(a[1]),
                        sys.acceleration.z - Float(a[2]))
                }
            case "linearDrag":
                sys.dampingFactor =
                    CGFloat(d3Double(m["coefficient"]) ?? 0)
            case "sizeOverLife":
                // A Scale curve bakes against the mean size — the
                // controller writes absolute values, so per-particle
                // size variance under a uniform startSize is lost
                // (documented in particles-spec.md).
                if let d = d3Map(m["scale"]) {
                    applySizeOverLife(sys, d3FloatDistKeys(d),
                                      sizeMean: sizeMean)
                }
            case "flipbook":
                let cells = min(max(flipbookCols, 1), Self.maxFlipbookAxis)
                    * min(max(flipbookRows, 1), Self.maxFlipbookAxis)
                let count = max(1, min(d3Int(m["frameCount"]) ?? cells,
                                       cells))
                sys.imageSequenceColumnCount = max(flipbookCols, 1)
                sys.imageSequenceRowCount = max(flipbookRows, 1)
                if let fps = d3Double(m["framesPerSecond"]), fps > 0 {
                    if count < cells {
                        // SceneKit's rate-driven sequence walks EVERY
                        // atlas cell; the reference wraps
                        // `age·fps mod frameCount`. Drive the frame
                        // index directly: a sawtooth over the mean
                        // lifespan (per-particle lifespan variation
                        // shifts the wrap points — approximate).
                        applyFlipbookSawtooth(sys, fps: fps,
                                              count: count,
                                              lifeSpan: lifeSpan,
                                              logKey: logKey)
                    } else {
                        sys.imageSequenceFrameRate = CGFloat(fps)
                    }
                } else {
                    // No fps → the strip plays once over the life.
                    sys.imageSequenceFrameRate = lifeSpan > 0
                        ? CGFloat(count) / lifeSpan : 0
                    sys.imageSequenceAnimationMode = .clamp
                }
                if d3Bool(m["randomStartFrame"]) == true {
                    sys.imageSequenceInitialFrame = 0
                    sys.imageSequenceInitialFrameVariation =
                        CGFloat(max(count - 1, 0))
                }
            case "rotation":
                break   // SceneKit integrates angular velocity natively
            case "turbulence":
                host.logOnce("\(logKey).turbulence",
                    "particleEmitter: 'turbulence' module has no "
                    + "SCNParticleSystem counterpart — skipped")
            default:
                host.logOnce("\(logKey).module.\(d3String(m["kind"]) ?? "?")",
                    "particleEmitter: unknown module kind — skipped")
            }
        }

        /// Size-over-life keys → an over-life `.size` controller
        /// (absolute values: scale × the mean start size).
        private func applySizeOverLife(
            _ sys: SCNParticleSystem, _ keys: [(t: Double, v: Double)],
            sizeMean: CGFloat
        ) {
            guard !keys.isEmpty else { return }
            let anim = CAKeyframeAnimation()
            anim.keyTimes = keys.map { NSNumber(value: $0.t) }
            anim.values = keys.map {
                NSNumber(value: Double(sizeMean) * $0.v)
            }
            let ctl = SCNParticlePropertyController(animation: anim)
            ctl.inputMode = .overLife
            var pcs = sys.propertyControllers ?? [:]
            pcs[.size] = ctl
            sys.propertyControllers = pcs
        }

        /// fps flipbook limited to `count` < atlas cells: an over-life
        /// `.frame` controller whose keys ramp 0→count and wrap every
        /// `count/fps` seconds of the mean lifespan (discrete, so the
        /// index holds whole cells). Capped at 128 wraps.
        private func applyFlipbookSawtooth(
            _ sys: SCNParticleSystem, fps: Double, count: Int,
            lifeSpan: CGFloat, logKey: String
        ) {
            let life = Double(lifeSpan)
            guard life > 0 else { return }
            let period = Double(count) / fps       // seconds per loop
            // Clamp in Double first: a huge fps/lifetime makes the
            // quotient exceed Int.max (or overflow to inf), and the
            // Int conversion would trap before `min` could cap it.
            let q = (life / period).rounded(.up)
            guard !q.isNaN, q > 0 else { return }
            let wraps = Int(min(q, 128))
            var times: [NSNumber] = []
            var values: [NSNumber] = []
            for w in 0..<max(wraps, 1) {
                let t0 = Double(w) * period / life
                guard t0 < 1 else { break }
                if times.count >= Self.maxFlipbookKeys { break }
                for f in 0..<count {
                    if times.count >= Self.maxFlipbookKeys { break }
                    let t = t0 + Double(f) / fps / life
                    guard t < 1 else { break }
                    times.append(NSNumber(value: t))
                    values.append(NSNumber(value: f))
                }
            }
            // keyTimes must end at 1 for a discrete animation.
            times.append(1)
            values.append(values.last ?? 0)
            let anim = CAKeyframeAnimation()
            anim.calculationMode = .discrete
            anim.keyTimes = times
            anim.values = values
            let ctl = SCNParticlePropertyController(animation: anim)
            ctl.inputMode = .overLife
            var pcs = sys.propertyControllers ?? [:]
            pcs[.frame] = ctl
            sys.propertyControllers = pcs
            sys.imageSequenceFrameRate = 0
            host.logOnce("\(logKey).flipbookSawtooth",
                "particleEmitter: fps flipbook with frameCount \(count) "
                + "< atlas cells — frame index driven over the mean "
                + "lifespan (approximate under lifetime variation)")
        }

        /// Curve/uniformCurve float distributions → keyframes for a
        /// size controller; constant/uniform fold to a one-key curve.
        private func d3FloatDistKeys(_ m: [String: Any])
            -> [(t: Double, v: Double)] {
            switch d3String(m["kind"]) ?? "constant" {
            case "curve":
                let scale = d3Double(m["scale"]) ?? 1
                return d3CurveKeys(m["curve"]).map {
                    (t: $0.t, v: $0.v * scale)
                }
            case "uniformCurve":
                // Fold to the midpoint curve — the controller writes
                // absolute values, so per-particle spread is lost.
                // The two curves can have different key times/counts:
                // sample both on the union timeline (an ordinal zip
                // paired unrelated keys and dropped the longer tail).
                let times = Set(d3CurveKeys(m["min"]).map { $0.t }
                    + d3CurveKeys(m["max"]).map { $0.t }).sorted()
                return times.map { t in
                    (t: t,
                     v: (d3CurveSample(m["min"], t: t, fallback: 0)
                         + d3CurveSample(m["max"], t: t, fallback: 0)) / 2)
                }
            case "uniform":
                let lo = d3Double(m["min"]) ?? 0
                let hi = d3Double(m["max"]) ?? 0
                return [(0, (lo + hi) / 2)]
            default:
                return [(0, d3Double(m["value"]) ?? 0)]
            }
        }

        /// The legacy flat stack — a component without `modules`
        /// carries `drag`/`sizeOverLife`/`colorOverLife` as flat
        /// members (the Dart reference and Android decoders both
        /// synthesize it). An absent curve/gradient means "no
        /// shaping": size ×1, color constant opaque white — the
        /// reference's own legacy default, which overrides
        /// startColor.
        private func legacyParticleModules(_ p: [String: Any]) -> [Any] {
            var out: [Any] = []
            let drag = d3Double(p["drag"]) ?? 0
            if drag > 0 {
                out.append(["kind": "linearDrag", "coefficient": drag])
            }
            if p["sizeOverLife"] != nil {
                out.append(["kind": "sizeOverLife",
                            "scale": ["kind": "curve",
                                      "curve": p["sizeOverLife"]!,
                                      "scale": 1.0]])
            }
            out.append(["kind": "colorOverLife",
                        "color": p["colorOverLife"] != nil
                            ? ["kind": "gradient",
                               "gradient": p["colorOverLife"]!]
                            : ["kind": "constant",
                               "color": [1.0, 1.0, 1.0, 1.0]]])
            return out
        }

        /// Builds and attaches the `SCNParticleSystem` for a
        /// `particleEmitter`/`meshParticleEmitter` component — or not:
        /// `enabled:false` attaches nothing (W18 makes `enabled` the
        /// first component flag with a live tick to gate).
        func decodeParticleEmitter(key: UInt64, node: SCNNode,
                                   index: Int, props: [String: Any],
                                   mesh: Bool) {
            let logKey = "particles.\(key).\(index)"
            if d3Bool(props["enabled"]) == false {
                let kind = mesh ? "meshParticleEmitter" : "particleEmitter"
                host.logOnce("\(logKey).enabled",
                    "component '\(kind)' on node \(key): enabled:false "
                    + "— emitter not attached (the first component with "
                    + "a real tick gate)")
                return
            }
            // The component contract skips an incomplete mesh
            // emitter — the sprite degrade would otherwise draw
            // white/default sprites for it.
            if mesh, (d3List(props["geometries"])?.isEmpty ?? true)
                || d3Ref(props["material"]) == nil {
                host.logOnce("\(logKey).meshIncomplete",
                    "meshParticleEmitter on node \(key): missing "
                    + "geometries or material — skipped")
                return
            }
            let sys = SCNParticleSystem()
            sys.isLocal = true  // upstream simulates in node space
            sys.birthRate =
                CGFloat(max(d3Double(props["emitRate"]) ?? 32, 0))
            // looping → emit forever: loops repeats the emit/idle
            // cycle and idleDuration defaults to 0, so emission is
            // gapless. emissionDuration must be a SMALL finite value
            // on iOS 26.5 — 0, .infinity, and 1e6 all emit NOTHING
            // (device-proven; likely a birthRate×duration budget).
            // A nonpositive duration normalizes to the 5 s format
            // default first (Dart/Android do the same) — 0 is exactly
            // the emit-nothing value.
            let looping = d3Bool(props["looping"]) ?? true
            sys.loops = looping
            let rawDuration = d3Double(props["duration"]) ?? 5
            let duration = rawDuration > 0 && rawDuration.isFinite
                ? rawDuration : 5
            sys.emissionDuration = CGFloat(duration)
            sys.warmupDuration =
                CGFloat(d3Double(props["prewarm"]) ?? 0)

            let (life, lifeVar) =
                d3DistMeanVar(props["lifetime"], 1.5)
            sys.particleLifeSpan = life
            sys.particleLifeSpanVariation = lifeVar
            let (speed, speedVar) =
                d3DistMeanVar(props["startSpeed"], 1.5)
            sys.particleVelocity = speed
            sys.particleVelocityVariation = speedVar
            let (size, sizeVar) =
                d3DistMeanVar(props["startSize"], 0.3)
            sys.particleSize = size
            sys.particleSizeVariation = sizeVar
            // SceneKit's particleAngle/particleAngularVelocity are
            // DEGREES (and degrees/s) per SCNParticleSystem.h — the
            // wire's radians convert here, like spreadingAngle.
            let deg = 180.0 / Double.pi
            let (rot, rotVar) =
                d3DistMeanVar(props["startRotation"], 0)
            sys.particleAngle = CGFloat(rot * deg)
            sys.particleAngleVariation = CGFloat(rotVar * deg)
            let (avel, avelVar) =
                d3DistMeanVar(props["startAngularVelocity"], 0)
            sys.particleAngularVelocity = CGFloat(avel * deg)
            sys.particleAngularVelocityVariation = CGFloat(avelVar * deg)

            // Emitter shape → emitterShape + direction knobs. All
            // fscene vectors mirror z entering SceneKit space. An
            // absent `shape` is the format's default cone (radius
            // 0.25, angle 0.3) — or the legacy flat `shapeType`/
            // `shapeRadius`/`shapeAngle` members when present, as the
            // Dart/Android decoders synthesize.
            var emitDir = SIMD3<Double>(0, 1, 0)
            let shape: [String: Any] = d3Map(props["shape"]) ?? {
                let r = max(d3Double(props["shapeRadius"]) ?? 0.25, 0)
                let a = max(d3Double(props["shapeAngle"]) ?? 0.3, 0)
                switch d3String(props["shapeType"]) ?? "cone" {
                case "point": return ["kind": "point"]
                case "sphere": return ["kind": "sphere", "radius": r]
                case "box":
                    return ["kind": "box", "halfExtents": [r, r, r]]
                default:
                    return ["kind": "cone", "radius": r, "angle": a]
                }
            }()
            switch d3String(shape["kind"]) ?? "cone" {
            case "point":
                if let d = d3Vec3(shape["direction"]),
                   d.count == 3 {
                    emitDir = SIMD3(d[0], d[1], d[2])
                }
            case "sphere":
                let r = d3Double(shape["radius"]) ?? 1
                sys.emitterShape =
                    SCNSphere(radius: CGFloat(r))
                sys.birthLocation =
                    d3Bool(shape["surfaceOnly"]) == true
                    ? .surface : .volume
                sys.birthDirection = .surfaceNormal
                if d3Bool(shape["hemisphere"]) == true {
                    host.logOnce("\(logKey).hemisphere",
                        "particleEmitter: sphere 'hemisphere' has "
                        + "no SceneKit counterpart — full sphere")
                }
            case "box":
                if let he = d3Vec3(shape["halfExtents"]),
                   he.count == 3 {
                    sys.emitterShape = SCNBox(
                        width: CGFloat(he[0] * 2),
                        height: CGFloat(he[1] * 2),
                        length: CGFloat(he[2] * 2),
                        chamferRadius: 0)
                    sys.birthLocation = .volume
                }
                if let d = d3Vec3(shape["direction"]),
                   d.count == 3 {
                    emitDir = SIMD3(d[0], d[1], d[2])
                }
            default:  // cone — the format default
                let r = d3Double(shape["radius"]) ?? 0
                if r > 0 {
                    // A zero-height cylinder's volume is the disc
                    // the cone emits from.
                    sys.emitterShape = SCNCylinder(
                        radius: CGFloat(r), height: 0.001)
                    sys.birthLocation = .volume
                }
                sys.spreadingAngle = CGFloat(
                    (d3Double(shape["angle"]) ?? 0.5) * deg)
            }
            sys.emittingDirection = SCNVector3(
                Float(emitDir.x), Float(emitDir.y), Float(-emitDir.z))

            // Constant acceleration: `gravity` plus every
            // acceleration module folds into sys.acceleration.
            if let g = d3Vec3(props["gravity"]), g.count == 3 {
                sys.acceleration = SCNVector3(
                    Float(g[0]), Float(g[1]), Float(-g[2]))
            }

            // Sprite render knobs.
            switch d3String(props["blendMode"]) ?? "alpha" {
            case "additive":
                sys.blendMode = .additive
            default:
                sys.blendMode = .alpha
                sys.sortingMode = .projectedDepth
            }
            switch d3String(props["facing"]) ?? "spherical" {
            case "axisLocked":
                sys.orientationMode = .billboardYAligned
            case "velocityStretched":
                sys.orientationMode = .billboardViewAligned
                sys.stretchFactor =
                    CGFloat(d3Double(props["velocityStretch"]) ?? 0)
            default:
                sys.orientationMode = .billboardViewAligned
            }
            if d3Bool(props["randomFlipX"]) == true {
                host.logOnce("\(logKey).randomFlipX",
                    "particleEmitter: 'randomFlipX' has no SceneKit "
                    + "counterpart — skipped")
            }
            if let ar = d3Double(props["aspectRatio"]), ar != 1.0 {
                host.logOnce("\(logKey).aspectRatio",
                    "particleEmitter: 'aspectRatio' has no SceneKit "
                    + "counterpart — square sprites")
            }
            if let texKey = d3Ref(props["texture"]),
               let tex = textures[texKey]?.contents {
                sys.particleImage = tex
            }
            // Clamped before any product: two huge-but-valid Int dims
            // overflow `cols * rows` and trap. 4096 per axis is far past
            // any usable atlas (a cell must still be ≥ 1 texel).
            let flipCols = min(max(d3Int(props["flipbookColumns"]) ?? 1, 1),
                               Self.maxFlipbookAxis)
            let flipRows = min(max(d3Int(props["flipbookRows"]) ?? 1, 1),
                               Self.maxFlipbookAxis)
            if flipCols > 1 || flipRows > 1 {
                sys.imageSequenceColumnCount = flipCols
                sys.imageSequenceRowCount = flipRows
            }

            // Mesh emitters degrade to an untextured sprite pass on
            // iOS (SCNParticleSystem is sprite-only) tinted by the
            // material's AUTHORED baseColor factor — read from the
            // material def, since `diffuse.contents` holds the image
            // once a base-color texture binds. Per-particle color is
            // inert on mesh emitters (upstream parity): startColor
            // and colorOverLife don't apply.
            if mesh {
                if let matKey = d3Ref(props["material"]) {
                    let mp = resourceDefs[matKey]?["properties"]
                        as? [String: Any]
                    if let c = d3Color(mp?["baseColor"]) {
                        sys.particleColor = c
                    } else if let c = materials[matKey]?.diffuse.contents
                                as? UIColor {
                        sys.particleColor = c
                    }
                }
                host.logOnce("\(logKey).meshDegrade",
                    "meshParticleEmitter on node \(key): realized as a "
                    + "sprite pass (SCNParticleSystem is sprite-only)")
            } else {
                // startColor samples ONCE at spawn — a gradient
                // contributes its age-0 color (the reference samples
                // `startColor` at normalized age 0); only a
                // colorOverLife module animates over life.
                switch d3ParticleColor(props["startColor"]) {
                case .fixed(let c, let v):
                    sys.particleColor = c
                    sys.particleColorVariation = v
                case .gradient(let stops):
                    sys.particleColor = stops[0].c
                }
            }

            // Modules, in list order. A component without `modules`
            // gets the legacy flat stack.
            var drag = 0.0
            var colorOverLife: CAKeyframeAnimation?
            let modules = d3List(props["modules"])
                ?? legacyParticleModules(props)
            for e in modules {
                guard let m = d3Map(e) else { continue }
                if d3String(m["kind"]) == "linearDrag" {
                    drag += d3Double(m["coefficient"]) ?? 0
                    continue
                }
                if d3String(m["kind"]) == "colorOverLife" {
                    // Inert on mesh emitters; otherwise it OVERWRITES
                    // the color each tick (reference semantics): a
                    // gradient animates, constant/uniform replace the
                    // spawn color outright.
                    guard !mesh, let dist = d3Map(m["color"]) else {
                        continue
                    }
                    switch d3ParticleColor(dist) {
                    case .gradient(let stops):
                        colorOverLife = gradientAnimation(stops)
                    case .fixed(let c, let v):
                        colorOverLife = nil
                        sys.particleColor = c
                        sys.particleColorVariation = v
                    }
                    continue
                }
                applyParticleModule(
                    sys, m, sizeMean: sys.particleSize,
                    lifeSpan: sys.particleLifeSpan,
                    flipbookCols: flipCols, flipbookRows: flipRows,
                    logKey: logKey)
            }
            if drag > 0 { sys.dampingFactor = CGFloat(drag) }
            if let anim = colorOverLife {
                let ctl = SCNParticlePropertyController(animation: anim)
                ctl.inputMode = .overLife
                var pcs = sys.propertyControllers ?? [:]
                pcs[.color] = ctl
                sys.propertyControllers = pcs
            }

            if d3Bool(props["paused"]) == true {
                sys.speedFactor = 0   // frozen sim, particles still draw
            }
            if props["seed"] != nil || props["fixedStep"] != nil
                || props["maxFrameTime"] != nil
                || props["maxParticles"] != nil {
                host.logOnce("\(logKey).simKnobs",
                    "particleEmitter on node \(key): seed/fixedStep/"
                    + "maxFrameTime/maxParticles have no SceneKit "
                    + "counterpart — the render clock drives the sim")
            }

            node.addParticleSystem(sys)
            scheduleParticleBursts(sys, node: node, props: props,
                                   looping: looping, duration: duration,
                                   prewarm: Double(sys.warmupDuration),
                                   index: index, logKey: logKey)
        }

        /// The action-key prefix every burst schedule runs under — a
        /// components re-decode strips them with the particle systems.
        static let burstActionPrefix = "d3burst:"

        /// Per-axis flipbook atlas cap (overflow guard, see decode).
        static let maxFlipbookAxis = 4096
        /// Keyframe cap for the fps-flipbook sawtooth controller.
        static let maxFlipbookKeys = 4096

        /// `bursts` have no SCNParticleSystem knob; each burst becomes
        /// a copy of the emitter's system that emits `count`
        /// particles in one 1/60 s window (birthRate·window = count):
        /// a node action waits `time`, then attaches it. A repeating
        /// burst (`interval` > 0) loops that window every `interval`
        /// (`idleDuration`); `cycles`, or a non-looping emitter's
        /// `duration` (the reference stops spawning there), end it by
        /// zeroing the copy's birthRate — live particles finish their
        /// lives. Bursts at/after a non-looping emitter's duration
        /// never fire. Approximate: SceneKit meters births per frame,
        /// so counts can be off by a frame's rounding.
        private func scheduleParticleBursts(
            _ base: SCNParticleSystem, node: SCNNode,
            props: [String: Any], looping: Bool, duration: Double,
            prewarm: Double, index: Int, logKey: String
        ) {
            guard let bursts = d3List(props["bursts"]),
                  !bursts.isEmpty else { return }
            let window = 1.0 / 60.0
            var scheduled = 0
            for (bi, e) in bursts.enumerated() {
                guard let m = d3Map(e) else { continue }
                let time = max(d3Double(m["time"]) ?? 0, 0)
                let count = max(d3Int(m["count"]) ?? 0, 0)
                let interval = d3Double(m["interval"]) ?? 0
                let cycles = d3Int(m["cycles"]).map { max($0, 1) }
                guard count > 0, time.isFinite else { continue }
                if !looping && time >= duration { continue }
                guard let sys = base.copy() as? SCNParticleSystem
                else { continue }
                sys.birthRate = CGFloat(Double(count) / window)
                sys.birthRateVariation = 0
                sys.emissionDuration = CGFloat(window)
                sys.emissionDurationVariation = 0
                sys.warmupDuration = 0
                var stopAfter: Double? = nil   // seconds after start
                if interval > 0 && interval < window {
                    // Sub-frame interval: the reference counts every
                    // interval crossing inside a step, so the burst is
                    // really a rate — count/interval per second. Emit
                    // it continuously; a total that fits in one window
                    // (cycles·interval < window) goes out as one window
                    // carrying cycles·count births.
                    let span = cycles.map { Double($0) * interval }
                    if let span, span < window {
                        sys.birthRate = CGFloat(
                            Double(count) * Double(cycles!) / window)
                        sys.loops = false
                    } else {
                        sys.birthRate = CGFloat(Double(count) / interval)
                        sys.loops = true
                        sys.idleDuration = 0
                        stopAfter = span
                    }
                } else if interval > 0 {
                    sys.loops = true
                    sys.idleDuration = CGFloat(max(interval - window, 0))
                    if let cycles {
                        stopAfter = Double(cycles) * interval - window / 2
                    }
                } else {
                    sys.loops = false
                }
                if !looping {
                    let cap = duration - time
                    stopAfter = min(stopAfter ?? cap, cap)
                }
                // Prewarm advances the reference's system clock through
                // the spawner too, so bursts inside the warmup fire
                // during it: live start = time − prewarm. A burst that
                // started in the warmup attaches at once, warmed by
                // the part of the warmup after its start (its
                // particles have aged that long); its stop shifts by
                // the same amount.
                let delay = time - (prewarm.isFinite ? max(prewarm, 0) : 0)
                var aged = max(-delay, 0)
                // A finite repeating burst (cycles, or a non-looping
                // emitter's duration) whose stop falls inside the
                // warmup: SceneKit can't stop mid-warmup, so warming the
                // whole elapsed span would invent extra repetitions.
                // Fully expired (stop + longest particle life already
                // passed) → skip; otherwise warm only up to the stop
                // and zero births on the first frame — the survivors
                // are younger than the reference's by (aged − stop),
                // a documented approximation.
                if interval > 0, let stop = stopAfter, aged > stop {
                    let maxLife = Double(sys.particleLifeSpan
                        + sys.particleLifeSpanVariation)
                    if aged - stop >= maxLife { continue }
                    aged = max(stop, 0)
                }
                sys.warmupDuration = CGFloat(aged)
                var steps: [SCNAction] = []
                if delay > 0 { steps.append(.wait(duration: delay)) }
                steps.append(.run { n in n.addParticleSystem(sys) })
                if let stop = stopAfter, interval > 0 {
                    // At least one frame so the warmup runs emitting.
                    steps.append(.wait(duration: max(stop - aged, window)))
                    steps.append(.run { _ in sys.birthRate = 0 })
                }
                node.runAction(.sequence(steps),
                    forKey: "\(Self.burstActionPrefix)\(index).\(bi)")
                scheduled += 1
            }
            if scheduled > 0 {
                host.logOnce("\(logKey).bursts",
                    "particleEmitter: \(scheduled) burst(s) emulated "
                    + "with timed SCNParticleSystem copies "
                    + "(approximate counts)")
            }
        }

        // MARK: Skins / morphs / animations (W11)

        /// Node lookup that also consults the live registry when this
        /// context is surgical — manifest decode leaves
        /// `resolvesLiveNodes` false so a fresh scene never sees the
        /// OLD scene's nodes, while the op contexts (seeded from the
        /// live registries) need the fallthrough for skin joint refs
        /// that point at pre-existing nodes.
        func resolveNode(_ key: UInt64) -> SCNNode? {
            nodes[key] ?? (resolvesLiveNodes ? host.nodesById[key] : nil)
        }

        /// `skins` block decode. Each entry keeps its raw def in
        /// `skinDefs` so `upsertSkin`/`upsertPayload` re-decodes the
        /// single skin; consumers re-attach via `attachSkin` after the
        /// decode updates `skins`.
        func decodeSkins(_ map: [String: Any]) {
            for (id, any) in map {
                guard let key = D3Wire.localIdKey(id),
                      let def = any as? [String: Any] else { continue }
                skinDefs[key] = def
                decodeSkin(key, def)
            }
        }

        /// One `skins` entry: joint node refs in authored order, the
        /// `inverseBindMatrices` payload (16 f32 per joint, z-mirrored
        /// through `D3Wire.matrix`; absent or in-flight → identity, and
        /// `awaitingIBM` keeps the consumers pending so the payload's
        /// arrival re-binds), and the optional `skeleton` root.
        func decodeSkin(_ key: UInt64, _ def: [String: Any]) {
            let jointKeys = (def["joints"] as? [Any] ?? [])
                .compactMap {
                    ($0 as? String).flatMap(D3Wire.localIdKey)
                }
            let skeletonKey = (def["skeleton"] as? String)
                .flatMap(D3Wire.localIdKey)
            var ibms = [SCNMatrix4](repeating: SCNMatrix4Identity,
                                    count: jointKeys.count)
            var awaiting = false
            if let token = def["inverseBindMatrices"] as? String,
               let pid = D3Wire.localIdKey(token) {
                skinPayloadKeys[key] = pid
                if let data = host.payloadStore[pid] {
                    let floats = f32List(data)
                    let need = jointKeys.count * 16
                    if floats.count < need {
                        d3Log("skin \(key): inverseBindMatrices has "
                            + "\(floats.count) floats; expected \(need)")
                    }
                    for j in 0..<jointKeys.count {
                        let b = j * 16
                        guard b + 16 <= floats.count else { break }
                        ibms[j] = D3Wire.matrix(
                            (0..<16).map { Double(floats[b + $0]) })
                    }
                } else {
                    awaiting = true
                }
            } else {
                skinPayloadKeys.removeValue(forKey: key)
            }
            skins[key] = DecodedSkin(jointKeys: jointKeys, ibms: ibms,
                                     skeletonKey: skeletonKey,
                                     awaitingIBM: awaiting)
        }

        /// `animations` block decode — raw defs kept in `animDefs` for
        /// `upsertAnimation`/`upsertPayload` re-decodes.
        func decodeAnimations(_ map: [String: Any]) {
            for (id, any) in map {
                guard let key = D3Wire.localIdKey(id),
                      let def = any as? [String: Any] else { continue }
                guard let parsed = AnimationDefinition(def) else {
                    d3Log("animation \(key): malformed metadata; prior definition retained")
                    continue
                }
                animDefs[key] = parsed
                decodeAnimation(key, parsed)
            }
        }

        /// One `animations` entry. Each channel's timeline (f32 seconds)
        /// and keyframes are payload refs — recorded as claims first so
        /// an `upsertPayload` chunk re-decodes the animation it
        /// unblocks; a channel whose payloads haven't landed is skipped
        /// this pass. Values convert to SceneKit space here:
        /// translation negates z, rotation takes the (−x,−y,z,w)
        /// pseudovector map, scale and weights pass through. `weights`
        /// channels carry flattened per-key values — `targetCount` is
        /// `values.count / times.count`, trailing floats that don't
        /// complete a keyframe are dropped (upstream's rule).
        func decodeAnimation(_ key: UInt64, _ def: AnimationDefinition) {
            var channels: [DecodedChannel] = []
            var endTime = 0.0
            var claims = Set<UInt64>()
            for (index, c) in def.channels.enumerated() {
                let tPid = c.timeline, kPid = c.keyframes
                claims.insert(tPid)
                claims.insert(kPid)
                guard let tData = host.payloadStore[tPid],
                      let kData = host.payloadStore[kPid] else {
                    d3Log("animation \(key) channel \(index): pending payloads \(tPid)/\(kPid)")
                    continue
                }
                guard payloadSpecs[tPid]?.encoding == "floats",
                      payloadSpecs[kPid]?.encoding == "floats",
                      tData.count % 4 == 0, kData.count % 4 == 0,
                      payloadSpecs[tPid]?.length.map({ $0 >= 0 && $0 % 4 == 0 }) ?? true,
                      payloadSpecs[kPid]?.length.map({ $0 >= 0 && $0 % 4 == 0 }) ?? true else {
                    d3Log("animation \(key) channel \(index): invalid payload metadata \(tPid)/\(kPid)")
                    continue
                }
                let times = f32List(tData).map(Double.init)
                let vals = f32List(kData)
                guard !times.isEmpty, times.allSatisfy({ $0.isFinite && $0 >= 0 }),
                      zip(times, times.dropFirst()).allSatisfy({ $0 < $1 }),
                      vals.allSatisfy({ $0.isFinite }) else {
                    d3Log("animation \(key) channel \(index): invalid timeline/values \(tPid)/\(kPid)")
                    continue
                }
                var ch = DecodedChannel(target: c.target, targetName: c.targetName, kind: c.kind)
                let arity: Int
                switch c.kind {
                case .materialBaseColor, .rotation: arity = 4
                case .translation, .scale: arity = 3
                case .lightIntensity, .cameraFovRadiansY: arity = 1
                case .weights: arity = vals.count / times.count
                }
                let isProperty = c.kind == .materialBaseColor
                    || c.kind == .lightIntensity || c.kind == .cameraFovRadiansY
                if isProperty && vals.count != times.count * arity {
                    d3Log("animation \(key) channel \(index): invalid value arity \(kPid)")
                    continue
                }
                let validDomain: Bool
                switch c.kind {
                case .materialBaseColor:
                    validDomain = vals.enumerated().allSatisfy {
                        $0.element >= 0 && ($0.offset % 4 != 3 || $0.element <= 1)
                    }
                case .lightIntensity: validDomain = vals.allSatisfy { $0 >= 0 }
                case .cameraFovRadiansY:
                    validDomain = vals.allSatisfy { $0 > 0 && Double($0) < Double.pi }
                default: validDomain = true
                }
                guard validDomain else {
                    d3Log("animation \(key) channel \(index): invalid property domain \(kPid)")
                    continue
                }
                switch ch.kind {
                case .translation:
                    ch.vec3 = (0..<min(times.count, vals.count / 3))
                        .map {
                            let b = $0 * 3
                            return simd_float3(vals[b], vals[b + 1],
                                               -vals[b + 2])
                        }
                case .scale:
                    ch.vec3 = (0..<min(times.count, vals.count / 3))
                        .map {
                            let b = $0 * 3
                            return simd_float3(vals[b], vals[b + 1],
                                               vals[b + 2])
                        }
                case .rotation:
                    ch.quat = (0..<min(times.count, vals.count / 4))
                        .map {
                            let b = $0 * 4
                            return simd_quatf(
                                real: vals[b + 3],
                                imag: simd_float3(
                                    -vals[b], -vals[b + 1],
                                    vals[b + 2]))
                        }
                case .materialBaseColor:
                    ch.propertyValues = (0..<times.count).map {
                        let b = $0 * 4
                        return simd_float4(vals[b], vals[b + 1], vals[b + 2], vals[b + 3])
                    }
                case .lightIntensity, .cameraFovRadiansY:
                    ch.propertyValues = vals.map { simd_float4($0, 0, 0, 0) }
                case .weights:
                    let keyCount = times.count
                    let tc = keyCount > 0 ? vals.count / keyCount : 0
                    ch.targetCount = tc
                    ch.weights = Array(vals.prefix(tc * keyCount))
                }
                ch.times = times
                if let last = times.last {
                    endTime = max(endTime, last)
                }
                channels.append(ch)
            }
            animPayloadKeys[key] = claims
            animations[key] = DecodedAnimation(
                name: def.name, channels: channels, endTime: endTime)
        }

        /// Attaches the geometry's morph targets as a `SCNMorpher` —
        /// `.normalized` mode (upstream `MorphTargetData` normalizes)
        /// with the mesh's `defaultWeights` applied up front.
        func attachMorph(_ node: SCNNode, _ morph: DecodedMorph) {
            let morpher = SCNMorpher()
            morpher.targets = morph.targets
            morpher.calculationMode = .normalized
            for i in 0..<morph.targetCount {
                let w = i < morph.defaultWeights.count
                    ? morph.defaultWeights[i] : 0
                morpher.setWeight(CGFloat(w), forTargetAt: i)
            }
            // A replaced morpher goes to the graveyard — the in-flight
            // pass's frozen storage can still reference it.
            if let old = node.morpher { host.retire(old) }
            node.morpher = morpher
        }

        /// Attaches a `SCNSkinner` for the node's declared `skin`.
        /// Bone slots follow the authored joint order; a joint that
        /// hasn't landed (or was destroyed) substitutes a detached
        /// node — upstream renders a missing joint as identity, and
        /// keeping the slot preserves IBM/bone-index alignment — and
        /// the node stays in `pendingSkinNodes` so the joint's
        /// `addNode` arrival re-binds. `bones`, the IBMs, and the two
        /// bone geometry sources are retained by the skinner; the
        /// `skeleton` property is weak, so the skeleton's registry
        /// entry (`nodesById` / `nodes`) is what keeps it alive.
        func attachSkin(_ nodeKey: UInt64, _ node: SCNNode) {
            // Multi-primitive meshes park extra primitives on
            // `d3prim:` children — upstream skins every primitive of a
            // skinned mesh, so each child's skinner must come and go
            // with the node's.
            func dropSkinner() {
                if let old = node.skinner { host.retire(old) }
                node.skinner = nil
                for child in node.childNodes
                where child.name?.hasPrefix("d3prim:") == true {
                    if let old = child.skinner { host.retire(old) }
                    child.skinner = nil
                }
            }
            guard let skinKey = nodeSkinKeys[nodeKey] else {
                dropSkinner()
                pendingSkinNodes.remove(nodeKey)
                return
            }
            guard let skin = skins[skinKey],
                  let geo = node.geometry else {
                dropSkinner()
                pendingSkinNodes.insert(nodeKey)
                return
            }
            guard let weightSource = geo.sources.first(where: {
                      $0.semantic == .boneWeights }),
                  let indexSource = geo.sources.first(where: {
                      $0.semantic == .boneIndices }) else {
                host.logOnce("skin.\(nodeKey).unskinned",
                    "node \(nodeKey): has skin \(skinKey) but its "
                    + "geometry carries no bone sources")
                dropSkinner()
                pendingSkinNodes.insert(nodeKey)
                return
            }
            var complete = !skin.awaitingIBM
            var bones: [SCNNode] = []
            bones.reserveCapacity(skin.jointKeys.count)
            for jk in skin.jointKeys {
                if let joint = resolveNode(jk) {
                    bones.append(joint)
                } else {
                    bones.append(SCNNode())
                    complete = false
                }
            }
            var skeleton: SCNNode? = nil
            if let sk = skin.skeletonKey {
                if let s = resolveNode(sk) {
                    skeleton = s
                } else {
                    complete = false
                }
            }
            let skinner = SCNSkinner(
                baseGeometry: geo,
                bones: bones,
                boneInverseBindTransforms: skin.ibms.map {
                    NSValue(scnMatrix4: $0)
                },
                boneWeights: weightSource,
                boneIndices: indexSource)
            skinner.skeleton = skeleton
            // A replaced skinner goes to the graveyard — the in-flight
            // pass's frozen storage can still reference it.
            if let old = node.skinner { host.retire(old) }
            node.skinner = skinner
            // Extra primitives ride `d3prim:` children — each needs a
            // skinner over the same bones/IBMs/skeleton, sourced from
            // its own geometry's bone streams. A prim without bone
            // sources stays rigid (upstream skins what it can).
            for child in node.childNodes
            where child.name?.hasPrefix("d3prim:") == true {
                if let old = child.skinner { host.retire(old) }
                child.skinner = nil
                guard let cg = child.geometry,
                      let cw = cg.sources.first(where: {
                          $0.semantic == .boneWeights }),
                      let ci = cg.sources.first(where: {
                          $0.semantic == .boneIndices })
                else { continue }
                let cs = SCNSkinner(
                    baseGeometry: cg,
                    bones: bones,
                    boneInverseBindTransforms: skin.ibms.map {
                        NSValue(scnMatrix4: $0)
                    },
                    boneWeights: cw,
                    boneIndices: ci)
                cs.skeleton = skeleton
                child.skinner = cs
            }
            if complete {
                pendingSkinNodes.remove(nodeKey)
            } else {
                pendingSkinNodes.insert(nodeKey)
            }
        }

        /// Manifest-path post-pass — runs after `attachRoots` so every
        /// joint named by a skin has had its node built. Anything still
        /// unresolved lands in `pendingSkinNodes` for the op paths to
        /// retry (`addNode` landings, `upsertSkin`, payload arrival,
        /// `upsertGeometry` re-attach).
        func resolveSkinAttachments() {
            for (nodeKey, _) in nodeSkinKeys {
                if let node = nodes[nodeKey] {
                    attachSkin(nodeKey, node)
                }
            }
        }

        /// Re-attaches every node bound to `skinKey` — the
        /// `upsertSkin`/`removeSkin`-adjacent refresh after `decodeSkin`
        /// rewrites (or removes) the skin record.
        func refreshSkinConsumers(_ skinKey: UInt64) {
            for (nodeKey, key) in nodeSkinKeys where key == skinKey {
                if let node = resolveNode(nodeKey) {
                    attachSkin(nodeKey, node)
                } else {
                    pendingSkinNodes.remove(nodeKey)
                }
            }
        }

        // MARK: Stage / environment (W7)

        /// Applies the manifest `stage` block: the `environmentRef` →
        /// `kind:'environment'` resource drives the lighting env
        /// (`scene.lightingEnvironment`), the skybox background, and
        /// the camera exposure. An absent or unresolvable ref defaults
        /// to the built-in **studio** env — upstream behavior. Every
        /// env field is re-assigned (or cleared) each run so a re-decode
        /// — `updateStage`, env `upsertResource`, payload arrival —
        /// replaces the previous look without accumulation.
        func decodeStage(_ stage: [String: Any]?,
                         progressiveStepOverride: Int = 0) {
            // A ref swap retires the previous env's deferral/claim —
            // otherwise the old key sits in `deferredResourceIds` and
            // every later payload chunk triggers a full re-realize.
            if let oldToken = stageJSON?["environmentRef"] as? String,
               let oldKey = D3Wire.localIdKey(oldToken),
               (stage?["environmentRef"] as? String) != oldToken {
                deferredResourceIds.remove(oldKey)
                environmentPayloadKeys.removeValue(forKey: oldKey)
                lutPayloadKeys.removeValue(forKey: oldKey)
            }
            stageJSON = stage
            stageEnvDeferred = false

            // W14 stage quality — these live on `stage` itself, not
            // on the env resource's "look" fields. Absent → the wire
            // defaults; the host's `applyStageQuality` consumes them.
            stageAntiAliasing = (stage?["antiAliasing"] as? String)
                ?? d3String(stage?["antiAliasing"]) ?? "auto"
            stageRenderScale =
                (stage?["renderScale"] as? NSNumber)?.doubleValue
                ?? d3Double(stage?["renderScale"]) ?? 1.0
            stageFilterQuality = (stage?["filterQuality"] as? String)
                ?? d3String(stage?["filterQuality"]) ?? "medium"

            var envKey: UInt64?
            var env: [String: Any]?
            if let token = stage?["environmentRef"] as? String {
                if let ref = D3Wire.localIdKey(token) {
                    envKey = ref
                    env = environments[ref]
                    if env == nil {
                        host.logOnce("stage.envRef.\(ref)",
                            "stage environmentRef '\(token)' unresolved; "
                            + "using the studio default")
                    }
                } else {
                    host.logOnce("stage.envRef.token",
                        "stage environmentRef '\(token)' is malformed; "
                        + "using the studio default")
                }
            }
            // Upstream's zero-config default: a document with no
            // environment still gets the procedural studio IBL.
            let envRes = env ?? ["environment": ["type": "studio"]]

            // The "look" fields serialize as plain JSON values (the
            // tagged `{'d': …}` form is only for node/material
            // properties).
            stageExposure = plainDouble(envRes["exposure"]) ?? 1.0
            var toneMap = StageToneMap(
                mode: envRes["toneMapping"] as? String ?? "pbrNeutral",
                agxWhite: plainDouble(envRes["agxWhite"]) ?? 16.29,
                agxContrast: plainDouble(envRes["agxContrast"]) ?? 1.25)
            if toneMap.modeIndex == nil {
                host.logOnce("stage.toneMapping.\(toneMap.mode)",
                    "toneMapping '\(toneMap.mode)' unknown; using "
                    + "pbrNeutral")
                toneMap.mode = "pbrNeutral"
            }
            stageToneMap = toneMap
            // W13: absent key → nil ("don't touch"); present (even
            // `{}`) → a wholesale decode the host applies absolutely.
            stageEffects =
                StageEffects.decode(envRes["effects"] as? [String: Any])

            let intensity = plainDouble(envRes["environmentIntensity"])
                ?? 1.0
            let rotationY = plainDouble(envRes["environmentRotationY"])
                ?? 0.0

            let skyEnv = envRes["skyEnvironment"] as? [String: Any]
            let skyEnvSource = skyEnv?["source"] as? [String: Any]
            let skyEnvType = skyEnvSource?["type"] as? String
            let hasSkyEnv = skyEnv != nil
                && (skyEnvType == "physical" || skyEnvType == "gradient")
            if skyEnv != nil, !hasSkyEnv {
                switch skyEnvType {
                case "environment":
                    host.logOnce("stage.skyEnvironment.environment",
                        "skyEnvironment source 'environment' cannot "
                        + "light itself; falling back to stage environment")
                case "fmat":
                    host.logOnce("stage.skyEnvironment.fmat",
                        "skyEnvironment source 'fmat' is deferred; "
                        + "falling back to stage environment")
                default:
                    host.logOnce("stage.skyEnvironment.\(skyEnvType ?? "?")",
                        "skyEnvironment source '\(skyEnvType ?? "?")' "
                        + "unknown; falling back to stage environment")
                }
            }

            applyStageSunLight(
                skySource: hasSkyEnv ? skyEnvSource : nil,
                sunLightSpec: hasSkyEnv
                    ? skyEnv?["sunLight"] as? [String: Any] : nil)

            var lighting: EnvPixels? = nil
            var skipLightingUpdate = false
            if hasSkyEnv, let skyEnv, let skyEnvSource, let skyEnvType {
                let refresh = skyEnv["refresh"] as? String ?? "manual"
                let intervalSeconds = max(
                    0.0, plainDouble(skyEnv["intervalSeconds"]) ?? 1.0)
                let eqWidth = min(512, max(64,
                    (skyEnv["equirectWidth"] as? NSNumber)?.intValue ?? 512))
                let forceStep = progressiveStepOverride != 0
                    ? progressiveStepOverride
                    : ((skyEnv["d3ProgressiveStep"] as? NSNumber)?.intValue ?? 0)
                let sig = "\(skyEnvSource)|\(intensity)|\(rotationY)|\(eqWidth)"
                let now = CFAbsoluteTimeGetCurrent()
                let minInterval = refresh == "interval"
                    ? max(0.15, intervalSeconds) : 0.15
                let isFirstBake = host.skyEnvBakedSig == nil
                    || scene.lightingEnvironment.contents == nil
                if forceStep >= 1 && forceStep <= 3 || isFirstBake {
                    let effectiveStep = forceStep >= 1 && forceStep <= 3
                        ? forceStep : 3
                    let stepW: Int
                    switch effectiveStep {
                    case 1: stepW = 64
                    case 2: stepW = min(128, eqWidth)
                    default: stepW = min(256, eqWidth)
                    }
                    let stepH = max(32, stepW / 2)
                    let raw: EnvPixels?
                    switch skyEnvType {
                    case "physical":
                        raw = physicalEquirectPixels(
                            skyEnvSource, width: stepW, height: stepH,
                            conserveSunEnergy: true)
                    case "gradient":
                        raw = gradientEquirectPixels(
                            skyEnvSource, width: stepW, height: stepH)
                    default:
                        raw = nil
                    }
                    lighting = raw.map { mirroredRotated($0, rotationY) }
                    host.envLightingPixels = lighting
                    host.skyEnvBakedSig = sig
                    host.skyEnvLastBakeTime = now
                    host.skyEnvLastStepTime = now
                    host.skyEnvProgressiveStep = effectiveStep
                    host.activeSkyEnvStage = stage
                    if effectiveStep == 3 {
                        host.pendingSkyEnvStage = nil
                    }
                } else {
                    skipLightingUpdate = true
                    lighting = host.envLightingPixels
                    if sig == host.skyEnvBakedSig
                        && host.skyEnvProgressiveStep == 3 {
                        host.pendingSkyEnvStage = nil
                    } else {
                        host.pendingSkyEnvStage = stage
                        host.pendingSkyEnvInterval = minInterval
                    }
                }
            } else {
                host.skyEnvBakedSig = nil
                host.skyEnvProgressiveStep = 3
                host.activeSkyEnvStage = nil
                host.pendingSkyEnvStage = nil
                let envPixels = realizeEnvironmentSource(envRes,
                                                         envKey: envKey)
                // The z-mirror and rotationY are column ops baked into the
                // pixels. The intensity is the property's own: SceneKit
                // clamps an environment image at 1 and stores an 8-bit one
                // in 8 linear bits, so a scale baked into the pixels
                // clipped above 1 and lost the dark end below it. A float
                // source brighter than 1 is divided down to fit and the
                // divisor goes into the intensity as well.
                lighting = envPixels.map { mirroredRotated($0, rotationY) }
                host.envLightingPixels = lighting
            }

            if !stageEnvDeferred && !skipLightingUpdate {
                let fitted = lighting.map(unitRange)
                scene.lightingEnvironment.contents =
                    fitted.flatMap { envContents($0.pixels) }
                scene.lightingEnvironment.intensity =
                    CGFloat(intensity * (fitted?.divisor ?? 1))
                if let envKey { deferredResourceIds.remove(envKey) }
            } else if !stageEnvDeferred {
                if let envKey { deferredResourceIds.remove(envKey) }
            }

            // The skybox is a separate draw of (usually) the same env —
            // `skybox.intensity` stacks on top of environmentIntensity.
            let sky = envRes["skybox"] as? [String: Any]
            let source = sky?["source"] as? [String: Any]
            let skyIntensity = plainDouble(sky?["intensity"]) ?? 1.0
            switch source?["type"] as? String {
            case "environment":
                guard !stageEnvDeferred else { break }
                var background = lighting.map {
                    linearPixels($0, scale: intensity * skyIntensity)
                }
                let blurriness =
                    plainDouble(source?["blurriness"]) ?? 0.0
                if blurriness > 0, let p = background {
                    background = boxBlurredPixels(p,
                        radius: max(1, Int((blurriness
                            * Double(p.width) / 32).rounded())))
                    host.logOnce("skybox.blurriness",
                        "skybox blurriness \(blurriness): approximated "
                        + "with a CPU box blur on the equirect")
                }
                scene.background.contents =
                    background.flatMap(envContents)
            case "gradient":
                // The sky is its own source — env intensity/rotation
                // don't reach it, but the z-mirror does (world space).
                let background = linearPixels(
                    mirroredRotated(gradientEquirectPixels(source ?? [:]),
                                    0), scale: skyIntensity)
                scene.background.contents = envContents(background)
            case "physical":
                let background = linearPixels(
                    mirroredRotated(
                        physicalEquirectPixels(
                            source ?? [:], width: 256, height: 128,
                            conserveSunEnergy: false),
                        0),
                    scale: skyIntensity)
                scene.background.contents = envContents(background)
            case "fmat":
                host.logOnce("skybox.\(source?["type"] ?? "")",
                    "skybox source '\(source?["type"] ?? "")' is "
                    + "deferred; background cleared")
                scene.background.contents = nil
            default:
                if source != nil {
                    host.logOnce("skybox.\(source?["type"] ?? "?")",
                        "skybox source '\(source?["type"] ?? "?")' "
                        + "unknown; background cleared")
                }
                scene.background.contents = nil
            }

            // W25: the colorGrading LUT rides the env's payload-claim
            // path — a `chunk:`/id-token ref whose bytes haven't
            // landed defers this env id so the chunk's arrival
            // re-runs the stage decode (and the host's
            // `applyStageEffects` picks the table up). Asset-path
            // refs aren't claims; the host resolves them from the
            // main bundle at apply time. An absent `effects` key
            // keeps the prior claim (the decoded stack is retained).
            if let envKey, let fx = stageEffects {
                if let ref = fx.colorGrading.lut, !ref.isEmpty,
                   let lutPid = D3Wire.localIdKey(ref) {
                    lutPayloadKeys[envKey] = lutPid
                    if host.payloadStore[lutPid] == nil {
                        deferredResourceIds.insert(envKey)
                        host.logOnce("env.\(envKey).lut.awaiting",
                            "environment \(envKey): awaiting LUT "
                            + "payload")
                    }
                } else {
                    lutPayloadKeys.removeValue(forKey: envKey)
                }
            }
        }

        /// Realizes the env resource's `environment` member into
        /// equirect pixels. Returns nil for `empty` and for sources
        /// that fail to decode; a `payload` whose bytes haven't landed
        /// sets `stageEnvDeferred` and records the payload claim.
        func realizeEnvironmentSource(_ env: [String: Any],
                                      envKey: UInt64?) -> EnvPixels? {
            let spec = env["environment"] as? [String: Any]
                ?? ["type": "studio"]
            let tag = envKey.map { "environment \($0)" } ?? "environment"
            switch spec["type"] as? String ?? "studio" {
            case "studio":
                return EnvPixels(width: 256, height: 128, isFloat: false,
                                 data: studioEquirectPixels(256, 128))
            case "constant":
                // The wire color is linear radiance; the equirect
                // stores sRGB like every LDR source here.
                let c = rawVec3(spec["color"]) ?? [0, 0, 0]
                return EnvPixels(width: 16, height: 8, isFloat: false,
                                 data: solidEquirectPixels(c,
                                                           width: 16,
                                                           height: 8))
            case "empty":
                return nil
            case "asset":
                guard let ref = spec["ref"] as? String else {
                    host.logOnce("env.\(envKey ?? 0).asset",
                        "\(tag): asset environment lacks 'ref'")
                    return nil
                }
                return envPixels(fromAsset: ref, tag: tag)
            case "payload":
                guard let token = spec["payload"] as? String,
                      let pid = D3Wire.localIdKey(token) else {
                    host.logOnce("env.\(envKey ?? 0).payloadToken",
                        "\(tag): invalid payload token")
                    return nil
                }
                if let envKey { environmentPayloadKeys[envKey] = pid }
                guard let data = host.payloadStore[pid] else {
                    stageEnvDeferred = true
                    if let envKey { deferredResourceIds.insert(envKey) }
                    host.logOnce("env.\(envKey ?? 0).awaiting",
                        "\(tag): awaiting payload")
                    return nil
                }
                return envPixels(fromBytes: data, tag: tag)
            default:
                host.logOnce("env.\(envKey ?? 0).type",
                    "\(tag): unknown environment type "
                    + "'\(spec["type"] ?? "?")'; using studio")
                return EnvPixels(width: 256, height: 128, isFloat: false,
                                 data: studioEquirectPixels(256, 128))
            }
        }

        /// Verbatim port of flutter_scene's
        /// `_generateStudioEquirectPixels`
        /// (lib/src/material/environment.dart): a cool-neutral ceiling
        /// gradient over a warm-dim floor, a broad dirY² top fill, a
        /// warm pow²⁶ key lobe at normalize(0.45, 0.55, 0.70), and a
        /// cool pow¹⁶ fill at normalize(−0.70, 0.22, −0.35). Row 0 is
        /// the up pole; pixels are sRGB-encoded RGBA8.
        func studioEquirectPixels(_ width: Int, _ height: Int) -> Data {
            var pixels = Data(count: width * height * 4)
            let keyLen = (0.45 * 0.45 + 0.55 * 0.55 + 0.70 * 0.70)
                .squareRoot()
            let keyX = 0.45 / keyLen, keyY = 0.55 / keyLen
            let keyZ = 0.70 / keyLen
            let fillLen = (0.70 * 0.70 + 0.22 * 0.22 + 0.35 * 0.35)
                .squareRoot()
            let fillX = -0.70 / fillLen, fillY = 0.22 / fillLen
            let fillZ = -0.35 / fillLen
            let twoPi = 2.0 * Double.pi
            pixels.withUnsafeMutableBytes { buf in
                guard let p = buf.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                for py in 0..<height {
                    let v = (Double(py) + 0.5) / Double(height)
                    // Row 0 (top of the image) is the up hemisphere.
                    let latitude = (0.5 - v) * Double.pi
                    let cosLat = cos(latitude)
                    let dirY = sin(latitude)
                    for px in 0..<width {
                        let u = (Double(px) + 0.5) / Double(width)
                        let longitude = (u - 0.5) * twoPi
                        let dirX = cosLat * cos(longitude)
                        let dirZ = cosLat * sin(longitude)
                        var r: Double, g: Double, b: Double
                        if dirY >= 0 {
                            let t = smoothstep01(dirY)
                            r = lerp(0.50, 0.76, t)
                            g = lerp(0.51, 0.78, t)
                            b = lerp(0.52, 0.82, t)
                        } else {
                            let t = smoothstep01(-dirY)
                            r = lerp(0.50, 0.20, t)
                            g = lerp(0.51, 0.19, t)
                            b = lerp(0.52, 0.17, t)
                        }
                        let top = max(dirY, 0.0)
                        let topL = top * top
                        r += 0.85 * topL
                        g += 0.86 * topL
                        b += 0.88 * topL
                        let keyC = max(
                            dirX * keyX + dirY * keyY + dirZ * keyZ, 0.0)
                        let keyL = pow(keyC, 26.0)
                        r += 1.10 * keyL
                        g += 1.06 * keyL
                        b += 1.00 * keyL
                        let fillC = max(
                            dirX * fillX + dirY * fillY + dirZ * fillZ,
                            0.0)
                        let fillL = pow(fillC, 16.0)
                        r += 0.46 * fillL
                        g += 0.50 * fillL
                        b += 0.56 * fillL
                        let o = (py * width + px) * 4
                        p[o] = encodeSrgb(r)
                        p[o + 1] = encodeSrgb(g)
                        p[o + 2] = encodeSrgb(b)
                        p[o + 3] = 255
                    }
                }
            }
            return pixels
        }

        /// `constant` env — a tiny solid equirect of the linear color.
        /// Uniform diffuse ambient; the flat "reflections" are the
        /// cheapest SceneKit gets to upstream's black-spec +
        /// SH-diffuse form.
        func solidEquirectPixels(_ c: [Float], width: Int,
                                 height: Int) -> Data {
            let r = encodeSrgb(Double(c[0]))
            let g = encodeSrgb(Double(c[1]))
            let b = encodeSrgb(Double(c[2]))
            var data = Data(count: width * height * 4)
            data.withUnsafeMutableBytes { buf in
                guard let p = buf.baseAddress?
                    .assumingMemoryBound(to: UInt8.self) else { return }
                for i in stride(from: 0, to: width * height * 4, by: 4) {
                    p[i] = r; p[i + 1] = g; p[i + 2] = b; p[i + 3] = 255
                }
            }
            return data
        }

        /// `gradient` sky — mirrors upstream's SkyGradientFragment:
        /// horizon→zenith / horizon→ground blends on sqrt(|dirY|), the
        /// pow(dot(sun), sharpness) HDR sun disk, and its 0.15·s⁸ halo.
        /// Outputs linear RGBA float32 so HDR sunColor values survive
        /// `unitRange` normalization for `skyEnvironment` IBL as well
        /// as `linearPixels` background rendering.
        func gradientEquirectPixels(_ source: [String: Any],
                                    width: Int = 128,
                                    height: Int = 64) -> EnvPixels {
            let zenith = rawVec3(source["zenithColor"])
                ?? [0.05, 0.18, 0.55]
            let horizon = rawVec3(source["horizonColor"])
                ?? [0.45, 0.62, 0.90]
            let ground = rawVec3(source["groundColor"])
                ?? [0.16, 0.14, 0.12]
            let sun = rawVec3(source["sunDirection"]) ?? [0.4, 0.5, 0.6]
            let sunColor = rawVec3(source["sunColor"]) ?? [3.0, 2.7, 2.2]
            let sharpness = plainDouble(source["sunSharpness"]) ?? 400.0
            let sunLen = sqrt(Double(sun[0] * sun[0] + sun[1] * sun[1]
                                     + sun[2] * sun[2]))
            let sunX = sunLen > 0 ? Double(sun[0]) / sunLen : 0.0
            let sunY = sunLen > 0 ? Double(sun[1]) / sunLen : 0.0
            let sunZ = sunLen > 0 ? Double(sun[2]) / sunLen : 0.0
            var floats = [Float](repeating: 1.0, count: width * height * 4)
            let twoPi = 2.0 * Double.pi
            for py in 0..<height {
                let v = (Double(py) + 0.5) / Double(height)
                let latitude = (0.5 - v) * Double.pi
                let cosLat = cos(latitude)
                let dirY = sin(latitude)
                for px in 0..<width {
                    let u = (Double(px) + 0.5) / Double(width)
                    let longitude = (u - 0.5) * twoPi
                    let dirX = cosLat * cos(longitude)
                    let dirZ = cosLat * sin(longitude)
                    var r: Double, g: Double, b: Double
                    let t = sqrt(abs(dirY))
                    if dirY >= 0 {
                        r = lerp(Double(horizon[0]),
                                 Double(zenith[0]), t)
                        g = lerp(Double(horizon[1]),
                                 Double(zenith[1]), t)
                        b = lerp(Double(horizon[2]),
                                 Double(zenith[2]), t)
                    } else {
                        r = lerp(Double(horizon[0]),
                                 Double(ground[0]), t)
                        g = lerp(Double(horizon[1]),
                                 Double(ground[1]), t)
                        b = lerp(Double(horizon[2]),
                                 Double(ground[2]), t)
                    }
                    let s = max(
                        dirX * sunX + dirY * sunY + dirZ * sunZ, 0.0)
                    let disk = pow(s, sharpness)
                        + 0.15 * pow(s, 8.0)
                    r += Double(sunColor[0]) * disk
                    g += Double(sunColor[1]) * disk
                    b += Double(sunColor[2]) * disk
                    let o = (py * width + px) * 4
                    floats[o] = Float(max(r, 0.0))
                    floats[o + 1] = Float(max(g, 0.0))
                    floats[o + 2] = Float(max(b, 0.0))
                    floats[o + 3] = 1.0
                }
            }
            return EnvPixels(
                width: width, height: height, isFloat: true,
                data: floats.withUnsafeBufferPointer { Data(buffer: $0) })
        }

        /// W17 `physical` sky — mirrors upstream's
        /// `flutter_scene_sky_physical.frag`: analytic Preetham
        /// single-scattering daylight model with Rayleigh and Mie
        /// terms, zenith-angle optical mass, low-sun extinction
        /// re-saturation, ground fade below the horizon, and an
        /// atmospheric-attenuated HDR sun disk.
        func physicalEquirectPixels(_ source: [String: Any],
                                    width: Int = 256,
                                    height: Int = 128,
                                    conserveSunEnergy: Bool = false) -> EnvPixels {
            let sun = rawVec3(source["sunDirection"]) ?? [0.4, 0.5, 0.6]
            let sunAngularRadius = max(
                0.0, plainDouble(source["sunAngularRadius"]) ?? 0.0175)
            let rayleighCoefficient =
                plainDouble(source["rayleighCoefficient"]) ?? 2.0
            let rayleighColor = rawVec3(source["rayleighColor"])
                ?? [0.26, 0.41, 0.58]
            let mieCoefficient =
                plainDouble(source["mieCoefficient"]) ?? 0.005
            let mieEccentricity =
                plainDouble(source["mieEccentricity"]) ?? 0.8
            let mieColor = rawVec3(source["mieColor"])
                ?? [0.69, 0.73, 0.81]
            let turbidity = plainDouble(source["turbidity"]) ?? 10.0
            let groundColor = rawVec3(source["groundColor"])
                ?? [0.12, 0.12, 0.13]
            let energy = plainDouble(source["energy"]) ?? 1.0

            let sunLen = sqrt(Double(sun[0] * sun[0] + sun[1] * sun[1]
                                     + sun[2] * sun[2]))
            let sunX = sunLen > 1e-12 ? Double(sun[0]) / sunLen : 0.0
            let sunY = sunLen > 1e-12 ? Double(sun[1]) / sunLen : 1.0
            let sunZ = sunLen > 1e-12 ? Double(sun[2]) / sunLen : 0.0

            let sunZenithCos = min(max(sunY, -1.0), 1.0)
            let sunEnergy = max(
                0.0,
                1.0 - exp(-((Double.pi * 0.5) - acos(sunZenithCos))))
                * 60.0 * energy
            let sunFade = 1.0 - min(max(1.0 - exp(sunY), 0.0), 1.0)

            let rayleighScale =
                max(rayleighCoefficient - (1.0 - sunFade), 0.0) * 0.0001
            let rayleighBetaR = Double(rayleighColor[0]) * rayleighScale
            let rayleighBetaG = Double(rayleighColor[1]) * rayleighScale
            let rayleighBetaB = Double(rayleighColor[2]) * rayleighScale

            let mieScale = turbidity * mieCoefficient * 0.000434
            let mieBetaR = Double(mieColor[0]) * mieScale
            let mieBetaG = Double(mieColor[1]) * mieScale
            let mieBetaB = Double(mieColor[2]) * mieScale

            let denomR = max(rayleighBetaR + mieBetaR, 1e-12)
            let denomG = max(rayleighBetaG + mieBetaG, 1e-12)
            let denomB = max(rayleighBetaB + mieBetaB, 1e-12)

            let extCoeffR = rayleighBetaR * 8400.0 + mieBetaR * 1250.0
            let extCoeffG = rayleighBetaG * 8400.0 + mieBetaG * 1250.0
            let extCoeffB = rayleighBetaB * 8400.0 + mieBetaB * 1250.0

            let sunsetMix = min(max(pow(1.0 - sunZenithCos, 5.0), 0.0), 1.0)
            let g2 = mieEccentricity * mieEccentricity
            let oneMinusG2 = 1.0 - g2
            let invFourPi = 1.0 / (4.0 * Double.pi)
            let rayleighConst = 3.0 / (16.0 * Double.pi)

            let minGridRadius = 1.75 * Double.pi / Double(max(1, height))
            let rEff = (conserveSunEnergy
                && sunAngularRadius > 0.0 && sunAngularRadius < minGridRadius)
                ? minGridRadius : sunAngularRadius
            let directSunScale = (conserveSunEnergy
                && rEff > sunAngularRadius && rEff > 0.0)
                ? (sunAngularRadius / rEff) * (sunAngularRadius / rEff) : 1.0
            let diskOuter = cos(rEff)
            let diskInner = cos(rEff * 0.5)

            let twoPi = 2.0 * Double.pi
            var cosLon = [Double](repeating: 0, count: width)
            var sinLon = [Double](repeating: 0, count: width)
            for px in 0..<width {
                let u = (Double(px) + 0.5) / Double(width)
                let lon = (u - 0.5) * twoPi
                cosLon[px] = cos(lon)
                sinLon[px] = sin(lon)
            }

            var floats = [Float](repeating: 1.0, count: width * height * 4)
            for py in 0..<height {
                let v = (Double(py) + 0.5) / Double(height)
                let latitude = (0.5 - v) * Double.pi
                let cosLat = cos(latitude)
                let dirY = sin(latitude)

                let zenith = acos(max(0.0, dirY))
                let opticalMass = 1.0
                    / (cos(zenith) + 0.00094 * pow(1.6386 - zenith, -1.253))
                let extR = exp(-extCoeffR * opticalMass)
                let extG = exp(-extCoeffG * opticalMass)
                let extB = exp(-extCoeffB * opticalMass)
                let oneMinusExtR = 1.0 - extR
                let oneMinusExtG = 1.0 - extG
                let oneMinusExtB = 1.0 - extB

                let groundBlend = smoothstep(-0.1, 0.1, dirY)
                let groundFactorR = lerp(Double(groundColor[0]), 1.0, groundBlend)
                let groundFactorG = lerp(Double(groundColor[1]), 1.0, groundBlend)
                let groundFactorB = lerp(Double(groundColor[2]), 1.0, groundBlend)

                let rowDirectR = sunEnergy * extR * directSunScale
                let rowDirectG = sunEnergy * extG * directSunScale
                let rowDirectB = sunEnergy * extB * directSunScale

                for px in 0..<width {
                    let dirX = cosLat * cosLon[px]
                    let dirZ = cosLat * sinLon[px]
                    let cosTheta = dirX * sunX + dirY * sunY + dirZ * sunZ

                    let halfCos = cosTheta * 0.5 + 0.5
                    let rayleighPhase = rayleighConst * (1.0 + halfCos * halfCos)
                    let d = max(1.0 + g2 - 2.0 * mieEccentricity * cosTheta, 1e-12)
                    let miePhase = invFourPi * (oneMinusG2 / (d * sqrt(d)))

                    let scatterR =
                        (rayleighBetaR * rayleighPhase + mieBetaR * miePhase) / denomR
                    let scatterG =
                        (rayleighBetaG * rayleighPhase + mieBetaG * miePhase) / denomG
                    let scatterB =
                        (rayleighBetaB * rayleighPhase + mieBetaB * miePhase) / denomB

                    let sR = max(sunEnergy * scatterR * oneMinusExtR, 0.0)
                    let sG = max(sunEnergy * scatterG * oneMinusExtG, 0.0)
                    let sB = max(sunEnergy * scatterB * oneMinusExtB, 0.0)
                    var r = sR * sqrt(sR)
                    var g = sG * sqrt(sG)
                    var b = sB * sqrt(sB)

                    if sunsetMix > 0.0 {
                        let seR = sqrt(max(sunEnergy * scatterR * extR, 0.0))
                        let seG = sqrt(max(sunEnergy * scatterG * extG, 0.0))
                        let seB = sqrt(max(sunEnergy * scatterB * extB, 0.0))
                        r *= lerp(1.0, seR, sunsetMix)
                        g *= lerp(1.0, seG, sunsetMix)
                        b *= lerp(1.0, seB, sunsetMix)
                    }

                    r *= groundFactorR
                    g *= groundFactorG
                    b *= groundFactorB

                    if cosTheta > diskOuter {
                        let sunDisk = smoothstep(diskOuter, diskInner, cosTheta)
                        r += rowDirectR * sunDisk
                        g += rowDirectG * sunDisk
                        b += rowDirectB * sunDisk
                    }

                    let o = (py * width + px) * 4
                    floats[o] = Float(max(r, 0.0))
                    floats[o + 1] = Float(max(g, 0.0))
                    floats[o + 2] = Float(max(b, 0.0))
                    floats[o + 3] = 1.0
                }
            }
            return EnvPixels(
                width: width, height: height, isFloat: true,
                data: floats.withUnsafeBufferPointer { Data(buffer: $0) })
        }

        func smoothstep(_ edge0: Double, _ edge1: Double, _ x: Double) -> Double {
            if abs(edge1 - edge0) < 1e-12 { return x >= edge1 ? 1.0 : 0.0 }
            return smoothstep01((x - edge0) / (edge1 - edge0))
        }

        /// W17: creates or updates the stage-owned directional sun light
        /// driven by `skyEnvironment.sunLight` (`SunLightSpec`).
        func applyStageSunLight(skySource: [String: Any]?,
                                sunLightSpec: [String: Any]?) {
            guard let skySource, let sunLightSpec,
                  let skyType = skySource["type"] as? String,
                  skyType == "physical" || skyType == "gradient" else {
                host.stageSunLightNode?.removeFromParentNode()
                host.stageSunLightNode = nil
                return
            }
            let sun = rawVec3(skySource["sunDirection"]) ?? [0.4, 0.5, 0.6]
            let sunLen = sqrt(Double(sun[0] * sun[0] + sun[1] * sun[1]
                                     + sun[2] * sun[2]))
            let sunX = sunLen > 1e-12 ? Double(sun[0]) / sunLen : 0.0
            let sunY = sunLen > 1e-12 ? Double(sun[1]) / sunLen : 1.0
            let sunZ = sunLen > 1e-12 ? Double(sun[2]) / sunLen : 0.0

            let intensityScale = plainDouble(sunLightSpec["intensityScale"]) ?? 1.0
            let color: UIColor
            let sunIntensity: Double
            if skyType == "physical" {
                let energy = plainDouble(skySource["energy"]) ?? 1.0
                color = UIColor(red: 1.0, green: 0.98, blue: 0.95, alpha: 1.0)
                sunIntensity = 3.0 * energy * intensityScale
            } else {
                let sc = rawVec3(skySource["sunColor"]) ?? [3.0, 2.7, 2.2]
                let peak = max(Double(sc[0]), max(Double(sc[1]), Double(sc[2])))
                if peak > 0 {
                    color = UIColor(
                        red: CGFloat(Double(sc[0]) / peak),
                        green: CGFloat(Double(sc[1]) / peak),
                        blue: CGFloat(Double(sc[2]) / peak),
                        alpha: 1.0)
                } else {
                    color = UIColor.white
                }
                sunIntensity = peak * intensityScale
            }

            let node: SCNNode
            let light: SCNLight
            if let existing = host.stageSunLightNode,
               let existingLight = existing.light {
                node = existing
                light = existingLight
                if node.parent !== scene.rootNode {
                    scene.rootNode.addChildNode(node)
                }
            } else {
                node = SCNNode()
                node.name = "d3.stageSunLight"
                light = SCNLight()
                light.type = .directional
                node.light = light
                scene.rootNode.addChildNode(node)
                host.stageSunLightNode = node
            }

            // SceneKit directional lights shine along the node's local -Z,
            // so local +Z points toward the sun in SceneKit space:
            // zAxis = (sunX, sunY, -sunZ).
            let zAxis = simd_normalize(
                simd_float3(Float(sunX), Float(sunY), Float(-sunZ)))
            let refUp = abs(zAxis.y) < 0.99
                ? simd_float3(0, 1, 0) : simd_float3(1, 0, 0)
            let right = simd_normalize(simd_cross(refUp, zAxis))
            let up = simd_cross(zAxis, right)
            node.simdTransform = simd_float4x4(columns: (
                simd_float4(right, 0),
                simd_float4(up, 0),
                simd_float4(zAxis, 0),
                simd_float4(0, 0, 0, 1)
            ))

            light.color = color
            light.intensity = CGFloat(sunIntensity * 1000.0 / .pi)
            let castsShadow = (sunLightSpec["castsShadow"] as? Bool) ?? true
            if castsShadow {
                host.shadowAuthored.insert(ObjectIdentifier(light))
                light.castsShadow = host.viewQuality != "low"
                // Reset SunLightSpec defaults before decodeDirectionalShadow
                // applies any non-default overrides (fscene_json omits defaults).
                let defaultRes: CGFloat = host.viewQuality == "high" ? 2048 : 1024
                light.shadowMapSize = CGSize(width: defaultRes, height: defaultRes)
                light.shadowBias = CGFloat(
                    plainDouble(sunLightSpec["shadowDepthBias"]) ?? 0.02)
                light.shadowRadius = CGFloat(
                    plainDouble(sunLightSpec["shadowSoftness"]) ?? 0.08)
                let maxDist = plainDouble(sunLightSpec["shadowMaxDistance"]) ?? 150.0
                light.automaticallyAdjustsShadowProjection = false
                light.orthographicScale = CGFloat(maxDist)
                light.maximumShadowDistance = CGFloat(max(maxDist, 1.0))
                light.forcesBackFaceCasters = false
                light.shadowSampleCount = 16
                decodeDirectionalShadow(light, sunLightSpec)
            } else {
                host.shadowAuthored.remove(ObjectIdentifier(light))
                light.castsShadow = false
            }
        }

        /// `asset` env — bundle bytes sniffed by magic (an asset
        /// catalog image has no file, so `UIImage(named:)` is the
        /// fallback for those).
        func envPixels(fromAsset ref: String, tag: String)
            -> EnvPixels?
        {
            if let url = FlutterAssets.url(forResource: ref),
               let data = try? Data(contentsOf: url) {
                return envPixels(fromBytes: data, tag: tag)
            }
            if let image = UIImage(named: ref),
               let pixels = envPixels(from: image) {
                return pixels
            }
            host.logOnce("env.asset.\(ref)",
                "\(tag): asset '\(ref)' not found")
            return nil
        }

        /// Equirect bytes — decoder picked by magic: Radiance HDR
        /// (`#?RADIANCE`/`#?RGBE`) decodes to float32, OpenEXR goes
        /// through the platform HDR loaders (`decodeEXR`), everything
        /// else goes through `UIImage`'s container sniffing (png/jpg/…;
        /// the spec `format` tag is informational).
        func envPixels(fromBytes data: Data, tag: String) -> EnvPixels? {
            if isRadianceHDR(data) {
                return decodeRadianceHDR(data, tag: tag)
            }
            if isOpenEXR(data) {
                return decodeEXR(data, tag: tag)
            }
            guard let image = UIImage(data: data),
                  let pixels = envPixels(from: image) else {
                host.logOnce("env.bytes.\(tag)",
                    "\(tag): undecodable environment image")
                return nil
            }
            return pixels
        }

        /// A `UIImage` → sRGB8 equirect (the `rgbaPixels` re-decode).
        func envPixels(from image: UIImage) -> EnvPixels? {
            guard let (data, w, h) = rgbaPixels(image, alpha: false)
            else { return nil }
            return EnvPixels(width: w, height: h, isFloat: false,
                             data: data)
        }

        func isRadianceHDR(_ data: Data) -> Bool {
            guard data.count > 10,
                  data[data.startIndex] == 0x23,      // '#'
                  data[data.startIndex + 1] == 0x3F   // '?'
            else { return false }
            let head = data.prefix(10)
            return head.starts(with: Data("#?RADIANCE".utf8))
                || head.starts(with: Data("#?RGBE".utf8))
        }

        /// OpenEXR magic 0x01312F76, little-endian on the wire.
        func isOpenEXR(_ data: Data) -> Bool {
            guard data.count > 4 else { return false }
            let i = data.startIndex
            return data[i] == 0x76 && data[i + 1] == 0x2F
                && data[i + 2] == 0x31 && data[i + 3] == 0x01
        }

        /// Minimal Radiance .hdr (RGBE) decoder: header lines up to a
        /// blank line, a `-Y h +X w` resolution row, then per-scanline
        /// new-style RLE or flat RGBE data. Output is linear RGBA
        /// float32, row 0 = top of the image.
        func decodeRadianceHDR(_ data: Data, tag: String) -> EnvPixels? {
            func fail(_ why: String) -> EnvPixels? {
                host.logOnce("env.hdr.\(tag).\(why)",
                    "\(tag): malformed .hdr equirect (\(why))")
                return nil
            }
            var i = data.startIndex
            // Header: text lines through the first empty one.
            var sawHeaderEnd = false
            while i < data.endIndex {
                guard let nl = data[i...].firstIndex(of: 0x0A)
                else { return fail("unterminated header") }
                let line = data[i..<nl]
                    .filter { $0 != 0x0D }      // tolerate \r\n
                i = nl + 1
                if line.isEmpty { sawHeaderEnd = true; break }
            }
            guard sawHeaderEnd else { return fail("unterminated header") }
            // Resolution row: "±Y h ±X w" (Y-major only).
            guard let nl = data[i...].firstIndex(of: 0x0A)
            else { return fail("missing resolution line") }
            let tokens = String(decoding: data[i..<nl]
                                    .filter { $0 != 0x0D },
                                as: UTF8.self)
                .split(separator: " ").map(String.init)
            i = nl + 1
            guard tokens.count == 4,
                  let n1 = Int(tokens[1]), let n2 = Int(tokens[3]),
                  n1 > 0, n2 > 0
            else { return fail("bad resolution line") }
            let yMajor = tokens[0].hasSuffix("Y")
            guard yMajor else {
                return fail("X-major scanlines unsupported")
            }
            let height = n1, width = n2
            // "-Y": first scanline is the image top (the standard);
            // "+Y" starts at the bottom. "+X": left-to-right pixels.
            let bottomUp = tokens[0].hasPrefix("+")
            let rightToLeft = tokens[2].hasPrefix("-")
            var floats = [Float](repeating: 0, count: width * height * 4)
            let rle = width >= 8 && width < 32768
            for y in 0..<height {
                let row = bottomUp ? height - 1 - y : y
                var rgb = [UInt8](repeating: 0, count: width * 4)
                if rle {
                    guard i + 4 <= data.endIndex,
                          data[i] == 2, data[i + 1] == 2,
                          (data[i + 2] & 0x80) == 0,
                          (Int(data[i + 2]) << 8 | Int(data[i + 3]))
                            == width
                    else { return fail("bad RLE scanline \(y)") }
                    i += 4
                    for c in 0..<4 {
                        var x = 0
                        while x < width {
                            guard i < data.endIndex
                            else { return fail("truncated RLE") }
                            let count = Int(data[i]); i += 1
                            if count > 128 {
                                let run = count - 128
                                guard i < data.endIndex, x + run <= width
                                else { return fail("bad RLE run") }
                                let v = data[i]; i += 1
                                for k in 0..<run {
                                    rgb[(x + k) * 4 + c] = v
                                }
                                x += run
                            } else {
                                guard i + count <= data.endIndex,
                                      x + count <= width
                                else { return fail("bad RLE literal") }
                                for k in 0..<count {
                                    rgb[(x + k) * 4 + c] = data[i + k]
                                }
                                i += count
                                x += count
                            }
                        }
                    }
                } else {
                    guard i + width * 4 <= data.endIndex
                    else { return fail("truncated flat data") }
                    for k in 0..<width * 4 {
                        rgb[k] = data[i + k]
                    }
                    i += width * 4
                }
                for x in 0..<width {
                    let sx = rightToLeft ? width - 1 - x : x
                    let o = (row * width + x) * 4
                    let e = Int(rgb[sx * 4 + 3])
                    if e != 0 {
                        let f = Float(pow(2.0, Double(e) - 136.0))
                        floats[o] = Float(rgb[sx * 4]) * f
                        floats[o + 1] = Float(rgb[sx * 4 + 1]) * f
                        floats[o + 2] = Float(rgb[sx * 4 + 2]) * f
                    }
                    floats[o + 3] = 1.0
                }
            }
            return EnvPixels(width: width, height: height,
                             isFloat: true,
                             data: floats.withUnsafeBufferPointer {
                                 Data(bytes: $0.baseAddress!,
                                      count: $0.count
                                        * MemoryLayout<Float>.size)
                             })
        }

        /// OpenEXR equirect → linear float32 RGBA `EnvPixels` (W21) —
        /// the same float storage the .hdr decoder produces, so the
        /// mirror/rotate/intensity bakes and `envContents`' float
        /// CGImage binding apply unchanged. Primary path is
        /// `MTKTextureLoader` (ImageIO's EXR codec under Metal,
        /// `.SRGB: false` keeps the linear values); when it can't
        /// produce a readable texture, `CIImage` → `CIContext` RGBAf
        /// in extended-linear-sRGB is the fallback. Both verified to
        /// preserve >1.0 texels. No decoder on the OS → warn-once +
        /// nil (the env keeps whatever the stage defaults to — the
        /// pre-W21 behavior, now logged from the loader failures).
        func decodeEXR(_ data: Data, tag: String) -> EnvPixels? {
            if let device = host.renderDevice(),
               let env = exrMetalPixels(data, device: device, tag: tag) {
                return env
            }
            if let env = exrCoreImagePixels(data) {
                return env
            }
            host.logOnce("env.exr.\(tag).unsupported",
                "\(tag): EXR equirect undecodable on this OS — "
                + "MTKTextureLoader and CIImage both failed")
            return nil
        }

        /// EXR via `MTKTextureLoader` → `getBytes` readback. Handles
        /// the float formats ImageIO's codec emits (rgba16Float,
        /// rgba32Float); an 8-bit delivery means the loader clamped
        /// HDR — converted anyway and warn-onced rather than silently
        /// flattened. `.topLeft` origin keeps row 0 = image top (the
        /// `EnvPixels` convention). Row pitch is w·component-count·
        /// component-size — Metal rows are tightly packed here.
        func exrMetalPixels(_ data: Data, device: MTLDevice, tag: String)
            -> EnvPixels?
        {
            guard let tex = try? MTKTextureLoader(device: device)
                .newTexture(data: data, options: [
                    .SRGB: NSNumber(value: false),
                    .generateMipmaps: NSNumber(value: false),
                    .origin: MTKTextureLoader.Origin.topLeft as NSString,
                ]),
                tex.textureType == .type2D,
                tex.storageMode != .private   // getBytes needs CPU access
            else { return nil }
            let w = tex.width, h = tex.height
            var floats = [Float](repeating: 0, count: w * h * 4)
            switch tex.pixelFormat {
            case .rgba16Float:
                // `Float16` is iOS 14+ and the pod targets 13 —
                // decode the halfs manually (halfToFloat below).
                var halfs = [UInt16](repeating: 0, count: w * h * 4)
                halfs.withUnsafeMutableBytes { buf in
                    tex.getBytes(buf.baseAddress!, bytesPerRow: w * 8,
                                 from: MTLRegionMake2D(0, 0, w, h),
                                 mipmapLevel: 0)
                }
                for i in 0..<w * h * 4 {
                    floats[i] = halfToFloat(halfs[i])
                }
            case .rgba32Float:
                floats.withUnsafeMutableBytes { buf in
                    tex.getBytes(buf.baseAddress!, bytesPerRow: w * 16,
                                 from: MTLRegionMake2D(0, 0, w, h),
                                 mipmapLevel: 0)
                }
            case .rgba8Unorm, .rgba8Unorm_srgb,
                 .bgra8Unorm, .bgra8Unorm_srgb:
                var bytes = [UInt8](repeating: 0, count: w * h * 4)
                bytes.withUnsafeMutableBytes { buf in
                    tex.getBytes(buf.baseAddress!, bytesPerRow: w * 4,
                                 from: MTLRegionMake2D(0, 0, w, h),
                                 mipmapLevel: 0)
                }
                let bgra = tex.pixelFormat == .bgra8Unorm
                    || tex.pixelFormat == .bgra8Unorm_srgb
                host.logOnce("env.exr.\(tag).ldr",
                    "\(tag): EXR decoded to \(tex.pixelFormat) — HDR "
                    + "range clamped by the loader (approximation)")
                for i in 0..<w * h {
                    let o = i * 4
                    floats[o]     = Float(bytes[o + (bgra ? 2 : 0)]) / 255
                    floats[o + 1] = Float(bytes[o + 1]) / 255
                    floats[o + 2] = Float(bytes[o + (bgra ? 0 : 2)]) / 255
                    floats[o + 3] = Float(bytes[o + 3]) / 255
                }
            default:
                host.logOnce("env.exr.\(tag).fmt.\(tex.pixelFormat.rawValue)",
                    "\(tag): EXR decoded to unhandled pixelFormat "
                    + "\(tex.pixelFormat)")
                return nil
            }
            return EnvPixels(width: w, height: h, isFloat: true,
                             data: floats.withUnsafeBufferPointer {
                                 Data(bytes: $0.baseAddress!,
                                      count: $0.count
                                        * MemoryLayout<Float>.size)
                             })
        }

        /// EXR via `CIImage` → `CIContext` RGBAf — the fallback when
        /// Metal can't produce a readable texture. Rendering into
        /// extended-linear-sRGB keeps values >1.0 (a clamped working
        /// space would flatten HDR). `render(toBitmap:)` writes
        /// top-down rows, matching the `EnvPixels` convention.
        func exrCoreImagePixels(_ data: Data) -> EnvPixels? {
            guard let ci = CIImage(data: data),
                  ci.extent.width > 0, ci.extent.height > 0,
                  let space = CGColorSpace(
                      name: CGColorSpace.extendedLinearSRGB)
            else { return nil }
            let w = Int(ci.extent.width.rounded())
            let h = Int(ci.extent.height.rounded())
            // The render bounds are rect-anchored — move a non-zero
            // extent origin to (0,0) so the whole image renders.
            let moved = ci.extent.origin == .zero ? ci :
                ci.transformed(by: CGAffineTransform(
                    translationX: -ci.extent.minX, y: -ci.extent.minY))
            var floats = [Float](repeating: 0, count: w * h * 4)
            floats.withUnsafeMutableBytes { buf in
                CIContext().render(
                    moved, toBitmap: buf.baseAddress!,
                    rowBytes: w * 4 * MemoryLayout<Float>.size,
                    bounds: CGRect(x: 0, y: 0, width: w, height: h),
                    format: .RGBAf, colorSpace: space)
            }
            return EnvPixels(width: w, height: h, isFloat: true,
                             data: floats.withUnsafeBufferPointer {
                                 Data(bytes: $0.baseAddress!,
                                      count: $0.count
                                        * MemoryLayout<Float>.size)
                             })
        }

        // MARK: Environment pixel transforms

        /// The object SceneKit binds as env contents: HDR sources go
        /// through `rgbaFloatCGImage`, LDR through `rgbaCGImage` — both
        /// equirect, both cube-converted internally by SceneKit.
        /// Sources below the floor size are bilinear-upscaled first so
        /// the radiance chain has enough mip levels.
        func envContents(_ env: EnvPixels) -> Any? {
            let env = upscaledForRadiance(env)
            if env.isFloat {
                return rgbaFloatCGImage(env.data, width: env.width,
                                        height: env.height)
            }
            return rgbaCGImage(env.data, width: env.width,
                               height: env.height, content: "color")
                .map { UIImage(cgImage: $0) }
        }

        /// Bilinear upsample to the smallest env size verified to pass
        /// SceneKit's radiance chain. Below it (observed at 4×2 and
        /// 8×4) SceneKit builds the radiance texture with one mip level
        /// fewer than the view range it then requests — Metal aborts.
        /// 256×128 matches the studio env's proven-good size; the
        /// upscale is a no-op for sources already at or above it.
        func upscaledForRadiance(_ env: EnvPixels) -> EnvPixels {
            let minW = 256, minH = 128
            guard env.width < minW || env.height < minH else {
                return env
            }
            let w = max(env.width, minW), h = max(env.height, minH)
            host.logOnce(
                "env.upscale",
                "environment \(env.width)x\(env.height) upscaled to "
                    + "\(w)x\(h): below the radiance mip floor")
            let scaleX = Double(env.width) / Double(w)
            let scaleY = Double(env.height) / Double(h)
            var out = Data(count: w * h * 4 * (env.isFloat ? 4 : 1))
            env.data.withUnsafeBytes { src in
                out.withUnsafeMutableBytes { dst in
                    if env.isFloat {
                        let s = src.bindMemory(to: Float.self)
                        let d = dst.bindMemory(to: Float.self)
                        for y in 0..<h {
                            for x in 0..<w {
                                // Bilinear taps at pixel centers.
                                let fx = (Double(x) + 0.5) * scaleX - 0.5
                                let fy = (Double(y) + 0.5) * scaleY - 0.5
                                let x0 = max(0, Int(fx.rounded(.down)))
                                let y0 = max(0, Int(fy.rounded(.down)))
                                let x1 = min(x0 + 1, env.width - 1)
                                let y1 = min(y0 + 1, env.height - 1)
                                let tx = Float(max(0, fx - Double(x0)))
                                let ty = Float(max(0, fy - Double(y0)))
                                let i00 = (y0 * env.width + x0) * 4
                                let i10 = (y0 * env.width + x1) * 4
                                let i01 = (y1 * env.width + x0) * 4
                                let i11 = (y1 * env.width + x1) * 4
                                for c in 0..<4 {
                                    let a = s[i00 + c]
                                        + (s[i10 + c] - s[i00 + c]) * tx
                                    let b = s[i01 + c]
                                        + (s[i11 + c] - s[i01 + c]) * tx
                                    d[(y * w + x) * 4 + c] =
                                        a + (b - a) * ty
                                }
                            }
                        }
                    } else {
                        let s = src.bindMemory(to: UInt8.self)
                        let d = dst.bindMemory(to: UInt8.self)
                        for y in 0..<h {
                            for x in 0..<w {
                                let fx = (Double(x) + 0.5) * scaleX - 0.5
                                let fy = (Double(y) + 0.5) * scaleY - 0.5
                                let x0 = max(0, Int(fx.rounded(.down)))
                                let y0 = max(0, Int(fy.rounded(.down)))
                                let x1 = min(x0 + 1, env.width - 1)
                                let y1 = min(y0 + 1, env.height - 1)
                                let tx = max(0, fx - Double(x0))
                                let ty = max(0, fy - Double(y0))
                                let i00 = (y0 * env.width + x0) * 4
                                let i10 = (y0 * env.width + x1) * 4
                                let i01 = (y1 * env.width + x0) * 4
                                let i11 = (y1 * env.width + x1) * 4
                                for c in 0..<4 {
                                    let a = Double(s[i00 + c])
                                        + (Double(s[i10 + c])
                                            - Double(s[i00 + c])) * tx
                                    let b = Double(s[i01 + c])
                                        + (Double(s[i11 + c])
                                            - Double(s[i01 + c])) * tx
                                    let v = (a + (b - a) * ty)
                                        .rounded()
                                    d[(y * w + x) * 4 + c] =
                                        UInt8(min(255, max(0, v)))
                                }
                            }
                        }
                    }
                }
            }
            return EnvPixels(width: w, height: h,
                             isFloat: env.isFloat, data: out)
        }

        /// Bakes the LH→RH z-mirror plus `environmentRotationY` — both
        /// exact column ops on an equirect. The mirror flips longitude
        /// (upstream LH dir (x,y,z) lands at RH (x,y,−z), negating the
        /// atan2 longitude), and upstream's `Matrix3.rotationY(θ)` env
        /// transform moves content toward +longitude by θ — so output
        /// column x reads source column `w−1−x−shift` with
        /// `shift = round(θ·w/2π)`.
        func mirroredRotated(_ env: EnvPixels, _ rotationY: Double)
            -> EnvPixels
        {
            let bpp = env.isFloat ? 16 : 4
            let w = env.width, h = env.height
            let shift = (rotationY / (2 * .pi) * Double(w)).rounded()
            let s = ((Int(shift) % w) + w) % w
            var out = Data(count: env.data.count)
            env.data.withUnsafeBytes { srcBuf in
                out.withUnsafeMutableBytes { dstBuf in
                    guard let sp = srcBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self),
                          let dp = dstBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self)
                    else { return }
                    for y in 0..<h {
                        for x in 0..<w {
                            let sx = ((w - 1 - x - s) % w + w) % w
                            let so = (y * w + sx) * bpp
                            let dOff = (y * w + x) * bpp
                            for k in 0..<bpp {
                                dp[dOff + k] = sp[so + k]
                            }
                        }
                    }
                }
            }
            return EnvPixels(width: w, height: h, isFloat: env.isFloat,
                             data: out)
        }

        /// [env] as linear float pixels times [k] — what a sky is
        /// drawn from. SceneKit stores an 8-bit image in 8 *linear*
        /// bits, one step being 1/255 of white, so a dark sky came
        /// out in two or three levels per channel: sRGB (36, 39, 41)
        /// drew as (34, 38, 43). A float image keeps its values; it is
        /// still clamped at 1.
        func linearPixels(_ env: EnvPixels, scale k: Double) -> EnvPixels {
            let count = env.width * env.height * 4
            var out = [Float](repeating: 1, count: count)
            env.data.withUnsafeBytes { src in
                if env.isFloat {
                    let sp = src.bindMemory(to: Float.self)
                    let kf = Float(k)
                    for i in stride(from: 0, to: count, by: 4) {
                        out[i] = sp[i] * kf
                        out[i + 1] = sp[i + 1] * kf
                        out[i + 2] = sp[i + 2] * kf
                    }
                } else {
                    let table = (0..<256).map {
                        Float(srgbToLinear(Double($0) / 255.0) * k)
                    }
                    let sp = src.bindMemory(to: UInt8.self)
                    for i in stride(from: 0, to: count, by: 4) {
                        out[i] = table[Int(sp[i])]
                        out[i + 1] = table[Int(sp[i + 1])]
                        out[i + 2] = table[Int(sp[i + 2])]
                    }
                }
            }
            return EnvPixels(
                width: env.width, height: env.height, isFloat: true,
                data: out.withUnsafeBufferPointer { Data(buffer: $0) })
        }

        /// [env] with its values inside 0…1, and what they were
        /// divided by to get there (1 for an 8-bit source). The
        /// divisor stops at 256: past that the rest of a float image
        /// would fall below what a half float holds, and only the
        /// very brightest texels clip instead.
        func unitRange(_ env: EnvPixels)
            -> (pixels: EnvPixels, divisor: Double)
        {
            guard env.isFloat else { return (env, 1) }
            var peak: Float = 0
            env.data.withUnsafeBytes { src in
                let sp = src.bindMemory(to: Float.self)
                for i in stride(from: 0, to: env.width * env.height * 4,
                                by: 4) {
                    let m = max(sp[i], max(sp[i + 1], sp[i + 2]))
                    if m.isFinite, m > peak { peak = m }
                }
            }
            guard peak > 1 else { return (env, 1) }
            let divisor = Double(min(peak, 256))
            return (linearPixels(env, scale: 1 / divisor), divisor)
        }

        /// Cheap separable box blur for `skybox.blurriness` — longitude
        /// wraps, latitude clamps (equirect-aware edges). Runs in
        /// storage space (sRGB for LDR): approximate by design, and the
        /// caller warn-onces that.
        func boxBlurredPixels(_ env: EnvPixels, radius r: Int)
            -> EnvPixels
        {
            guard r > 0 else { return env }
            let w = env.width, h = env.height
            let count = 2 * r + 1
            if env.isFloat {
                var px = env.data.withUnsafeBytes {
                    [Float]($0.bindMemory(to: Float.self))
                }
                var tmp = [Float](repeating: 0, count: w * h * 4)
                let f = 1.0 / Float(count)
                for y in 0..<h {
                    for x in 0..<w {
                        var acc: (Float, Float, Float, Float) = (0, 0, 0, 0)
                        for k in -r...r {
                            let sx = ((x + k) % w + w) % w
                            let o = (y * w + sx) * 4
                            acc.0 += px[o]; acc.1 += px[o + 1]
                            acc.2 += px[o + 2]; acc.3 += px[o + 3]
                        }
                        let o = (y * w + x) * 4
                        tmp[o] = acc.0 * f; tmp[o + 1] = acc.1 * f
                        tmp[o + 2] = acc.2 * f; tmp[o + 3] = acc.3 * f
                    }
                }
                for y in 0..<h {
                    for x in 0..<w {
                        var acc: (Float, Float, Float, Float) = (0, 0, 0, 0)
                        for k in -r...r {
                            let sy = min(max(y + k, 0), h - 1)
                            let o = (sy * w + x) * 4
                            acc.0 += tmp[o]; acc.1 += tmp[o + 1]
                            acc.2 += tmp[o + 2]; acc.3 += tmp[o + 3]
                        }
                        let o = (y * w + x) * 4
                        px[o] = acc.0 * f; px[o + 1] = acc.1 * f
                        px[o + 2] = acc.2 * f; px[o + 3] = acc.3 * f
                    }
                }
                return EnvPixels(width: w, height: h, isFloat: true,
                                 data: px.withUnsafeBufferPointer {
                                     Data(bytes: $0.baseAddress!,
                                          count: $0.count
                                            * MemoryLayout<Float>.size)
                                 })
            }
            var px = env.data
            var tmp = Data(count: px.count)
            px.withUnsafeMutableBytes { srcBuf in
                tmp.withUnsafeMutableBytes { tmpBuf in
                    guard let sp = srcBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self),
                          let tp = tmpBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self)
                    else { return }
                    for y in 0..<h {
                        for x in 0..<w {
                            var acc: (Int, Int, Int, Int) = (0, 0, 0, 0)
                            for k in -r...r {
                                let sx = ((x + k) % w + w) % w
                                let o = (y * w + sx) * 4
                                acc.0 += Int(sp[o])
                                acc.1 += Int(sp[o + 1])
                                acc.2 += Int(sp[o + 2])
                                acc.3 += Int(sp[o + 3])
                            }
                            let o = (y * w + x) * 4
                            tp[o] = UInt8(acc.0 / count)
                            tp[o + 1] = UInt8(acc.1 / count)
                            tp[o + 2] = UInt8(acc.2 / count)
                            tp[o + 3] = UInt8(acc.3 / count)
                        }
                    }
                }
            }
            tmp.withUnsafeBytes { tmpBuf in
                px.withUnsafeMutableBytes { dstBuf in
                    guard let tp = tmpBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self),
                          let dp = dstBuf.baseAddress?
                        .assumingMemoryBound(to: UInt8.self)
                    else { return }
                    for y in 0..<h {
                        for x in 0..<w {
                            var acc: (Int, Int, Int, Int) = (0, 0, 0, 0)
                            for k in -r...r {
                                let sy = min(max(y + k, 0), h - 1)
                                let o = (sy * w + x) * 4
                                acc.0 += Int(tp[o])
                                acc.1 += Int(tp[o + 1])
                                acc.2 += Int(tp[o + 2])
                                acc.3 += Int(tp[o + 3])
                            }
                            let o = (y * w + x) * 4
                            dp[o] = UInt8(acc.0 / count)
                            dp[o + 1] = UInt8(acc.1 / count)
                            dp[o + 2] = UInt8(acc.2 / count)
                            dp[o + 3] = UInt8(acc.3 / count)
                        }
                    }
                }
            }
            return EnvPixels(width: w, height: h, isFloat: false,
                             data: px)
        }

        /// Untagged JSON number — the env "look" fields serialize raw,
        /// unlike the `{'d': …}` tagged property values.
        func plainDouble(_ v: Any?) -> Double? {
            (v as? NSNumber)?.doubleValue
        }

        func smoothstep01(_ x: Double) -> Double {
            let t = min(max(x, 0.0), 1.0)
            return t * t * (3.0 - 2.0 * t)
        }

        func lerp(_ a: Double, _ b: Double, _ t: Double) -> Double {
            a + (b - a) * t
        }

        /// Upstream `_encodeSrgb` — linear → sRGB-encoded byte.
        func encodeSrgb(_ linear: Double) -> UInt8 {
            let c = min(max(linear, 0.0), 1.0)
            let e = c <= 0.0031308
                ? c * 12.92
                : 1.055 * pow(c, 1.0 / 2.4) - 0.055
            return UInt8(min(max(Int((e * 255.0).rounded()), 0), 255))
        }

        /// Upstream `_srgbToLinear` — sRGB byte → linear.
        func srgbToLinear(_ c: Double) -> Double {
            c <= 0.04045 ? c / 12.92
                : pow((c + 0.055) / 1.055, 2.4)
        }

        /// IEEE-754 half → float32. Hand-rolled because `Float16`
        /// needs iOS 14 and the pod targets 13. Sign, 5-bit exponent
        /// (bias 15), 10-bit mantissa; subnormals scale by 2⁻²⁴,
        /// exp=31 maps to inf/NaN.
        func halfToFloat(_ h: UInt16) -> Float {
            let sign: Float = (h & 0x8000) != 0 ? -1 : 1
            let exp = Int((h >> 10) & 0x1F)
            let mant = Int(h & 0x3FF)
            if exp == 0 { return sign * Float(mant) * powf(2, -24) }
            if exp == 31 {
                return mant != 0 ? .nan : sign * .infinity
            }
            return sign * (1 + Float(mant) / 1024)
                * powf(2, Float(exp - 15))
        }

        // MARK: Tagged property values

        /// All d3* readers accept the bare (untagged) JSON upstream's
        /// `_encodeProcedural` emits — raw bools/numbers/strings,
        /// `[[x,y,z],…]` lists, plain maps — alongside our tagged
        /// `{'b':…}`-style envelopes. Tagged wins when both parse.
        func d3Bool(_ v: Any?) -> Bool? {
            (v as? [String: Any])?["b"] as? Bool ?? (v as? Bool)
        }

        func d3Double(_ v: Any?) -> Double? {
            ((v as? [String: Any])?["d"] ?? (v as? [String: Any])?["i"]) as? Double
                ?? (((v as? [String: Any])?["d"] ?? (v as? [String: Any])?["i"]) as? Int)
                    .map(Double.init)
                ?? (v as? Double) ?? (v as? Int).map(Double.init)
        }

        /// `{'v3': [x,y,z]}` — bare `[x,y,z]` fallback: procedural spec
        /// fields (e.g. cuboid `extents`) serialize untagged upstream.
        func d3Vec3(_ v: Any?) -> [Double]? {
            if let tagged = (v as? [String: Any])?["v3"] as? [Double] {
                return tagged
            }
            return v as? [Double]
        }

        func d3Vec4(_ v: Any?) -> [Double]? {
            if let tagged = (v as? [String: Any])?["v4"] as? [Double] {
                return tagged
            }
            return v as? [Double]
        }

        /// `{'q': [x,y,z,w]}` — quaternion (basis fields).
        func d3Quat(_ v: Any?) -> [Double]? {
            if let tagged = (v as? [String: Any])?["q"] as? [Double],
               tagged.count == 4 {
                return tagged
            }
            return v as? [Double]
        }

        func d3String(_ v: Any?) -> String? {
            (v as? [String: Any])?["s"] as? String ?? (v as? String)
        }

        func d3Int(_ v: Any?) -> Int? {
            let raw = (v as? [String: Any])?["i"]
                ?? (v as? [String: Any])?["d"]
            if let i = raw as? Int { return i }
            if let d = raw as? Double { return Int(d) }
            return (v as? Int) ?? (v as? Double).map(Int.init)
        }

        /// `{'v2': [x,y]}` — with a bare `[x,y]` fallback so a raw
        /// (untagged) transform map decodes the same way.
        func d3Vec2(_ v: Any?) -> [Double]? {
            if let tagged = (v as? [String: Any])?["v2"] as? [Double] {
                return tagged
            }
            return v as? [Double]
        }

        /// Raw [r,g,b,a] for a `{'c': …}` color — the bake path needs
        /// the components, not a UIColor.
        func d3ColorComponents(_ v: Any?) -> [Double]? {
            if let c = (v as? [String: Any])?["c"] as? [Double],
               c.count == 4 { return c }
            guard let c = v as? [Double], c.count == 4 else { return nil }
            return c
        }

        func d3Color(_ v: Any?) -> UIColor? {
            guard let c = d3ColorComponents(v) else { return nil }
            return Self.linearColor(c[0], c[1], c[2], c[3])
        }

        /// A wire colour as SceneKit should read it. Wire colours are
        /// linear RGB (upstream's `ColorValue`); `UIColor(red:…)` would
        /// tag the same numbers as sRGB-encoded and SceneKit would
        /// decode them a second time, so a 0.18 grey rendered as 0.027.
        static func linearColor(_ r: Double, _ g: Double, _ b: Double,
                                _ a: Double) -> UIColor {
            guard let space = CGColorSpace(
                      name: CGColorSpace.extendedLinearSRGB),
                  let color = CGColor(
                      colorSpace: space,
                      components: [CGFloat(r), CGFloat(g), CGFloat(b),
                                   CGFloat(a)])
            else { return UIColor(red: r, green: g, blue: b, alpha: a) }
            return UIColor(cgColor: color)
        }

        func d3Ref(_ v: Any?) -> UInt64? {
            guard let token = (v as? [String: Any])?["rref"] as? String
                    ?? (v as? [String: Any])?["nref"] as? String
            else { return nil }
            return D3Wire.localIdKey(token)
        }

        func d3List(_ v: Any?) -> [Any]? {
            (v as? [String: Any])?["list"] as? [Any] ?? (v as? [Any])
        }

        /// Single-key tag envelopes — a bare map that happens to hold
        /// only e.g. {"d": 5} is a scalar envelope, not a map.
        private static let envelopeKeys: Set<String> = [
            "b", "d", "i", "v2", "v3", "v4", "q", "c", "s", "m4",
            "list", "map", "rref", "nref",
        ]

        func d3Map(_ v: Any?) -> [String: Any]? {
            guard let d = v as? [String: Any] else { return nil }
            if let m = d["map"] as? [String: Any] { return m }
            if d.count == 1, let k = d.keys.first,
               Context.envelopeKeys.contains(k) { return nil }
            return d
        }

        /// Column-major 16-element `Matrix4` storage, converted LH→RH.
        func d3Mat4(_ v: Any?) -> SCNMatrix4? {
            let m = (v as? [String: Any])?["m4"] as? [Double]
                ?? v as? [Double]
            guard let m, m.count == 16 else { return nil }
            return D3Wire.matrix(m)
        }
    }
}

extension FsceneRealizer {
    static func screenDebugMaterialSignature(_ material: SCNMaterial) -> NSArray {
        var values: [Any] = [material.lightingModel.rawValue, material.name ?? "",
            material.shaderModifiers ?? [:], material.blendMode.rawValue,
            material.transparencyMode.rawValue, material.transparency,
            material.isDoubleSided, material.cullMode.rawValue,
            material.readsFromDepthBuffer, material.writesToDepthBuffer,
            material.colorBufferWriteMask.rawValue, material.fillMode.rawValue]
        var properties = [material.diffuse, material.metalness, material.roughness,
                         material.normal, material.transparent, material.emission,
                         material.ambientOcclusion, material.clearCoat,
                         material.clearCoatRoughness, material.clearCoatNormal,
                         material.multiply, material.reflective, material.specular]
        for key in ["d3BaseColorFactor", "d3SheenColorTex", "d3SheenRoughTex",
                    "d3SpriteTint", "d3SpriteSourcePremultiplied", "d3CatcherRegion"] {
            let value = material.value(forKey: key)
            if let property = value as? SCNMaterialProperty { properties.append(property) }
            else { values.append(value ?? NSNull()) }
        }
        for property in properties {
            values.append(contentsOf: [property.contents ?? NSNull(),
                property.intensity, NSValue(scnMatrix4: property.contentsTransform),
                property.mappingChannel, property.wrapS.rawValue,
                property.wrapT.rawValue, property.minificationFilter.rawValue,
                property.magnificationFilter.rawValue, property.mipFilter.rawValue,
                property.maxAnisotropy, property.textureComponents.rawValue])
        }
        return values as NSArray
    }

    static func makeScreenDebugMaterial(_ source: SCNMaterial,
        channel: ScreenDebugOptions.Channel, host: SceneViewHost) -> SCNMaterial {
        let material = source.copy() as! SCNMaterial
        let sprite = source.name == "d3.sprite"
        let bakedCatcher = source.lightingModel == .constant
            && source.name?.hasPrefix("d3.shadowCatcher:") == true
        let unlit = !bakedCatcher && source.lightingModel == .constant
            && source.value(forKey: "d3BaseColorFactor") != nil
        let pbr = source.lightingModel == .physicallyBased
        guard pbr || unlit || sprite || bakedCatcher else {
            host.logOnce("debugView.family.\(source.lightingModel.rawValue)",
                "debugView: this implementation unit covers PBR, unlit meshes, sprites and baked catchers; "
                + "material family \(source.lightingModel.rawValue) is unsupported")
            return material
        }
        for key in ["d3BaseColorFactor", "d3SheenColorTex", "d3SheenRoughTex",
                    "d3SpriteTint", "d3SpriteSourcePremultiplied", "d3CatcherRegion"] {
            if let value = source.value(forKey: key) {
                if let current = value as? SCNMaterialProperty {
                    let property = SCNMaterialProperty()
                    property.contents = current.contents
                    property.contentsTransform = current.contentsTransform
                    property.mappingChannel = current.mappingChannel
                    property.intensity = current.intensity
                    property.wrapS = current.wrapS
                    property.wrapT = current.wrapT
                    property.minificationFilter = current.minificationFilter
                    property.magnificationFilter = current.magnificationFilter
                    property.mipFilter = current.mipFilter
                    property.maxAnisotropy = current.maxAnisotropy
                    property.textureComponents = current.textureComponents
                    material.setValue(property, forKey: key)
                } else { material.setValue(value, forKey: key) }
            }
        }
        let rgb: String
        switch channel {
        case .none: return material
        case .normals:
            if !pbr { material.normal.contents = UIColor.white }
            rgb = "0.5 * normalize(_surface.normal) + 0.5"
        case .metallic:
            rgb = pbr ? "float3(saturate(_surface.metalness))" : "float3(1.0, 0.0, 1.0)"
        case .roughness:
            rgb = pbr ? "float3(saturate(_surface.roughness))" : "float3(1.0, 0.0, 1.0)"
        case .baseColor:
            if bakedCatcher {
                rgb = "float3(1.0, 0.0, 1.0)"
            } else if sprite {
                rgb = """
                    saturate(d3SpriteSourcePremultiplied > 0.5
                        ? (_surface.diffuse.a > 0.0
                            ? d3SampledSpriteColor.rgb / _surface.diffuse.a : float3(0.0))
                        : d3SampledSpriteColor.rgb)
                    """
            } else { rgb = "saturate(_surface.diffuse.rgb)" }
        case .depth:
            rgb = "float3(max(-_surface.position.z, 0.0) / (1.0 + max(-_surface.position.z, 0.0)))"
        }
        // Existing MASK discard and sheen declarations/body remain before the
        // final RGB. Transparent modifiers expect premultiplied RGB once.
        let coverage = bakedCatcher || sprite || (source.blendMode == .alpha && !source.writesToDepthBuffer)
            ? " * _output.color.a" : ""
        var modifiers = source.shaderModifiers ?? [:]
        if bakedCatcher {
            modifiers[.fragment] = "#pragma transparent\n#pragma body\n"
                + (modifiers[.fragment] ?? "")
        }
        if unlit {
            modifiers[.geometry] = """
                #pragma varyings
                float4 d3DebugUnlitColor;
                #pragma body
                out.d3DebugUnlitColor = _geometry.color;
                _geometry.color = float4(1.0);
                """
            modifiers[.surface] = (modifiers[.surface] ?? "")
                + "\n_surface.diffuse *= in.d3DebugUnlitColor;\n"
        }
        modifiers[.fragment] = (modifiers[.fragment] ?? "")
            + "\n_output.color.rgb = (\(rgb))\(coverage);\n"
        material.shaderModifiers = modifiers
        return material
    }
}
